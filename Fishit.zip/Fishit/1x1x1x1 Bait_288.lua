-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 32,
		["Type"] = "Baits",
		["Name"] = "1x1x1x1 Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://87040459042143",
		["Tier"] = 4
	},
	["Hidden"] = true,
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1