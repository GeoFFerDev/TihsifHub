-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 403,
		["Type"] = "Fishing Rods",
		["Name"] = "1x1x1x1 Ban Hammer",
		["Description"] = "",
		["Icon"] = "rbxassetid://86403842628116",
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0, 1.7, 0.7),
	["OverrideROT"] = CFrame.fromOrientation(0, 3.141592653589793, -0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(0, -1.1, 0)) * CFrame.fromOrientation(0, 1.5707963267948966, -1.5707963267948966),
	["GripC1"] = CFrame.identity,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1