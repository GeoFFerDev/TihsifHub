-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 448,
		["Type"] = "Fish",
		["Name"] = "1x1x1x1 Comet Shark",
		["Description"] = "",
		["Icon"] = "rbxassetid://98046606623336",
		["Tier"] = 7
	},
	["SellPrice"] = 444444,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(352000, 455000),
		["Default"] = NumberRange.new(262700, 344000)
	},
	["Probability"] = {
		["Chance"] = 2.5e-7
	},
	["Events"] = { "Admin - 1x1x1x1 Rage" },
	["_moduleScript"] = script
}
return v1