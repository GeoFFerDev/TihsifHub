-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 40,
	["ForcedClockTime"] = 0,
	["GeographicLatitude"] = 315,
	["Music"] = {
		["SoundId"] = "rbxassetid://94386390512184",
		["Volume"] = 0.2
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(92, 86, 124),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(66, 188, 95)
	},
	["Atmosphere"] = {
		["Density"] = 0.288,
		["Glare"] = 0.99,
		["Haze"] = 1.89,
		["Color"] = Color3.fromRGB(17, 166, 52),
		["Decay"] = Color3.fromRGB(25, 166, 25)
	},
	["Clouds"] = {
		["Enabled"] = false
	},
	["Sky"] = script.Sky,
	["WaterColor"] = Color3.fromRGB(117, 91, 129),
	["WaitForSignal"] = true,
	["SignalName"] = "1x1x1x1Rage"
}
return v1