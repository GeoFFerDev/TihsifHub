-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 445,
		["Type"] = "Fish",
		["Name"] = "1x1x1x1 Shark",
		["Description"] = "",
		["Icon"] = "rbxassetid://126602140465429",
		["Tier"] = 7
	},
	["SellPrice"] = 150000,
	["Variants"] = { "Color Burn" },
	["Weight"] = {
		["Big"] = NumberRange.new(176575, 211890),
		["Default"] = NumberRange.new(104482, 135827)
	},
	["Probability"] = {
		["Chance"] = 4e-7
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1