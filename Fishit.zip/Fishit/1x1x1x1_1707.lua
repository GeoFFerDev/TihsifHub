-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = require(v4.Packages.Trove)
local v_u_6 = require(script.EmitAt)
local v_u_7 = require(script.FOVTable)
local v_u_8 = require(v4.Shared.Soundbook)
local v_u_9 = require(v4.Modules.GuiControl)
local function v_u_15(p10)
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v11 = p10 or false
	local v_u_12 = v_u_1.LocalPlayer
	if v_u_12 then
		v_u_12 = v_u_1.LocalPlayer:FindFirstChild("PlayerGui")
	end
	if v_u_12 then
		v_u_12 = v_u_12:FindFirstChild("Blackout")
	end
	if v_u_12 then
		v_u_12.Label.Visible = false
		v_u_12.Blackout.BackgroundTransparency = 1
		v_u_12.Blackout.BackgroundColor3 = v11 and Color3.new(1, 1, 1) or Color3.new(0, 0, 0)
		local v13 = v_u_3:Create(v_u_12.Blackout, TweenInfo.new(0.3), {
			["BackgroundTransparency"] = 0
		})
		local v14 = v_u_3:Create(v_u_12.Blackout, TweenInfo.new(0.3), {
			["BackgroundTransparency"] = 1
		})
		v14.Completed:Once(function()
			-- upvalues: (copy) v_u_12
			v_u_12.Enabled = false
			v_u_12.Label.Visible = true
			v_u_12.Blackout.BackgroundTransparency = 0
			v_u_12.Blackout.BackgroundColor3 = Color3.new(0, 0, 0)
		end)
		v_u_12.Enabled = true
		v13:Play()
		v13.Completed:Wait()
		task.wait(0.3)
		v14:Play()
	end
end
local v_u_16 = {}
v_u_16.__index = v_u_16
function v_u_16.new(_, _)
	-- upvalues: (copy) v_u_16, (copy) v_u_5, (copy) v_u_1
	local v17 = v_u_16
	local v18 = setmetatable({}, v17)
	v18.Cleaner = v_u_5.new()
	v18.Destroyed = false
	v18.Finished = false
	v18.Camera = nil
	local v19 = {}
	local v20 = {}
	for _, v21 in script.Rigs:GetChildren() do
		local v22 = v21:Clone()
		local v23 = script.Animations:FindFirstChild(v22.Name)
		local v24 = v22:FindFirstChildWhichIsA("Animator", true)
		if v24 then
			v22.Parent = workspace
			local v25 = v24:LoadAnimation(v23)
			v25.Priority = Enum.AnimationPriority.Action4
			v25.Looped = false
			table.insert(v19, v25)
		end
		if v22.Name == "Cam" then
			v18.Camera = v22
		elseif v22.Name == "Character" then
			local v26 = v_u_1.LocalPlayer
			local v27 = v26.Character
			if v27 then
				v27 = v27.Humanoid:GetAppliedDescription()
			end
			if v27 then
				v22.Humanoid:ApplyDescription(v27)
			end
			v26:RequestStreamAroundAsync(v22:GetPivot().Position, 30)
		end
		v18.Cleaner:Add(v22)
		table.insert(v20, v22)
	end
	v18.Rigs = v20
	v18.Tracks = v19
	return v18
end
function v_u_16.Play(p_u_28, _, _)
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (copy) v_u_8, (copy) v_u_15, (copy) v_u_2, (copy) v_u_7, (copy) v_u_6
	local v_u_29 = workspace.CurrentCamera
	local v_u_30 = v_u_29.FieldOfView
	p_u_28.PreviousFrame = 0
	p_u_28.Started = time()
	for _, v31 in p_u_28.Tracks do
		v31:Play()
	end
	v_u_29.CameraType = Enum.CameraType.Scriptable
	v_u_29.CFrame = p_u_28.Camera.CamPart.CFrame
	local v_u_32 = v_u_9:HideAllHUD({ "Blackout" })
	p_u_28.Cleaner:Add(function()
		-- upvalues: (copy) v_u_29, (copy) v_u_30, (ref) v_u_9, (copy) v_u_32, (ref) v_u_1
		v_u_29.FieldOfView = v_u_30
		v_u_29.CameraType = Enum.CameraType.Custom
		v_u_9:RestoreHUD(v_u_32)
		workspace:SetAttribute("1x1x1x1Rage", true)
		v_u_1.LocalPlayer:SetAttribute("InCutscene", false)
	end)
	p_u_28.Cleaner:Add(v_u_29:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		-- upvalues: (copy) v_u_29, (copy) p_u_28
		v_u_29.CameraType = Enum.CameraType.Scriptable
		v_u_29.CFrame = p_u_28.Camera.CamPart.CFrame
	end))
	v_u_8.Sounds["1x1x1x1 Cutscene"]:Play()
	task.wait(0.1)
	task.defer(v_u_15)
	local v_u_33 = false
	local v_u_34 = nil
	v_u_1.LocalPlayer:SetAttribute("InCutscene", true)
	v_u_34 = v_u_2.RenderStepped:Connect(function(_)
		-- upvalues: (copy) p_u_28, (ref) v_u_34, (copy) v_u_29, (ref) v_u_7, (ref) v_u_6, (ref) v_u_33, (ref) v_u_15
		local v35 = (time() - p_u_28.Started) * 60
		local v36 = math.ceil(v35) + 1
		if v36 == p_u_28.PreviousFrame then
			return
		elseif workspace:IsAncestorOf(p_u_28.Camera) and workspace:IsAncestorOf(p_u_28.Camera.CamPart) then
			v_u_29.CFrame = p_u_28.Camera.CamPart.CFrame
			if v_u_7[tostring(v36)] then
				v_u_29.FieldOfView = v_u_7[tostring(v36)]
			end
			if v_u_6[v36] then
				task.defer(v_u_6[v36])
			end
			if not v_u_33 and v36 >= 1701 then
				v_u_33 = true
				task.defer(v_u_15, true)
			end
			if v36 >= 1746 then
				p_u_28.Finished = true
				v_u_34:Disconnect()
				p_u_28.Cleaner:Clean()
			else
				p_u_28.PreviousFrame = v36
			end
		else
			p_u_28.Finished = true
			v_u_34:Disconnect()
			p_u_28.Cleaner:Clean()
			return
		end
	end)
end
function v_u_16.IsFinished(p37)
	return p37.Finished
end
function v_u_16.Destroy(p38)
	if not p38.Destroyed then
		p38.Destroyed = true
		p38.Cleaner:Destroy()
	end
end
return v_u_16