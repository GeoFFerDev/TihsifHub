-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 19,
		["Type"] = "Variant",
		["Name"] = "1x1x1x1",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(43, 189, 65)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(11, 33, 7)), ColorSequenceKeypoint.new(1, Color3.fromRGB(111, 15, 16)) })
	},
	["Versions"] = 1,
	["Colors"] = 4,
	["SellMultiplier"] = 2.6,
	["Probability"] = {
		["Chance"] = 2.5
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1