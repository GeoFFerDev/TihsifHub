-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 11,
		["Type"] = "Trophies",
		["Name"] = "2024 Gold Fishing Plaque",
		["Description"] = "Top placement on the Xmas leaderboard!",
		["Icon"] = "rbxassetid://78534342221694",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1