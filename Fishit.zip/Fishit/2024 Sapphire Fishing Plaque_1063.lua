-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 12,
		["Type"] = "Trophies",
		["Name"] = "2024 Sapphire Fishing Plaque",
		["Description"] = "Awarded to top fishers!",
		["Icon"] = "rbxassetid://118204072681371",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1