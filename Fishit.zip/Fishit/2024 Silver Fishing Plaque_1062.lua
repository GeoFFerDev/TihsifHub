-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 13,
		["Type"] = "Trophies",
		["Name"] = "2024 Silver Fishing Plaque",
		["Description"] = "Awarded to top fishers!",
		["Icon"] = "rbxassetid://120308546229609",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1