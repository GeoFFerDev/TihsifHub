-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 118,
		["Type"] = "Trophies",
		["Name"] = "2024 Wood Fishing Plaque",
		["Description"] = "Awarded to top fishers!",
		["Icon"] = "rbxassetid://123128787503074",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1