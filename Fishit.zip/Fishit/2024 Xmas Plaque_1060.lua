-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 104,
		["Type"] = "Trophies",
		["Name"] = "2024 Xmas Plaque",
		["Description"] = "You beat the 2024 Xmas event \240\159\146\155",
		["Icon"] = "rbxassetid://139475070609098",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1