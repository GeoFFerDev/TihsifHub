-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 40,
	["Music"] = {
		["SoundId"] = "rbxassetid://99225941170851",
		["Volume"] = 0.08
	}
}
return v1