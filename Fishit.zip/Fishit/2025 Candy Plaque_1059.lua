-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 332,
		["Type"] = "Trophies",
		["Name"] = "2025 Candy Plaque",
		["Description"] = "You beat the Halloween event pass \240\159\142\131",
		["Icon"] = "rbxassetid://137834147336272",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1