-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 291,
		["Type"] = "Trophies",
		["Name"] = "2025 Jungle Plaque",
		["Description"] = "You beat the Jungle event pass \240\159\144\141 ",
		["Icon"] = "rbxassetid://74106881060205",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1