-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 588,
		["Type"] = "Trophies",
		["Name"] = "2025 Pirate Plaque",
		["Description"] = "You beat the Pirate event pass \226\152\160\239\184\143",
		["Icon"] = "rbxassetid://114810497530097",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1