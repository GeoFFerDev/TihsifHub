-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 447,
		["Type"] = "Trophies",
		["Name"] = "2025 Retro Plaque",
		["Description"] = "You beat the Classic event pass \240\159\149\185\239\184\143",
		["Icon"] = "rbxassetid://100341068702922",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1