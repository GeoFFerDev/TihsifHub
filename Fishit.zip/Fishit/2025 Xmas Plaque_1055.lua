-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 556,
		["Type"] = "Trophies",
		["Name"] = "2025 Xmas Plaque",
		["Description"] = "You beat the Xmas event pass \240\159\142\132",
		["Icon"] = "rbxassetid://124732395752283",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1