-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 754,
		["Type"] = "Trophies",
		["Name"] = "2026 Valentines Plaque",
		["Description"] = "You beat the Valentines event pass \226\157\164\239\184\143",
		["Icon"] = "rbxassetid://89211854872793",
		["Tier"] = 90
	},
	["_moduleScript"] = script
}
return v1