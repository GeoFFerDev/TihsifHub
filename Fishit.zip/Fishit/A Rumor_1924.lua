-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Phil & Bill will tell you about the rumors they\'ve heard in exchange for some fish!",
	["AssociatedTier"] = 0
}
local v4 = {}
local v5 = {
	["Id"] = 1,
	["Name"] = "Catch fish in the new Laboratory area at Kohana",
	["Goal"] = 10,
	["Type"] = "Catch",
	["Requirements"] = {
		["Location"] = "Kohana Lab"
	}
}
local v6 = {
	["Id"] = 2,
	["Name"] = "Speak with Bill to hear the rumor",
	["Goal"] = 1,
	["Type"] = "SpeakWithNPC",
	["Requirements"] = {
		["NPC"] = "Bill",
		["Path"] = 2,
		["Index"] = 1
	}
}
__set_list(v4, 1, {v5, v6})
v3.Objectives = v4
v3.Ordered = true
v3.Reward = v2.currencyReward("Coins", 5000)
return v3