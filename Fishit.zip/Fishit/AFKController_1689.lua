-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("UserInputService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players").LocalPlayer
local v4 = require(v2.Packages.Net)
local v5 = require(v2.Packages.Signal)
local v_u_6 = require(v2.Shared.PlayerEvents)
local v_u_7 = v4:RemoteEvent("ReconnectPlayer")
local v_u_8 = 0
local v_u_9 = v5.new()
local v_u_13 = {
	["SetTime"] = function(_, p10)
		-- upvalues: (ref) v_u_8, (copy) v_u_9
		v_u_8 = p10
		v_u_9:Fire()
	end,
	["RemoveTime"] = function(_, _)
		-- upvalues: (ref) v_u_8, (copy) v_u_9
		if v_u_8 ~= 0 then
			v_u_8 = 0
			v_u_9:Fire()
		end
	end,
	["Start"] = function(_)
		-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_6, (copy) v_u_3, (copy) v_u_9, (ref) v_u_8, (copy) v_u_7
		v_u_1.InputBegan:Connect(function()
			-- upvalues: (ref) v_u_13
			v_u_13:RemoveTime("Input")
		end)
		v_u_1.WindowFocused:Connect(function()
			-- upvalues: (ref) v_u_13
			v_u_13:RemoveTime("Focused")
		end)
		v_u_6:PlayerRemoving(function(p11)
			-- upvalues: (ref) v_u_3, (ref) v_u_13
			if p11 == v_u_3 then
				v_u_13:RemoveTime("Left")
			end
		end)
		v_u_3.Idled:Connect(function(p12)
			-- upvalues: (ref) v_u_13
			v_u_13:SetTime(p12)
		end)
		v_u_9:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_7
			if v_u_8 >= 900 then
				v_u_7:FireServer()
			end
		end)
	end
}
return v_u_13