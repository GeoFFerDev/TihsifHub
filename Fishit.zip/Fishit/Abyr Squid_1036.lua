-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 638,
		["Type"] = "Fish",
		["Name"] = "Abyr Squid",
		["Description"] = "",
		["Icon"] = "rbxassetid://119969620866795",
		["Tier"] = 7
	},
	["SellPrice"] = 135000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(49500, 63800),
		["Default"] = NumberRange.new(36700, 45200)
	},
	["Probability"] = {
		["Chance"] = 5e-6
	},
	["_moduleScript"] = script
}
return v1