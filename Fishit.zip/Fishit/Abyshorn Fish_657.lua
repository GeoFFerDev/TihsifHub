-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 280,
		["Type"] = "Fish",
		["Name"] = "Abyshorn Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://79899223576801",
		["Tier"] = 2
	},
	["SellPrice"] = 63,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(16, 21),
		["Default"] = NumberRange.new(7, 12)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1