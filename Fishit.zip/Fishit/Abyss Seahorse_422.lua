-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 15,
		["Type"] = "Fish",
		["Name"] = "Abyss Seahorse",
		["Description"] = "",
		["Icon"] = "rbxassetid://140212951494890",
		["Tier"] = 5
	},
	["SellPrice"] = 38500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1, 1.3),
		["Default"] = NumberRange.new(0.7, 0.8)
	},
	["Probability"] = {
		["Chance"] = 0.000011764705882352942
	},
	["_moduleScript"] = script
}
return v1