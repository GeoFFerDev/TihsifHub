-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 167,
		["Type"] = "Fishing Rods",
		["Name"] = "Abyssal Chroma",
		["Description"] = "",
		["Icon"] = "rbxassetid://124678532461341",
		["Tier"] = 100
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1