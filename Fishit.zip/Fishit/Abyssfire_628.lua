-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 219,
		["Type"] = "Fishing Rods",
		["Name"] = "Abyssfire",
		["Description"] = "",
		["Icon"] = "rbxassetid://139097361782267",
		["Tier"] = 2
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.5, 1.9, 1),
	["_moduleScript"] = script
}
return v1