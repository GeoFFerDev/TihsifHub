-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	{ "Low", 1, 1 },
	{ "Medium", 2, 0.5 },
	{ "High", 3, 0.1 },
	{ "Precise", 4, 0 }
}