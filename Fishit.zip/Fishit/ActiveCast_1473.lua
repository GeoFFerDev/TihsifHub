-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

require(script.Parent.TypeDefinitions)
local v_u_1 = require(script.Parent.TypeMarshaller)
local v_u_2 = {}
v_u_2.__index = v_u_2
v_u_2.__type = "ActiveCast"
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent.Table)
local v_u_5 = nil
function DbgVisualizeSegment(p6, p7)
	-- upvalues: (ref) v_u_5
	if v_u_5.VisualizeCasts ~= true then
		return nil
	end
	local v8 = Instance.new("ConeHandleAdornment")
	v8.Adornee = workspace.Terrain
	v8.CFrame = p6
	v8.Height = p7
	v8.Color3 = Color3.new()
	v8.Radius = 0.25
	v8.Transparency = 0.5
	local v9 = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects")
	if v9 == nil then
		v9 = Instance.new("Folder")
		v9.Name = "FastCastVisualizationObjects"
		v9.Archivable = false
		v9.Parent = workspace.Terrain
	end
	v8.Parent = v9
	return v8
end
function DbgVisualizeHit(p10, p11)
	-- upvalues: (ref) v_u_5
	if v_u_5.VisualizeCasts ~= true then
		return nil
	end
	local v12 = Instance.new("SphereHandleAdornment")
	v12.Adornee = workspace.Terrain
	v12.CFrame = p10
	v12.Radius = 0.4
	v12.Transparency = 0.25
	v12.Color3 = p11 == false and Color3.new(0.2, 1, 0.5) or Color3.new(1, 0.2, 0.2)
	local v13 = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects")
	if v13 == nil then
		v13 = Instance.new("Folder")
		v13.Name = "FastCastVisualizationObjects"
		v13.Archivable = false
		v13.Parent = workspace.Terrain
	end
	v12.Parent = v13
	return v12
end
local function v_u_27(p14, p15)
	local v16 = p14.StateInfo.UpdateConnection ~= nil
	assert(v16, "This ActiveCast has been terminated. It can no longer be used.")
	local v17 = p14.StateInfo.Trajectories[p15]
	local v18 = v17.EndTime - v17.StartTime
	local v19 = v17.Origin
	local v20 = v17.InitialVelocity
	local v21 = v17.Acceleration
	local v22 = {}
	local v23 = v21.X * v18 ^ 2 / 2
	local v24 = v21.Y * v18 ^ 2 / 2
	local v25 = v21.Z * v18 ^ 2 / 2
	local v26 = Vector3.new(v23, v24, v25)
	__set_list(v22, 1, {v19 + v20 * v18 + v26, v20 + v21 * v18})
	return v22
end
local function v_u_94(p28, p29, p30)
	-- upvalues: (ref) v_u_5, (copy) v_u_4
	local v31 = p28.StateInfo.UpdateConnection ~= nil
	assert(v31, "This ActiveCast has been terminated. It can no longer be used.")
	if v_u_5.DebugLogging == true then
		print("Casting for frame.")
	end
	local v32 = p28.StateInfo.Trajectories[#p28.StateInfo.Trajectories]
	local v33 = v32.Origin
	local v34 = p28.StateInfo.TotalRuntime - v32.StartTime
	local v35 = v32.InitialVelocity
	local v36 = v32.Acceleration
	local v37 = v36.X * v34 ^ 2 / 2
	local v38 = v36.Y * v34 ^ 2 / 2
	local v39 = v36.Z * v34 ^ 2 / 2
	local v40 = Vector3.new(v37, v38, v39)
	local v41 = v33 + v35 * v34 + v40
	local _ = v35 + v36 * v34
	local v42 = p28.StateInfo.TotalRuntime - v32.StartTime
	local v43 = p28.StateInfo
	v43.TotalRuntime = v43.TotalRuntime + p29
	local v44 = p28.StateInfo.TotalRuntime - v32.StartTime
	local v45 = v36.X * v44 ^ 2 / 2
	local v46 = v36.Y * v44 ^ 2 / 2
	local v47 = v36.Z * v44 ^ 2 / 2
	local v48 = Vector3.new(v45, v46, v47)
	local v49 = v33 + v35 * v44 + v48
	local v50 = v35 + v36 * v44
	local v51 = (v49 - v41).Unit * v50.Magnitude * p29
	local v52 = p28.RayInfo.WorldRoot
	local v53 = v52:Raycast(v41, v51, p28.RayInfo.Parameters)
	local v54 = Enum.Material.Air
	Vector3.new()
	local v55, v56
	if v53 == nil then
		v55 = v49
		v56 = nil
	else
		v55 = v53.Position
		v56 = v53.Instance
		v54 = v53.Material
		local _ = v53.Normal
	end
	local v57 = (v55 - v41).Magnitude
	local v58 = v51.Unit
	local v59 = p28.RayInfo.CosmeticBulletObject
	p28.Caster.LengthChanged:Fire(p28, v41, v58, v57, v50, v59, p29)
	local v60 = p28.StateInfo
	v60.DistanceCovered = v60.DistanceCovered + v57
	local v61
	if p29 > 0 then
		v61 = DbgVisualizeSegment(CFrame.new(v41, v41 + v51), v57)
	else
		v61 = nil
	end
	if v56 and v56 ~= p28.RayInfo.CosmeticBulletObject then
		tick()
		if v_u_5.DebugLogging == true then
			print("Hit something, testing now.")
		end
		if p28.RayInfo.CanPierceCallback ~= nil then
			if p30 == false and p28.StateInfo.IsActivelySimulatingPierce then
				p28:Terminate()
				error("ERROR: The latest call to CanPierceCallback took too long to complete! This cast is going to suffer desyncs which WILL cause unexpected behavior and errors. Please fix your performance problems, or remove statements that yield (e.g. wait() calls)")
			end
			p28.StateInfo.IsActivelySimulatingPierce = true
		end
		if p28.RayInfo.CanPierceCallback == nil or p28.RayInfo.CanPierceCallback ~= nil and p28.RayInfo.CanPierceCallback(p28, v53, v50, p28.RayInfo.CosmeticBulletObject) == false then
			if v_u_5.DebugLogging == true then
				print("Piercing function is nil or it returned FALSE to not pierce this hit.")
			end
			p28.StateInfo.IsActivelySimulatingPierce = false
			if p28.StateInfo.HighFidelityBehavior == 2 and (v32.Acceleration ~= Vector3.new() and p28.StateInfo.HighFidelitySegmentSize ~= 0) then
				p28.StateInfo.CancelHighResCast = false
				if p28.StateInfo.IsActivelyResimulating then
					p28:Terminate()
					error("Cascading cast lag encountered! The caster attempted to perform a high fidelity cast before the previous one completed, resulting in exponential cast lag. Consider increasing HighFidelitySegmentSize.")
				end
				p28.StateInfo.IsActivelyResimulating = true
				if v_u_5.DebugLogging == true then
					print("Hit was registered, but recalculation is on for physics based casts. Recalculating to verify a real hit...")
				end
				local v62 = v57 / p28.StateInfo.HighFidelitySegmentSize
				local v63 = math.floor(v62)
				local _ = v57 / v63
				local v64 = p29 / v63
				for v65 = 1, v63 do
					if p28.StateInfo.CancelHighResCast then
						p28.StateInfo.CancelHighResCast = false
						break
					end
					local v66 = v42 + v64 * v65
					local v67 = v36.X * v66 ^ 2 / 2
					local v68 = v36.Y * v66 ^ 2 / 2
					local v69 = v36.Z * v66 ^ 2 / 2
					local v70 = Vector3.new(v67, v68, v69)
					local v71 = v33 + v35 * v66 + v70
					local v72 = v35 + v36 * (v42 + v64 * v65)
					local v73 = v52:Raycast(v71, v72 * p29, p28.RayInfo.Parameters)
					local v74 = (v71 - (v71 + v72)).Magnitude
					if v73 == nil then
						local v75 = DbgVisualizeSegment(CFrame.new(v71, v71 + v72), v74)
						if v75 ~= nil then
							v75.Color3 = Color3.new(0.286275, 0.329412, 0.247059)
						end
					else
						local v76 = (v71 - v73.Position).Magnitude
						local v77 = DbgVisualizeSegment(CFrame.new(v71, v71 + v72), v76)
						if v77 ~= nil then
							v77.Color3 = Color3.new(0.286275, 0.329412, 0.247059)
						end
						if p28.RayInfo.CanPierceCallback == nil or p28.RayInfo.CanPierceCallback ~= nil and p28.RayInfo.CanPierceCallback(p28, v73, v72, p28.RayInfo.CosmeticBulletObject) == false then
							p28.StateInfo.IsActivelyResimulating = false
							local v78 = p28.RayInfo.CosmeticBulletObject
							p28.Caster.RayHit:Fire(p28, v73, v72, v78)
							p28:Terminate()
							local v79 = DbgVisualizeHit(CFrame.new(v55), false)
							if v79 ~= nil then
								v79.Color3 = Color3.new(0.0588235, 0.87451, 1)
							end
							return
						end
						local v80 = p28.RayInfo.CosmeticBulletObject
						p28.Caster.RayPierced:Fire(p28, v73, v72, v80)
						local v81 = DbgVisualizeHit(CFrame.new(v55), true)
						if v81 ~= nil then
							v81.Color3 = Color3.new(1, 0.113725, 0.588235)
						end
						if v77 ~= nil then
							v77.Color3 = Color3.new(0.305882, 0.243137, 0.329412)
						end
					end
				end
				p28.StateInfo.IsActivelyResimulating = false
			else
				if p28.StateInfo.HighFidelityBehavior == 1 or p28.StateInfo.HighFidelityBehavior == 3 then
					if v_u_5.DebugLogging == true then
						print("Hit was successful. Terminating.")
					end
					local v82 = p28.RayInfo.CosmeticBulletObject
					p28.Caster.RayHit:Fire(p28, v53, v50, v82)
					p28:Terminate()
					DbgVisualizeHit(CFrame.new(v55), false)
					return
				end
				p28:Terminate()
				error("Invalid value " .. p28.StateInfo.HighFidelityBehavior .. " for HighFidelityBehavior.")
			end
		else
			if v_u_5.DebugLogging == true then
				print("Piercing function returned TRUE to pierce this part.")
			end
			if v61 ~= nil then
				v61.Color3 = Color3.new(0.4, 0.05, 0.05)
			end
			DbgVisualizeHit(CFrame.new(v55), true)
			local v83 = p28.RayInfo.Parameters
			local v84 = v83.FilterDescendantsInstances
			local v85 = {}
			local v86 = false
			local v87 = 0
			while true do
				if v53.Instance:IsA("Terrain") then
					if v54 == Enum.Material.Water then
						p28:Terminate()
						error("Do not add Water as a piercable material. If you need to pierce water, set cast.RayInfo.Parameters.IgnoreWater = true instead", 0)
					end
					warn("WARNING: The pierce callback for this cast returned TRUE on Terrain! This can cause severely adverse effects.")
				end
				if v83.FilterType == Enum.RaycastFilterType.Blacklist then
					local v88 = v83.FilterDescendantsInstances
					v_u_4.insert(v88, v53.Instance)
					v_u_4.insert(v85, v53.Instance)
					v83.FilterDescendantsInstances = v88
				else
					local v89 = v83.FilterDescendantsInstances
					v_u_4.removeObject(v89, v53.Instance)
					v_u_4.insert(v85, v53.Instance)
					v83.FilterDescendantsInstances = v89
				end
				local v90 = p28.RayInfo.CosmeticBulletObject
				p28.Caster.RayPierced:Fire(p28, v53, v50, v90)
				v53 = v52:Raycast(v41, v51, v83)
				if v53 == nil then
					break
				end
				if v87 >= 100 then
					warn("WARNING: Exceeded maximum pierce test budget for a single ray segment (attempted to test the same segment " .. 100 .. " times!)")
					break
				end
				v87 = v87 + 1
				if p28.RayInfo.CanPierceCallback(p28, v53, v50, p28.RayInfo.CosmeticBulletObject) == false then
					v86 = true
					break
				end
			end
			p28.RayInfo.Parameters.FilterDescendantsInstances = v84
			p28.StateInfo.IsActivelySimulatingPierce = false
			if v86 then
				local v91 = v53.Instance
				local v92 = "Broke because the ray hit something solid (" .. tostring(v91) .. ") while testing for a pierce. Terminating the cast."
				if v_u_5.DebugLogging == true then
					print(v92)
				end
				local v93 = p28.RayInfo.CosmeticBulletObject
				p28.Caster.RayHit:Fire(p28, v53, v50, v93)
				p28:Terminate()
				DbgVisualizeHit(CFrame.new(v53.Position), false)
				return
			end
		end
	end
	if p28.StateInfo.DistanceCovered >= p28.RayInfo.MaxDistance then
		p28:Terminate()
		DbgVisualizeHit(CFrame.new(v49), false)
	end
end
function v_u_2.new(p95, p96, p97, p98, p99)
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (ref) v_u_5, (copy) v_u_94
	if v_u_1(p98) == "number" then
		p98 = p97.Unit * p98
	end
	if p99.HighFidelitySegmentSize <= 0 then
		error("Cannot set FastCastBehavior.HighFidelitySegmentSize <= 0!", 0)
	end
	local v_u_100 = {
		["Caster"] = p95,
		["StateInfo"] = {
			["UpdateConnection"] = nil,
			["Paused"] = false,
			["TotalRuntime"] = 0,
			["DistanceCovered"] = 0,
			["HighFidelitySegmentSize"] = p99.HighFidelitySegmentSize,
			["HighFidelityBehavior"] = p99.HighFidelityBehavior,
			["IsActivelySimulatingPierce"] = false,
			["IsActivelyResimulating"] = false,
			["CancelHighResCast"] = false,
			["Trajectories"] = {
				{
					["StartTime"] = 0,
					["EndTime"] = -1,
					["Origin"] = p96,
					["InitialVelocity"] = p98,
					["Acceleration"] = p99.Acceleration
				}
			}
		},
		["RayInfo"] = {
			["Parameters"] = p99.RaycastParams,
			["WorldRoot"] = workspace,
			["MaxDistance"] = p99.MaxDistance or 1000,
			["CosmeticBulletObject"] = p99.CosmeticBulletTemplate,
			["CanPierceCallback"] = p99.CanPierceFunction
		},
		["UserData"] = {}
	}
	if v_u_100.StateInfo.HighFidelityBehavior == 2 then
		v_u_100.StateInfo.HighFidelityBehavior = 3
	end
	if v_u_100.RayInfo.Parameters == nil then
		v_u_100.RayInfo.Parameters = RaycastParams.new()
	else
		local v101 = v_u_100.RayInfo
		local v102 = v_u_100.RayInfo.Parameters
		local v103 = RaycastParams.new()
		v103.CollisionGroup = v102.CollisionGroup
		v103.FilterType = v102.FilterType
		v103.FilterDescendantsInstances = v102.FilterDescendantsInstances
		v103.IgnoreWater = v102.IgnoreWater
		v101.Parameters = v103
	end
	local v104 = false
	if p99.CosmeticBulletProvider == nil then
		if v_u_100.RayInfo.CosmeticBulletObject ~= nil then
			if not v_u_100.RayInfo.CosmeticBulletObject:GetAttribute("UseCosmeticBulletObject") then
				v_u_100.RayInfo.CosmeticBulletObject = v_u_100.RayInfo.CosmeticBulletObject:Clone()
			end
			local v105 = v_u_100.RayInfo.CosmeticBulletObject
			if v105:IsA("Model") then
				v105.PrimaryPart.CFrame = CFrame.new(p96, p96 + p97)
			else
				v105.CFrame = CFrame.new(p96, p96 + p97)
			end
			v105.Parent = p99.CosmeticBulletContainer
		end
	elseif v_u_1(p99.CosmeticBulletProvider) == "PartCache" then
		if v_u_100.RayInfo.CosmeticBulletObject ~= nil then
			warn("Do not define FastCastBehavior.CosmeticBulletTemplate and FastCastBehavior.CosmeticBulletProvider at the same time! The provider will be used, and CosmeticBulletTemplate will be set to nil.")
			v_u_100.RayInfo.CosmeticBulletObject = nil
			p99.CosmeticBulletTemplate = nil
		end
		v_u_100.RayInfo.CosmeticBulletObject = p99.CosmeticBulletProvider:GetPart()
		v_u_100.RayInfo.CosmeticBulletObject.CFrame = CFrame.new(p96, p96 + p97)
		v104 = true
	else
		warn("FastCastBehavior.CosmeticBulletProvider was not an instance of the PartCache module (an external/separate model)! Are you inputting an instance created via PartCache.new? If so, are you on the latest version of PartCache? Setting FastCastBehavior.CosmeticBulletProvider to nil.")
		p99.CosmeticBulletProvider = nil
	end
	local v106
	if v104 then
		v106 = p99.CosmeticBulletProvider.CurrentCacheParent
	else
		v106 = p99.CosmeticBulletContainer
	end
	if p99.AutoIgnoreContainer == true and v106 ~= nil then
		local v107 = v_u_100.RayInfo.Parameters.FilterDescendantsInstances
		if v_u_4.find(v107, v106) == nil then
			v_u_4.insert(v107, v106)
			v_u_100.RayInfo.Parameters.FilterDescendantsInstances = v107
		end
	end
	local v108
	if v_u_3:IsClient() then
		v108 = v_u_3.RenderStepped
	else
		v108 = v_u_3.Heartbeat
	end
	local v109 = v_u_2
	setmetatable(v_u_100, v109)
	v_u_100.StateInfo.UpdateConnection = v108:Connect(function(p110)
		-- upvalues: (copy) v_u_100, (ref) v_u_5, (ref) v_u_94
		if v_u_100.StateInfo.Paused then
			return
		end
		if v_u_5.DebugLogging == true then
			print("Casting for frame.")
		end
		local v111 = v_u_100.StateInfo.Trajectories[#v_u_100.StateInfo.Trajectories]
		if v_u_100.StateInfo.HighFidelityBehavior == 3 and (v111.Acceleration ~= Vector3.new() and v_u_100.StateInfo.HighFidelitySegmentSize > 0) then
			local v112 = tick()
			if v_u_100.StateInfo.IsActivelyResimulating then
				v_u_100:Terminate()
				error("Cascading cast lag encountered! The caster attempted to perform a high fidelity cast before the previous one completed, resulting in exponential cast lag. Consider increasing HighFidelitySegmentSize.")
			end
			v_u_100.StateInfo.IsActivelyResimulating = true
			local v113 = v111.Origin
			local v114 = v_u_100.StateInfo.TotalRuntime - v111.StartTime
			local v115 = v111.InitialVelocity
			local v116 = v111.Acceleration
			local v117 = v116.X * v114 ^ 2 / 2
			local v118 = v116.Y * v114 ^ 2 / 2
			local v119 = v116.Z * v114 ^ 2 / 2
			local v120 = Vector3.new(v117, v118, v119)
			local v121 = v113 + v115 * v114 + v120
			local _ = v115 + v116 * v114
			local _ = v_u_100.StateInfo.TotalRuntime - v111.StartTime
			local v122 = v_u_100.StateInfo
			v122.TotalRuntime = v122.TotalRuntime + p110
			local v123 = v_u_100.StateInfo.TotalRuntime - v111.StartTime
			local v124 = v116.X * v123 ^ 2 / 2
			local v125 = v116.Y * v123 ^ 2 / 2
			local v126 = v116.Z * v123 ^ 2 / 2
			local v127 = Vector3.new(v124, v125, v126)
			local v128 = v113 + v115 * v123 + v127
			local v129 = v115 + v116 * v123
			local v130 = (v128 - v121).Unit * v129.Magnitude * p110
			local v131 = v_u_100.RayInfo.WorldRoot:Raycast(v121, v130, v_u_100.RayInfo.Parameters)
			if v131 ~= nil then
				v128 = v131.Position
			end
			local v132 = (v128 - v121).Magnitude
			local v133 = v_u_100.StateInfo
			v133.TotalRuntime = v133.TotalRuntime - p110
			local v134 = v132 / v_u_100.StateInfo.HighFidelitySegmentSize
			local v135 = math.floor(v134)
			local v136 = v135 == 0 and 1 or v135
			local v137 = p110 / v136
			for v138 = 1, v136 do
				local v139 = v_u_100
				if getmetatable(v139) == nil then
					return
				end
				if v_u_100.StateInfo.CancelHighResCast then
					v_u_100.StateInfo.CancelHighResCast = false
					break
				end
				local v140 = "[" .. v138 .. "] Subcast of time increment " .. v137
				if v_u_5.DebugLogging == true then
					print(v140)
				end
				v_u_94(v_u_100, v137, true)
			end
			local v141 = v_u_100
			if getmetatable(v141) == nil then
				return
			end
			v_u_100.StateInfo.IsActivelyResimulating = false
			if tick() - v112 > 0.08 then
				warn("Extreme cast lag encountered! Consider increasing HighFidelitySegmentSize.")
				return
			end
		else
			v_u_94(v_u_100, p110, false)
		end
	end)
	return v_u_100
end
function v_u_2.SetStaticFastCastReference(p142)
	-- upvalues: (ref) v_u_5
	v_u_5 = p142
end
local function v_u_153(p143, p144, p145, p146)
	-- upvalues: (copy) v_u_27, (copy) v_u_4
	local v147 = p143.StateInfo.Trajectories
	local v148 = v147[#v147]
	if v148.StartTime == p143.StateInfo.TotalRuntime then
		if p144 == nil then
			p144 = v148.InitialVelocity
		end
		if p145 == nil then
			p145 = v148.Acceleration
		end
		if p146 == nil then
			p146 = v148.Origin
		end
		v148.Origin = p146
		v148.InitialVelocity = p144
		v148.Acceleration = p145
	else
		v148.EndTime = p143.StateInfo.TotalRuntime
		local v149 = p143.StateInfo.UpdateConnection ~= nil
		assert(v149, "This ActiveCast has been terminated. It can no longer be used.")
		local v150 = v_u_27(p143, #p143.StateInfo.Trajectories)
		local v151, v152 = unpack(v150)
		if p144 == nil then
			p144 = v152
		end
		if p145 == nil then
			p145 = v148.Acceleration
		end
		if p146 ~= nil then
			v151 = p146
		end
		v_u_4.insert(p143.StateInfo.Trajectories, {
			["StartTime"] = p143.StateInfo.TotalRuntime,
			["EndTime"] = -1,
			["Origin"] = v151,
			["InitialVelocity"] = p144,
			["Acceleration"] = p145
		})
		p143.StateInfo.CancelHighResCast = true
	end
end
function v_u_2.SetVelocity(p154, p155)
	-- upvalues: (copy) v_u_2, (copy) v_u_153
	local v156 = getmetatable(p154) == v_u_2
	assert(v156, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetVelocity", "ActiveCast.new(...)"))
	local v157 = p154.StateInfo.UpdateConnection ~= nil
	assert(v157, "This ActiveCast has been terminated. It can no longer be used.")
	v_u_153(p154, p155, nil, nil)
end
function v_u_2.SetAcceleration(p158, p159)
	-- upvalues: (copy) v_u_2, (copy) v_u_153
	local v160 = getmetatable(p158) == v_u_2
	assert(v160, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetAcceleration", "ActiveCast.new(...)"))
	local v161 = p158.StateInfo.UpdateConnection ~= nil
	assert(v161, "This ActiveCast has been terminated. It can no longer be used.")
	v_u_153(p158, nil, p159, nil)
end
function v_u_2.SetPosition(p162, p163)
	-- upvalues: (copy) v_u_2, (copy) v_u_153
	local v164 = getmetatable(p162) == v_u_2
	assert(v164, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetPosition", "ActiveCast.new(...)"))
	local v165 = p162.StateInfo.UpdateConnection ~= nil
	assert(v165, "This ActiveCast has been terminated. It can no longer be used.")
	v_u_153(p162, nil, nil, p163)
end
function v_u_2.GetVelocity(p166)
	-- upvalues: (copy) v_u_2
	local v167 = getmetatable(p166) == v_u_2
	assert(v167, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetVelocity", "ActiveCast.new(...)"))
	local v168 = p166.StateInfo.UpdateConnection ~= nil
	assert(v168, "This ActiveCast has been terminated. It can no longer be used.")
	local v169 = p166.StateInfo.Trajectories[#p166.StateInfo.Trajectories]
	local v170 = p166.StateInfo.TotalRuntime - v169.StartTime
	return v169.InitialVelocity + v169.Acceleration * v170
end
function v_u_2.GetAcceleration(p171)
	-- upvalues: (copy) v_u_2
	local v172 = getmetatable(p171) == v_u_2
	assert(v172, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetAcceleration", "ActiveCast.new(...)"))
	local v173 = p171.StateInfo.UpdateConnection ~= nil
	assert(v173, "This ActiveCast has been terminated. It can no longer be used.")
	return p171.StateInfo.Trajectories[#p171.StateInfo.Trajectories].Acceleration
end
function v_u_2.GetPosition(p174)
	-- upvalues: (copy) v_u_2
	local v175 = getmetatable(p174) == v_u_2
	assert(v175, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetPosition", "ActiveCast.new(...)"))
	local v176 = p174.StateInfo.UpdateConnection ~= nil
	assert(v176, "This ActiveCast has been terminated. It can no longer be used.")
	local v177 = p174.StateInfo.Trajectories[#p174.StateInfo.Trajectories]
	local v178 = p174.StateInfo.TotalRuntime - v177.StartTime
	local v179 = v177.Origin
	local v180 = v177.InitialVelocity
	local v181 = v177.Acceleration
	local v182 = v181.X * v178 ^ 2 / 2
	local v183 = v181.Y * v178 ^ 2 / 2
	local v184 = v181.Z * v178 ^ 2 / 2
	local v185 = Vector3.new(v182, v183, v184)
	return v179 + v180 * v178 + v185
end
function v_u_2.AddVelocity(p186, p187)
	-- upvalues: (copy) v_u_2
	local v188 = getmetatable(p186) == v_u_2
	assert(v188, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddVelocity", "ActiveCast.new(...)"))
	local v189 = p186.StateInfo.UpdateConnection ~= nil
	assert(v189, "This ActiveCast has been terminated. It can no longer be used.")
	p186:SetVelocity(p186:GetVelocity() + p187)
end
function v_u_2.AddAcceleration(p190, p191)
	-- upvalues: (copy) v_u_2
	local v192 = getmetatable(p190) == v_u_2
	assert(v192, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddAcceleration", "ActiveCast.new(...)"))
	local v193 = p190.StateInfo.UpdateConnection ~= nil
	assert(v193, "This ActiveCast has been terminated. It can no longer be used.")
	p190:SetAcceleration(p190:GetAcceleration() + p191)
end
function v_u_2.AddPosition(p194, p195)
	-- upvalues: (copy) v_u_2
	local v196 = getmetatable(p194) == v_u_2
	assert(v196, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddPosition", "ActiveCast.new(...)"))
	local v197 = p194.StateInfo.UpdateConnection ~= nil
	assert(v197, "This ActiveCast has been terminated. It can no longer be used.")
	p194:SetPosition(p194:GetPosition() + p195)
end
function v_u_2.Pause(p198)
	-- upvalues: (copy) v_u_2
	local v199 = getmetatable(p198) == v_u_2
	assert(v199, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Pause", "ActiveCast.new(...)"))
	local v200 = p198.StateInfo.UpdateConnection ~= nil
	assert(v200, "This ActiveCast has been terminated. It can no longer be used.")
	p198.StateInfo.Paused = true
end
function v_u_2.Resume(p201)
	-- upvalues: (copy) v_u_2
	local v202 = getmetatable(p201) == v_u_2
	assert(v202, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Resume", "ActiveCast.new(...)"))
	local v203 = p201.StateInfo.UpdateConnection ~= nil
	assert(v203, "This ActiveCast has been terminated. It can no longer be used.")
	p201.StateInfo.Paused = false
end
function v_u_2.Terminate(p204)
	-- upvalues: (copy) v_u_2
	local v205 = getmetatable(p204) == v_u_2
	assert(v205, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Terminate", "ActiveCast.new(...)"))
	local v206 = p204.StateInfo.UpdateConnection ~= nil
	assert(v206, "This ActiveCast has been terminated. It can no longer be used.")
	local v207 = p204.StateInfo.Trajectories
	v207[#v207].EndTime = p204.StateInfo.TotalRuntime
	p204.StateInfo.UpdateConnection:Disconnect()
	p204.Caster.CastTerminating:FireSync(p204)
	p204.StateInfo.UpdateConnection = nil
	p204.Caster = nil
	p204.StateInfo = nil
	p204.RayInfo = nil
	p204.UserData = nil
	setmetatable(p204, nil)
end
return v_u_2