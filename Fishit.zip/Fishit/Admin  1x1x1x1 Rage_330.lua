-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - 1x1x1x1 Rage",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "LIMITED EVENT",
	["GlobalDescription"] = "LIMITED EVENT +200,000% LUCK + COMET SHARK",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 600,
	["Coordinates"] = { Vector3.new(16.116, 120.966, 2965) },
	["Variants"] = { "1x1x1x1" },
	["GlobalFish"] = { "1x1x1x1 Comet Shark" },
	["Modifiers"] = {
		["MutationMultiplier"] = 4,
		["BaseLuck"] = 2000
	}
}
return v1