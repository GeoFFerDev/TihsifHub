-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - 2025 Anniversary",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "LIMITED EVENT",
	["GlobalDescription"] = "LIMITED TIME LUCK BOOST + BIRTHDAY Shark",
	["UseBirthdayColor"] = true,
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 1200,
	["Coordinates"] = { Vector3.new(42.396, 95.691, 2928.036) },
	["Modifiers"] = {
		["BaseLuck"] = 1000
	}
}
return v1