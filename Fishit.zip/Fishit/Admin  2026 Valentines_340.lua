-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - 2026 Valentines",
	["Icon"] = "rbxassetid://87576435779607",
	["Description"] = "SPECIAL EVENT",
	["GlobalDescription"] = "SPECIAL EVENT! 200K LUCK FOR 10 MINS",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 600,
	["Coordinates"] = { Vector3.new(1119, 120, 2720) },
	["Modifiers"] = {
		["BaseLuck"] = 2000
	}
}
return v1