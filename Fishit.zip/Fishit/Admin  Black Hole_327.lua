-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Black Hole",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "Fish in Black Hole area!",
	["GlobalDescription"] = "Fish in Black Hole for x7 Galaxy & Corrupt mutations!",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 3600,
	["Coordinates"] = { Vector3.new(883, -1, 2542) }
}
local v2 = {
	["Fish"] = {},
	["Variants"] = {}
}
local v3 = {
	["Admin - Black Hole"] = {
		["CorruptMutationMultiplier"] = 7,
		["GalaxyMutationMultiplier"] = 7
	}
}
v2.Modifiers = v3
v1.LinkedEvents = v2
v1.Modifiers = {}
return v1