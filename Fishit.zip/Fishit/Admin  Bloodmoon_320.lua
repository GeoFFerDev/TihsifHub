-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Bloodmoon",
	["Icon"] = "rbxassetid://87075905315600",
	["Description"] = "10 MINS",
	["GlobalDescription"] = "OG EVENT + ADMIN FISH + NEW MUTATION!",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 600,
	["Coordinates"] = { Vector3.new(16.116, 120.966, 3029.588) },
	["GlobalFish"] = { "Bloodmoon Whale" },
	["Variants"] = { "Bloodmoon" },
	["Modifiers"] = {
		["MutationMultiplier"] = 5,
		["BaseLuck"] = 2000
	}
}
return v1