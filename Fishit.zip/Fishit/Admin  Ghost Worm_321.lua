-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Ghost Worm",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "Only 1 Ghost Worm!",
	["GlobalDescription"] = "Be the first to catch the ADMIN Ghost Worm Fish!",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["OptionalDuration"] = true,
	["Coordinates"] = { Vector3.new(-327, -1.4, 2422) }
}
local v2 = {
	["Fish"] = {
		["Admin - Ghost Worm"] = { "Ghost Worm Fish" }
	},
	["Variants"] = {},
	["Modifiers"] = {}
}
v1.LinkedEvents = v2
v1.Modifiers = {}
return v1