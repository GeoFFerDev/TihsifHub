-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Leviathan Awakening",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "LIMITED EVENT",
	["GlobalDescription"] = "10 MINS, +200K GLOBAL LUCK BOOST + LEVIATHAN CHANCE",
	["UseBirthdayColor"] = false,
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 600,
	["Variants"] = { "Leviathan Rage" },
	["GlobalFish"] = { "Leviathan" },
	["Coordinates"] = { Vector3.new(948.186, -41.185, 1637.272) },
	["Modifiers"] = {
		["BaseLuck"] = 2000
	}
}
return v1