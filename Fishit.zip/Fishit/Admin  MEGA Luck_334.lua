-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - MEGA Luck",
	["Icon"] = "rbxassetid://101739550540739",
	["Description"] = "MEGA LUCK",
	["GlobalDescription"] = "Global effect, +10,000% Luck!",
	["Tier"] = 7,
	["Duration"] = 3600,
	["Modifiers"] = {
		["BaseLuck"] = 100
	}
}
return v1