-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Meteor Rain",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "Fish in Meteor Rain area!",
	["GlobalDescription"] = "Fish in Meteor Rain area for x9 mutation chance!",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 3600,
	["Coordinates"] = { Vector3.new(383, -1.4, 2452) }
}
local v2 = {
	["Fish"] = {},
	["Variants"] = {}
}
local v3 = {
	["Admin - Black Hole"] = {
		["MutationMultiplier"] = 9,
		["BaseLuck"] = 0.3
	}
}
v2.Modifiers = v3
v1.LinkedEvents = v2
v1.Modifiers = {}
return v1