-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Night Celebration",
	["Icon"] = "rbxassetid://87075905315600",
	["Description"] = "2 HOURS",
	["GlobalDescription"] = "SPECIAL EVENT! 10K LUCK FOR 2 HOURS",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 7200,
	["Modifiers"] = {
		["BaseLuck"] = 100
	}
}
return v1