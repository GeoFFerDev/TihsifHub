-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Purple Bloodmoon",
	["Icon"] = "rbxassetid://97605522098864",
	["Description"] = "10 MINS",
	["GlobalDescription"] = "+250K LUCK + BLOODMOON WHALE FOR 10 MINS!",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 600,
	["Coordinates"] = { Vector3.new(16.116, 700, 3029.588) },
	["GlobalFish"] = { "Bloodmoon Whale" },
	["Variants"] = { "Bloodmoon", "Moon Fragment" },
	["Modifiers"] = {
		["MutationMultiplier"] = 2,
		["BaseLuck"] = 2500
	}
}
return v1