-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Shocked",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "Fish in Shocked area!",
	["GlobalDescription"] = "Fish in Shocked area for x8 Lightning mutation chance!",
	["Tier"] = 7,
	["QueueTime"] = 0,
	["Duration"] = 3600,
	["Coordinates"] = { Vector3.new(137.4, -1.4, 2268.5) }
}
local v2 = {
	["Fish"] = {},
	["Variants"] = {}
}
local v3 = {
	["Admin - Shocked"] = {
		["LightningMutationMultiplier"] = 7
	}
}
v2.Modifiers = v3
v1.LinkedEvents = v2
v1.Modifiers = {}
return v1