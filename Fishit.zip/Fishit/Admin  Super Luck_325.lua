-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Super Luck",
	["Icon"] = "rbxassetid://101739550540739",
	["Description"] = "SUPER LUCK",
	["GlobalDescription"] = "Global effect, +5,000% Luck!",
	["Tier"] = 7,
	["Duration"] = 3600,
	["Modifiers"] = {
		["BaseLuck"] = 50
	}
}
return v1