-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Admin - Super Mutated",
	["Icon"] = "rbxassetid://85808602968553",
	["Description"] = "Mutation chance x4",
	["GlobalDescription"] = "Global effect, x4 mutation chance!",
	["Tier"] = 7,
	["Duration"] = 3600,
	["Modifiers"] = {
		["MutationMultiplier"] = 5
	}
}
return v1