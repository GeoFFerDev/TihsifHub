-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
game:GetService("Lighting")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v4 = game:GetService("ReplicatedStorage")
game:GetService("CollectionService")
local v_u_5 = require(v4.Packages.Trove)
local v_u_6 = require(script.FOVTable)
local v_u_7 = require(script.EmitAt)
local v_u_8 = require(v4.Shared.Soundbook)
local v_u_9 = require(v4.Modules.GuiControl)
local function v_u_15(p10)
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v11 = p10 or false
	local v_u_12 = v_u_1.LocalPlayer
	if v_u_12 then
		v_u_12 = v_u_1.LocalPlayer:FindFirstChild("PlayerGui")
	end
	if v_u_12 then
		v_u_12 = v_u_12:FindFirstChild("Blackout")
	end
	if v_u_12 then
		v_u_12.Label.Visible = false
		v_u_12.Blackout.BackgroundTransparency = 1
		v_u_12.Blackout.BackgroundColor3 = v11 and Color3.new(1, 1, 1) or Color3.new(0, 0, 0)
		local v13 = v_u_3:Create(v_u_12.Blackout, TweenInfo.new(0.5), {
			["BackgroundTransparency"] = 0
		})
		local v14 = v_u_3:Create(v_u_12.Blackout, TweenInfo.new(0.5), {
			["BackgroundTransparency"] = 1
		})
		v14.Completed:Once(function()
			-- upvalues: (copy) v_u_12
			v_u_12.Enabled = false
			v_u_12.Label.Visible = true
			v_u_12.Blackout.BackgroundTransparency = 0
			v_u_12.Blackout.BackgroundColor3 = Color3.new(0, 0, 0)
		end)
		v_u_12.Enabled = true
		v13:Play()
		v13.Completed:Wait()
		task.wait(0.3)
		v14:Play()
	end
end
local v_u_16 = {}
v_u_16.__index = v_u_16
function v_u_16.new(_, _)
	-- upvalues: (copy) v_u_16, (copy) v_u_5, (copy) v_u_1
	local v17 = v_u_16
	local v18 = setmetatable({}, v17)
	v18.Cleaner = v_u_5.new()
	v18.Destroyed = false
	v18.Finished = false
	v18.Camera = nil
	local v19 = Instance.new("Model")
	v19.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
	v19.Name = "CutsceneStuff"
	v19.Parent = workspace
	v18.Cleaner:Add(v19)
	local v20 = {}
	local v21 = {}
	for _, v22 in script.Rigs:GetChildren() do
		local v23 = v22:Clone()
		local v24 = script.Animations:FindFirstChild(v23.Name)
		local v25 = v23:FindFirstChildWhichIsA("Animator", true)
		if v25 then
			v23.Parent = v19
			local v26 = v25:LoadAnimation(v24)
			v26.Priority = Enum.AnimationPriority.Action4
			v26.Looped = false
			table.insert(v20, v26)
		else
			warn("Failed to find Animator!")
		end
		if v23.Name == "Cam" then
			v18.Camera = v23
		elseif v23.Name == "Character" then
			local v27 = v_u_1.LocalPlayer
			local v28 = v27.Character
			if v28 then
				v28 = v28.Humanoid:GetAppliedDescription()
			end
			if v28 then
				v23.Humanoid:ApplyDescription(v28)
			end
			v27:RequestStreamAroundAsync(v23:GetPivot().Position)
		end
		v18.Cleaner:Add(v23)
		table.insert(v21, v23)
	end
	if script:FindFirstChild("Scene") then
		local v29 = v_u_1.LocalPlayer
		local v30 = script.Scene:Clone()
		v30.Parent = v19
		v29:RequestStreamAroundAsync(v30:GetPivot().Position)
		v18.Cleaner:Add(v30)
	end
	for _, v31 in script.VFX:GetChildren() do
		local v32 = v31:Clone()
		v32.Parent = v19
		v18.Cleaner:Add(v32)
	end
	v18.Rigs = v21
	v18.Tracks = v20
	return v18
end
function v_u_16.Play(p_u_33, _, _)
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_15, (copy) v_u_9, (copy) v_u_2, (copy) v_u_6, (copy) v_u_7
	v_u_1.LocalPlayer:SetAttribute("InCutscene", true)
	local v_u_34 = workspace.CurrentCamera
	local v_u_35 = v_u_34.FieldOfView
	v_u_8.Sounds["Volcano Eruption Cutscene"]:Play()
	task.wait(0.15)
	task.defer(v_u_15)
	task.wait(0.3)
	local v_u_36 = v_u_9:HideAllHUD({ "Blackout" })
	v_u_34.CameraType = Enum.CameraType.Scriptable
	v_u_34.CFrame = p_u_33.Camera.CamPart.CFrame
	p_u_33.Cleaner:Add(function()
		-- upvalues: (copy) v_u_34, (copy) v_u_35, (ref) v_u_9, (copy) v_u_36, (ref) v_u_1
		v_u_34.FieldOfView = v_u_35
		v_u_34.CameraType = Enum.CameraType.Custom
		v_u_9:RestoreHUD(v_u_36)
		v_u_1.LocalPlayer:SetAttribute("InCutscene", false)
	end)
	p_u_33.Cleaner:Add(v_u_34:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		-- upvalues: (copy) v_u_34, (copy) p_u_33
		v_u_34.CameraType = Enum.CameraType.Scriptable
		v_u_34.CFrame = p_u_33.Camera.CamPart.CFrame
	end))
	p_u_33.PreviousFrame = 0
	p_u_33.Started = time()
	local v_u_37 = nil
	local v_u_38 = false
	for _, v39 in p_u_33.Tracks do
		v39:Play()
	end
	local function v_u_40()
		-- upvalues: (copy) p_u_33, (ref) v_u_37
		p_u_33.Finished = true
		v_u_37:Disconnect()
		p_u_33.Cleaner:Clean()
	end
	local _ = v_u_2.RenderStepped:Connect(function(_)
		-- upvalues: (copy) p_u_33, (ref) v_u_37, (copy) v_u_34, (ref) v_u_6, (ref) v_u_7, (ref) v_u_38, (ref) v_u_15, (copy) v_u_40
		local v41 = (time() - p_u_33.Started) * 60
		local v42 = math.ceil(v41) + 1
		if v42 == p_u_33.PreviousFrame then
			return
		elseif workspace:IsAncestorOf(p_u_33.Camera) and workspace:IsAncestorOf(p_u_33.Camera.CamPart) then
			v_u_34.CFrame = p_u_33.Camera.CamPart.CFrame
			if v_u_6[tostring(v42)] then
				v_u_34.FieldOfView = v_u_6[tostring(v42)]
			end
			if v_u_7[v42] then
				task.defer(v_u_7[v42])
			end
			if p_u_33.PreviousFrame + 1 ~= v42 and v_u_7[p_u_33.PreviousFrame + 1] then
				task.defer(v_u_7[p_u_33.PreviousFrame + 1])
			end
			if not v_u_38 and v42 >= 550 then
				v_u_38 = true
				task.defer(v_u_15, true)
				task.delay(0.5, v_u_40)
			end
			p_u_33.PreviousFrame = v42
		else
			p_u_33.Finished = true
			v_u_37:Disconnect()
			p_u_33.Cleaner:Clean()
		end
	end)
end
function v_u_16.IsFinished(p43)
	return p43.Finished
end
function v_u_16.Destroy(p44)
	if not p44.Destroyed then
		p44.Destroyed = true
		p44.Cleaner:Destroy()
	end
end
return v_u_16