-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v_u_3 = require(v1.Packages.spr)
local v4 = require(v1.Packages.Replion)
local v_u_5 = require(v1.Shared.EventUtility)
local v_u_6 = require(v1.Modules.GuiControl)
local v_u_7 = v4.Client:WaitReplion("Events")
local v_u_8 = v2.LocalPlayer.PlayerGui:WaitForChild("HUD"):WaitForChild("Frame"):WaitForChild("Frame")
local v_u_9 = v_u_8:WaitForChild("Inside")
local v_u_10 = v_u_9:WaitForChild("ScrollingFrame")
local v_u_11 = script.Template
v_u_11.Parent = nil
local v_u_12 = {}
local v_u_13 = false
local v14 = {}
local function v_u_17(p15)
	-- upvalues: (copy) v_u_3, (copy) v_u_9
	local v16
	if p15 then
		v16 = {
			["AnchorPoint"] = Vector2.new(1, 0)
		}
	else
		v16 = {
			["AnchorPoint"] = Vector2.new(0, 0)
		}
	end
	v_u_3.stop(v_u_9)
	v_u_3.target(v_u_9, 20, 200, v16)
end
function v14.Init(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (ref) v_u_13, (copy) v_u_17, (copy) v_u_5, (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) v_u_8, (copy) v_u_7
	v_u_6:Hook("Hold Button", v_u_9.Toggle).Clicked:Connect(function()
		-- upvalues: (ref) v_u_13, (ref) v_u_17
		local v18 = not v_u_13
		v_u_13 = v18
		v_u_17(v18)
	end)
	local function v_u_26(p19)
		-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_11, (ref) v_u_10
		if p19.eventId then
			local v20 = v_u_5:GetEvent(p19.eventId)
			if v20 then
				if not v_u_12[p19.eventId] then
					local v21 = v_u_11:Clone()
					local v22 = v21.Inside
					local v23
					if v20.Name:find("Admin") then
						v23 = v20.Name:sub(9, #v20.Name)
					else
						v23 = v20.Name
					end
					v22.Content.Bottom.Display.Header.Text = v23
					v22.Content.Bottom.Description.Text = v20.GlobalDescription or (v20.Description or "???")
					if v20.UseBirthdayColor then
						for _, v24 in v21:GetDescendants() do
							if v24:IsA("UIGradient") then
								v24.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 85, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 170, 255)) })
							end
						end
						v21.Inside.Content.Top.Vector.ImageColor3 = Color3.fromRGB(255, 182, 193)
						v21.Inside.Content.Top.TextLabel.TextColor3 = Color3.fromRGB(255, 182, 193)
					end
					v21.Visible = true
					local v25 = v20.Name
					v21.LayoutOrder = -1000000 - string.len(v25)
					v21.Parent = v_u_10
					v_u_12[p19.eventId] = v21
				end
			else
				return
			end
		else
			return
		end
	end
	local function v33(p27, p28)
		-- upvalues: (copy) v_u_26, (ref) v_u_12, (ref) v_u_8
		for _, v29 in p27 do
			v_u_26(v29)
		end
		for v30, v31 in p28 do
			if p27[v30] == nil then
				if v31.eventId then
					local v32 = v_u_12[v31.eventId]
					if v32 then
						v32:Destroy()
						v_u_12[v31.eventId] = nil
					end
				end
			end
		end
		v_u_8.Visible = next(p27) ~= nil
	end
	v_u_7:OnChange("AdminEvents", v33)
	local v34 = v_u_7:Get("AdminEvents")
	if v34 then
		v33(v34, {})
	end
end
return v14