-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Lighting")
local v2 = game:GetService("ReplicatedStorage")
local v3 = require(v2.Packages.Net)
local v_u_4 = require(v2.Packages.spr)
local v_u_5 = require(v2.Packages.Replion)
local v_u_6 = require(v2.Shared.Soundbook)
local v7 = require(v2.Shared.ItemUtility)
local v_u_8 = require(v2.Controllers.TextNotificationController)
local v_u_9 = v3:RemoteFunction("EquipOxygenTank")
local v_u_10 = v3:RemoteFunction("UnequipOxygenTank")
local v_u_11 = v7.GetItemDataFromItemType("Gears", "Advanced Diving Gear")
return function()
	-- upvalues: (copy) v_u_11, (copy) v_u_5, (copy) v_u_10, (copy) v_u_9, (copy) v_u_6, (copy) v_u_4, (copy) v_u_1, (copy) v_u_8
	if v_u_11 then
		local v12 = v_u_5.Client:GetReplion("Data")
		if v12 then
			local v13, v14
			if v12:Get("EquippedOxygenTankId") == v_u_11.Data.Id then
				v13 = v_u_10:InvokeServer()
				v14 = true
			else
				v13 = v_u_9:InvokeServer(v_u_11.Data.Id)
				v14 = false
			end
			if v13 then
				v_u_6.Sounds.DivingToggle:Play().PlaybackSpeed = 1 + math.random() * 0.3
				v_u_4.stop(v_u_1)
				v_u_1.ExposureCompensation = -0.5
				v_u_4.target(v_u_1, 1, 2, {
					["ExposureCompensation"] = 0
				})
				v_u_8:DeliverNotification({
					["Type"] = "Text",
					["Text"] = ("Advanced Diving Gear: %*"):format(v14 and "Off" or "On"),
					["TextColor"] = v14 and {
						["R"] = 255,
						["G"] = 0,
						["B"] = 0
					} or {
						["R"] = 9,
						["G"] = 255,
						["B"] = 0
					}
				})
			end
		end
	else
		return
	end
end