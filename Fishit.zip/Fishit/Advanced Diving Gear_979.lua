-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 575,
		["Type"] = "Gears",
		["Name"] = "Advanced Diving Gear",
		["Description"] = "An advanced version of the Diving Gear, with much more storage for oxygen!",
		["Icon"] = "rbxassetid://70900622237072",
		["Tier"] = 6
	},
	["MaxOxygen"] = 200000,
	["RegenOxygen"] = 5000,
	["Price"] = 1000000,
	["_moduleScript"] = script
}
return v1