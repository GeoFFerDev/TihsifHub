-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 9,
		["Type"] = "Potions",
		["Name"] = "Advanced Luck",
		["Description"] = "+150%",
		["Icon"] = "rbxassetid://102557247370375",
		["Tier"] = 1
	},
	["Hidden"] = true,
	["Infinite"] = true,
	["Duration"] = 0,
	["Modifiers"] = {
		["BaseLuck"] = 1.5
	},
	["_moduleScript"] = script
}
return v1