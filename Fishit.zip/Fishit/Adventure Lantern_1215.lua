-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 6,
		["Type"] = "Lanterns",
		["Name"] = "Adventure Lantern",
		["Description"] = "",
		["Icon"] = "rbxassetid://134175245832452",
		["Tier"] = 1
	},
	["GripC0"] = CFrame.new(Vector3.new(0, 1.3, 0.9)) * CFrame.fromOrientation(0, 1.5707963267948966, -0.17453292519943295),
	["_moduleScript"] = script
}
return v1