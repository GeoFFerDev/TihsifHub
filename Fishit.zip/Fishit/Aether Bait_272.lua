-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 16,
		["Type"] = "Baits",
		["Name"] = "Aether Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://91317933862702",
		["Tier"] = 6
	},
	["Price"] = 3700000,
	["Modifiers"] = {
		["BaseLuck"] = 2.6,
		["ShinyMultiplier"] = 0.05,
		["MutationMultiplier"] = 0.15
	},
	["_moduleScript"] = script
}
return v1