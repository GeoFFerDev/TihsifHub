-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 177,
		["Type"] = "Fishing Rods",
		["Name"] = "Aether Shard",
		["Description"] = "",
		["Icon"] = "rbxassetid://125006628928474",
		["Tier"] = 2
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1