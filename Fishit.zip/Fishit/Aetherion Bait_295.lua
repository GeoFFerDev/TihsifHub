-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 39,
		["Type"] = "Baits",
		["Name"] = "Aetherion Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://120506387204714",
		["Tier"] = 7
	},
	["Modifiers"] = {
		["BaseLuck"] = 5,
		["ShinyMultiplier"] = 0.1,
		["MutationMultiplier"] = 0.2,
		["SizeMultiplier"] = 0.1
	},
	["_moduleScript"] = script
}
return v1