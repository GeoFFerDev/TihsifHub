-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
return function()
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	require(v_u_1:WaitForChild("Packages"):WaitForChild("Loader")).LoadChildren(v_u_1:WaitForChild("Observers"))
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_2
		if require(v_u_1:WaitForChild("Shared"):WaitForChild("UserPriority")):GetPriorityLevel(v_u_2.LocalPlayer) >= 3 then
			local v3 = require(v_u_1:WaitForChild("CmdrClient"))
			if v3 then
				v3:SetActivationKeys({ Enum.KeyCode.F2 })
			end
		end
	end)
end