-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 14,
		["Type"] = "Variant",
		["Name"] = "Albino",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255)) })
	},
	["Versions"] = 1,
	["Colors"] = 2,
	["SellMultiplier"] = 1.4,
	["Probability"] = {
		["Chance"] = 2.5
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1