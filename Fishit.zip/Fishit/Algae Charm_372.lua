-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 2,
		["Type"] = "Charms",
		["Name"] = "Algae Charm",
		["Description"] = "x1.5 Chance of fishing up a Cryoshade Glider!",
		["Icon"] = "rbxassetid://108632682987377",
		["NewIcon"] = true,
		["Tier"] = 5
	},
	["Level"] = 50,
	["Uses"] = 50,
	["Price"] = 40000,
	["C0"] = CFrame.identity,
	["C1"] = CFrame.identity,
	["Modifiers"] = {
		["BaseLuck"] = 0
	},
	["FishModifiers"] = {
		["Cryoshade Glider"] = 0.5
	},
	["Downloadable"] = true,
	["_moduleScript"] = script
}
return v1