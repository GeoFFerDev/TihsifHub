-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 444,
		["Type"] = "Fish",
		["Name"] = "Alienhead Squid",
		["Description"] = "",
		["Icon"] = "rbxassetid://104195278889702",
		["Tier"] = 3
	},
	["SellPrice"] = 330,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(18, 22),
		["Default"] = NumberRange.new(10, 14)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1