-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 8,
		["Type"] = "Boats",
		["Name"] = "Alpha Floaty",
		["Description"] = "",
		["Icon"] = "rbxassetid://90149134987407",
		["Tier"] = 100
	},
	["HiddenInShop"] = true,
	["Seats"] = 1,
	["_moduleScript"] = script
}
return v1