-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 178,
		["Type"] = "Fishing Rods",
		["Name"] = "Amber",
		["Description"] = "",
		["Icon"] = "rbxassetid://92025920580149",
		["Tier"] = 2
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1