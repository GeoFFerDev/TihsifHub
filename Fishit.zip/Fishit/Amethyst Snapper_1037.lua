-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 632,
		["Type"] = "Fish",
		["Name"] = "Amethyst Snapper",
		["Description"] = "",
		["Icon"] = "rbxassetid://139389336483330",
		["Tier"] = 3
	},
	["SellPrice"] = 320,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8.5, 9.2),
		["Default"] = NumberRange.new(6.2, 7.3)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1