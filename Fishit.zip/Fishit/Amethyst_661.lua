-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 253,
		["Type"] = "Fishing Rods",
		["Name"] = "Amethyst",
		["Description"] = "",
		["Icon"] = "rbxassetid://127662437307615",
		["Tier"] = 6
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.8, -0.25, -2),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, 0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.Angles(-0.08726646259971647, -3.141592653589793, 1.5707963267948966),
	["GripC1"] = CFrame.identity * CFrame.Angles(0.08726646259971647, -3.141592653589793, 1.5707963267948966),
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1