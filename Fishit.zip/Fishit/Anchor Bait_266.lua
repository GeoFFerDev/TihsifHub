-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 11,
		["Type"] = "Baits",
		["Name"] = "Anchor Bait",
		["Description"] = "Why would you ever use this?",
		["Icon"] = "rbxassetid://78860633660517",
		["Tier"] = 95
	},
	["HiddenInShop"] = true,
	["IsSkin"] = true,
	["EquipAsSkin"] = true,
	["_moduleScript"] = script
}
return v1