-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 9,
		["Type"] = "Charms",
		["Name"] = "Anchor Charm",
		["Description"] = "Needs a description!",
		["Icon"] = "rbxassetid://108153466770730",
		["NewIcon"] = true,
		["Tier"] = 5
	},
	["Level"] = 75,
	["Uses"] = 150,
	["C0"] = CFrame.identity,
	["C1"] = CFrame.identity,
	["Modifiers"] = {
		["BaseLuck"] = 0,
		["ReelMultiplier"] = 0.05,
		["SizeMultiplier"] = 0.05
	},
	["FishModifiers"] = {},
	["Downloadable"] = true,
	["_moduleScript"] = script
}
return v1