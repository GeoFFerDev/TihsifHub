-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 262,
		["Type"] = "Fish",
		["Name"] = "Ancient Arapaima",
		["Description"] = "",
		["Icon"] = "rbxassetid://83287284251523",
		["Tier"] = 2
	},
	["SellPrice"] = 64,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(31, 36),
		["Default"] = NumberRange.new(22, 28)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1