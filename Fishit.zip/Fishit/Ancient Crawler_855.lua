-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 443,
		["Type"] = "Fish",
		["Name"] = "Ancient Crawler",
		["Description"] = "",
		["Icon"] = "rbxassetid://132304105842168",
		["Tier"] = 3
	},
	["SellPrice"] = 330,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(24, 28),
		["Default"] = NumberRange.new(17, 20)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1