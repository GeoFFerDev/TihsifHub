-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 1
}
local v2 = {
	["Priority"] = 10,
	["Music"] = {
		["SoundId"] = "rbxassetid://110762334423902",
		["Volume"] = 0.1
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(124, 77, 115),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(117, 62, 62)
	},
	["Atmosphere"] = {
		["Density"] = 0.32,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(152, 255, 181),
		["Decay"] = Color3.fromRGB(204, 239, 90)
	},
	["Clouds"] = {
		["Color"] = Color3.fromRGB(178, 255, 187)
	}
}
v1.Day = v2
local v3 = {
	["Priority"] = 10,
	["Music"] = {
		["SoundId"] = "rbxassetid://110762334423902",
		["Volume"] = 0.1
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(124, 77, 115),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(117, 62, 62)
	},
	["Atmosphere"] = {
		["Density"] = 0.32,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(152, 255, 181),
		["Decay"] = Color3.fromRGB(204, 239, 90)
	},
	["Clouds"] = {
		["Color"] = Color3.fromRGB(56, 121, 60)
	}
}
v1.Night = v3
return v1