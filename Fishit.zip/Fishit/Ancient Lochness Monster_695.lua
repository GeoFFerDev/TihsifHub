-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 345,
		["Type"] = "Fish",
		["Name"] = "Ancient Lochness Monster",
		["Description"] = "",
		["Icon"] = "rbxassetid://122849883484708",
		["Tier"] = 7
	},
	["SellPrice"] = 20000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(338000, 381000),
		["Default"] = NumberRange.new(260000, 295000)
	},
	["Probability"] = {
		["Chance"] = 3.3333333333333335e-7
	},
	["Events"] = { "Ancient Ruin" },
	["_moduleScript"] = script
}
return v1