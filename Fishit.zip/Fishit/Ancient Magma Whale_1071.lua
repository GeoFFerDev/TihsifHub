-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 676,
		["Type"] = "Fish",
		["Name"] = "Ancient Magma Whale",
		["Description"] = "",
		["Icon"] = "rbxassetid://79419619363511",
		["Tier"] = 7
	},
	["SellPrice"] = 400000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(770000, 860000),
		["Default"] = NumberRange.new(630000, 740000)
	},
	["Probability"] = {
		["Chance"] = 2e-7
	},
	["_moduleScript"] = script
}
return v1