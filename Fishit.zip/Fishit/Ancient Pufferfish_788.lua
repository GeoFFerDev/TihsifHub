-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 346,
		["Type"] = "Fish",
		["Name"] = "Ancient Pufferfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://94080226439959",
		["Tier"] = 5
	},
	["SellPrice"] = 4500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.1, 3.8),
		["Default"] = NumberRange.new(2.2, 2.6)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1