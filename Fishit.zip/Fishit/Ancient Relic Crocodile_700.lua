-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 264,
		["Type"] = "Fish",
		["Name"] = "Ancient Relic Crocodile",
		["Description"] = "",
		["Icon"] = "rbxassetid://131025252592514",
		["Tier"] = 6
	},
	["SellPrice"] = 98000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(18684, 22914),
		["Default"] = NumberRange.new(10638, 16257)
	},
	["Probability"] = {
		["Chance"] = 4.081632653061224e-6
	},
	["_moduleScript"] = script
}
return v1