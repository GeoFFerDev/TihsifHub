-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 23,
		["Type"] = "Boats",
		["Name"] = "Ancient Ship",
		["Description"] = "",
		["Icon"] = "rbxassetid://111560216162492",
		["Tier"] = 6
	},
	["HiddenInShop"] = true,
	["Seats"] = 7,
	["_moduleScript"] = script
}
return v1