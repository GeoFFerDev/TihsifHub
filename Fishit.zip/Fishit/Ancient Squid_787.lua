-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 347,
		["Type"] = "Fish",
		["Name"] = "Ancient Squid",
		["Description"] = "",
		["Icon"] = "rbxassetid://103962641004338",
		["Tier"] = 6
	},
	["SellPrice"] = 95000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(6380, 7032),
		["Default"] = NumberRange.new(4923, 5700)
	},
	["Probability"] = {
		["Chance"] = 0.000011111111111111112
	},
	["_moduleScript"] = script
}
return v1