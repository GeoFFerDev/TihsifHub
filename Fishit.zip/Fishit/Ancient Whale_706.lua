-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 295,
		["Type"] = "Fish",
		["Name"] = "Ancient Whale",
		["Description"] = "",
		["Icon"] = "rbxassetid://106712272327597",
		["Tier"] = 7
	},
	["SellPrice"] = 270000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(388502, 410935),
		["Default"] = NumberRange.new(310893, 355731)
	},
	["Probability"] = {
		["Chance"] = 3.6363636363636366e-7
	},
	["_moduleScript"] = script
}
return v1