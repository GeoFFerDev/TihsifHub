-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 124,
		["Type"] = "Fishing Rods",
		["Name"] = "Angelic Rod",
		["Description"] = "LIMITED - Valentine Pack",
		["Icon"] = "rbxassetid://103391024554005",
		["Tier"] = 100
	},
	["EquipAsSkin"] = true,
	["VisualClickPowerPercent"] = 0.29,
	["ClickPower"] = 0.135,
	["Resilience"] = 3.8,
	["Windup"] = NumberRange.new(3.01, 3.8499999999999996),
	["MaxWeight"] = 75000,
	["LinkedGamePass"] = "Valentine Pack"
}
local v2 = {
	["BaseLuck"] = 1.8,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1