-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 149,
		["Type"] = "Fish",
		["Name"] = "Angler Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://95565358831204",
		["Tier"] = 4
	},
	["SellPrice"] = 3620,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(70.1, 76.5),
		["Default"] = NumberRange.new(57.2, 65.3)
	},
	["Probability"] = {
		["Chance"] = 0.0003333333333333333
	},
	["_moduleScript"] = script
}
return v1