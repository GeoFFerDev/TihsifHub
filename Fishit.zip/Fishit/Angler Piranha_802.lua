-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 384,
		["Type"] = "Fish",
		["Name"] = "Freshwater Piranha",
		["Description"] = "",
		["Icon"] = "rbxassetid://138330943047773",
		["Tier"] = 3
	},
	["SellPrice"] = 410,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(18, 24),
		["Default"] = NumberRange.new(12, 16)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1