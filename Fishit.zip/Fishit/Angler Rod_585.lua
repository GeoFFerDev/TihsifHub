-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 168,
		["Type"] = "Fishing Rods",
		["Name"] = "Angler Rod",
		["Description"] = "",
		["Icon"] = "rbxassetid://76924330674942",
		["Tier"] = 6
	},
	["ClickPower"] = 0.22,
	["Resilience"] = 5.2,
	["Windup"] = NumberRange.new(2.8, 3.2),
	["Price"] = 8000000,
	["HiddenInShop"] = true,
	["MaxWeight"] = 500000
}
local v2 = {
	["BaseLuck"] = 5.3,
	["Frequency"] = {
		["Golden"] = 2,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1