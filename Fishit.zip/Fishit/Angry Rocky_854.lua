-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 442,
		["Type"] = "Fish",
		["Name"] = "Angry Rocky",
		["Description"] = "",
		["Icon"] = "rbxassetid://86379985934607",
		["Tier"] = 2
	},
	["SellPrice"] = 55,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8, 10),
		["Default"] = NumberRange.new(4, 6)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1