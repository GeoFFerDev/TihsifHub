-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 348,
		["Type"] = "Fish",
		["Name"] = "Angrylion Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://135099762730215",
		["Tier"] = 4
	},
	["SellPrice"] = 3330,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(135, 221),
		["Default"] = NumberRange.new(75, 105)
	},
	["Probability"] = {
		["Chance"] = 0.0005
	},
	["_moduleScript"] = script
}
return v1