-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
game:GetService("Players")
local v_u_2 = require(v1.Packages.Observers)
local v_u_3 = require(v1.Shared.TierUtility)
v_u_2.observePlayer(function(p4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v_u_6 = v_u_2.observeAttribute(p4, "SelectedRarity", function(p5)
		-- upvalues: (ref) v_u_3
		if p5 then
			p5 = v_u_3:GetTier(p5)
		end
	end)
	return function()
		-- upvalues: (copy) v_u_6
		v_u_6()
	end
end)
return {}