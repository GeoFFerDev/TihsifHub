-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
local v_u_2 = game:GetService("CollectionService")
v1.RenderStepped:Connect(function(p3)
	-- upvalues: (copy) v_u_2
	local v4 = v_u_2:GetTagged("AnimateTier")
	local v5 = p3 * 60 * 3
	for _, v6 in ipairs(v4) do
		v6.Rotation = v6.Rotation + v5
	end
end)
return {}