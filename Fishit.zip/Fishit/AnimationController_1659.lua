-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("ContentProvider")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("Players").LocalPlayer
local v_u_6 = require(v4.Packages.Replion).Client
local v_u_7 = require(v4.Packages.Trove)
local v_u_8 = require(v4.Packages.Signal)
local v_u_9 = require(v4.Shared.Soundbook)
local v_u_10 = require(v4.Modules.Animations)
require(v4.Modules.NPC)
local v_u_11 = require(v4.Shared.PlayerStatsUtility)
local v_u_12 = require(v4.Shared.ItemUtility)
local v_u_13 = require(script:WaitForChild("MarkerOffsets"))
local v_u_14 = require(v4.Shared.RodThrowVFXData)
local v_u_15 = require(v4.Controllers.VFXController)
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_128 = {
	["MarkerListener"] = v_u_8.new(),
	["MarkerOffsets"] = v_u_13,
	["Init"] = function(_)
		-- upvalues: (copy) v_u_5, (copy) v_u_17, (copy) v_u_18
		v_u_5.CharacterRemoving:Connect(function(p20)
			-- upvalues: (ref) v_u_17
			for _, v21 in ipairs(v_u_17) do
				task.spawn(v21, p20)
			end
		end)
		v_u_5.CharacterAdded:Connect(function(p22)
			-- upvalues: (ref) v_u_18
			for _, v23 in ipairs(v_u_18) do
				task.delay(0, v23, p22)
			end
		end)
	end,
	["Start"] = function(_)
		-- upvalues: (copy) v_u_128
		v_u_128:RegisterCharacterAdded(function(_)
			-- upvalues: (ref) v_u_128
			v_u_128:_preloadTracks()
		end)
		v_u_128:RegisterCharacterRemoving(function(_)
			-- upvalues: (ref) v_u_128
			v_u_128:_destroyActiveTracks()
		end)
	end,
	["_destroyActiveTracks"] = function(_)
		-- upvalues: (copy) v_u_19
		for _, v24 in v_u_19 do
			v24:Stop()
			v24:Destroy()
		end
		table.clear(v_u_19)
	end,
	["_preloadTracks"] = function(_)
		-- upvalues: (copy) v_u_10, (copy) v_u_128, (copy) v_u_3
		local v_u_25 = {}
		for v26, v27 in v_u_10 do
			if not v27.Disabled and (not v26:find("NPC") and v27.Animation) then
				local v28 = v27.Animation
				table.insert(v_u_25, v28)
			end
		end
		task.defer(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_128
			for v29, v30 in v_u_10 do
				if not (v30.Disabled or v29:find("NPC")) then
					v_u_128:AddAnimation(v29)
					task.wait(0.1)
				end
			end
		end)
		pcall(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_25
			v_u_3:PreloadAsync(v_u_25)
		end)
	end,
	["StopAnimation"] = function(_, p31)
		-- upvalues: (copy) v_u_128, (copy) v_u_16, (copy) v_u_2, (copy) v_u_19
		local v32, v33 = v_u_128:GetAnimationData(p31)
		if v32 then
			v_u_16[v33] = v_u_2:GenerateGUID(false)
			local v34 = v_u_19[v32.AnimationId]
			if v34 then
				v34:Stop()
			end
		end
	end,
	["GetAnimationData"] = function(_, p35)
		-- upvalues: (copy) v_u_10, (copy) v_u_6, (copy) v_u_11, (copy) v_u_12
		local v36 = v_u_10[p35]
		local v37 = nil
		local v38
		if v36 and v36.Variants then
			local v39 = v_u_6:GetReplion("Data")
			if v39 then
				local v40 = v39:GetExpect("EquippedSkinUUID")
				local v_u_41 = v39:GetExpect("EquippedItems")[1]
				if string.len(v40) > 0 then
					v_u_41 = v40
				end
				local v43 = v_u_11:GetItemFromInventory(v39, function(p42)
					-- upvalues: (ref) v_u_41
					return p42.UUID == v_u_41
				end, "Fishing Rods")
				if v43 then
					local v44 = v_u_12.GetItemDataFromItemType("Fishing Rods", v43.Id)
					if v44 then
						v38 = ("%s - %s"):format(v44.Data.Name, p35)
						if not v_u_10[v38] then
							v38 = v37
						end
					else
						v38 = v37
					end
				else
					v38 = v37
				end
			else
				v38 = v37
			end
		else
			v38 = v37
		end
		if v_u_10[v38] then
			return v_u_10[v38], v38
		else
			return v36, p35
		end
	end,
	["IsDisabled"] = function(_, p45)
		-- upvalues: (copy) v_u_128
		local v46, _ = v_u_128:GetAnimationData(p45)
		if v46 then
			return v46.Disabled and true or false
		else
			return false
		end
	end,
	["PlayAnimation"] = function(_, p47, p48)
		-- upvalues: (copy) v_u_128, (copy) v_u_2, (copy) v_u_16, (copy) v_u_19, (copy) v_u_6, (copy) v_u_7, (copy) v_u_14, (copy) v_u_5, (copy) v_u_15, (copy) v_u_9
		local v49, v50 = v_u_128:GetAnimationData(p47)
		if v49 then
			v_u_16[v50] = v_u_2:GenerateGUID(false)
			local v51 = v_u_19[v49.AnimationId]
			local v52
			if v51 == nil then
				v51, v52 = v_u_128:AddAnimation(v50)
			else
				v52 = nil
			end
			local v53 = v_u_6:GetReplion("Data")
			if v51 and v53 then
				v51:Play(nil, nil, v49.PlaybackSpeed)
				local v_u_54 = v53:Get({ "Settings", "Self Rod VFX" })
				local v_u_55 = v_u_7.new()
				v_u_55:Add(v51:GetMarkerReachedSignal("Throw"):Once(function(p56)
					-- upvalues: (ref) v_u_14, (ref) v_u_5, (copy) v_u_54, (ref) v_u_15
					if p56 and v_u_14[p56] then
						if v_u_14[p56].PlayAttachment then
							local v57 = v_u_5.Character:FindFirstChild("CastingEmitVFX", true)
							if v57 and v_u_54 then
								v_u_15.Handle(p56, v57)
								return
							end
						elseif v_u_54 then
							v_u_15.Handle(p56, v_u_5.Character.HumanoidRootPart.CFrame * v_u_14[p56].Offset)
						end
					end
				end))
				v_u_55:Add(v51.Stopped:Once(function()
					-- upvalues: (copy) v_u_55
					v_u_55:Clean()
				end))
				v_u_55:Add(v51.Destroying:Once(function()
					-- upvalues: (copy) v_u_55
					v_u_55:Clean()
				end))
				if p48 then
					v51.Ended:Wait()
					v_u_55:Clean()
				end
			end
			local v58 = v49.CustomCastSFX and v_u_5.Character
			if v58 then
				v_u_9:RenderAt(v49.CustomCastSFX, v58:GetPivot().Position)
			end
			return v51, v52
		end
	end,
	["AddAnimation"] = function(_, p_u_59)
		-- upvalues: (copy) v_u_5, (copy) v_u_10, (copy) v_u_19, (copy) v_u_7, (copy) v_u_8, (copy) v_u_16, (copy) v_u_128, (copy) v_u_13, (copy) v_u_1
		local v60 = v_u_5.Character
		if v60 then
			local v61 = v60:FindFirstChildWhichIsA("Humanoid")
			if v61 then
				local v_u_62 = v61:FindFirstChildWhichIsA("Animator")
				if v_u_62 then
					local v_u_63 = v_u_10[p_u_59]
					if v_u_63 then
						local v_u_64 = v_u_63.Animation
						if v_u_64 then
							local v65 = v_u_19[v_u_63.AnimationId]
							if not v65 then
								local v66 = v_u_63.CustomMarkers
								local v67 = v_u_63.LinkedMarkers
								local v_u_68 = v_u_63.LinkedAnimations
								local _ = v_u_63.PlaybackSpeed
								local v69 = v_u_63.Looped
								local v70 = v_u_63.TimePosition
								local _ = v_u_63.Looped
								if not v65 then
									local v_u_71 = v_u_7.new()
									local v_u_72 = v_u_8.new()
									local v_u_73 = v_u_8.new()
									local v_u_74 = v_u_8.new()
									local v_u_75 = v_u_8.new()
									local v_u_76 = nil
									local v77
									if v67 then
										v77 = next(v67) ~= nil
									else
										v77 = false
									end
									local v78
									if v_u_68 then
										v78 = #v_u_68 > 0
									else
										v78 = false
									end
									v_u_71:Add(function()
										-- upvalues: (copy) v_u_72, (copy) v_u_73, (copy) v_u_74, (copy) v_u_75, (ref) v_u_76, (ref) v_u_19, (copy) v_u_63
										v_u_72:DisconnectAll()
										v_u_72:Destroy()
										v_u_73:DisconnectAll()
										v_u_73:Destroy()
										v_u_74:DisconnectAll()
										v_u_74:Destroy()
										v_u_75:DisconnectAll()
										v_u_75:Destroy()
										v_u_76 = nil
										v_u_19[v_u_63.AnimationId] = nil
									end)
									local v_u_79, v_u_80 = pcall(function()
										-- upvalues: (copy) v_u_62, (copy) v_u_64
										return v_u_62:LoadAnimation(v_u_64)
									end)
									local function v_u_82()
										-- upvalues: (ref) v_u_80, (ref) v_u_16, (copy) p_u_59, (ref) v_u_76, (copy) v_u_68, (ref) v_u_128, (ref) v_u_79
										if v_u_80.TimePosition == v_u_80.Length then
											if v_u_76 == v_u_16[p_u_59] then
												for _, v81 in ipairs(v_u_68) do
													task.spawn(v_u_128.PlayAnimation, v_u_128, v81)
												end
											elseif v_u_79 then
												v_u_80:Stop()
											end
										else
											return
										end
									end
									if v_u_79 then
										if v69 ~= nil then
											v_u_80.Looped = v69
										end
										if v70 then
											v_u_80.TimePosition = v70
										end
										v_u_71:Add(v_u_80:GetPropertyChangedSignal("IsPlaying"):Connect(function()
											-- upvalues: (ref) v_u_80, (ref) v_u_76, (ref) v_u_16, (copy) p_u_59
											if v_u_80.IsPlaying then
												v_u_76 = v_u_16[p_u_59]
											end
										end))
										local v_u_83
										if v77 then
											v_u_83 = v_u_80
											local v_u_84 = v_u_79
											for v_u_85, v_u_86 in v67 do
												v_u_71:Add(v_u_83:GetMarkerReachedSignal(v_u_85):Connect(function()
													-- upvalues: (copy) v_u_85, (copy) v_u_86, (ref) v_u_16, (copy) p_u_59, (ref) v_u_76, (copy) v_u_72, (ref) v_u_128, (ref) v_u_84, (ref) v_u_83
													local v87 = v_u_85
													local v88 = v_u_86
													if v_u_16[p_u_59] == v_u_76 then
														v_u_72:Fire(v87)
														if typeof(v88) == "string" then
															v_u_128:PlayAnimation(v88)
															return
														end
													elseif v_u_84 then
														v_u_83:Stop()
													end
												end))
											end
										else
											v_u_83 = v_u_80
										end
										if v66 then
											for _, v_u_89 in v66 do
												v_u_71:Add(v_u_83:GetMarkerReachedSignal(v_u_89):Connect(function()
													-- upvalues: (ref) v_u_128, (copy) v_u_89
													v_u_128.MarkerListener:Fire(v_u_89)
												end))
											end
										end
										if v78 then
											v_u_71:Add(v_u_83.Stopped:Connect(function()
												-- upvalues: (copy) v_u_82
												v_u_82()
											end))
										end
										v_u_19[v_u_63.AnimationId] = v_u_83
										v_u_83.Destroying:Once(function()
											-- upvalues: (copy) v_u_71
											v_u_71:Destroy()
										end)
										return v_u_83
									end
									local v_u_90 = v_u_71:Extend()
									if v77 then
										local v_u_91 = v_u_80
										local v_u_92 = v_u_79
										for v_u_93, v_u_94 in v67 do
											local v_u_95 = v_u_13[v_u_93]
											if v_u_95 then
												local v_u_99 = v_u_73:Connect(function(p96)
													-- upvalues: (copy) v_u_95, (copy) v_u_93, (copy) v_u_94, (ref) v_u_16, (copy) p_u_59, (ref) v_u_76, (copy) v_u_72, (ref) v_u_128, (ref) v_u_92, (ref) v_u_91
													task.wait(v_u_95 / (p96 or 1))
													local v97 = v_u_93
													local v98 = v_u_94
													if v_u_16[p_u_59] == v_u_76 then
														v_u_72:Fire(v97)
														if typeof(v98) == "string" then
															v_u_128:PlayAnimation(v98)
															return
														end
													elseif v_u_92 then
														v_u_91:Stop()
													end
												end)
												v_u_71:Add(function()
													-- upvalues: (copy) v_u_99
													v_u_99:Disconnect()
												end)
											end
										end
									end
									if v66 then
										for _, v_u_100 in v66 do
											local v_u_101 = v_u_13[v_u_100]
											if v_u_101 then
												local v_u_103 = v_u_73:Connect(function(p102)
													-- upvalues: (copy) v_u_101, (ref) v_u_128, (copy) v_u_100
													task.wait(v_u_101 / (p102 or 1))
													v_u_128.MarkerListener:Fire(v_u_100)
												end)
												v_u_71:Add(function()
													-- upvalues: (copy) v_u_103
													v_u_103:Disconnect()
												end)
											end
										end
									end
									if v78 then
										local v_u_104 = v_u_74:Connect(function()
											-- upvalues: (copy) v_u_82
											v_u_82()
										end)
										v_u_71:Add(function()
											-- upvalues: (copy) v_u_104
											v_u_104:Disconnect()
										end)
									end
									local v_u_110 = {
										["Play"] = function(_, _, _, _, p105)
											-- upvalues: (ref) v_u_76, (ref) v_u_16, (copy) p_u_59, (copy) v_u_73
											v_u_76 = v_u_16[p_u_59]
											v_u_73:Fire(p105)
										end,
										["Stop"] = function(_)
											-- upvalues: (copy) v_u_90, (copy) v_u_74, (copy) v_u_75
											v_u_90:Clean()
											v_u_74:Fire()
											v_u_75:Fire()
										end,
										["Destroy"] = function(_)
											-- upvalues: (copy) v_u_90, (copy) v_u_74, (copy) v_u_75, (copy) v_u_71
											v_u_90:Clean()
											v_u_74:Fire()
											v_u_75:Fire()
											v_u_71:Destroy()
										end,
										["Stopped"] = {
											["Connect"] = function(_, p106)
												-- upvalues: (copy) v_u_74
												v_u_74:Connect(p106)
											end,
											["Once"] = function(_, p107)
												-- upvalues: (copy) v_u_74
												v_u_74:Once(p107)
											end
										},
										["Ended"] = {
											["Connect"] = function(_, p108)
												-- upvalues: (copy) v_u_75
												v_u_75:Connect(p108)
											end,
											["Once"] = function(_, p109)
												-- upvalues: (copy) v_u_75
												v_u_75:Once(p109)
											end
										},
										["TimePosition"] = 0,
										["Length"] = v_u_63.Length or 0
									}
									local v_u_115 = v_u_73:Connect(function()
										-- upvalues: (copy) v_u_90, (copy) v_u_110, (ref) v_u_1, (copy) v_u_75
										local v_u_111 = false
										v_u_90:Clean()
										v_u_110.TimePosition = 0
										v_u_90:Add(v_u_1.PreAnimation:Connect(function(_)
											-- upvalues: (ref) v_u_110, (ref) v_u_111, (ref) v_u_75
											local v112 = v_u_110
											local v113 = v_u_110.TimePosition
											local v114 = v_u_110.Length
											v112.TimePosition = math.min(v113, v114)
											if not v_u_111 and v_u_110.TimePosition >= v_u_110.Length then
												v_u_111 = true
												v_u_75:Fire()
											end
										end))
									end)
									v_u_90:Add(function()
										-- upvalues: (copy) v_u_115
										v_u_115:Disconnect()
									end)
									v_u_79 = true
									v_u_80 = v_u_110
									v_u_19[v_u_63.AnimationId] = v_u_110
									return v_u_80
								end
							end
						else
							return
						end
					else
						return
					end
				else
					return
				end
			else
				return
			end
		else
			return
		end
	end,
	["DestroyActiveAnimationTracks"] = function(_, p116)
		-- upvalues: (copy) v_u_10, (copy) v_u_19, (copy) v_u_16
		local v117 = p116 or {}
		for v118, v119 in pairs(v_u_10) do
			if not v119.Disabled then
				local v120 = v_u_19[v119.AnimationId]
				if v120 and not table.find(v117, v118) then
					local v121 = v118:split(" ")
					local v122 = v121[#v121]
					if not table.find(v117, v122) then
						if v_u_16[v118] then
							v_u_16[v118] = nil
						end
						v120:Stop()
					end
				end
			end
		end
	end,
	["RegisterCharacterRemoving"] = function(_, p123)
		-- upvalues: (copy) v_u_17
		local v124 = v_u_17
		table.insert(v124, p123)
	end,
	["RegisterCharacterAdded"] = function(_, p125)
		-- upvalues: (copy) v_u_18, (copy) v_u_5
		local v126 = v_u_18
		table.insert(v126, p125)
		local v127 = v_u_5.Character
		if v127 then
			task.spawn(p125, v127)
		end
	end
}
return v_u_128