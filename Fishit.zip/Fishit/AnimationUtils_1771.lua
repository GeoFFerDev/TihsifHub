-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["new"] = function(p1)
		local v_u_2 = p1.RenderStepped
		local v_u_3 = p1.Easing
		local v4 = p1.Settings
		local v_u_5 = p1.activeEggs
		local v_u_6 = p1.Bezier
		local v_u_7 = p1.autoControlPoint
		local v_u_8 = v4.Timings
		local v_u_9 = v4.Other
		local function v_u_14(p10)
			-- upvalues: (copy) v_u_5, (copy) v_u_8
			local v11 = {}
			local v12 = 0
			for v13 in pairs(v_u_5) do
				if p10 ~= v13 and (not v13.completed and p10.priority > v13.priority) then
					v11[v13.priority] = true
				end
			end
			for _ in pairs(v11) do
				v12 = v12 + v_u_8.PauseDuration
			end
			return v12
		end
		return {
			["scaleModelIn"] = function(p_u_15)
				-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_8
				v_u_2(function(_, p16)
					-- upvalues: (copy) p_u_15, (ref) v_u_3
					p_u_15:ScaleTo(v_u_3.ExpoInOut(p16))
				end, v_u_8.UpscaleDuration, true)
				p_u_15:ScaleTo(1)
			end,
			["moveModelToOffset"] = function(p_u_17, p18, p19)
				-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_8
				local v20 = p_u_17:GetExtentsSize().Y / 2
				local v21 = p19 + Vector3.new(0, v20, 0)
				local v_u_22 = v_u_6(p18, v_u_7(p18, v21), v21)
				v_u_2(function(_, p23)
					-- upvalues: (copy) p_u_17, (copy) v_u_22
					local v24 = p23 * 3.141592653589793 / 2
					local v25 = 1 - math.cos(v24)
					p_u_17:PivotTo(CFrame.new(v_u_22(v25)) * p_u_17:GetPivot().Rotation)
				end, v_u_8.MoveDuration, true):Wait()
				p_u_17:PivotTo(CFrame.new(v21) * p_u_17:GetPivot().Rotation)
			end,
			["bounceModel"] = function(p_u_26, p_u_27)
				-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_8
				v_u_2(function(_, p28)
					-- upvalues: (ref) v_u_3, (copy) p_u_26, (copy) p_u_27, (ref) v_u_9
					local v29 = 1 - v_u_3.BounceOut(p28)
					local v30 = p_u_26
					local v31 = p_u_27
					local v32 = v_u_9.BounceHeight
					v30:PivotTo(v31 + Vector3.new(0, v32, 0) * v29)
				end, v_u_8.BounceDuration, true):Wait()
				p_u_26:PivotTo(p_u_27)
			end,
			["hopSpinModel"] = function(p_u_33, p_u_34, p35, p36, p37, p38)
				-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3
				local v_u_39 = p35 or 1
				local v40 = p37 or v_u_8.BounceDuration
				local v_u_41 = p36 or v_u_9.BounceHeight * 1.05
				local v42 = p38 or 0
				if v42 > 0 then
					task.wait(v42)
				end
				v_u_2(function(_, p43)
					-- upvalues: (ref) v_u_3, (copy) v_u_39, (copy) v_u_41, (copy) p_u_33, (copy) p_u_34
					local v44 = v_u_3.ExpoInOut(p43)
					local v45 = 360 * v_u_39 * v44
					local v46 = math.rad(v45)
					local v47 = p43 * 3.141592653589793
					local v48 = math.sin(v47) * v_u_41
					p_u_33:PivotTo(p_u_34 * CFrame.Angles(0, v46, 0) + Vector3.new(0, v48, 0))
				end, v40, true):Wait()
				p_u_33:PivotTo(p_u_34)
			end,
			["computeShakePause"] = v_u_14,
			["shakeModel"] = function(p_u_49, p_u_50, p_u_51)
				-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2, (copy) v_u_14, (copy) v_u_3
				local v_u_52 = v_u_8.ShakePreDuration * 1.35
				local v_u_53 = v_u_8.ShakePostDuration * 1.35
				local v_u_54 = v_u_52 + v_u_53
				local v_u_55 = 0
				local v_u_56 = v_u_9.BounceHeight
				local v_u_57 = v_u_9.ShakePitchMagnitude
				local v_u_58 = v_u_9.ShakePitchA
				local v_u_59 = v_u_9.ShakePitchB
				v_u_2(function(_, p60)
					-- upvalues: (ref) v_u_14, (copy) p_u_50, (ref) v_u_55, (copy) v_u_54, (copy) v_u_52, (copy) v_u_53, (ref) v_u_3, (copy) v_u_57, (copy) v_u_58, (copy) v_u_59, (copy) v_u_56, (copy) p_u_49, (copy) p_u_51
					local v61 = v_u_14(p_u_50)
					local v62 = v_u_55
					v_u_55 = math.max(v62, v61)
					if v_u_54 + v_u_55 <= p60 then
						return true
					end
					local v63 = p60 / v_u_54
					local v64 = math.clamp(v63, 0, 1.5)
					local v65 = p60 / v_u_52
					local v66 = math.clamp(v65, 0, 1)
					local v67 = v_u_53
					local v68 = (p60 - (v_u_54 - v_u_53)) / math.max(v67, 0.001)
					local v69 = math.clamp(v68, 0, 1)
					local v70 = 1 - v_u_3.QuadOut(v69)
					local v71 = v_u_3.QuadOut(v66) * v70
					local v72 = v63 * 0.7
					local v73 = v_u_57 * 1.4
					local v74 = 6.283185307179586 * (v72 * (v64 * v_u_58) * v_u_59)
					local v75 = 6.283185307179586 * (v72 * (v64 * (v_u_58 + 0.4)) * (v_u_59 + 2))
					local v76 = 6.283185307179586 * (v72 * (v64 * (v_u_58 + 0.9)) * (v_u_59 + 4))
					local v77 = v73 * math.sin(v74) * v71
					local v78 = math.rad(v77)
					local v79 = v73 * 0.7 * math.sin(v75) * v71
					local v80 = math.rad(v79)
					local v81 = v73 * 0.4 * math.cos(v76) * v71
					local v82 = math.rad(v81)
					local v83 = v_u_56 * 0.28
					local v84 = 6.283185307179586 * v72 * 4
					local v85 = v83 * math.sin(v84) * v71
					local v86 = v_u_56 * 0.16
					local v87 = 6.283185307179586 * v72 * 5
					local v88 = v86 * math.cos(v87) * v71
					local v89 = v_u_56 * 0.12
					local v90 = 6.283185307179586 * v72 * 3.5
					local v91 = v89 * math.sin(v90) * v71
					p_u_49:PivotTo(p_u_51 * CFrame.fromOrientation(v78, v80, v82) + Vector3.new(v88, v85, v91))
					return false
				end):Wait()
				p_u_49:PivotTo(p_u_51)
			end,
			["animateLid"] = function(p_u_92, p_u_93)
				-- upvalues: (copy) v_u_2, (copy) v_u_8
				v_u_2(function(p94)
					-- upvalues: (ref) v_u_8, (copy) p_u_93, (copy) p_u_92
					local v95 = p94 / v_u_8.OpenTime * p_u_93
					local v96 = math.rad(v95)
					if p_u_92:IsA("BasePart") then
						local v97 = p_u_92.CFrame
						local v98 = v97 * CFrame.new(p_u_92.PivotOffset.Position)
						local v99 = v98:Inverse() * v97
						p_u_92.CFrame = v98 * CFrame.Angles(v96, 0, 0) * v99
					else
						p_u_92:PivotTo(p_u_92:GetPivot() * CFrame.Angles(v96, 0, 0))
					end
				end, v_u_8.OpenTime):Wait()
			end,
			["applyLegendaryLight"] = function(p_u_100, p101)
				-- upvalues: (copy) v_u_2
				v_u_2(function(_, p102)
					-- upvalues: (copy) p_u_100
					local v103 = p102 / 1.5 % 1
					p_u_100.Color = Color3.fromHSV(v103, 1, 1)
				end, p101):Wait()
			end
		}
	end
}