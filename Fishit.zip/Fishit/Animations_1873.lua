-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ContentProvider")
local v1 = game:GetService("RunService")
v1:IsClient()
local v2 = v1:IsServer()
local v3 = {
	["Disabled"] = true
}
local v4 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://133354558740014",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v5 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://140344626493067",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v6 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://129632039690279",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v7 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://84396532594877",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v8 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://112759143341343",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v9 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://85246394508551",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v10 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://92036914464034",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
local v11 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://86376110148779",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
local v12 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://76325124055693",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 5,
	["PlaybackSpeed"] = 1.2
}
local v13 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://126831815839724",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 4
}
local v14 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://115229621326605",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.08
}
local v15 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://104188512165442",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 6
}
local v16 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://110738276580375",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.55
}
local v17 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://74643095451174",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.09
}
local v18 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://81700883907369",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.08
}
local v19 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://138790747812051",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.08
}
local v20 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://98716967215984",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.08
}
local v21 = {
	["AnimationOverride"] = {
		["Variants"] = true,
		["AnimationId"] = "",
		["AnimationPriority"] = Enum.AnimationPriority.Core,
		["Length"] = 0
	}
}
local v22 = {
	["Variants"] = true,
	["AnimationId"] = "rbxassetid://92624107165273",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.966,
	["LinkedMarkers"] = {
		["THROW_LINE"] = "ReelingIdle"
	}
}
v21.RodThrow = v22
v21.ReelingIdle = {
	["Variants"] = true,
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://134965425664034",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.316
}
v21.ReelStart = {
	["Variants"] = true,
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://136614469321844",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 0.666,
	["LinkedAnimations"] = { "ReelingIdle" }
}
v21.ReelIntermission = {
	["Variants"] = true,
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://114959536562596",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 1.316
}
local v23 = {
	["Variants"] = true,
	["AnimationId"] = "rbxassetid://117319000848286",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 1.233,
	["LinkedMarkers"] = {
		["FISH_CAUGHT"] = true
	}
}
v21.FishCaught = v23
v21.EquipIdleFake = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://96586569072385",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 0.5
}
v21.EquipIdle = {
	["Variants"] = true,
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://96586569072385",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 0.5
}
v21["Electric Guitar - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://108792932396384",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 8.33
}
v21["Electric Guitar - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://108792932396384",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 8.33
}
v21["Pirate Banjo - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://120677591068007",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 10.5
}
v21["Pirate Banjo - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://120677591068007",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 10.5
}
v21["Kraken Anchor - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://126023229958416",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 12.5
}
v21["Oceanic Harpoon - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://77549515147440",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 8.33,
	["PlaybackSpeed"] = 1.2
}
v21["Oceanic Harpoon - RodThrow"] = {
	["AnimationId"] = "rbxassetid://127872348080219",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["PlaybackSpeed"] = 2.5,
	["Length"] = 1.88,
	["CustomMarkers"] = { "ADD_ARROW", "HARP_THROW_LINE" },
	["LinkedAnimations"] = { "Oceanic Harpoon - EquipIdle" }
}
v21["Oceanic Harpoon - FishCaught"] = v3
v21["Oceanic Harpoon - ReelingIdle"] = v12
v21["Oceanic Harpoon - ReelStart"] = v3
v21["Oceanic Harpoon - ReelIntermission"] = v3
v21["Oceanic Harpoon - LoopedRodCharge"] = v12
v21["Oceanic Harpoon - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://84873660213983",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.5,
	["Length"] = 1.58,
	["CustomMarkers"] = { "HIDE_ARROW" },
	["LinkedAnimations"] = { "Oceanic Harpoon - LoopedRodCharge" }
}
local v24 = {
	["AnimationId"] = "rbxassetid://104946400643250",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.9,
	["LinkedMarkers"] = {
		["THROW_SCYTHE"] = "Soul Scythe - ReelingIdle"
	}
}
v21["Soul Scythe - RodThrow"] = v24
v21["Soul Scythe - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://95453600470089",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.316
}
v21["Soul Scythe - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://137684649541594",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 0.65,
	["LinkedAnimations"] = { "Soul Scythe - ReelingIdle" }
}
v21["Soul Scythe - ReelIntermission"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://139621583239992",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 1.33
}
local v25 = {
	["AnimationId"] = "rbxassetid://82259219343456",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 1.25,
	["LinkedMarkers"] = {
		["FISH_CAUGHT"] = true
	}
}
v21["Soul Scythe - FishCaught"] = v25
v21["Soul Scythe - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://84686809448947",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.33
}
v21["Soul Scythe - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://117668204114399",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.4,
	["Length"] = 2.6,
	["LinkedAnimations"] = { "Soul Scythe - LoopedRodCharge" }
}
v21["Soul Scythe - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://88768375910397",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.33
}
v21["Aether Monarch - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://121491018104381",
	["Length"] = 14
}
v21["Aether Monarch - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://90830760763606",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.98,
	["CustomCastSFX"] = "Aether Monarch Custom Cast",
	["LinkedAnimations"] = { "Aether Monarch - ReelIntermission" }
}
v21["Aether Monarch - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://74447876553309",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.05
}
v21["Aether Monarch - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://84610696434784",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.33
}
v21["Aether Monarch - AnimationOverride"] = v3
v21["Aether Monarch - ReelIntermission"] = v4
v21["Aether Monarch - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://126835913497348",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.82,
	["LinkedAnimations"] = { "Aether Monarch - ReelingIdle" }
}
v21["Aether Monarch - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://76209550449427",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.65,
	["LinkedAnimations"] = { "Aether Monarch - LoopedRodCharge" }
}
v21["Aether Monarch - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://116748897248196",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.33
}
v21["Ethereal Sword - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://116654265230180",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 12.33
}
v21["Ethereal Sword - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://102875258412698",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08,
	["PlaybackSpeed"] = 1.2,
	["LinkedAnimations"] = { "Aether Monarch - ReelIntermission" }
}
v21["Ethereal Sword - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://110866636674655",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.98
}
v21["Ethereal Sword - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://74353386311203",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21["Ethereal Sword - AnimationOverride"] = v3
v21["Ethereal Sword - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://134537167807676",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.73,
	["LinkedAnimations"] = { "Ethereal Sword - ReelingIdle" }
}
v21["Ethereal Sword - ReelIntermission"] = v6
v21["Ethereal Sword - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://117245023195506",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.48,
	["LinkedAnimations"] = { "Ethereal Sword - LoopedRodCharge" }
}
v21["Ethereal Sword - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://128015350117740",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.33
}
v21["Cupid\'s Harp - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://85435462874982",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 12.5
}
v21["Cupid\'s Harp - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://119286359658156",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.97,
	["PlaybackSpeed"] = 1,
	["CustomCastSFX"] = "Cupid\'s Harp Custom Cast",
	["LinkedAnimations"] = { "ReelIntermission" }
}
v21["Cupid\'s Harp - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://93542218938956",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.35
}
v21["Cupid\'s Harp - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://117980059371136",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.98
}
v21["Cupid\'s Harp - AnimationOverride"] = v3
v21["Cupid\'s Harp - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://88976110787345",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1.12,
	["LinkedAnimations"] = { "Cupid\'s Harp - ReelingIdle" }
}
v21["Cupid\'s Harp - ReelIntermission"] = v7
v21["Cupid\'s Harp - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://135163693343497",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.32,
	["LinkedAnimations"] = { "Cupid\'s Harp - LoopedRodCharge" }
}
v21["Cupid\'s Harp - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://81522018863770",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.32
}
v21["Aurelian Bow - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://112757205434160",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 14
}
v21["Aurelian Bow - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://140314062309330",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.82,
	["PlaybackSpeed"] = 1,
	["CustomCastSFX"] = "Aurelian Bow Custom Cast",
	["LinkedAnimations"] = { "ReelIntermission" }
}
v21["Aurelian Bow - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://89083607138153",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.98
}
v21["Aurelian Bow - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://115413643438054",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21["Aurelian Bow - AnimationOverride"] = v3
v21["Aurelian Bow - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://130610377568181",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.57,
	["LinkedAnimations"] = { "Aurelian Bow - ReelingIdle" }
}
v21["Aurelian Bow - ReelIntermission"] = v8
v21["Aurelian Bow - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://99852728253687",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.48,
	["LinkedAnimations"] = { "Aurelian Bow - LoopedRodCharge" }
}
v21["Aurelian Bow - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://76014507717255",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1
}
v21["Chromatic Katana - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://87355322562067",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 12.33
}
v21["Chromatic Katana - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://126097033168659",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.33,
	["PlaybackSpeed"] = 1.3,
	["LinkedAnimations"] = { "Chromatic Katana - ReelIntermission" }
}
v21["Chromatic Katana - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://75078942392746",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.98
}
v21["Chromatic Katana - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://85246394508551",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21["Chromatic Katana - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://84160502333903",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.5,
	["LinkedAnimations"] = { "Chromatic Katana - ReelingIdle" }
}
v21["Chromatic Katana - AnimationOverride"] = v3
v21["Chromatic Katana - ReelIntermission"] = v9
v21["Chromatic Katana - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://75015195359151",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.48,
	["LinkedAnimations"] = { "Chromatic Katana - LoopedRodCharge" }
}
v21["Chromatic Katana - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://85246394508551",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.33
}
v21["Crescendo Scythe - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://91723046661800",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 12
}
v21["Crescendo Scythe - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://140421284729758",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.98,
	["LinkedAnimations"] = { "Crescendo Scythe - ReelIntermission" }
}
v21["Crescendo Scythe - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://101593515409348",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.82
}
v21["Crescendo Scythe - ReelingHold"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://123869733913273",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21["Crescendo Scythe - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://111056917953819",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.73,
	["LinkedAnimations"] = { "Crescendo Scythe - ReelingIdle" }
}
v21["Crescendo Scythe - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://123869733913273",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21["Crescendo Scythe - AnimationOverride"] = v3
v21["Crescendo Scythe - ReelIntermission"] = v5
v21["Crescendo Scythe - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://95597987757506",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.65,
	["LinkedAnimations"] = { "Crescendo Scythe - LoopedRodCharge" }
}
v21["Crescendo Scythe - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://128488550256172",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.33
}
v21["Blackhole Sword - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://110434285817259",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 13.47
}
v21["Blackhole Sword - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://120554144611008",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.57,
	["LinkedAnimations"] = { "Blackhole Sword - ReelIntermission" }
}
v21["Blackhole Sword - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://88993991486322",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.98
}
v21["Blackhole Sword - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://126645853428201",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21["Blackhole Sword - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://80063739027478",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.73,
	["LinkedAnimations"] = { "Blackhole Sword - ReelingIdle" }
}
v21["Blackhole Sword - AnimationOverride"] = v3
v21["Blackhole Sword - ReelIntermission"] = v10
v21["Blackhole Sword - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://106390588424443",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.48,
	["LinkedAnimations"] = { "Blackhole Sword - LoopedRodCharge" }
}
v21["Blackhole Sword - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://76049869128172",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1
}
v21["Eternal Flower - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://115119558523816",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.5
}
v21["Eternal Flower - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://105844949829012",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["AnimationSpeed"] = 1.3,
	["Length"] = 1.32,
	["LinkedAnimations"] = { "Eternal Flower - ReelIntermission" }
}
v21["Eternal Flower - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://119567958965696",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.9
}
v21["Eternal Flower - ReelingIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://110020934764602",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.67
}
v21["Eternal Flower - ReelStart"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://135819234295555",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.73,
	["LinkedAnimations"] = { "Eternal Flower - ReelingIdle" }
}
v21["Eternal Flower - AnimationOverride"] = v3
v21["Eternal Flower - ReelIntermission"] = v11
v21["Eternal Flower - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://77131632555646",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 0.98,
	["LinkedAnimations"] = { "Eternal Flower - LoopedRodCharge" }
}
v21["Eternal Flower - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://124036821497471",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.33
}
v21["Holy Trident - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://83219020397849",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 6.67
}
local v26 = {
	["AnimationId"] = "rbxassetid://114917462794864",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["PlaybackSpeed"] = 1.3,
	["Length"] = 0.966,
	["LinkedMarkers"] = {
		["FLEX_THROW_LINE"] = "ReelingIdle"
	}
}
v21["Holy Trident - RodThrow"] = v26
v21["Holy Trident - FishCaught"] = {
	["AnimationId"] = "rbxassetid://128167068291703",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.67,
	["PlaybackSpeed"] = 1.2
}
v21["Holy Trident - ReelingIdle"] = v13
v21["Holy Trident - ReelStart"] = v13
v21["Holy Trident - ReelIntermission"] = v13
v21["Holy Trident - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://83219020397849",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 6.67
}
v21["Binary Edge - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://103714544264522",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.08
}
local v27 = {
	["AnimationId"] = "rbxassetid://104527781253009",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.88,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["Binary Edge - RodThrow"] = v27
v21["Binary Edge - FishCaught"] = {
	["AnimationId"] = "rbxassetid://109653945741202",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.8
}
v21["Binary Edge - ReelingIdle"] = v18
v21["Binary Edge - ReelStart"] = v18
v21["Binary Edge - ReelIntermission"] = v18
v21["Binary Edge - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://72745361965091",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.53,
	["LinkedAnimations"] = { "Binary Edge - LoopedRodCharge" }
}
v21["Binary Edge - LoopedRodCharge"] = {
	["Variants"] = true,
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://98710992523201",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08
}
v21["The Vanquisher - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://123194574699925",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.08
}
local v28 = {
	["AnimationId"] = "rbxassetid://102380394663862",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["The Vanquisher - RodThrow"] = v28
v21["The Vanquisher - FishCaught"] = {
	["AnimationId"] = "rbxassetid://93884986836266",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1
}
v21["The Vanquisher - ReelingIdle"] = v19
v21["The Vanquisher - ReelStart"] = v19
v21["The Vanquisher - AnimationOverride"] = v3
v21["The Vanquisher - ReelIntermission"] = v19
v21["The Vanquisher - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://92063415632933",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1,
	["LinkedAnimations"] = { "The Vanquisher - LoopedRodCharge" }
}
v21["The Vanquisher - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://92063415632933",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08
}
v21["Frozen Krampus Scythe - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://124265469726043",
	["AnimationPriority"] = Enum.AnimationPriority.Movement,
	["Length"] = 1.08
}
v21["Frozen Krampus Scythe - RodThrow"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://96196869100887",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08,
	["LinkedAnimations"] = { "Frozen Krampus Scythe - ReelingIdle" }
}
v21["Frozen Krampus Scythe - FishCaught"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://134934781977605",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1
}
v21["Frozen Krampus Scythe - ReelingIdle"] = v20
v21["Frozen Krampus Scythe - ReelStart"] = v20
v21["Frozen Krampus Scythe - AnimationOverride"] = v3
v21["Frozen Krampus Scythe - ReelIntermission"] = v20
v21["Frozen Krampus Scythe - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://93987679432095",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1,
	["LinkedAnimations"] = { "Frozen Krampus Scythe - LoopedRodCharge" }
}
v21["Frozen Krampus Scythe - LoopedRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://107284147985305",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08
}
v21["1x1x1x1 Ban Hammer - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://81302570422307",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.09
}
local v29 = {
	["AnimationId"] = "rbxassetid://123133988645038",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.18,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["1x1x1x1 Ban Hammer - RodThrow"] = v29
v21["1x1x1x1 Ban Hammer - FishCaught"] = {
	["AnimationId"] = "rbxassetid://96285280763544",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.18
}
v21["1x1x1x1 Ban Hammer - ReelingIdle"] = v17
v21["1x1x1x1 Ban Hammer - ReelStart"] = v17
v21["1x1x1x1 Ban Hammer - ReelIntermission"] = v17
v21["1x1x1x1 Ban Hammer - StartRodCharge"] = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://134431618143422",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.62,
	["LinkedAnimations"] = { "1x1x1x1 Ban Hammer - LoopedRodCharge" }
}
v21["1x1x1x1 Ban Hammer - LoopedRodCharge"] = {
	["Variants"] = true,
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://128538861163297",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1.08
}
v21["Corruption Edge - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://93958525241489",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 2.18
}
local v30 = {
	["AnimationId"] = "rbxassetid://84892442268560",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 0.62,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["Corruption Edge - RodThrow"] = v30
v21["Corruption Edge - FishCaught"] = {
	["AnimationId"] = "rbxassetid://126613975718573",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 0.93
}
v21["Corruption Edge - ReelingIdle"] = v16
v21["Corruption Edge - ReelStart"] = v16
v21["Corruption Edge - ReelIntermission"] = v16
v21["Corruption Edge - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://112104009500915",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.08
}
v21["Gingerbread Katana - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://103641983335689",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.06
}
local v31 = {
	["AnimationId"] = "rbxassetid://124037675493192",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["PlaybackSpeed"] = 1.4,
	["Length"] = 1.08,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["Gingerbread Katana - RodThrow"] = v31
v21["Gingerbread Katana - FishCaught"] = {
	["AnimationId"] = "rbxassetid://107940819382815",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.07
}
v21["Gingerbread Katana - ReelingIdle"] = v14
v21["Gingerbread Katana - ReelStart"] = v14
v21["Gingerbread Katana - ReelIntermission"] = v14
v21["Gingerbread Katana - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://115229621326605",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.09
}
v21["Eclipse Katana - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://103641983335689",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 1.06
}
local v32 = {
	["AnimationId"] = "rbxassetid://82600073500966",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["PlaybackSpeed"] = 1.4,
	["Length"] = 1.08,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["Eclipse Katana - RodThrow"] = v32
v21["Eclipse Katana - FishCaught"] = {
	["AnimationId"] = "rbxassetid://107940819382815",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.07
}
v21["Eclipse Katana - ReelingIdle"] = v14
v21["Eclipse Katana - ReelStart"] = v14
v21["Eclipse Katana - ReelIntermission"] = v14
v21["Eclipse Katana - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://115229621326605",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.09
}
v21["Christmas Parasol - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://79754634120924",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 6
}
local v33 = {
	["AnimationId"] = "rbxassetid://122784676901871",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["PlaybackSpeed"] = 1.3,
	["Length"] = 1.08,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["Christmas Parasol - RodThrow"] = v33
v21["Christmas Parasol - FishCaught"] = {
	["AnimationId"] = "rbxassetid://99143072029495",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.55,
	["PlaybackSpeed"] = 1.2
}
v21["Christmas Parasol - ReelingIdle"] = v15
v21["Christmas Parasol - ReelStart"] = v15
v21["Christmas Parasol - ReelIntermission"] = v15
v21["Christmas Parasol - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://104188512165442",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.13
}
v21["Princess Parasol - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://79754634120924",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 6
}
local v34 = {
	["AnimationId"] = "rbxassetid://108621937425425",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["PlaybackSpeed"] = 1.3,
	["Length"] = 1.08,
	["LinkedMarkers"] = {
		["Throw"] = "ReelingIdle"
	}
}
v21["Princess Parasol - RodThrow"] = v34
v21["Princess Parasol - FishCaught"] = {
	["AnimationId"] = "rbxassetid://99143072029495",
	["AnimationPriority"] = Enum.AnimationPriority.Action4,
	["Length"] = 1.55,
	["PlaybackSpeed"] = 1.2
}
v21["Princess Parasol - ReelingIdle"] = v15
v21["Princess Parasol - ReelStart"] = v15
v21["Princess Parasol - ReelIntermission"] = v15
v21["Princess Parasol - StartRodCharge"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://104188512165442",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.13
}
v21.FishingFailure = {
	["AnimationId"] = "rbxassetid://78824620552051",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["PlaybackSpeed"] = 1.2,
	["Length"] = 1.8
}
v21.StartRodCharge = {
	["Variants"] = true,
	["AnimationId"] = "rbxassetid://139622307103608",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 2.683,
	["LinkedAnimations"] = { "LoopedRodCharge" }
}
v21.LoopedRodCharge = {
	["Variants"] = true,
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://137429009359442",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1.166
}
v21.NPC_Emote = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://113892097123931",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 15.5
}
v21.NPC_Sit = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://119383377956726",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 7.5
}
v21.NPC_Leaning = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://100479761518539",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 5
}
v21.NPC_Sleep = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://91507769462696",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 12.5
}
v21.NPC_Chill = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://82584695013092",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 8.33
}
v21.NPC_Scared = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://135510090299807",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 4
}
v21.NPC_Headless = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://138312424622026",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21.NPC_Witch = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://80495385390558",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 1
}
v21.HoldFish3 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://126738217543503",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.533
}
v21.HoldFish2 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://75033370620947",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.55
}
v21.HoldFish1 = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://131771776568234",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["Length"] = 0.366
}
v21["Undead Guitar - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://130474623877752",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 7.5
}
v21["Royal Spider - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://79263851052023",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 4.17
}
v21["Trick O\' Treat - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://105569745192317",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 8.33
}
v21["Reaver Scythe - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://79066316609985",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 11.67
}
v21["Spirit Staff - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://77452908864699",
	["AnimationPriority"] = Enum.AnimationPriority.Core,
	["Length"] = 13.33
}
v21["Divine Blade - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://82781088583962",
	["Length"] = 10.83
}
v21["Heartfelt Blade - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://111118151202469",
	["Length"] = 1.33
}
v21["Candy Cane Trident - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://131643088615283",
	["Length"] = 1
}
v21["Ornament Axe - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://90021589040653",
	["Length"] = 1
}
v21["Gingerbread Sword - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://106017647759827",
	["Length"] = 1
}
v21["Xmas Tree Rod - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://97171752999251",
	["Length"] = 1
}
v21["Pink Present Lance - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://101986838283328",
	["Length"] = 1
}
v21["Wings of Everlove - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://125409322606200",
	["Length"] = 12
}
v21["Voidpunk Axe - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://82305386881445",
	["Length"] = 11.67
}
v21["Crimson Rose - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://99781097640024",
	["Length"] = 11.67
}
v21["Heartbreaker Surge - EquipIdle"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://105432325608290",
	["Length"] = 11.67
}
v21.PickaxeIdle = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://132127568585411",
	["AnimationPriority"] = Enum.AnimationPriority.Idle,
	["Length"] = 1
}
v21.PickaxeMining = {
	["Looped"] = false,
	["AnimationId"] = "rbxassetid://127791492757405",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1
}
v21["LavaSurfboard-Surf"] = {
	["Looped"] = true,
	["AnimationId"] = "rbxassetid://82189048200405",
	["AnimationPriority"] = Enum.AnimationPriority.Action,
	["Length"] = 1
}
if v2 then
	for v35, v36 in v21 do
		if not v36.Disabled then
			if not v36.Length then
				warn((("Error! No length provided for animation: %*"):format(v35)))
			end
			if v36.AnimationId then
				local v37 = v36.AnimationId
				if string.len(v37) ~= 0 then
					local v38 = Instance.new("Animation")
					v38.Name = v35
					v38.AnimationId = v36.AnimationId
					v38.Parent = script
					v21[v35].Animation = v38
				end
			end
		end
	end
	return v21
else
	for v39, v40 in v21 do
		if not v40.Disabled and v40.AnimationId then
			local v41 = v40.AnimationId
			if string.len(v41) ~= 0 then
				local v42 = script:WaitForChild(v39)
				if v42 then
					v21[v39].Animation = v42
				end
			end
		end
	end
	return v21
end