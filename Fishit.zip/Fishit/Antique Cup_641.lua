-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 239,
		["Type"] = "Fish",
		["Name"] = "Antique Cup",
		["Description"] = "",
		["Icon"] = "rbxassetid://82143322416088",
		["Tier"] = 3
	},
	["SellPrice"] = 430,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.22, 0.32),
		["Default"] = NumberRange.new(0.14, 0.18)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1