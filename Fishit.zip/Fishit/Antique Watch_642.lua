-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 238,
		["Type"] = "Fish",
		["Name"] = "Antique Watch",
		["Description"] = "",
		["Icon"] = "rbxassetid://93941516308809",
		["Tier"] = 3
	},
	["SellPrice"] = 1680,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.41, 1.75),
		["Default"] = NumberRange.new(0.84, 1.22)
	},
	["Probability"] = {
		["Chance"] = 0.0006666666666666666
	},
	["_moduleScript"] = script
}
return v1