-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 171,
		["Type"] = "Fishing Rods",
		["Name"] = "Aqua Prism",
		["Description"] = "",
		["Icon"] = "rbxassetid://108606190037759",
		["Tier"] = 100
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1