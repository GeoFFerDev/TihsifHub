-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 170,
		["Type"] = "Fishing Rods",
		["Name"] = "Aquatic",
		["Description"] = "",
		["Icon"] = "rbxassetid://113612903290719",
		["Tier"] = 100
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1