-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 22,
		["Type"] = "Variant",
		["Name"] = "Arctic Frost",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(183, 249, 255)) })
	},
	["Versions"] = 1,
	["Colors"] = 4,
	["SellMultiplier"] = 2,
	["Probability"] = {
		["Chance"] = 1.1
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1