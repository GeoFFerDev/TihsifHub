-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v2.Packages.Signal)
local v5 = require(v2.Packages.Replion).Client
require(v2.Packages.Trove)
require(v2.Packages.Thread)
require(v2.Shared.SystemMessage)
require(v2.Shared.AreaUtility)
require(v2.Areas)
v5:WaitReplion("Area")
local v_u_6 = v_u_4.new()
local v_u_7 = Instance.new("Folder")
v_u_7.Name = "FakeIslands"
v_u_7.Parent = workspace
workspace:WaitForChild("Islands")
workspace:WaitForChild("Characters")
workspace:WaitForChild("Vehicles")
workspace:WaitForChild("Locations")
local v_u_8 = v2:WaitForChild("ReplicatedIslands")
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = {}
local _ = workspace.CurrentCamera
return {
	["Start"] = function(_) end,
	["IsPlayerInArea"] = function(_, p13, p14)
		-- upvalues: (copy) v_u_3
		local v15 = v_u_3.LocalPlayer.Character
		if not v15 then
			return false
		end
		local v16 = v15:GetPivot().Position
		local v17
		if v16.X >= p13.X - p14.X and (v16.X <= p13.X + p14.X and (v16.Z >= p13.Z - p14.Z and (v16.Z <= p13.Z + p14.Z and v16.Y >= p13.Y - p14.Y))) then
			v17 = v16.Y <= p13.Y + p14.Y
		else
			v17 = false
		end
		return v17
	end,
	["_insidePart"] = function(_, p18, p19, p20)
		local v21 = p18:PointToObjectSpace(p20)
		local v22 = p19 / 2
		local v23 = v21.X
		local v24
		if math.abs(v23) <= v22.X then
			local v25 = v21.Z
			v24 = math.abs(v25) <= v22.Z
		else
			v24 = false
		end
		return v24
	end,
	["AreaAdded"] = function(_, p26)
		-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_11, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7
		local v_u_27 = v_u_1:GenerateGUID(false)
		v_u_10[p26] = v_u_27
		local v_u_28 = v_u_8:WaitForChild(p26, 1)
		if v_u_28 then
			if v_u_27 == v_u_10[p26] then
				if not v_u_9[p26] then
					v_u_9[p26] = v_u_28
				end
				v_u_12[p26] = "Loading"
				v_u_11[v_u_27] = {}
				local v_u_29 = v_u_11[v_u_27]
				local v_u_30 = v_u_4.new()
				local v_u_31 = false
				local v33 = v_u_6:Connect(function(p32)
					-- upvalues: (copy) v_u_27, (ref) v_u_31, (copy) v_u_30
					if p32 == v_u_27 then
						v_u_31 = true
						v_u_30:Fire(false)
					end
				end)
				task.spawn(function()
					-- upvalues: (copy) v_u_28, (copy) v_u_29, (ref) v_u_7, (ref) v_u_31, (copy) v_u_30
					for v34, v35 in ipairs(v_u_28:GetChildren()) do
						local v36 = v_u_29
						table.insert(v36, v35)
						v35.Parent = v_u_7
						if v34 % 6 == 0 then
							task.wait(0.016666666666666666)
						end
					end
					if not v_u_31 then
						v_u_30:Fire(true)
					end
				end)
				v_u_30:Wait()
				for _, v37 in ipairs(v_u_28:GetChildren()) do
					table.insert(v_u_29, v37)
					v37.Parent = v_u_7
				end
				v33:Disconnect()
				v_u_30:Destroy()
				v_u_12[p26] = "Done"
			end
		else
			return
		end
	end,
	["AreaRemoved"] = function(_, p38)
		-- upvalues: (copy) v_u_12, (copy) v_u_10, (copy) v_u_6, (copy) v_u_9, (copy) v_u_11
		v_u_12[p38] = "Dead"
		local v39 = v_u_10[p38]
		if v39 then
			v_u_6:Fire(v39)
		end
		local v40 = v_u_9[p38]
		if v39 then
			v39 = v_u_11[v39]
		end
		if v40 and v39 then
			for v41, v42 in ipairs(v39) do
				if v41 % 6 == 0 then
					task.wait(0.016666666666666666)
				end
				v42.Parent = v40
			end
			v_u_12[p38] = nil
		end
		print("Removed:", p38)
	end
}