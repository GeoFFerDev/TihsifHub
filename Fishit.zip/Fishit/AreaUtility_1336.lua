-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Packages.Replion)
local v_u_4 = require(v2.Areas)
local v5 = require(v2.Shared.RewardInfo)
local v_u_6 = require(v2.Shared.PlayerStatsUtility)
local v_u_7 = require(v2.Shared.ItemUtility)
local v_u_8 = require(v2.Shared.TierUtility)
local v_u_9 = require(v2.Events)
local v_u_10 = require(script.SpecialItems)
local v_u_11 = {
	{
		["Position"] = 1,
		["Percentile"] = 0.25,
		["Reward"] = v5.potionReward("Luck I Potion", 3)
	},
	{
		["Position"] = 2,
		["Percentile"] = 0.5,
		["Reward"] = v5.enchantStoneReward("Super Enchant Stone", 1)
	},
	{
		["Position"] = 3,
		["Percentile"] = 0.75,
		["Reward"] = v5.totemReward("Luck Totem", 1)
	},
	{
		["Position"] = 4,
		["Percentile"] = 1,
		["Reward"] = { v5.itemReward("Ruin Key", 1) }
	}
}
local v_u_12 = {}
local v13 = {
	["Replace"] = {
		["Love Nessie"] = "Broken Heart Nessie"
	},
	["Remove"] = {}
}
v_u_12.Heartbreaker = v13
local v_u_93 = {
	["GetGlobalMilestoneRewards"] = function(_, p14)
		-- upvalues: (copy) v_u_11
		return v_u_11[p14]
	end,
	["GetTotalAreaCompletion"] = function(_, p15, p16)
		-- upvalues: (copy) v_u_4, (copy) v_u_93
		local v17 = 0
		local v18 = 0
		for v19, _ in pairs(v_u_4) do
			local v20 = v_u_93:GetAreaCompletion(p15, v19, p16)
			v17 = v17 + v20.Max
			v18 = v18 + v20.Min
		end
		return NumberRange.new(math.min(v18, v17), v17)
	end,
	["GetArea"] = function(_, p21)
		-- upvalues: (copy) v_u_4
		return v_u_4[p21]
	end,
	["GetGlobalFish"] = function(_)
		return {}
	end,
	["ValidateFishingArea"] = function(_, p22, p23)
		local v24 = p22:GetAttribute("QuestRequirement")
		local v25 = p22:GetAttribute("EligiblePath")
		if not v25 then
			return true
		end
		local v26
		if v25 and (p23 and not p23.Destroyed) then
			if v24 then
				return p23:Find(v25, v24) ~= nil
			end
			v26 = p23:Get(v25)
		else
			v26 = nil
		end
		return v26
	end,
	["AreaUnlocked"] = function(_, p27, p28)
		-- upvalues: (copy) v_u_93
		local v29 = v_u_93:GetArea(p28)
		if not v29 then
			return false
		end
		if v29.DefaultLocation then
			return true
		end
		local v30 = v_u_93:GetAreaCompletion(p27, p28)
		return v30.Min >= v30.Max
	end,
	["GetAreaCompletion"] = function(_, p31, p32, p_u_33)
		-- upvalues: (copy) v_u_93, (copy) v_u_7, (copy) v_u_8
		local v34 = v_u_93:GetArea(p32)
		if not v34 then
			return NumberRange.new(0, 0)
		end
		local v_u_35 = p31:GetExpect("CaughtFishMastery")
		local v_u_36 = 0
		local v_u_37 = 0
		local function v42(p38)
			-- upvalues: (ref) v_u_7, (copy) p_u_33, (ref) v_u_8, (ref) v_u_37, (copy) v_u_35, (ref) v_u_36
			local v39 = v_u_7:GetItemData(p38)
			if v39 then
				local v40 = v39.Probability
				if v40 then
					local v41 = 7
					if p_u_33 then
						if p_u_33.IgnoreFish and table.find(p_u_33.IgnoreFish, v39.Data.Name) then
							return
						end
						if p_u_33.IgnoreWeatherFish and v39.Events then
							return
						end
						if p_u_33.SecretsAllowed then
							v41 = v41 + 1
						end
					end
					if v41 > v_u_8:GetTierFromRarity(v40.Chance).Tier then
						v_u_37 = v_u_37 + 1
						if v_u_35[v39.Data.Name] or v_u_35[v39.Data.Id] then
							v_u_36 = v_u_36 + 1
						end
					end
				else
					return
				end
			else
				return
			end
		end
		local v43 = v_u_37
		local v44 = v_u_36
		for _, v45 in ipairs(v34.Items) do
			v42(v45)
		end
		return NumberRange.new(v44, v43)
	end,
	["GetItemProbabilities"] = function(_, p46, p47, p_u_48, p49, p50, p51)
		-- upvalues: (copy) v_u_93, (copy) v_u_9, (copy) v_u_6, (copy) v_u_12, (copy) v_u_7, (copy) v_u_8, (copy) v_u_10
		local v_u_52 = {}
		local v53 = v_u_93:GetArea(p47)
		if not v53 then
			return v_u_52
		end
		local v_u_54 = v53.OverrideProbability
		local v55 = table.clone(v53.Items)
		local v56 = getEventsReplion()
		if v56 then
			local v57 = v56:GetExpect("Events")
			for _, v58 in ipairs(v57) do
				local v59 = v_u_9[v58]
				if v59 then
					local v60 = nil
					if p49 then
						local v61 = v59.LinkedEvents
						if v61 then
							v61 = v59.LinkedEvents.Fish[p49]
						end
						v60 = v61 or v60
					elseif p47 then
						local v62 = v59.AreaConfiguration
						if v62 then
							v62 = v59.AreaConfiguration.Fish[p47]
						end
						v60 = v62 or v60
					end
					if v60 then
						for _, v63 in ipairs(v60) do
							table.insert(v55, v63)
						end
					end
					if v59.GlobalFish then
						for _, v64 in ipairs(v59.GlobalFish) do
							table.insert(v55, v64)
						end
					end
				end
			end
		end
		local v65 = v_u_6:GetQuestFish(p46)
		if p50 then
			table.insert(v65, p50)
		end
		if p51 and #p51 > 0 then
			for _, v66 in ipairs(p51) do
				local v67 = v_u_12[v66]
				if v67 then
					if next(v67.Replace) then
						for v68, v69 in v67.Replace do
							local v70 = table.find(v55, v68)
							if v70 then
								table.remove(v55, v70)
								table.insert(v55, v69)
							end
						end
					end
					if #v67.Remove > 0 then
						for _, v71 in ipairs(v67.Remove) do
							local v72 = table.find(v55, v71)
							if v72 then
								table.remove(v55, v72)
							end
						end
					end
				end
			end
		end
		local function v82(p73, p74)
			-- upvalues: (ref) v_u_7, (copy) p_u_48, (ref) v_u_8, (copy) v_u_54, (copy) v_u_52
			local v75 = v_u_7:GetItemData(p73)
			if v75 then
				local v76 = v75.Probability
				if v76 then
					if not v75.Weight or p_u_48 >= v75.Weight.Default.Min then
						local v77 = v75.IgnoreTier
						local v78
						if v76 then
							v78 = v_u_8:GetTierFromRarity(v76.Chance).Tier
						else
							v78 = v75.Data.Tier
						end
						local v79
						if v_u_54 and v_u_54[p73] then
							v79 = v_u_54[p73]
						else
							v79 = v76.Chance
						end
						local v80 = {
							["Chance"] = v79,
							["Identifier"] = v75.Data.Id,
							["Name"] = v75.Data.Name,
							["IgnoreTier"] = v77,
							["Tier"] = v78,
							["Proability"] = v76
						}
						if p74 then
							v80.Forever = true
						end
						local v81 = v_u_52
						table.insert(v81, v80)
					end
				else
					return
				end
			else
				return
			end
		end
		for _, v83 in ipairs(v65) do
			v82(v83, true)
		end
		for _, v84 in ipairs(v55) do
			v82(v84, false)
		end
		local v85 = v_u_93:GetGlobalFish()
		if #v85 > 0 then
			for _, v86 in ipairs(v85) do
				v82(v86, false)
			end
		end
		if #v_u_10 > 0 then
			for _, v87 in ipairs(v_u_10) do
				local v88 = v_u_7:GetItemData(v87.Identifier)
				if v88 then
					local v89 = v88.Probability
					local v90 = v88.IgnoreTier
					local v91
					if v89 then
						v91 = v_u_8:GetTierFromRarity(v89.Chance).Tier
					else
						v91 = v88.Data.Tier
					end
					local v92 = {
						["Chance"] = v87.Chance,
						["Identifier"] = v87.Identifier,
						["Name"] = v87.Name,
						["IgnoreTier"] = v90,
						["Tier"] = v91,
						["Proability"] = v89
					}
					table.insert(v_u_52, v92)
				end
			end
		end
		return v_u_52
	end
}
function getEventsReplion()
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	if v_u_1:IsClient() then
		return v_u_3.Client:WaitReplion("Events")
	else
		return v_u_3.Server:WaitReplion("Events")
	end
end
return v_u_93