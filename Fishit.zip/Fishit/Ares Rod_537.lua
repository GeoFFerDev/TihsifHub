-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 126,
		["Type"] = "Fishing Rods",
		["Name"] = "Ares Rod",
		["Description"] = "",
		["Icon"] = "rbxassetid://74424529377774",
		["Tier"] = 6
	},
	["ClickPower"] = 0.2,
	["Resilience"] = 6,
	["Windup"] = NumberRange.new(2.5, 3),
	["Price"] = 3000000,
	["HiddenInShop"] = true,
	["MaxWeight"] = 400000
}
local v2 = {
	["BaseLuck"] = 4.55,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1