-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.Util)
local function v_u_4(p2)
	for _, v3 in ipairs({
		"%.",
		"%?",
		"%*",
		"%*%*"
	}) do
		p2 = p2:gsub("\\" .. v3, v3:gsub("%%", ""))
	end
	return p2
end
local v_u_5 = {}
v_u_5.__index = v_u_5
function v_u_5.new(p6, p7, p8)
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v9 = {
		["Command"] = p6,
		["Type"] = nil,
		["Name"] = p7.Name,
		["Object"] = p7
	}
	local v10
	if p7.Default == nil then
		v10 = p7.Optional ~= true
	else
		v10 = false
	end
	v9.Required = v10
	v9.Executor = p6.Executor
	v9.RawValue = p8
	v9.RawSegments = {}
	v9.TransformedValues = {}
	v9.Prefix = ""
	v9.TextSegmentInProgress = ""
	v9.RawSegmentsAreAutocomplete = false
	local v11 = p7.Type
	if type(v11) == "table" then
		v9.Type = p7.Type
	else
		local v12, v13, v14 = v_u_1.ParsePrefixedUnionType(p6.Cmdr.Registry:GetTypeName(p7.Type), p8)
		v9.Type = p6.Dispatcher.Registry:GetType(v12)
		v9.RawValue = v13
		v9.Prefix = v14
		if v9.Type == nil then
			error(string.format("%s has an unregistered type %q", v9.Name or "<none>", v12 or "<none>"))
		end
	end
	local v15 = v_u_5
	setmetatable(v9, v15)
	v9:Transform()
	return v9
end
function v_u_5.GetDefaultAutocomplete(p16)
	if not p16.Type.Autocomplete then
		return {}
	end
	local v17 = p16:TransformSegment("")
	local v18, v19 = p16.Type.Autocomplete(v17)
	return v18, v19 or {}
end
function v_u_5.Transform(p20)
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	if #p20.TransformedValues == 0 then
		local v21 = p20.RawValue
		if v21 == "." and p20.Type.Default then
			v21 = p20.Type.Default(p20.Executor) or ""
			p20.RawSegmentsAreAutocomplete = true
		end
		if v21 == "?" and p20.Type.Autocomplete then
			local v22, v23 = p20:GetDefaultAutocomplete()
			if not v23.IsPartial and #v22 > 0 then
				v21 = v22[math.random(1, #v22)]
				p20.RawSegmentsAreAutocomplete = true
			end
		end
		if p20.Type.Listable and #p20.RawValue > 0 then
			local v24 = v21:match("^%?(%d+)$")
			if v24 then
				local v25 = tonumber(v24)
				if v25 and v25 > 0 then
					local v26 = {}
					local v27, v28 = p20:GetDefaultAutocomplete()
					if not v28.IsPartial and #v27 > 0 then
						local v29 = #v27
						for _ = 1, math.min(v25, v29) do
							local v30 = table.remove
							local v31 = math.random
							local v32 = #v27
							table.insert(v26, v30(v27, v31(1, v32)))
						end
						v21 = table.concat(v26, ",")
						p20.RawSegmentsAreAutocomplete = true
					end
				end
			elseif v21 == "*" or v21 == "**" then
				local v33, v34 = p20:GetDefaultAutocomplete()
				if not v34.IsPartial and #v33 > 0 then
					if v21 == "**" and p20.Type.Default then
						local v35 = p20.Type.Default(p20.Executor) or ""
						for v36, v37 in ipairs(v33) do
							if v37 == v35 then
								table.remove(v33, v36)
							end
						end
					end
					v21 = table.concat(v33, ",")
					p20.RawSegmentsAreAutocomplete = true
				end
			end
			local v38 = v_u_4(v21)
			local v39 = v_u_1.SplitStringSimple(v38, ",")
			local v40 = #v39 == 0 and { "" } or v39
			if v38:sub(#v38, #v38) == "," then
				v40[#v40 + 1] = ""
			end
			for v41, v42 in ipairs(v40) do
				p20.RawSegments[v41] = v42
				p20.TransformedValues[v41] = { p20:TransformSegment(v42) }
			end
			p20.TextSegmentInProgress = v40[#v40]
		else
			local v43 = v_u_4(v21)
			p20.RawSegments[1] = v_u_4(v43)
			p20.TransformedValues[1] = { p20:TransformSegment(v43) }
			p20.TextSegmentInProgress = p20.RawValue
		end
	else
		return
	end
end
function v_u_5.TransformSegment(p44, p45)
	if p44.Type.Transform then
		return p44.Type.Transform(p45, p44.Executor)
	else
		return p45
	end
end
function v_u_5.GetTransformedValue(p46, p47)
	local v48 = p46.TransformedValues[p47]
	return unpack(v48)
end
function v_u_5.Validate(p49, p50)
	if p49.RawValue == nil or #p49.RawValue == 0 and p49.Required == false then
		return true
	end
	if p49.Required and (p49.RawSegments[1] == nil or #p49.RawSegments[1] == 0) then
		return false, "This argument is required."
	end
	if not (p49.Type.Validate or p49.Type.ValidateOnce) then
		return true
	end
	for v51 = 1, #p49.TransformedValues do
		if p49.Type.Validate then
			local v52, v53 = p49.Type.Validate(p49:GetTransformedValue(v51))
			if not v52 then
				return v52, v53 or "Invalid value"
			end
		end
		if p50 and p49.Type.ValidateOnce then
			local v54, v55 = p49.Type.ValidateOnce(p49:GetTransformedValue(v51))
			if not v54 then
				return v54, v55
			end
		end
	end
	return true
end
function v_u_5.GetAutocomplete(p56)
	return not p56.Type.Autocomplete and {} or p56.Type.Autocomplete(p56:GetTransformedValue(#p56.TransformedValues))
end
function v_u_5.ParseValue(p57, p58)
	if p57.Type.Parse then
		return p57.Type.Parse(p57:GetTransformedValue(p58))
	else
		return p57:GetTransformedValue(p58)
	end
end
function v_u_5.GetValue(p59)
	if #p59.RawValue == 0 and (not p59.Required and p59.Object.Default ~= nil) then
		return p59.Object.Default
	end
	if not p59.Type.Listable then
		return p59:ParseValue(1)
	end
	local v60 = {}
	for v61 = 1, #p59.TransformedValues do
		local v62 = p59:ParseValue(v61)
		if type(v62) ~= "table" then
			error(("Listable types must return a table from Parse (%s)"):format(p59.Type.Name))
		end
		for _, v63 in pairs(v62) do
			v60[v63] = true
		end
	end
	local v64 = {}
	for v65 in pairs(v60) do
		v64[#v64 + 1] = v65
	end
	return v64
end
return v_u_5