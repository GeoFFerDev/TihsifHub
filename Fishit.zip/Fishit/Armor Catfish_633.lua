-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 215,
		["Type"] = "Fish",
		["Name"] = "Armor Catfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://130020230064983",
		["Tier"] = 6
	},
	["SellPrice"] = 30500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3593, 4424),
		["Default"] = NumberRange.new(2374, 3062)
	},
	["Probability"] = {
		["Chance"] = 0.00002
	},
	["_moduleScript"] = script
}
return v1