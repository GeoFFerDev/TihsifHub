-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 242,
		["Type"] = "Fish",
		["Name"] = "Arowana",
		["Description"] = "",
		["Icon"] = "rbxassetid://81593253309929",
		["Tier"] = 2
	},
	["SellPrice"] = 61,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.9, 4.7),
		["Default"] = NumberRange.new(2.2, 3.4)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1