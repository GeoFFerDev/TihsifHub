-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.GameId == 6902403037 and 0.001 or 0.0005
return {
	["Data"] = {
		["Id"] = 265,
		["Type"] = "Gears",
		["Name"] = "Arrow Artifact",
		["Description"] = "",
		["Icon"] = "rbxassetid://71938301181096",
		["Tier"] = 4
	},
	["RecordData"] = true,
	["TradeLocked"] = true,
	["SellPrice"] = 0,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1, 1.25),
		["Default"] = NumberRange.new(0.5, 0.75)
	},
	["Probability"] = {
		["Chance"] = v1
	},
	["_moduleScript"] = script
}