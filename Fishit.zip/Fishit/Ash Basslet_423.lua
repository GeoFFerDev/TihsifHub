-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 20,
		["Type"] = "Fish",
		["Name"] = "Ash Basslet",
		["Description"] = "",
		["Icon"] = "rbxassetid://89467763428838",
		["Tier"] = 1
	},
	["SellPrice"] = 19,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.7, 2.1),
		["Default"] = NumberRange.new(1.1, 1.3)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1