-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 17,
		["Type"] = "Fish",
		["Name"] = "Astra Damsel",
		["Description"] = "",
		["Icon"] = "rbxassetid://80597542368624",
		["Tier"] = 4
	},
	["SellPrice"] = 1633,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.6, 4.5),
		["Default"] = NumberRange.new(2.5, 3.1)
	},
	["Probability"] = {
		["Chance"] = 0.0005
	},
	["_moduleScript"] = script
}
return v1