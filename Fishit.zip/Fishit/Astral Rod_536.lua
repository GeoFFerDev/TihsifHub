-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 5,
		["Type"] = "Fishing Rods",
		["Name"] = "Astral Rod",
		["Description"] = "Ascend beyond the stars",
		["Icon"] = "rbxassetid://123734625865292",
		["Tier"] = 5
	},
	["ClickPower"] = 0.18,
	["Resilience"] = 6.6,
	["Windup"] = NumberRange.new(3.33, 5.22),
	["Price"] = 1000000,
	["MaxWeight"] = 125000
}
local v2 = {
	["BaseLuck"] = 3.8,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1