-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 698,
		["Type"] = "Gears",
		["Name"] = "Astryx Core",
		["Description"] = "",
		["Icon"] = "rbxassetid://71584156008470",
		["Tier"] = 5
	},
	["RecordData"] = true,
	["UseQuantity"] = true,
	["TradeLocked"] = true,
	["Consumable"] = true,
	["IgnoreVariants"] = true,
	["_moduleScript"] = script
}
return v1