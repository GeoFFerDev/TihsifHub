-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
game:GetService("GroupService")
game:GetService("Players")
if not v1:IsStudio() then
	print((("\240\159\141\141 Running TopbarPlus %* by ForeverHD"):format((require(script.Parent.VERSION)))))
end
return {}