-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 2,
		["Type"] = "Emotes",
		["Name"] = "Aura Backflip",
		["Description"] = "",
		["Icon"] = "rbxassetid://99227802227344",
		["Tier"] = 5
	},
	["AnimationId"] = "rbxassetid://108299660040407",
	["AnimationPriority"] = Enum.AnimationPriority.Action3,
	["PlaybackSpeed"] = 1,
	["VFXStartDelay"] = 5,
	["Looped"] = true,
	["Effect"] = "AuraBackflip",
	["_moduleScript"] = script
}
return v1