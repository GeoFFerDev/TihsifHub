-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 17,
		["Type"] = "Boats",
		["Name"] = "Aura Boat",
		["Description"] = "",
		["Icon"] = "rbxassetid://84714071584727",
		["Tier"] = 6
	},
	["HiddenInShop"] = true,
	["Seats"] = 3,
	["_moduleScript"] = script
}
return v1