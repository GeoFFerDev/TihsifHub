-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Aura farm your way into the sunset with this Indonesian legend",
	["AssociatedTier"] = 6
}
local v4 = {}
local v5 = {
	["Id"] = 1,
	["Name"] = "Catch a SECRET Crystal Crab",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 7,
		["Fish"] = "Crystal Crab"
	},
	["AssociatedType"] = "Fish",
	["AssociatedItem"] = "Crystal Crab"
}
local v6 = {
	["Id"] = 2,
	["Name"] = "Catch 100 Epic fish",
	["Goal"] = 100,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 4
	}
}
__set_list(v4, 1, {v5, v6, {
	["Id"] = 3,
	["Name"] = "Catch 10,000 fish",
	["Goal"] = 10000,
	["Type"] = "Catch"
}})
v3.Objectives = v4
v3.Reward = v2.boatReward("Aura Boat")
return v3