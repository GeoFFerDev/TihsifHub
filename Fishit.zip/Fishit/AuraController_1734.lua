-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = v1.LocalPlayer
local v_u_4 = require(v_u_2.Packages.Replion).Client
local v_u_5 = require(v_u_2.Packages.Observers)
local v_u_6 = require(v_u_2.Packages.Trove)
return {
	["Start"] = function(_)
		-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3
		v_u_5.observeCharacter(function(p_u_7, p_u_8)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5
			local v_u_9 = v_u_6.new()
			local v_u_10 = v_u_9:Extend()
			local v_u_11 = false
			local function v_u_21(p12)
				-- upvalues: (ref) v_u_2, (ref) v_u_11, (copy) v_u_10, (ref) v_u_4, (copy) p_u_7, (ref) v_u_3, (copy) p_u_8
				local v13 = v_u_2.Assets.Auras:FindFirstChild(p12)
				if v13 then
					if v_u_11 then
						v_u_10:Clean()
					end
					local v14 = v_u_4:GetReplion("Data")
					if v14 then
						local v15 = v14:Get({ "Settings", "Self Rod VFX" })
						local v16 = v14:Get({ "Settings", "Others Rod VFX" })
						if (p_u_7 ~= v_u_3 or v15) and (p_u_7 == v_u_3 or v16) then
							v_u_11 = true
							for _, v17 in v13:GetChildren() do
								local v18 = p_u_8:FindFirstChild(v17.Name)
								if v18 then
									for _, v19 in v17:GetChildren() do
										local v20 = v19:Clone()
										v20.Parent = v18
										v_u_10:Add(v20)
									end
								end
							end
						end
					else
						return
					end
				else
					return
				end
			end
			local function v_u_22()
				-- upvalues: (copy) v_u_10, (ref) v_u_11
				v_u_10:Clean()
				v_u_11 = false
			end
			local function v23()
				-- upvalues: (copy) v_u_9
				v_u_9:Destroy()
			end
			local v24 = p_u_8:WaitForChild("Humanoid")
			if v24 then
				v_u_9:Add(v24.Died:Once(v23))
			end
			for _, v25 in ipairs(v_u_2.Assets.Auras:GetChildren()) do
				local v_u_26 = v25.Name
				v_u_9:Add((v_u_5.observeAttribute(p_u_7, "FishingRodSkin", function(p27)
					-- upvalues: (copy) v_u_26, (copy) p_u_7, (copy) v_u_21, (copy) v_u_22
					if p27 == v_u_26 then
						task.wait(0.5)
						if p_u_7:GetAttribute("FishingRodSkin") == p27 then
							v_u_21(p27)
							return v_u_22
						end
					end
				end)))
			end
			return v23
		end)
	end
}