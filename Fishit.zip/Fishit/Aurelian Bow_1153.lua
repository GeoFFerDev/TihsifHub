-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 756,
		["Type"] = "Fishing Rods",
		["Name"] = "Aurelian Bow",
		["Description"] = "",
		["Icon"] = "rbxassetid://81605239060543",
		["NewIcon"] = true,
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.65, 0, 0.75),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, 0.9599310885968813),
	["GripC0"] = CFrame.new(Vector3.new(0, -1.05, 0)) * CFrame.Angles(-1.5707963267948966, 0, 0),
	["GripC1"] = CFrame.identity,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1