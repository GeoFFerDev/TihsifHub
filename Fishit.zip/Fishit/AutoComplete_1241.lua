-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players").LocalPlayer
return function(p2)
	-- upvalues: (copy) v_u_1
	local v_u_3 = {
		["Items"] = {},
		["ItemOptions"] = {},
		["SelectedItem"] = 0
	}
	local v_u_4 = p2.Util
	local v_u_5 = v_u_4.MakeDictionary({
		"me",
		"all",
		".",
		"*",
		"others"
	})
	local v_u_6 = v_u_1:WaitForChild("PlayerGui"):WaitForChild("Cmdr"):WaitForChild("Autocomplete")
	local v_u_7 = v_u_6:WaitForChild("TextButton")
	local v_u_8 = v_u_6:WaitForChild("Title")
	local v_u_9 = v_u_6:WaitForChild("Description")
	local v_u_10 = v_u_6.Parent:WaitForChild("Frame"):WaitForChild("Entry")
	v_u_7.Parent = nil
	local function v_u_15(p11, p12, p13, p14)
		-- upvalues: (copy) v_u_4
		p11.Visible = p13 ~= nil
		p12.Text = p13 or ""
		if p14 then
			p12.Size = UDim2.new(0, v_u_4.GetTextSize(p13 or "", p12, Vector2.new(1000, 1000), 1, 0).X, p11.Size.Y.Scale, p11.Size.Y.Offset)
		end
	end
	local function v_u_26(p16)
		-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6
		v_u_15(v_u_8, v_u_8.Field, p16.name, true)
		local v17 = v_u_8.Field.Type
		local v18 = v_u_8.Field.Type
		local v19 = p16.type
		if v19 then
			v19 = ": " .. p16.type:sub(1, 1):upper() .. p16.type:sub(2)
		end
		v17.Visible = v19 ~= nil
		v18.Text = v19 or ""
		local v20 = v_u_9
		local v21 = v_u_9.Label
		local v22 = p16.description
		v20.Visible = v22 ~= nil
		v21.Text = v22 or ""
		v_u_9.Label.TextColor3 = p16.invalid and Color3.fromRGB(255, 73, 73) or Color3.fromRGB(255, 255, 255)
		local v23 = v_u_8.Field.TextBounds.X + v_u_8.Field.Type.TextBounds.X
		local v24 = v_u_6.Size.X.Offset
		local v25 = math.max(v23, v24)
		v_u_9.Size = UDim2.new(1, 0, 0, 40)
		while not v_u_9.Label.TextFits do
			v_u_9.Size = v_u_9.Size + UDim2.new(0, 0, 0, 2)
			if v_u_9.Size.Y.Offset > 500 then
				break
			end
		end
		wait()
		v_u_6.UIListLayout:ApplyLayout()
		v_u_6.Size = UDim2.new(0, v25, 0, v_u_6.UIListLayout.AbsoluteContentSize.Y)
	end
	function v_u_3.Show(p27, p28, p29)
		-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_10, (copy) v_u_4, (copy) v_u_26
		local v30 = p29 or {}
		for _, v31 in pairs(p27.Items) do
			if v31.gui then
				v31.gui:Destroy()
			end
		end
		p27.SelectedItem = 1
		p27.Items = p28
		p27.Prefix = v30.prefix or ""
		p27.LastItem = v30.isLast or false
		p27.Command = v30.command
		p27.Arg = v30.arg
		p27.NumArgs = v30.numArgs
		p27.IsPartial = v30.isPartial
		local v32 = 200
		for v33, v34 in pairs(p27.Items) do
			local v35 = v34[1]
			local v36 = v34[2]
			if v_u_5[v35] then
				v35 = v36
			end
			local v37 = v_u_7:Clone()
			v37.Name = v35 .. v36
			v37.BackgroundTransparency = v33 == p27.SelectedItem and 0.5 or 1
			v37.Typed.Text = v35
			v37.Suggest.Text = string.rep(" ", #v35) .. v36:sub(#v35 + 1)
			v37.Parent = v_u_6
			v37.LayoutOrder = v33
			local v38 = v37.Typed.TextBounds.X
			local v39 = v37.Suggest.TextBounds.X
			local v40 = math.max(v38, v39) + 20
			if v32 < v40 then
				v32 = v40
			end
			v34.gui = v37
		end
		v_u_6.UIListLayout:ApplyLayout()
		local v41 = v_u_10.TextBox.Text
		local v42 = v_u_4.SplitString(v41)
		if v41:sub(#v41, #v41) == " " and not v30.at then
			v42[#v42 + 1] = "e"
		end
		table.remove(v42, #v42)
		local v43 = (v30.at and v30.at or #table.concat(v42, " ") + 1) * 7
		v_u_6.Position = UDim2.new(0, v_u_10.TextBox.AbsolutePosition.X - 10 + v43, 0, v_u_10.TextBox.AbsolutePosition.Y + 30)
		v_u_6.Size = UDim2.new(0, v32, 0, v_u_6.UIListLayout.AbsoluteContentSize.Y)
		v_u_6.Visible = true
		local v44 = v_u_26
		if p27.Items[1] then
			v30 = p27.Items[1].options or v30
		end
		v44(v30)
	end
	function v_u_3.GetSelectedItem(_)
		-- upvalues: (copy) v_u_6, (copy) v_u_3
		if v_u_6.Visible == false then
			return nil
		else
			return v_u_3.Items[v_u_3.SelectedItem]
		end
	end
	function v_u_3.Hide(_)
		-- upvalues: (copy) v_u_6
		v_u_6.Visible = false
	end
	function v_u_3.IsVisible(_)
		-- upvalues: (copy) v_u_6
		return v_u_6.Visible
	end
	function v_u_3.Select(p45, p46)
		-- upvalues: (copy) v_u_6, (copy) v_u_26
		if v_u_6.Visible then
			p45.SelectedItem = p45.SelectedItem + p46
			if p45.SelectedItem > #p45.Items then
				p45.SelectedItem = 1
			elseif p45.SelectedItem < 1 then
				p45.SelectedItem = #p45.Items
			end
			for v47, v48 in pairs(p45.Items) do
				v48.gui.BackgroundTransparency = v47 == p45.SelectedItem and 0.5 or 1
			end
			if p45.Items[p45.SelectedItem] and p45.Items[p45.SelectedItem].options then
				v_u_26(p45.Items[p45.SelectedItem].options or {})
			end
		end
	end
	return v_u_3
end