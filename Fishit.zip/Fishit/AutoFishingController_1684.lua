-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v3 = require(v1.Packages.Net)
local v_u_4 = require(v1.Packages.Replion)
require(v1.Packages.Thread)
local v_u_5 = require(v1.Packages.Observers)
local v_u_6 = require(v1.Packages.spr)
local v_u_7 = require(v1.Modules.GuiControl)
local v_u_8 = require(v1.Modules.ToolTip)
local v_u_9 = require(v1.Shared.Constants)
require(v1.Controllers.PromptController)
local v_u_10 = require(v1.Controllers.FishingController)
local v_u_11 = require(v1.Controllers.TextNotificationController)
local v_u_12 = require(v1.Shared.AreaUtility)
local v_u_13 = v3:RemoteFunction("UpdateAutoFishingState")
local v_u_14 = v3:RemoteFunction("MarkAutoFishingUsed")
local v_u_15 = nil
local v_u_16 = v2.LocalPlayer
local v_u_17 = v_u_16.PlayerGui
local v_u_18 = workspace.CurrentCamera
local v_u_19 = false
local v_u_20 = false
v_u_17:WaitForChild("!!! Daily Login")
v_u_17:WaitForChild("HUD")
local v_u_21 = {
	["Inactive"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromHex("#ff5d60")), ColorSequenceKeypoint.new(1, Color3.fromHex("#ff2256")) }),
	["Active"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromHex("#62ffb6")), ColorSequenceKeypoint.new(1, Color3.fromHex("#21ff7d")) })
}
local v_u_34 = {
	["Start"] = function(_)
		-- upvalues: (ref) v_u_15, (copy) v_u_4, (copy) v_u_5, (copy) v_u_34, (copy) v_u_17, (copy) v_u_16, (copy) v_u_13, (copy) v_u_11, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_18, (ref) v_u_20
		v_u_15 = v_u_4.Client:WaitReplion("Data")
		local v22 = { v_u_17 }
		v_u_5.observeTag("AutoFishingButton", function(p23)
			-- upvalues: (ref) v_u_34
			return v_u_34:RegisterAutoFishingButton(p23)
		end, v22)
		local v_u_24 = nil
		v_u_15:OnChange("AutoFishing", function(p25)
			-- upvalues: (ref) v_u_16, (ref) v_u_24
			if p25 then
				local v26 = v_u_16.Character
				if v26 then
					v26 = v26:FindFirstChild("HumanoidRootPart")
				end
				if v26 then
					v_u_24 = v26.Position
					return
				end
			else
				v_u_24 = nil
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_24, (ref) v_u_13, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (ref) v_u_18
			while true do
				while true do
					while true do
						while true do
							while v_u_16:GetAttribute("InCutscene") do
								task.wait(0.5)
							end
							if v_u_15:GetExpect("AutoFishing") then
								break
							end
							v_u_24 = nil
							task.wait(2)
						end
						if v_u_15:GetExpect("EquippedType") == "Fishing Rods" then
							break
						end
						task.wait(2)
					end
					local v27 = v_u_16.Character
					if v27 then
						v27 = v27:FindFirstChild("HumanoidRootPart")
					end
					if not v27 then
						break
					end
					if v_u_24 == nil then
						v_u_24 = v27.Position
					end
					if (v27.Position - v_u_24).Magnitude < 8 then
						goto l11
					end
					v_u_13:InvokeServer(false)
					v_u_24 = nil
					local v28 = {
						["Type"] = "Text",
						["Text"] = "Auto Fishing stopped: You walked away!",
						["TextColor"] = {
							["R"] = 255,
							["G"] = 165,
							["B"] = 0
						}
					}
					v_u_11:DeliverNotification(v28)
					task.wait(0.5)
				end
				::l11::
				if v_u_9:CountInventorySize(v_u_15) >= v_u_9.MaxInventorySize then
					task.wait(2.5)
					if v_u_10:NoInventorySpace() then
						task.wait(0.5)
						goto l16
					end
				else
					::l16::
					if v_u_10:OnCooldown() then
						task.wait(0.2)
					elseif v_u_10:GetCurrentGUID() then
						local v29 = v_u_16:GetAttribute("SelectedRarity") or 1
						local v30 = v_u_12:GetArea(v_u_16:GetAttribute("LocationName") or "Fisherman Island")
						if not v30 then
							v30 = {
								["ClickPowerMultiplier"] = 1
							}
						end
						local v31 = v_u_9:GetClickTiming(v29, v30)
						v_u_10:RequestFishingMinigameClick()
						task.wait(v31)
					else
						v_u_10:RequestChargeFishingRod(Vector2.new(v_u_18.ViewportSize.X / 2, v_u_18.ViewportSize.Y / 2), true)
						task.wait(0.5)
					end
				end
			end
		end)
		v_u_20 = true
	end,
	["RegisterAutoFishingButton"] = function(_, p32)
		-- upvalues: (ref) v_u_15, (copy) v_u_7, (ref) v_u_19, (copy) v_u_9, (copy) v_u_13, (copy) v_u_14, (copy) v_u_11, (copy) v_u_8
		if not p32:GetAttribute("Registered") then
			p32:SetAttribute("Registered", true)
			if v_u_15:Get("AutoFishingUsed") then
				p32.Gradient.Main:RemoveTag("ShineEffect")
			end
			local v_u_33 = v_u_7:Hook("Hold Button", p32)
			v_u_33.Clicked:Connect(function()
				-- upvalues: (ref) v_u_19, (ref) v_u_15, (ref) v_u_9, (ref) v_u_13, (ref) v_u_14, (ref) v_u_11
				if not v_u_19 then
					v_u_19 = true
					if game.GameId == 6902403037 and true or v_u_15:GetExpect("Level") >= v_u_9.AutoFishingLevel then
						v_u_13:InvokeServer(not v_u_15:GetExpect("AutoFishing"))
						if not v_u_15:Get("AutoFishingUsed") then
							v_u_14:InvokeServer()
						end
					else
						v_u_11:DeliverNotification({
							["Type"] = "Text",
							["Text"] = ("Reach Level %* to unlock!"):format(v_u_9.AutoFishingLevel),
							["TextColor"] = {
								["R"] = 255,
								["G"] = 0,
								["B"] = 0
							}
						})
					end
					task.delay(0.75, function()
						-- upvalues: (ref) v_u_19
						v_u_19 = false
					end)
				end
			end)
			v_u_8.observe(p32, v_u_33.Cleaner, function()
				return {
					["Style"] = "Label",
					["Text"] = "Toggle auto fishing"
				}
			end)
			v_u_15:OnChange("EquippedType", OnEquippedTypeChanged(p32))
			v_u_15:OnChange("AutoFishing", AutoFishingStateChanged(p32))
			v_u_15:OnChange("Level", OnLevelChanged(p32))
			v_u_15:OnChange("AutoFishingUsed", OnAutoFishingUsedChanged(p32))
			OnEquippedTypeChanged(p32)(v_u_15:GetExpect("EquippedType"))
			AutoFishingStateChanged(p32)(v_u_15:GetExpect("AutoFishing"))
			OnLevelChanged(p32)(v_u_15:GetExpect("Level"))
			return function()
				-- upvalues: (copy) v_u_33
				v_u_33:Destroy()
			end
		end
	end
}
function IsAutoFishingUnlocked()
	return true
end
function OnEquippedTypeChanged(p_u_35)
	return function(p36)
		-- upvalues: (copy) p_u_35
		p_u_35.Visible = p36 == "Fishing Rods" and IsAutoFishingUnlocked()
	end
end
function OnLevelChanged(p_u_37)
	-- upvalues: (ref) v_u_15
	return function(_)
		-- upvalues: (ref) v_u_15, (copy) p_u_37
		local v38 = IsAutoFishingUnlocked()
		p_u_37.Visible = v_u_15:GetExpect("EquippedType") == "Fishing Rods" and v38
	end
end
function OnAutoFishingUsedChanged(p_u_39)
	-- upvalues: (ref) v_u_15
	return function()
		-- upvalues: (ref) v_u_15, (copy) p_u_39
		if v_u_15:Get("AutoFishingUsed") then
			p_u_39.Gradient.Main:RemoveTag("ShineEffect")
		end
	end
end
function AutoFishingStateChanged(p_u_40)
	-- upvalues: (copy) v_u_21, (copy) v_u_6, (ref) v_u_20, (copy) v_u_11
	return function(p41)
		-- upvalues: (ref) v_u_21, (ref) v_u_6, (copy) p_u_40, (ref) v_u_20, (ref) v_u_11
		local v42 = p41 and v_u_21.Active or v_u_21.Inactive
		v_u_6.stop(p_u_40.UIGradient)
		v_u_6.target(p_u_40.UIGradient, 1, 3, {
			["Color"] = v42
		})
		if v_u_20 then
			v_u_11:DeliverNotification({
				["Type"] = "Text",
				["Text"] = ("Auto Fishing: %*"):format(p41 and "Enabled" or "Disabled"),
				["TextColor"] = p41 and {
					["R"] = 9,
					["G"] = 255,
					["B"] = 0
				} or {
					["R"] = 255,
					["G"] = 0,
					["B"] = 0
				}
			})
		end
	end
end
return v_u_34