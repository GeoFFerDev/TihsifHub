-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui")
local v3 = require(v1.Packages.Observers)
local v_u_4 = require(v1.Modules.GuiControl)
v3.observeTag("AutomaticCloseButton", function(p_u_5)
	-- upvalues: (copy) v_u_4
	p_u_5:SetAttribute("Ignore2D", true)
	local v_u_6 = v_u_4:Hook("Hold Button", p_u_5)
	local v_u_7 = v_u_6.Clicked:Connect(function()
		-- upvalues: (copy) p_u_5, (ref) v_u_4
		if p_u_5:GetAttribute("Unlock") == true then
			v_u_4:Unlock()
		end
		v_u_4:Close()
	end)
	return function()
		-- upvalues: (copy) v_u_7, (copy) v_u_6
		v_u_7:Disconnect()
		v_u_6:Destroy()
	end
end, { v2 })
return {}