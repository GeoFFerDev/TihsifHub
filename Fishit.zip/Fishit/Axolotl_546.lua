-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 138,
		["Type"] = "Fish",
		["Name"] = "Axolotl",
		["Description"] = "",
		["Icon"] = "rbxassetid://76558551981982",
		["Tier"] = 4
	},
	["SellPrice"] = 3971,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.31, 0.44),
		["Default"] = NumberRange.new(0.12, 0.22)
	},
	["Probability"] = {
		["Chance"] = 0.00015384615384615385
	},
	["_moduleScript"] = script
}
return v1