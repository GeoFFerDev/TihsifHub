-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 66,
		["Type"] = "Fish",
		["Name"] = "Azure Damsel",
		["Description"] = "",
		["Icon"] = "rbxassetid://82037285284063",
		["Tier"] = 1
	},
	["SellPrice"] = 22,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.8, 1),
		["Default"] = NumberRange.new(0.5, 0.6)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1