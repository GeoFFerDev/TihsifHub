-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Packages.Loader).LoadChildren(script:WaitForChild("Modules"))
for _, v3 in v_u_2 do
	if v3.Init then
		v3:Init()
	end
end
for _, v4 in v_u_2 do
	if v4.Start then
		task.spawn(v4.Start, v4)
	end
end
script.Destroying:Once(function()
	-- upvalues: (copy) v_u_2
	table.clear(v_u_2)
end)