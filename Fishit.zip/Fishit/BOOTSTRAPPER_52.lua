-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
game:GetService("Players")
local v_u_2 = require(v_u_1:WaitForChild("Packages"):WaitForChild("Loader"));
(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	require(script:WaitForChild("WaitForPlayerData"))()
	require(script:WaitForChild("BeforeInit"))()
	local v3 = v_u_2.LoadDescendants(v_u_1.Controllers, v_u_2.MatchesName("Controller$"))
	for v4, v5 in v3 do
		local v6 = v5.Init
		if typeof(v6) == "function" then
			local v7, v8 = pcall(v5.Init, v5)
			if not v7 then
				task.spawn(error, (("[Init Error]: %*\nController: %*"):format(v8, v4)))
			end
		end
	end
	for v_u_9, v_u_10 in v3 do
		local v11 = v_u_10.Start
		if typeof(v11) == "function" then
			task.spawn(function()
				-- upvalues: (copy) v_u_10, (copy) v_u_9
				local v12, v13 = pcall(v_u_10.Start, v_u_10)
				if not v12 then
					task.spawn(error, (("[Start Error]: %*\nController: %*}"):format(v13, v_u_9)))
				end
			end)
		end
	end
	require(script:WaitForChild("AfterStart"))()
end)()