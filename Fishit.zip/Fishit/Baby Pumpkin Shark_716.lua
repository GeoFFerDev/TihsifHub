-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 310,
		["Type"] = "Fish",
		["Name"] = "Baby Pumpkin Shark",
		["Description"] = "",
		["Icon"] = "rbxassetid://92277291116292",
		["Tier"] = 3
	},
	["SellPrice"] = 435,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8.7, 11),
		["Default"] = NumberRange.new(3.8, 5.8)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["EventTag"] = "HALLOW25",
	["_moduleScript"] = script
}
return v1