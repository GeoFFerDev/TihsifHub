-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 349,
		["Type"] = "Fish",
		["Name"] = "Baby Shrimp",
		["Description"] = "",
		["Icon"] = "rbxassetid://100664684321181",
		["Tier"] = 2
	},
	["SellPrice"] = 79,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.1, 0.12),
		["Default"] = NumberRange.new(0.04, 0.08)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1