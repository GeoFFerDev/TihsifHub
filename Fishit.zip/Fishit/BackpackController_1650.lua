-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("RunService")
local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("Players")
local v5 = require(v_u_3.Packages.Signal)
local v6 = require(v_u_3.Packages.Net)
local v_u_7 = require(v_u_3.Packages.Replion)
local v_u_8 = require(v_u_3.Packages.Trove)
local v_u_9 = require(v_u_3.Packages.spr)
require(v_u_3.Modules.ItemStringUtility)
local v_u_10 = require(v_u_3.Shared.StringLibrary)
local v_u_11 = require(v_u_3.Shared.ItemUtility)
local v_u_12 = require(v_u_3.Shared.TierUtility)
require(v_u_3.Shared.Soundbook)
local v_u_13 = require(v_u_3.Shared.FishingRodModifiers)
local v_u_14 = require(v_u_3.Shared.PlayerStatsUtility)
require(v_u_3.Types.Modifiers)
local v_u_15 = require(v_u_3.Shared.InventoryMapping)
local v_u_16 = require(v_u_3.Modules.Device)
local v_u_17 = require(v_u_3.Modules.GuiControl)
local v_u_18 = require(v_u_3.Modules.ToolTip)
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = v4.LocalPlayer
local v23 = v_u_22.PlayerGui
local _ = workspace.CurrentCamera
local v_u_24 = v6:RemoteEvent("UnequipToolFromHotbar")
local v_u_25 = v6:RemoteEvent("EquipToolFromHotbar")
local v_u_26 = v6:RemoteEvent("UnequipItem")
local v_u_27 = v6:RemoteEvent("FavoriteStateChanged")
v6:RemoteEvent("RollEnchant")
v23:WaitForChild("Quest")
local v_u_28 = v23:WaitForChild("Backpack")
local v_u_29 = v_u_28:WaitForChild("Display")
local v_u_30 = false
local v_u_31 = true
local v_u_32 = nil
local v_u_33 = script:WaitForChild("Modifiers")
local v_u_34 = script:WaitForChild("ModifierTiles")
local v_u_35 = script:WaitForChild("EquipRodNotification")
local v_u_36 = v_u_28:WaitForChild("Display"):WaitForChild("Tile")
v_u_36.Parent = nil
local v_u_37 = false
local v_u_38 = false
local v_u_39 = v5.new()
local v_u_40 = {
	1,
	4,
	5,
	6,
	7,
	8,
	9,
	0
}
local v_u_41 = {
	["PC"] = {
		Enum.KeyCode.One,
		Enum.KeyCode.Four,
		Enum.KeyCode.Five,
		Enum.KeyCode.Six,
		Enum.KeyCode.Seven
	},
	["Console"] = {
		Enum.KeyCode.ButtonY,
		Enum.KeyCode.ButtonX,
		Enum.KeyCode.ButtonR1,
		Enum.KeyCode.ButtonL1,
		Enum.KeyCode.ButtonL2
	},
	["Special"] = { Enum.KeyCode.ButtonX, Enum.KeyCode.DPadLeft, Enum.KeyCode.DPadRight }
}
local v_u_42 = {
	["001"] = v_u_29:WaitForChild("Inventory"),
	["002"] = v_u_29:WaitForChild("Rods")
}
local v_u_43 = {}
local v_u_112 = {
	["Resize"] = function(_)
		-- upvalues: (copy) v_u_29, (copy) v_u_42
		local v44 = v_u_29:GetAttribute("TileSize")
		if v44 then
			for _, v45 in v_u_42 do
				v45.Size = v44
			end
		end
	end,
	["ToggleHotbarItem"] = function(_, p46)
		-- upvalues: (copy) v_u_22, (copy) v_u_28, (ref) v_u_21, (copy) v_u_24, (copy) v_u_25
		if v_u_22:GetAttribute("Loading") == nil then
			return
		elseif v_u_28.Enabled then
			local v47 = v_u_21:Find("EquippedItems", p46)
			if v47 == nil then
				return
			elseif v_u_21:GetExpect("EquippedId") == p46 then
				v_u_24:FireServer()
			else
				v_u_25:FireServer(v47)
			end
		else
			return
		end
	end,
	["_refresh"] = function(_)
		-- upvalues: (ref) v_u_37, (ref) v_u_38, (copy) v_u_39, (copy) v_u_42, (ref) v_u_21
		if not v_u_37 then
			if v_u_38 then
				v_u_39:Wait()
			end
			v_u_38 = true
			v_u_37 = true
			if next(v_u_42) then
				for v48, v49 in v_u_42 do
					if v48 ~= "001" and v48 ~= "002" then
						v49:Destroy()
						v_u_42[v48] = nil
					end
				end
			end
			local v50 = v_u_21:GetExpect("EquippedItems")
			for v51, v52 in ipairs(v50) do
				DrawTile(v51, v52)
			end
			v_u_39:Fire()
			task.wait()
			v_u_37 = false
			v_u_38 = false
		end
	end,
	["_registerModifierFrames"] = function(_)
		-- upvalues: (copy) v_u_33, (copy) v_u_13, (copy) v_u_34, (copy) v_u_14, (copy) v_u_22, (ref) v_u_21, (copy) v_u_18, (copy) v_u_43, (copy) v_u_11, (ref) v_u_31, (ref) v_u_32, (copy) v_u_16, (ref) v_u_19, (copy) v_u_28
		local v_u_53 = v_u_33:Clone()
		for v_u_54, v_u_55 in v_u_13 do
			local v56 = v_u_34:FindFirstChild(v_u_54)
			if v56 then
				local v_u_57 = v56:Clone()
				local function v_u_66(p58)
					-- upvalues: (ref) v_u_14, (ref) v_u_22, (copy) v_u_55, (copy) v_u_54, (copy) v_u_57, (copy) v_u_53
					local v59 = v_u_14:GetPlayerModifiers(v_u_22)
					local v60 = v_u_55.Requirement
					local v61 = v59.Frequency[v_u_54]
					if v61 then
						local v62 = v60 - v61
						v60 = math.max(v62, 1)
					end
					local v63 = math.min(p58, v60)
					local v64 = v63 / v60
					local v65 = math.clamp(v64, 0, 1) * -1
					if v_u_57 and v_u_57:IsDescendantOf(v_u_53) then
						v_u_57.Fill.UIGradient.Offset = Vector2.new(0, v65)
						v_u_57.Label.Text = ("%*/%*"):format(v63, v60)
					end
				end
				local v_u_67 = { "Modifiers", v_u_54 }
				v_u_21:OnChange(v_u_67, v_u_66)
				v_u_21:OnChange("EquippedId", function(p68)
					-- upvalues: (copy) v_u_66, (ref) v_u_21, (copy) v_u_67
					if string.len(p68) > 0 then
						v_u_66(v_u_21:GetExpect(v_u_67))
					end
				end)
				task.defer(function()
					-- upvalues: (copy) v_u_66, (ref) v_u_21, (copy) v_u_67
					v_u_66(v_u_21:GetExpect(v_u_67))
				end)
				v_u_18.observe(v_u_57, nil, function()
					-- upvalues: (copy) v_u_55
					return {
						["Style"] = "Label",
						["Text"] = v_u_55.Description,
						["Icon"] = v_u_55.Icon
					}
				end)
				v_u_57.Visible = false
				v_u_57.Parent = v_u_53
				v_u_43[v_u_54] = v_u_57
			end
		end
		local function v_u_74(p69)
			-- upvalues: (ref) v_u_13, (ref) v_u_43, (ref) v_u_11, (ref) v_u_21, (copy) v_u_53
			for v70, v71 in v_u_13 do
				local v72 = v_u_43[v70]
				if v72 then
					local v73 = v_u_11.GetItemDataFromItemType("Fishing Rods", p69.Id)
					v72.Visible = not (v71.RequiredTier and (v73 and v73.Data.Tier)) and true or v73.Data.Tier >= v71.RequiredTier
				end
			end
			v_u_53.Visible = v_u_21:GetExpect("EquippedType") == "Fishing Rods"
		end
		local function v80()
			-- upvalues: (ref) v_u_21, (ref) v_u_14, (copy) v_u_74, (ref) v_u_13, (ref) v_u_43, (copy) v_u_53
			local v_u_75 = v_u_21:GetExpect("EquippedItems")[1]
			local v77 = v_u_14:GetItemFromInventory(v_u_21, function(p76)
				-- upvalues: (copy) v_u_75
				return p76.UUID == v_u_75
			end, "Fishing Rods")
			if v77 then
				v_u_74(v77)
			else
				for v78, _ in v_u_13 do
					local v79 = v_u_43[v78]
					if v79 then
						v79.Visible = false
					end
				end
				v_u_53.Visible = v_u_21:GetExpect("EquippedType") == "Fishing Rods"
			end
		end
		local function v84()
			-- upvalues: (ref) v_u_21, (ref) v_u_31, (ref) v_u_32, (ref) v_u_16, (ref) v_u_19
			local v81 = v_u_21:GetExpect({ "Statistics", "FishCaught" })
			if v_u_21:GetExpect("NewPlayer") or v81 <= 1000 then
				v_u_31 = true
			end
			local v_u_82 = nil
			v_u_82 = v_u_21:OnChange({ "EquippedType" }, function(p83)
				-- upvalues: (ref) v_u_31, (ref) v_u_82, (ref) v_u_32, (ref) v_u_16, (ref) v_u_19
				if p83 == "Fishing Rods" then
					v_u_31 = false
					v_u_82:Disconnect()
					if v_u_32 then
						v_u_32:Destroy()
						v_u_32 = nil
					end
					v_u_19:DeliverNotification({
						["Type"] = "Text",
						["Text"] = v_u_16:IsMobile() and "Use the TAP BUTTON to cast your rod!" or (v_u_16:_getDevice() == "Console" and "Press [RT] to cast your rod!" or "Click + Hold to charge your rod!"),
						["TextColor"] = {
							["R"] = 255,
							["G"] = 255,
							["B"] = 255
						},
						["CustomDuration"] = 5
					})
				end
			end)
		end
		v_u_21:OnChange("EquippedType", v80)
		v_u_21:OnChange("EquippedItems", v80)
		v80()
		v84()
		v_u_53.Parent = v_u_28
	end,
	["Start"] = function(_)
		-- upvalues: (ref) v_u_21, (copy) v_u_7, (ref) v_u_19, (copy) v_u_3, (ref) v_u_20, (copy) v_u_112, (copy) v_u_29, (copy) v_u_42, (copy) v_u_40, (copy) v_u_27, (copy) v_u_16, (copy) v_u_2, (ref) v_u_30, (copy) v_u_22, (copy) v_u_28, (copy) v_u_41, (copy) v_u_24, (copy) v_u_25
		v_u_21 = v_u_7.Client:WaitReplion("Data")
		v_u_19 = require(v_u_3.Controllers.TextNotificationController)
		v_u_20 = require(v_u_3.Modules.InputControl)
		v_u_112:_registerModifierFrames()
		v_u_29:GetAttributeChangedSignal("TileSize"):Connect(function()
			-- upvalues: (ref) v_u_112
			v_u_112:Resize()
		end)
		v_u_21:OnArrayInsert("EquippedItems", function(p85, p86)
			DrawTile(p85, p86)
		end)
		v_u_21:OnArrayRemove("EquippedItems", function(_, p87)
			-- upvalues: (ref) v_u_42
			local v88 = v_u_42[p87]
			if v88 then
				v88:Destroy()
				v_u_42[p87] = nil
			end
		end)
		v_u_21:OnChange("EquippedItems", function(p89, _)
			-- upvalues: (ref) v_u_42, (ref) v_u_40
			for v90, v91 in ipairs(p89) do
				local v92 = v_u_42[v91]
				if v92 then
					local v93 = v92:FindFirstChild("InputVisual")
					if v93 then
						v93:SetAttribute("Slot", v_u_40[v90])
					end
				end
			end
			for v94, v95 in ipairs(p89) do
				if v_u_42[v95] == nil then
					DrawTile(v94, v95)
				end
			end
			for v96 in v_u_42 do
				if v96 ~= "001" and (v96 ~= "002" and table.find(p89, v96) == nil) then
					local v97 = v_u_42[v96]
					if v97 then
						v97:Destroy()
						v_u_42[v96] = nil
					end
				end
			end
		end)
		v_u_27.OnClientEvent:Connect(function(p98, p99)
			-- upvalues: (ref) v_u_21, (ref) v_u_42
			if v_u_21:Find("EquippedItems", p98) == nil then
				return
			else
				local v100 = v_u_42[p98]
				if v100 then
					local v101 = v100:FindFirstChild("InputVisual")
					local v102
					if v101 then
						v102 = v101:FindFirstChild("Star")
					else
						v102 = v101
					end
					if v102 then
						v102.Visible = p99 and true or false
						if not v101.Visible then
							v101.Position = v102.Position
						end
					end
				end
			end
		end)
		v_u_21:OnChange("EquippedItems", function(p103, p104)
			-- upvalues: (ref) v_u_42
			if typeof(p103) == "table" and typeof(p104) == "table" then
				local v105 = p103[1]
				local v106 = p104[1]
				if v105 == v106 then
					return
				end
				local v107 = v106 and v_u_42[v106]
				if v107 then
					v107:Destroy()
					v_u_42[v106] = nil
				end
				if v105 then
					DrawTile(1, v105)
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_16, (ref) v_u_112
			v_u_16:RegisterDeviceChanged(InputChanged)
			InputChanged()
			v_u_112:Resize()
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_21
			v_u_2:GetInstanceAddedSignal("RodSkinActive"):Connect(UpdateSkinLabels)
			v_u_21:OnChange("EquippedSkinUUID", UpdateSkinLabels)
			UpdateSkinLabels()
		end)
		pcall(function()
			-- upvalues: (ref) v_u_112, (ref) v_u_30
			v_u_112:_refresh()
			v_u_30 = true
		end)
		v_u_20:RegisterInput({
			Enum.KeyCode.One,
			Enum.KeyCode.Four,
			Enum.KeyCode.Five,
			Enum.KeyCode.Six,
			Enum.KeyCode.Seven,
			Enum.KeyCode.ButtonY,
			Enum.KeyCode.ButtonX,
			Enum.KeyCode.ButtonR1,
			Enum.KeyCode.ButtonL1,
			Enum.KeyCode.ButtonL2
		}, { function()
				-- upvalues: (ref) v_u_22
				return v_u_22:GetAttribute("Loading") == false
			end, function()
				-- upvalues: (ref) v_u_28
				return v_u_28.Enabled
			end }, function(p108)
			-- upvalues: (ref) v_u_16, (ref) v_u_41, (ref) v_u_21, (ref) v_u_24, (ref) v_u_25
			local v109 = v_u_41[v_u_16:_getDevice()]
			if v109 then
				local v110 = table.find(v109, p108.KeyCode)
				if v110 then
					local v111 = v_u_21:GetExpect("EquippedItems")
					if v_u_21:GetExpect("EquippedId") == v111[v110] then
						v_u_24:FireServer()
					else
						v_u_25:FireServer(v110)
					end
				else
					return
				end
			else
				return
			end
		end)
		UpdateTile(2, nil, v_u_28.Display.Rods, false)
		UpdateTile(3, nil, v_u_28.Display.Inventory, false)
	end
}
function DrawTile(p113, p_u_114)
	-- upvalues: (copy) v_u_42, (copy) v_u_14, (ref) v_u_21, (copy) v_u_15, (copy) v_u_11, (copy) v_u_8, (copy) v_u_36, (ref) v_u_31, (ref) v_u_32, (copy) v_u_35, (copy) v_u_9, (copy) v_u_17, (copy) v_u_26, (copy) v_u_12, (copy) v_u_10, (copy) v_u_112, (copy) v_u_28
	if v_u_42[p_u_114] then
		return
	else
		local v116, v117 = v_u_14:GetItemFromInventory(v_u_21, function(p115)
			-- upvalues: (copy) p_u_114
			return p115.UUID == p_u_114
		end)
		if v116 then
			local v118 = v117.Category or "Items"
			local _ = v_u_15[v118]
			local v119 = v_u_11.GetItemDataFromItemType(v118, v116.Id)
			if v119 then
				local v120 = v116.Metadata
				local v121
				if v120 and v120.VariantId then
					v121 = v_u_11:GetVariantData(v120.VariantId)
				else
					v121 = nil
				end
				local v_u_122 = v_u_8.new()
				local v_u_123 = v_u_36:Clone()
				local v_u_124 = v_u_123.UIStroke
				local v125 = v_u_123.Inner.Tags
				local v126 = v_u_123.Inner.Configuration
				local v_u_127 = Instance.new("UIScale")
				v_u_127.Scale = 1
				v_u_127.Parent = v_u_123
				UpdateTile(p113, v116, v_u_123, true)
				v_u_42[p_u_114] = v_u_123
				if v119.Data.Type == "Fishing Rods" then
					v_u_123.Inner.Tags.SkinActive:AddTag("RodSkinActive")
				end
				if v119.Data.Type == "Fishing Rods" then
					if v_u_31 then
						if v_u_32 then
							v_u_32:Destroy()
						end
						local v128 = v_u_35:Clone()
						v128.Visible = true
						v128.Parent = v_u_123
						v_u_32 = v128
					end
				else
					local v_u_129 = v_u_8.new()
					local v_u_130 = true
					local v_u_131 = nil
					local v132 = script.Hitbox:Clone()
					local v_u_133 = v132.Close
					local function v_u_136(p134, p135)
						-- upvalues: (ref) v_u_9, (copy) v_u_133
						v_u_9.stop(v_u_133)
						v_u_9.target(v_u_133, 3, 15, {
							["ImageTransparency"] = p134
						})
						if p135 then
							v_u_9.completed(v_u_133, p135)
						end
					end
					local function v138()
						-- upvalues: (ref) v_u_130, (ref) v_u_131, (copy) v_u_136, (copy) v_u_133
						if v_u_130 then
							local v_u_137 = tick()
							v_u_131 = v_u_137
							task.wait(0.4)
							if v_u_137 == v_u_131 then
								v_u_136(1, function()
									-- upvalues: (copy) v_u_137, (ref) v_u_131, (ref) v_u_133
									if v_u_137 == v_u_131 then
										v_u_133.Visible = false
									end
								end)
							end
						else
							return
						end
					end
					local function v139()
						-- upvalues: (ref) v_u_130, (ref) v_u_131, (copy) v_u_133, (ref) v_u_9
						if v_u_130 then
							v_u_131 = tick()
							v_u_133.Visible = true
							v_u_9.stop(v_u_133)
							v_u_9.target(v_u_133, 3, 15, {
								["ImageTransparency"] = 0
							})
						end
					end
					local v140 = v_u_17:Hook("Hold Button", v_u_133, nil, nil, v_u_129)
					v_u_129:Add(function()
						-- upvalues: (ref) v_u_130, (ref) v_u_131, (ref) v_u_9, (copy) v_u_133
						v_u_130 = false
						v_u_131 = nil
						v_u_9.stop(v_u_133)
					end)
					v140.Clicked:Connect(function()
						-- upvalues: (ref) v_u_21, (copy) p_u_114, (ref) v_u_26
						if v_u_21:Find("EquippedItems", p_u_114) ~= nil then
							v_u_26:FireServer(p_u_114)
						end
					end)
					v_u_129:Add(v_u_123.MouseEnter:Connect(v139))
					v_u_129:Add(v_u_123.MouseLeave:Connect(v138))
					v_u_123.Destroying:Once(function()
						-- upvalues: (copy) v_u_129
						v_u_129:Destroy()
					end)
					v_u_133.ImageTransparency = 1
					v132.Parent = v_u_123
				end
				local v141 = nil
				if v119.Probability then
					v141 = v_u_12:GetTierFromRarity(v119.Probability.Chance)
				elseif v119.Data.Tier then
					v141 = v_u_12:GetTier(v119.Data.Tier)
				end
				if v141 then
					v_u_123.Inner.Tags.ItemName.Text = v119.Data.Name
					v_u_123.Inner.Tags.ItemName.UIGradient.Color = v141.TierColor
				end
				Vector2.new(0.5, 0.5)
				UDim2.fromScale(0.5, 0.525)
				local v142 = UDim2.fromScale(0.7, 0.7)
				local v143, v144
				if v119.Data.Type == "Fishing Rods" then
					if v119.Data.NewIcon then
						v142 = UDim2.fromScale(2, 2)
						v143 = UDim2.fromScale(0.5, 0.5)
						v144 = Vector2.new(0.5, 0.5)
					else
						v142 = UDim2.fromScale(1.05, 2.6)
						v143 = UDim2.fromScale(0.6, 1.025)
						v144 = Vector2.new(0.5, 1)
					end
					v126.Visible = false
				else
					local v145
					if v120 then
						v145 = v120.Shiny
					else
						v145 = v120
					end
					v126.ShinyFrame.Visible = v145
					v_u_123.Inner.ShinyUnderlay.Visible = v145
					local v146 = v119.Weight
					local v147
					if v120 then
						v147 = v120.Weight
					else
						v147 = v120
					end
					if v147 and v146 then
						if v146.Big.Min <= v147 then
							v142 = UDim2.fromScale(1.4, 1.4)
							v126.BigFrame.Visible = true
						end
						local v148 = v_u_10:AddWeight(v147)
						v126.WeightFrame.Label.Text = v148
						v126.WeightFrame.Visible = true
					else
						v126.WeightFrame.Visible = false
					end
					v143 = UDim2.fromScale(0.5, 0.525)
					v144 = Vector2.new(0.5, 0.5)
				end
				if v121 then
					v125.Variant.Text = v121.Data.Name
					v125.Variant.UIGradient.Color = v121.Data.TierColor
					v125.Variant.Visible = true
				end
				local v149 = v_u_21:Get("OnboardingStep")
				if v119.Data.Type == "Fish" and (v149 and v149 < 5) then
					v_u_124.Thickness = 3
					v_u_124.UIGradient.Enabled = false
					v_u_124.Enabled = true
					task.spawn(function()
						-- upvalues: (copy) v_u_124, (copy) v_u_123
						local v150 = Color3.fromRGB(100, 255, 100)
						local v151 = Color3.fromRGB(255, 255, 255)
						local v152 = 0
						local v153 = true
						while v152 < 3 and v_u_124.Parent do
							local v154 = v_u_124
							local v155
							if v153 then
								v155 = v150
							else
								v155 = v151
							end
							v154.Color = v155
							task.wait(0.2)
							v152 = v152 + 0.2
							v153 = not v153
						end
						if v_u_123 and v_u_123.Parent then
							v_u_124.Color = v151
							v_u_124.Thickness = 1.6
							v_u_124.UIGradient.Enabled = true
						end
					end)
				end
				local v156 = v125.Enchant1
				v156.Parent = nil
				if v120 then
					for v157, v158 in { v120.EnchantId, v120.EnchantId2 } do
						local v159 = v_u_11:GetEnchantData(v158)
						if v159 then
							local v160 = v156:Clone()
							v160.Text = v159.Data.Name
							v160.UIGradient.Color = v159.Data.TierColor
							v160.LayoutOrder = v160.LayoutOrder + (v157 - 1)
							v160.Visible = true
						end
					end
				end
				local v161 = CombineColors(v120)
				if v161 then
					v121 = v161
				elseif v121 then
					v121 = v121.Data.TierColor
				end
				if v121 then
					v_u_123.UIStroke.UIGradient.Color = v121
				end
				v156:Destroy()
				local function v163(p162)
					-- upvalues: (copy) p_u_114, (ref) v_u_9, (copy) v_u_127
					if p162 == p_u_114 then
						v_u_9.stop(v_u_127)
						v_u_9.target(v_u_127, 50, 325, {
							["Scale"] = 1.1
						})
					else
						v_u_9.stop(v_u_127)
						v_u_9.target(v_u_127, 50, 200, {
							["Scale"] = 1
						})
					end
				end
				local v_u_164 = v_u_21:OnChange("EquippedId", v163)
				v163(v_u_21:GetExpect("EquippedId"))
				v_u_122:Add(function()
					-- upvalues: (copy) v_u_164
					v_u_164:Disconnect()
				end)
				local function v165()
					-- upvalues: (copy) v_u_123, (ref) v_u_112, (copy) p_u_114
					v_u_123.Active = false
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_123
						v_u_123.Active = true
					end)
					v_u_112:ToggleHotbarItem(p_u_114)
				end
				v_u_122:Add(v_u_123.Activated:Connect(v165))
				v_u_123.Destroying:Once(function()
					-- upvalues: (copy) v_u_122
					v_u_122:Destroy()
				end)
				local v166 = v119.Data.Icon or ""
				local v167
				if v142 == UDim2.fromScale(1.05, 2.6) then
					v167 = Enum.ScaleType.Crop
				else
					v167 = Enum.ScaleType.Fit
				end
				local v168 = v_u_123.Inner.Vector
				v168.Size = v142
				v168.Position = v143
				v168.AnchorPoint = v144
				v168.ScaleType = v167
				v168.Image = v166
				v_u_123.Size = v_u_28.Display:GetAttribute("TileSize")
				v_u_123.LayoutOrder = p113
				v_u_123.Parent = v_u_28.Display
			else
				local v169 = warn
				local v170 = v116.Id
				local v171 = v116.Id
				v169("Unable to find item data for", v170, typeof(v171), v116)
			end
		else
			warn("Could not find inventory item for", p113)
			return
		end
	end
end
function InputChanged()
	-- upvalues: (copy) v_u_16, (copy) v_u_28
	if v_u_16:IsMobile() then
		v_u_28.Display:SetAttribute("TileSize", UDim2.fromOffset(58, 58))
		v_u_28.Display.Position = UDim2.fromScale(0.475, 1)
	else
		v_u_28.Display:SetAttribute("TileSize", UDim2.fromOffset(80, 80))
		v_u_28.Display.Position = UDim2.fromScale(0.5, 1)
	end
end
function UpdateSkinLabels()
	-- upvalues: (ref) v_u_21, (copy) v_u_2
	local v172 = v_u_21:GetExpect("EquippedSkinUUID")
	local v173 = string.len(v172) > 0
	for _, v174 in ipairs(v_u_2:GetTagged("RodSkinActive")) do
		v174.Visible = v173
	end
end
function CombineColors(p175)
	-- upvalues: (copy) v_u_11
	if p175 ~= nil then
		local v176 = {}
		for _, v177 in { p175.EnchantId, p175.EnchantId2 } do
			local v178 = v_u_11:GetEnchantData(v177)
			if v178 then
				local v179 = v178.Data.TierColor
				table.insert(v176, v179)
			end
		end
		if #v176 > 0 then
			local v180 = #v176
			local v181 = {}
			for v182, v183 in ipairs(v176) do
				local v184 = (v182 - 1) / v180
				local v185 = 1 / v180
				for _, v186 in ipairs(v183.Keypoints) do
					local v187 = v184 + v186.Time * v185
					local v188 = ColorSequenceKeypoint.new
					local v189 = v186.Value
					table.insert(v181, v188(v187, v189))
				end
			end
			table.sort(v181, function(p190, p191)
				return p190.Time < p191.Time
			end)
			local v192
			if #v181 > 19 then
				local v193 = (#v181 - 1) / 18
				v192 = {}
				for v194 = 0, 18 do
					local v195 = v194 * v193
					local v196 = v181[math.floor(v195) + 1]
					table.insert(v192, v196)
				end
			else
				v192 = v181
			end
			if #v192 < 2 then
				if #v192 ~= 1 then
					return ColorSequence.new(Color3.new(1, 1, 1))
				end
				local v197 = ColorSequenceKeypoint.new
				local v198 = v192[1].Value
				table.insert(v192, v197(1, v198))
			end
			if v192[1].Time > 0 then
				local v199 = ColorSequenceKeypoint.new
				local v200 = v192[1].Value
				table.insert(v192, 1, v199(0, v200))
			end
			if v192[#v192].Time < 1 then
				local v201 = ColorSequenceKeypoint.new
				local v202 = v192[1].Value
				table.insert(v192, v201(1, v202))
			end
			return ColorSequence.new(v192)
		end
	end
end
function UpdateTile(p_u_203, p204, p_u_205, p_u_206)
	-- upvalues: (copy) v_u_16, (copy) v_u_41, (copy) v_u_1, (copy) v_u_40
	local v_u_207 = p_u_205:WaitForChild("InputVisual")
	local v_u_208 = v_u_207:WaitForChild("BG")
	local v_u_209 = v_u_207:WaitForChild("Vector")
	local v_u_210 = v_u_207:WaitForChild("Label")
	local v_u_211 = v_u_207:WaitForChild("Star")
	local v_u_212 = v_u_211.Position
	local function v_u_215()
		-- upvalues: (ref) v_u_16, (copy) v_u_208, (copy) v_u_209, (copy) v_u_210, (copy) v_u_207, (copy) p_u_206, (ref) v_u_41, (copy) p_u_203, (ref) v_u_1, (copy) v_u_211, (copy) v_u_212
		local v213 = v_u_16:IsMobile()
		if v213 then
			v_u_208.Visible = false
			v_u_209.Visible = false
			v_u_210.Visible = false
		elseif v_u_16:_getDevice() == "Console" then
			if v_u_207:GetAttribute("Slot") then
				local v214 = p_u_206 and v_u_41.Console[p_u_203] or v_u_41.Special[p_u_203]
				if v214 then
					v214 = v_u_1:GetImageForKeyCode(v214)
				end
				if v214 then
					v_u_209.Image = v214
				else
					v_u_209.Image = ""
				end
			end
			v_u_208.Visible = true
			v_u_209.Visible = true
			v_u_210.Visible = false
		else
			v_u_208.Visible = true
			v_u_209.Visible = false
			v_u_210.Visible = true
		end
		if v213 then
			v_u_211.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_211.Position = UDim2.fromScale(0.5, 0.5)
		else
			v_u_211.AnchorPoint = Vector2.new(0, 0.5)
			v_u_211.Position = v_u_212
		end
	end
	local v_u_216 = v_u_16:RegisterDeviceChanged(v_u_215)
	local v_u_217 = v_u_1.InputChanged:Connect(v_u_215)
	local v_u_219 = v_u_207:GetAttributeChangedSignal("Slot"):Connect(function()
		-- upvalues: (copy) v_u_207, (copy) v_u_210, (copy) p_u_205
		local v218 = v_u_207:GetAttribute("Slot")
		if v218 then
			v_u_210.Text = tostring(v218)
			p_u_205.LayoutOrder = v218
		end
	end)
	v_u_207.Destroying:Once(function()
		-- upvalues: (copy) v_u_219, (copy) v_u_217, (ref) v_u_16, (copy) v_u_216
		v_u_219:Disconnect()
		v_u_217:Disconnect()
		v_u_16:Remove(v_u_216)
	end)
	if p_u_206 then
		p_u_203 = v_u_40[p_u_203] or p_u_203
	end
	v_u_207:SetAttribute("Slot", p_u_203)
	if p204 then
		v_u_211.Visible = p204.Favorited
	end
	pcall(function()
		-- upvalues: (copy) v_u_215, (copy) v_u_207, (copy) v_u_210, (copy) p_u_205
		v_u_215()
		local v220 = v_u_207:GetAttribute("Slot")
		if v220 then
			v_u_210.Text = tostring(v220)
			p_u_205.LayoutOrder = v220
		end
	end)
	v_u_207.Parent = p_u_205
end
return v_u_112