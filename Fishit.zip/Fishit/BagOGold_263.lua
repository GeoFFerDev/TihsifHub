-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 7,
		["Type"] = "Baits",
		["Name"] = "Bag-O-Gold",
		["Description"] = "",
		["Icon"] = "rbxassetid://137212237115277",
		["Tier"] = 100
	},
	["Hidden"] = true,
	["EquipAsSkin"] = true,
	["Modifiers"] = {
		["BaseLuck"] = 0.45
	},
	["_moduleScript"] = script
}
return v1