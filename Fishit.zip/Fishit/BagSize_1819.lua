-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v3 = require(v1.Packages.Replion)
local v_u_4 = require(v1.Shared.StringLibrary)
local v_u_5 = require(v1.Shared.Constants)
local v_u_6 = {
	["FishCount"] = 0,
	["ItemCount"] = 0
}
local v_u_7 = {
	["FishCount"] = {},
	["ItemCount"] = {}
}
local v_u_8 = {
	["FishCount"] = v_u_4:AddCommas(v_u_5.MaxInventorySize),
	["ItemCount"] = v_u_4:AddCommas(v_u_5.MaxItemSize)
}
local v_u_9 = { "Inventory", "Items" }
local v_u_10 = Color3.fromRGB(255, 67, 86)
local v_u_11 = Color3.fromRGB(255, 255, 255)
local function v_u_19(p12, p13)
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_11
	local v14 = v_u_8[p12]
	local v15 = v_u_7[p12]
	if v15 then
		local v16 = ("%*/%*"):format(v_u_4:AddCommas(p13), v14)
		for _, v17 in ipairs(v15) do
			v17.Text = v16
			local v18
			if v_u_5.MaxInventorySize <= p13 then
				v18 = v_u_10
			else
				v18 = v_u_11
			end
			v17.TextColor3 = v18
		end
	end
end
v3.Client:AwaitReplion("Data", function(p_u_20)
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_19, (copy) v_u_9
	local function v23()
		-- upvalues: (ref) v_u_5, (copy) p_u_20, (ref) v_u_6, (ref) v_u_19
		local v21, v22 = v_u_5:CountInventorySize(p_u_20)
		v_u_6.FishCount = v21
		v_u_6.ItemCount = v22
		v_u_19("FishCount", v21)
		v_u_19("ItemCount", v22)
	end
	p_u_20:OnChange(v_u_9, v23)
	p_u_20:OnArrayInsert(v_u_9, v23)
	p_u_20:OnArrayRemove(v_u_9, v23)
	local v24, v25 = v_u_5:CountInventorySize(p_u_20)
	v_u_6.FishCount = v24
	v_u_6.ItemCount = v25
	v_u_19("FishCount", v24)
	v_u_19("ItemCount", v25)
end)
v2.observeTag("BagSize", function(p_u_26)
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_19
	local v_u_27 = v_u_7.FishCount
	table.insert(v_u_27, p_u_26)
	local v28 = v_u_6.FishCount
	if v28 then
		v_u_19("FishCount", v28)
	end
	return function()
		-- upvalues: (copy) v_u_27, (copy) p_u_26
		local v29 = table.find(v_u_27, p_u_26)
		if v29 then
			table.remove(v_u_27, v29)
		end
	end
end)
v2.observeTag("ItemSize", function(p_u_30)
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_19
	local v_u_31 = v_u_7.ItemCount
	table.insert(v_u_31, p_u_30)
	local v32 = v_u_6.ItemCount
	if v32 then
		v_u_19("ItemCount", v32)
	end
	return function()
		-- upvalues: (copy) v_u_31, (copy) p_u_30
		local v33 = table.find(v_u_31, p_u_30)
		if v33 then
			table.remove(v_u_31, v33)
		end
	end
end)
return {}