-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v_u_3 = nil
local v4 = v2.LocalPlayer.PlayerGui
local v_u_5 = require(v1.Packages.MarketplaceService)
local v_u_6 = require(v1.Packages.Replion).Client
local v7 = require(v1.Packages.Trove)
local v8 = require(v1.Packages.Net)
local v_u_9 = require(v1.Shared.Soundbook)
local v_u_10 = require(v1.Shared.StringLibrary)
local v_u_11 = require(v1.Shared.ItemUtility)
local v_u_12 = require(v1.Shared.TierUtility)
local v_u_13 = require(v1.Shared.GamePassUtility)
local v_u_14 = require(v1.Modules.CoinProductsUtility)
local v_u_15 = require(v1.Shared.PlayerStatsUtility)
require(v1.Types.Modifiers)
local v_u_16 = require(v1.Modules.GuiControl)
local v_u_17 = require(v1.Controllers.TextNotificationController)
local v_u_18 = require(v1.Modules.InterfaceHighlight)
local v_u_19 = v8:RemoteFunction("PurchaseBait")
local v_u_20 = v8:RemoteEvent("EquipBait")
local v_u_21 = v4:WaitForChild("Bait Shop")
local v_u_22 = v_u_21.Main.Content.List.ScrollingFrame
local v_u_23 = v_u_22.Tile
v_u_23.Parent = nil
local v_u_24 = {}
local v_u_25 = v7.new()
local v_u_26 = nil
local v_u_27 = v_u_12:GetTier("Exclusive")
local v_u_38 = {
	["Start"] = function(_)
		-- upvalues: (ref) v_u_3, (copy) v_u_6, (copy) v_u_16, (copy) v_u_21, (copy) v_u_11, (copy) v_u_24, (ref) v_u_26, (copy) v_u_18
		v_u_3 = v_u_6:WaitReplion("Data")
		v_u_16.GuiUnfocusedSignal:Connect(DestroyTiles)
		v_u_16.GuiFocusedSignal:Connect(function(p28)
			-- upvalues: (ref) v_u_21, (ref) v_u_11, (ref) v_u_3, (ref) v_u_24, (ref) v_u_26, (ref) v_u_18
			if p28 == v_u_21 then
				DestroyTiles()
				local v29 = v_u_11:GetBaits()
				for _, v30 in ipairs(v29) do
					DrawShopTile(v30)
				end
				if v_u_3:Get({ "Quests", "Mainline", "Catch 5 Fish & Upgrade Bait!" }) then
					task.defer(function()
						-- upvalues: (ref) v_u_24, (ref) v_u_26, (ref) v_u_18
						local v31 = v_u_24["Topwater Bait"]
						if v31 then
							v_u_26 = v_u_18.highlight(v31)
						end
					end)
				end
			end
		end)
		v_u_3:OnArrayInsert({ "Inventory", "Baits" }, function(_, p32)
			-- upvalues: (ref) v_u_11
			local v33 = v_u_11:GetBaitData(p32.Id)
			if v33 then
				MarkAsOwned(v33.Data.Name)
			end
		end)
	end,
	["Check"] = function(_, p34)
		-- upvalues: (ref) v_u_3
		local v35 = v_u_3:GetExpect({ "Inventory", "Baits" })
		local v36 = true
		for _, v37 in ipairs(v35) do
			if v37.Id == p34 then
				return false
			end
		end
		return v36
	end
}
function DrawShopTile(p_u_39)
	-- upvalues: (copy) v_u_13, (copy) v_u_5, (copy) v_u_24, (copy) v_u_23, (copy) v_u_12, (copy) v_u_10, (copy) v_u_27, (copy) v_u_15, (copy) v_u_38, (copy) v_u_9, (copy) v_u_17, (ref) v_u_3, (copy) v_u_14, (copy) v_u_19, (copy) v_u_20, (copy) v_u_25, (copy) v_u_22
	if p_u_39.HiddenInShop then
		return
	else
		local v40 = p_u_39.Price
		local v_u_41 = p_u_39.LinkedGamePass
		if v_u_41 then
			local v42 = v_u_13:GetGamePassIdFromName(v_u_41)
			if not v42 then
				return
			end
			local v44, v45 = v_u_5:GetProductInfoAsync(v42, Enum.InfoType.GamePass):andThen(function(p43)
				return p43.PriceInRobux
			end):catch(warn):await()
			if v44 then
				v40 = v45 or v40
			end
		end
		if v40 then
			if not v_u_24[p_u_39.Data.Name] then
				local v46 = v_u_23:Clone()
				local v47 = v46.Padded.Bottom.Luck
				local v_u_48 = v46.Padded.Buy
				local v49 = v46.Padded.Top.CurrencyFrame
				v46.Padded.Top.Label.Text = p_u_39.Data.Name or ""
				v46.BG.Vector.Image = p_u_39.Data.Icon or ""
				local v50 = p_u_39.Data.Tier
				if v50 then
					v50 = v_u_12:GetTier(v50)
				end
				if v50 and v50.Tier > 1 then
					v46.BG.Glow.UIGradient.Color = v50.TierColor
					v46.BG.Glow.Visible = true
				else
					v46.BG.Glow.Visible = false
				end
				if v_u_41 then
					v_u_10:AddCommas(v40)
					v49.Counter.Text = "GAMEPASS"
					v49.Counter.UIGradient.Color = v_u_27.TierColor
					v49.Counter.UIStroke.Color = Color3.new(0, 0, 0)
					v49.VectorFrame.Visible = false
				else
					local v51 = v_u_10:Shorten(v40)
					v49.Counter.Text = v51
				end
				local v52 = p_u_39.Modifiers
				if v52 then
					local v53 = 0
					for _ in v52 do
						v53 = v53 + 1
					end
					v46.Padded.Bottom.Size = UDim2.fromScale(1, v53 / 10)
					local v54 = v46.Padded.Bottom.UIGridLayout
					local v55 = UDim2.fromScale
					local v56 = 1 / v53
					v54.CellSize = v55(1, (math.min(v56, 0.9)))
					for v57, v58 in v52 do
						local v59, v60 = v_u_15:GetModifierDisplayName(v57)
						if v59 then
							local v61
							if v59:find("Multi") then
								local v62 = (1 + v58) * 10
								v61 = ("x%*"):format(math.round(v62) / 10)
							else
								local v63 = v58 * 100
								v61 = ("%*%%"):format((math.round(v63)))
							end
							local v64 = v47:Clone()
							v64.Label.Text = ("%*:"):format(v59)
							v64.Counter.Text = v61
							v64.Counter.TextColor3 = v60
							v64.Parent = v46.Padded.Bottom
						end
					end
				end
				v47:Destroy()
				local v65 = nil
				if v_u_38:Check(p_u_39.Data.Id) then
					v65 = function()
						-- upvalues: (ref) v_u_9, (ref) v_u_38, (copy) p_u_39, (ref) v_u_17, (copy) v_u_41, (ref) v_u_13, (ref) v_u_3, (ref) v_u_14, (ref) v_u_19, (ref) v_u_20
						v_u_9.Sounds.ThickClick:Play()
						if v_u_38:Check(p_u_39.Data.Id) then
							if not v_u_41 or v_u_13:ClientPromptGamepassFromName(v_u_41) then
								local v66 = p_u_39.Price
								if v66 then
									local v67 = v_u_3:GetExpect("Coins")
									if v67 < v66 then
										v_u_14:PurchaseBestCoinPack(v67, v66)
										return
									end
								end
								local v68, v69 = v_u_19:InvokeServer(p_u_39.Data.Id)
								if v68 then
									v_u_9.Sounds.StorePurchase:Play()
									v_u_9.Sounds.CoinsChanged:Play()
									if v69 then
										v_u_20:FireServer(p_u_39.Data.Id)
										v_u_17:DeliverNotification({
											["Type"] = "Text",
											["Text"] = "Equipped new Bait!",
											["TextColor"] = {
												["R"] = 0,
												["G"] = 255,
												["B"] = 255
											},
											["CustomDuration"] = 6
										})
									end
								end
							end
						else
							return v_u_17:DeliverNotification({
								["Type"] = "Text",
								["Text"] = v_u_41 and "You do not own this gamepass!" or "You already own this!",
								["TextColor"] = {
									["R"] = 255,
									["G"] = 203,
									["B"] = 16
								}
							})
						end
					end
				else
					task.defer(MarkAsOwned, p_u_39.Data.Name)
				end
				if v65 then
					v_u_25:Add(v_u_48.Activated:Connect(v65))
				end
				local function v70()
					-- upvalues: (copy) v_u_48
					v_u_48.BackgroundColor3 = Color3.fromRGB(186, 186, 186)
					v_u_48.UIStroke.Color = Color3.fromRGB(255, 255, 255)
					v_u_48.Padded.Label.TextColor3 = Color3.fromRGB(20, 255, 79)
				end
				local function v71()
					-- upvalues: (copy) v_u_48
					v_u_48.BackgroundColor3 = Color3.fromRGB(28, 186, 78)
					v_u_48.UIStroke.Color = Color3.fromRGB(20, 255, 79)
					v_u_48.Padded.Label.TextColor3 = Color3.fromRGB(255, 255, 255)
				end
				v_u_25:Add(v_u_48.MouseEnter:Connect(v70))
				v_u_25:Add(v_u_48.SelectionGained:Connect(v70))
				v_u_25:Add(v_u_48.MouseLeave:Connect(v71))
				v_u_25:Add(v_u_48.SelectionLost:Connect(v71))
				if v_u_41 then
					v46.LayoutOrder = 1000000 + v40
				else
					local v72 = v40 / 100
					v46.LayoutOrder = math.ceil(v72)
				end
				v46.Parent = v_u_22
				v_u_24[p_u_39.Data.Name] = v46
			end
		end
	end
end
function MarkAsOwned(p73)
	-- upvalues: (copy) v_u_24, (ref) v_u_26
	local v74 = v_u_24[p73]
	if v74 then
		if p73 == "Topwater Bait" and v_u_26 then
			v_u_26()
			v_u_26 = nil
		end
		local v75 = v74.Padded.Top
		v75.CurrencyFrame.Visible = false
		v75.OwnedFrame.Visible = true
		if not v74.BG:FindFirstChild("BlackoutVector") then
			local v76 = v74.BG.Vector:Clone()
			v76.Name = "BlackoutVector"
			v76.ImageColor3 = Color3.fromRGB(0, 0, 0)
			v76.ImageTransparency = 0.2
			v76.Parent = v74.BG
		end
		v74.Padded.Bottom.Position = UDim2.fromScale(0, 1)
		v74.Padded.Buy.Visible = false
	end
end
function DestroyTiles()
	-- upvalues: (copy) v_u_25, (ref) v_u_26, (copy) v_u_24
	v_u_25:Clean()
	if v_u_26 then
		v_u_26()
		v_u_26 = nil
	end
	for _, v77 in v_u_24 do
		v77:Destroy()
	end
	table.clear(v_u_24)
end
return v_u_38