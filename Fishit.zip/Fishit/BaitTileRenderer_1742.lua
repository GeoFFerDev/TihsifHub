-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Packages.spr)
local v_u_3 = require(v1.Shared.ItemUtility)
local v_u_4 = require(v1.Shared.TierUtility)
local v_u_5 = require(v1.Shared.PlayerStatsUtility)
local v_u_6 = require(script.Parent.Parent.TileInteraction)
local v_u_7 = {}
v_u_7.__index = v_u_7
function v_u_7.new(p8, p9, p10)
	-- upvalues: (copy) v_u_7
	local v11 = v_u_7
	local v12 = setmetatable({}, v11)
	v12._template = p8
	v12._parentFrame = p9
	v12._tiles = {}
	v12._mobileGridSize = p10
	return v12
end
function v_u_7.SetMobileGridSize(p13, p14)
	p13._mobileGridSize = p14
end
function v_u_7.GetCacheKey(_, p15)
	-- upvalues: (copy) v_u_3
	local v16 = v_u_3:GetBaitData(p15.Id)
	return v16 and v16.Data.Id or 0
end
function v_u_7.GetLayoutOrder(_, _, p17)
	if p17.Modifiers then
		return (p17.Modifiers.BaseLuck or 0) * -1000
	end
	local v18 = p17.Data.Name
	return string.len(v18)
end
function v_u_7.Create(p19, p20, p21)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_6
	local v22 = v_u_3:GetBaitData(p20.Id)
	if not v22 then
		return nil
	end
	local v_u_23 = v22.Data.Id
	local v24 = p19._tiles[v_u_23]
	if v24 then
		p19:Update(v24, p20, v22, p21)
		return v24
	end
	local v25 = v22.IsSkin
	local v26 = v22.EquipAsSkin
	local v27 = v22.Modifiers
	local v28 = p19._template:Clone()
	local v29 = v28.Padded.Bottom.Luck
	local v30 = v28.Padded.Top.EquipAsSkin
	v28.Padded.Top.Label.Text = v22.Data.Name or ""
	v28.BG.Vector.Image = v22.Data.Icon or ""
	if v27 then
		local v31 = 0
		for _ in v27 do
			v31 = v31 + 1
		end
		if p19._mobileGridSize then
			v28.Padded.Bottom.Size = UDim2.fromScale(1, 0)
			v28.Padded.Bottom.AutomaticSize = Enum.AutomaticSize.Y
			v28.Padded.Bottom.UIGridLayout.CellSize = p19._mobileGridSize
		else
			v28.Padded.Bottom.Size = UDim2.fromScale(1, v31 / 10)
			v28.Padded.Bottom.UIGridLayout.CellSize = UDim2.fromScale(1, 1 / v31 * 0.9)
		end
		for v32, v33 in pairs(v27) do
			local v34, v35 = v_u_5:GetModifierDisplayName(v32)
			if v34 then
				local v36
				if v32:find("Multiplier") or v32:find("Multi") then
					local v37 = (1 + v33) * 10
					v36 = ("x%*"):format(math.round(v37) / 10)
				else
					local v38 = v33 * 100
					v36 = ("%*%%"):format((math.round(v38)))
				end
				local v39 = v29:Clone()
				v39.Label.Text = ("%*:"):format(v34)
				v39.Counter.Text = v36
				v39.Counter.TextColor3 = v35
				v39.Parent = v28.Padded.Bottom
			end
		end
	end
	v29:Destroy()
	local v40 = v22.Data.Tier
	local v41
	if v40 then
		v41 = v_u_4:GetTier(v40)
	else
		v41 = v40
	end
	if v41 and v40 > 1 then
		v28.BG.Glow.UIGradient.Color = v41.TierColor
		v28.BG.Glow.Visible = true
	else
		v28.BG.Glow.Visible = false
	end
	local v42 = p21.GuiControl
	local _ = p21.PlayerReplion
	if v25 or v26 then
		p19:_setupSkinButton(v28, v30, v22, p21)
		if v25 then
			v28.Padded.Bottom.Visible = false
		end
	else
		v30:Destroy()
	end
	if not v25 or v26 then
		v42:Hook("Hold Button", v28).Clicked:Connect(function()
			-- upvalues: (ref) v_u_6, (copy) v_u_23
			v_u_6:EquipBait(v_u_23)
		end)
	end
	v28.LayoutOrder = p19:GetLayoutOrder(p20, v22)
	v28.Parent = p19._parentFrame
	p19._tiles[v_u_23] = v28
	p19:Update(v28, p20, v22, p21)
	return v28
end
function v_u_7.Update(_, p43, _, p44, p45)
	local v46 = p45.PlayerReplion:GetExpect("EquippedBaitId") == p44.Data.Id
	p43.UIStroke.Enabled = v46
end
function v_u_7._setupSkinButton(_, _, p_u_47, p48, p49)
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	local v_u_50 = p49.GuiControl
	local v51 = p49.PlayerReplion
	local v_u_52 = p48.Data.Id
	local function v54(p53)
		-- upvalues: (ref) v_u_2, (copy) p_u_47, (copy) v_u_52
		v_u_2.stop(p_u_47)
		if p53 == v_u_52 then
			p_u_47.Label.Text = "UNEQUIP SKIN"
			v_u_2.target(p_u_47, 3, 10, {
				["ImageColor3"] = Color3.fromRGB(255, 94, 97)
			})
		else
			p_u_47.Label.Text = "EQUIP SKIN"
			v_u_2.target(p_u_47, 3, 10, {
				["ImageColor3"] = Color3.fromRGB(123, 187, 255)
			})
		end
	end
	local v55 = v_u_50:Hook("Hold Button", p_u_47)
	local v_u_56 = v51:OnChange("EquippedBaitSkinId", v54)
	v55.Cleaner:Add(function()
		-- upvalues: (copy) v_u_56
		v_u_56:Disconnect()
	end)
	v55.Clicked:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) v_u_52, (copy) v_u_50
		if v_u_6:ToggleBaitSkin(v_u_52) then
			v_u_50:Close()
		end
	end)
	v54(v51.Data.EquippedBaitSkinId)
	p_u_47.Visible = true
end
function v_u_7.GetTile(p57, p58)
	return p57._tiles[p58]
end
function v_u_7.GetAllTiles(p59)
	return p59._tiles
end
function v_u_7.DestroyAll(p60)
	for _, v61 in p60._tiles do
		v61:Destroy()
	end
	table.clear(p60._tiles)
end
return v_u_7