-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["new"] = function(p1)
		local v2 = {}
		local v3 = 0
		for v4, v5 in p1 do
			if v5 >= 3 then
				v2[v4] = v5
				v3 = v3 + v5
			end
		end
		if v3 == 0 then
			return p1
		end
		local v6 = 100 / v3
		local v7 = {}
		local v8 = 0
		for v9, v10 in p1 do
			if v10 >= 3 then
				v7[v9] = v10 * v6
				v8 = v8 + v7[v9]
			else
				v7[v9] = v10
			end
		end
		local v11 = 100 - v8
		for v12, _ in v7 do
			if p1[v12] >= 3 then
				v7[v12] = v7[v12] + v11
				return v7
			end
		end
		return v7
	end
}