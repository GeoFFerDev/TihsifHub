-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 119,
		["Type"] = "Fish",
		["Name"] = "Ballina Angelfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://99236757363784",
		["Tier"] = 3
	},
	["SellPrice"] = 391,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.12, 4.52),
		["Default"] = NumberRange.new(1.94, 2.52)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1