-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 460,
		["Type"] = "Fish",
		["Name"] = "Balloon Shrimp",
		["Description"] = "",
		["Icon"] = "rbxassetid://123420550559333",
		["Tier"] = 5
	},
	["SellPrice"] = 5500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(10, 13),
		["Default"] = NumberRange.new(6, 8)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["EventTag"] = "BDAY",
	["_moduleScript"] = script
}
return v1