-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 258,
		["Type"] = "Fishing Rods",
		["Name"] = "Bamboo Rod",
		["Description"] = "",
		["Icon"] = "rbxassetid://95236691549566",
		["Tier"] = 6
	},
	["ClickPower"] = 0.25,
	["Resilience"] = 6.5,
	["Windup"] = NumberRange.new(2.9, 3.4),
	["MaxWeight"] = 500000
}
local v2 = {
	["BaseLuck"] = 7.6,
	["SizeMultiplier"] = 0.1,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1.OverrideC0 = Vector3.new(0, 2, -0.6)
v1.OverrideROT = CFrame.fromOrientation(0, 0, -0.7853981633974483)
v1.GripC0 = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.Angles(-1.5707963267948966, 3.141592653589793, 0)
v1.GripC1 = CFrame.identity
v1.UseNewRodGrip = true
v1.Price = 12000000
v1.HiddenInShop = true
v1.EligiblePath = { "UnlockedTemple" }
v1._moduleScript = script
return v1