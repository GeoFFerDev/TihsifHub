-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 37,
		["Type"] = "Boats",
		["Name"] = "Banana Pirate Raft",
		["Description"] = "",
		["Icon"] = "rbxassetid://101675793745922",
		["Tier"] = 4
	},
	["HiddenInShop"] = true,
	["Seats"] = 3,
	["_moduleScript"] = script
}
return v1