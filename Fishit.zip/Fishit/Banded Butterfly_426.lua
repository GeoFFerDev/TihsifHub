-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 44,
		["Type"] = "Fish",
		["Name"] = "Banded Butterfly",
		["Description"] = "",
		["Icon"] = "rbxassetid://108599906664305",
		["Tier"] = 2
	},
	["SellPrice"] = 153,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.2, 4),
		["Default"] = NumberRange.new(2, 2.4)
	},
	["Probability"] = {
		["Chance"] = 0.008
	},
	["_moduleScript"] = script
}
return v1