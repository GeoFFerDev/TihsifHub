-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 117,
		["Type"] = "Fish",
		["Name"] = "Bandit Angelfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://86776001616210",
		["Tier"] = 2
	},
	["SellPrice"] = 105,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(5.09, 5.72),
		["Default"] = NumberRange.new(2.26, 3.39)
	},
	["Probability"] = {
		["Chance"] = 0.015384615384615385
	},
	["_moduleScript"] = script
}
return v1