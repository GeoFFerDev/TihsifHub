-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 594,
		["Type"] = "Fish",
		["Name"] = "Banditfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://84761253891494",
		["Tier"] = 4
	},
	["SellPrice"] = 1220,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2, 2.4),
		["Default"] = NumberRange.new(1.2, 1.5)
	},
	["Probability"] = {
		["Chance"] = 0.0006666666666666666
	},
	["_moduleScript"] = script
}
return v1