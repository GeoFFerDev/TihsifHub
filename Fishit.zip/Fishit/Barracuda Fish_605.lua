-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 194,
		["Type"] = "Fish",
		["Name"] = "Barracuda Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://109111807975453",
		["Tier"] = 3
	},
	["SellPrice"] = 392,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(19.5, 22.1),
		["Default"] = NumberRange.new(15.7, 17.9)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1