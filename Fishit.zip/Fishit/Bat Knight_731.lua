-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 328,
		["Type"] = "Fishing Rods",
		["Name"] = "Bat Knight",
		["Description"] = "",
		["Icon"] = "rbxassetid://85098865707017",
		["Tier"] = 4
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0, 2, -0.75),
	["OverrideROT"] = CFrame.fromOrientation(0, 0, -0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(0, -1.2, 0)) * CFrame.fromOrientation(1.5707963267948966, 3.141592653589793, 0),
	["GripC1"] = CFrame.identity,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1