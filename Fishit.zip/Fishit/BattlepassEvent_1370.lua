-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["BattlepassId"] = "PiratesCoveEvent",
	["CurrencyName"] = "Doubloons",
	["BPItems"] = {
		{
			["Cost"] = 250,
			["CurrencyRewardInfo"] = v2.currencyReward("Coins", 1000)
		},
		{
			["Cost"] = 400,
			["CurrencyRewardInfo"] = v2.potionReward("Luck I Potion", 3)
		},
		{
			["Cost"] = 1000,
			["CurrencyRewardInfo"] = v2.fishingRodReward("Rocky Prism")
		},
		{
			["Cost"] = 2500,
			["CurrencyRewardInfo"] = v2.itemReward("Enchant Stone", 1)
		},
		{
			["Cost"] = 4000,
			["CurrencyRewardInfo"] = v2.potionReward("Luck II Potion", 2)
		},
		{
			["Cost"] = 6500,
			["CurrencyRewardInfo"] = v2.potionReward("Mutation I Potion", 1)
		},
		{
			["Cost"] = 8000,
			["CurrencyRewardInfo"] = v2.currencyReward("Coins", 5000)
		},
		{
			["Cost"] = 10000,
			["CurrencyRewardInfo"] = v2.itemReward("Enchant Stone", 1)
		},
		{
			["Cost"] = 12500,
			["CurrencyRewardInfo"] = v2.potionReward("Mutation I Potion", 1)
		},
		{
			["Cost"] = 18000,
			["CurrencyRewardInfo"] = v2.potionReward("Luck II Potion", 3)
		},
		{
			["Cost"] = 30000,
			["CurrencyRewardInfo"] = v2.baitReward("Hooke\'s Bait")
		},
		{
			["Cost"] = 42000,
			["CurrencyRewardInfo"] = v2.potionReward("Mutation I Potion", 2)
		},
		{
			["Cost"] = 48000,
			["CurrencyRewardInfo"] = v2.potionReward("Luck II Potion", 2)
		},
		{
			["Cost"] = 50000,
			["CurrencyRewardInfo"] = v2.itemReward("2026 Pirates Plaque", 1)
		},
		{
			["Cost"] = 54000,
			["CurrencyRewardInfo"] = v2.fishingRodReward("Sea Wisp")
		},
		{
			["Cost"] = 58000,
			["CurrencyRewardInfo"] = v2.boatReward("Banana Pirate Raft")
		}
	}
}
return v3