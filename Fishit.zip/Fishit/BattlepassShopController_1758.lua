-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v_u_3 = require(v_u_1.Packages.Replion)
local v4 = require(v_u_1.Packages.Net)
local v_u_5 = require(v_u_1.Packages.Trove)
local v6 = require(v_u_1.Shared.RewardInfo)
local v_u_7 = require(v_u_1.Shared.BattlepassShop)
local v_u_8 = require(v_u_1.Shared.ItemUtility)
local v_u_9 = require(v_u_1.Shared.TierUtility)
local v_u_10 = require(v_u_1.Shared.StringLibrary)
local v_u_11 = require(v_u_1.Modules.CurrencyUtility)
require(v_u_1.Shared.InventoryMapping)
require(v_u_1.Shared.PlayerStatsUtility)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = v4:RemoteEvent("BPPurchaseRequest")
local v_u_15 = v_u_11:GetCurrency(v6.BattlepassCurrency)
local v_u_16 = v2.LocalPlayer
local v17 = v_u_16.PlayerGui
local v_u_18 = nil
local v_u_19 = v17:WaitForChild("BattlepassShop")
local v20 = v17:WaitForChild("Quest")
local v_u_21 = v_u_19.Container.ScrollBG.ScrollingFrame
local v_u_22 = v20.List.Inside.EventFrame.EventButton
local v_u_23 = v_u_21.Template
v_u_23.Parent = nil
local v_u_24 = {
	["Baits"] = "Bobber Skin",
	["Lanterns"] = "Lantern Skin",
	["Fishing Rods"] = "Rod Skin"
}
local v_u_25 = {}
v_u_11:GetCurrency("Valentines Coins")
function v_u_25.Init(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13
	v_u_12 = require(v_u_1.Modules.GuiControl)
	v_u_13 = require(v_u_1.Controllers.DialogueController)
end
function v_u_25.Start(_)
	-- upvalues: (ref) v_u_18, (copy) v_u_3, (ref) v_u_12, (copy) v_u_22, (copy) v_u_19, (copy) v_u_7, (copy) v_u_16, (copy) v_u_8, (copy) v_u_11, (copy) v_u_9, (copy) v_u_23, (copy) v_u_24, (copy) v_u_10, (copy) v_u_5, (copy) v_u_25, (copy) v_u_21
	v_u_18 = v_u_3.Client:WaitReplion("Data")
	v_u_12:Hook("Hold Button", v_u_22).Clicked:Connect(function()
		-- upvalues: (ref) v_u_12
		if v_u_12:IsOpen("BattlepassShop") then
			v_u_12:Close("BattlepassShop")
		else
			v_u_12:Open("BattlepassShop")
		end
	end);
	(function()
		-- upvalues: (ref) v_u_19, (ref) v_u_18, (ref) v_u_7, (ref) v_u_3, (ref) v_u_16, (ref) v_u_12
		local v26 = v_u_19.Container.SkipAll.SkipAll
		v26:SetAttribute("DevProductId", 3535927301)
		v26:AddTag("DevProductPrice")
		local v27 = v_u_18:GetExpect({ "ValentinesBP25" })
		if v27 then
			local v28 = #v_u_7
			if v27[tostring(v28)] then
				v_u_19.Container.SkipAll.Visible = false
			else
				local function v_u_34(p_u_29, p30)
					-- upvalues: (ref) v_u_3, (ref) v_u_7, (ref) v_u_16
					local v31 = v_u_3.Client:GetReplion("Data")
					if v31 then
						if p30 and v31:Find("Limiteds", p_u_29) then
							return
						else
							local v32 = v31:GetExpect({ "ValentinesBP25" })
							if v32 then
								local v33 = #v_u_7
								if not v32[tostring(v33)] then
									pcall(function()
										-- upvalues: (ref) v_u_16, (copy) p_u_29
										return game:GetService("MarketplaceService"):PromptProductPurchase(v_u_16, p_u_29)
									end)
								end
							else
								return
							end
						end
					else
						return
					end
				end
				v_u_12:Hook("Hold Button", v26).Clicked:Connect(function()
					-- upvalues: (copy) v_u_34
					v_u_34(3535927301)
				end)
			end
		else
			return
		end
	end)()
	for v_u_35, v36 in v_u_7 do
		local v37 = v36.RewardInfo.Identifier
		local v38 = v_u_8.GetItemDataFromItemType(v36.RewardInfo.Type, v36.RewardInfo.Identifier)
		local v39 = v36.RewardInfo.Type
		local v40 = v36.RewardInfo.Quantity or (v36.RewardInfo.Amount or 1)
		if v39 then
			local v41 = v39 == "Currency"
			if v37 or v41 then
				if v41 and v36.RewardInfo.Name then
					v38 = v_u_11:GetCurrency(v36.RewardInfo.Name)
				end
				if v38 then
					local v42 = v41 and v_u_9:GetTier(5) or v_u_9:GetTier(v38.Data.Tier)
					if v42 or v41 then
						local v43 = v_u_23:Clone()
						local v_u_44 = v43.BuyButton
						local v45
						if v41 then
							v45 = v36.RewardInfo.Name
						else
							v45 = v_u_24[v38.Data.Type]
						end
						if v45 then
							v43.ItemType.Text = v45
							v43.ItemType.Visible = true
						else
							v43.ItemType.Visible = false
						end
						v43.ItemName.Text = v41 and ("+%*"):format((v_u_10:AddCommas(v40))) or v38.Data.Name
						v43.Tier.Text = v42.Name
						v43.Tier.UIGradient.Color = v42.TierColor
						v43.DecorationHolder.Icon.Image = v41 and v38.Icon or v38.Data.Icon
						v_u_44.BuyButton.Counter.Text = v_u_10:AddCommas(v36.Price)
						v_u_44.BuyButton.OwnedGradient.Enabled = false
						v_u_44.BuyButton.OwnedUIStroke.Enabled = false
						v_u_44.BuyButton.UIStroke.Enabled = true
						v_u_44.BuyButton.UIGradient.Enabled = true
						v43.LayoutOrder = v_u_35
						local v46 = v_u_18:GetExpect({ "ValentinesBP25" })
						local v47
						if v46 then
							v47 = not v46[tostring(v_u_35)] and true or false
						else
							v47 = nil
						end
						if v47 then
							local v_u_48 = v_u_5.new()
							local v_u_49 = v_u_12:Hook("Hold Button", v_u_44)
							v_u_49.Clicked:Connect(function()
								-- upvalues: (ref) v_u_25, (copy) v_u_35
								v_u_25:PurchaseItem(v_u_35)
							end)
							local v_u_53 = v_u_18:OnChange("ValentinesBP25", function()
								-- upvalues: (copy) v_u_35, (ref) v_u_18, (copy) v_u_44, (copy) v_u_48
								task.wait(0.25)
								local v50 = v_u_35
								local v51 = v_u_18:GetExpect({ "ValentinesBP25" })
								local v52
								if v51 then
									v52 = not v51[tostring(v50)] and true or false
								else
									v52 = nil
								end
								if not v52 then
									v_u_44.BuyButton.UIStroke.Enabled = false
									v_u_44.BuyButton.UIGradient.Enabled = false
									v_u_44.BuyButton.OwnedGradient.Enabled = true
									v_u_44.BuyButton.OwnedUIStroke.Enabled = true
									v_u_44.BuyButton.Counter.Text = "Owned"
									v_u_48:Clean()
								end
							end)
							v_u_48:Add(function()
								-- upvalues: (copy) v_u_49, (copy) v_u_53
								v_u_49:Destroy()
								v_u_53:Disconnect()
							end)
						else
							v_u_44.BuyButton.UIStroke.Enabled = false
							v_u_44.BuyButton.UIGradient.Enabled = false
							v_u_44.BuyButton.OwnedGradient.Enabled = true
							v_u_44.BuyButton.OwnedUIStroke.Enabled = true
							v_u_44.BuyButton.Counter.Text = "Owned"
						end
						v43.Parent = v_u_21
					else
						warn("No tier data??")
					end
				else
					warn("No item data??", v37, v39)
				end
			end
		end
	end
end
function v_u_25.PurchaseItem(_, p54)
	-- upvalues: (copy) v_u_7, (ref) v_u_18, (copy) v_u_15, (copy) v_u_14
	local v55 = v_u_7[p54]
	if v55 then
		if (v_u_18:Get(v_u_15.Path) or 0) < v55.Price then
			return
		else
			local v56 = v_u_18:GetExpect({ "ValentinesBP25" })
			local v57
			if v56 then
				v57 = not v56[tostring(v55)] and true or false
			else
				v57 = nil
			end
			if v57 then
				v_u_14:FireServer(p54)
			end
		end
	else
		return
	end
end
return v_u_25