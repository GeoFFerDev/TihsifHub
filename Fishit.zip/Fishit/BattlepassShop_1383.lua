-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
return {
	{
		["RewardInfo"] = v2.potionReward("Luck I Potion", 1),
		["Price"] = 2000
	},
	{
		["RewardInfo"] = v2.currencyReward("Coins", 2000),
		["Price"] = 5000
	},
	{
		["RewardInfo"] = v2.potionReward("Luck II Potion", 1),
		["Price"] = 7000
	},
	{
		["RewardInfo"] = v2.currencyReward("Coins", 5000),
		["Price"] = 9000
	},
	{
		["RewardInfo"] = v2.baitReward("Loving Heart"),
		["Price"] = 12000
	},
	{
		["RewardInfo"] = v2.baitReward("Eternal Love"),
		["Price"] = 15000
	},
	{
		["RewardInfo"] = v2.charmReward("Heart Charm", 2),
		["Price"] = 18000
	},
	{
		["RewardInfo"] = v2.lanternReward("Heart Lantern"),
		["Price"] = 22000
	},
	{
		["RewardInfo"] = v2.fishingRodReward("Lovestruck"),
		["Price"] = 26000
	},
	{
		["RewardInfo"] = v2.potionReward("Love I Potion", 3),
		["Price"] = 30000
	},
	{
		["RewardInfo"] = v2.lanternReward("Lovestruck Lantern"),
		["Price"] = 34000
	},
	{
		["RewardInfo"] = v2.fishingRodReward("Cupid Wings"),
		["Price"] = 38000
	},
	{
		["RewardInfo"] = v2.baitReward("Magical Heart"),
		["Price"] = 42000
	},
	{
		["RewardInfo"] = v2.fishingRodReward("Cute Ribbon"),
		["Price"] = 45000
	},
	{
		["RewardInfo"] = v2.itemReward("2026 Valentines Plaque", 1),
		["Price"] = 50000
	},
	{
		["RewardInfo"] = v2.boatReward("Swan Boat"),
		["Price"] = 55000
	}
}