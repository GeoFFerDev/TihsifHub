-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 9,
		["Type"] = "Baits",
		["Name"] = "Beach Ball Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://108189237998480 ",
		["Tier"] = 1
	},
	["Hidden"] = true,
	["Modifiers"] = {
		["BaseLuck"] = 0.05
	},
	["_moduleScript"] = script
}
return v1