-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 441,
		["Type"] = "Fish",
		["Name"] = "Beach Ball",
		["Description"] = "",
		["Icon"] = "rbxassetid://99523992488689",
		["Tier"] = 2
	},
	["SellPrice"] = 55,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(4.9, 5.8),
		["Default"] = NumberRange.new(2.9, 3.7)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1