-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 290,
		["Type"] = "Fish",
		["Name"] = "Beanie Leedsicheye",
		["Description"] = "",
		["Icon"] = "rbxassetid://85346893566616",
		["Tier"] = 1
	},
	["SellPrice"] = 19,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.6, 2.1),
		["Default"] = NumberRange.new(0.5, 1.2)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1