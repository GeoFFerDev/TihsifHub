-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local _ = game:GetService("Players").LocalPlayer
require(v1.Modules.Animations)
return function()
	if not game:IsLoaded() then
		game.Loaded:Wait()
	end
end