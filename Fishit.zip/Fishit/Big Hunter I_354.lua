-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 3,
		["Type"] = "Enchants",
		["Name"] = "Big Hunter I",
		["Description"] = "Makes fish 10% bigger",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(103, 123, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(95, 119, 175)) })
	},
	["Modifiers"] = {
		["SizeMultiplier"] = 0.1
	},
	["_moduleScript"] = script
}
return v1