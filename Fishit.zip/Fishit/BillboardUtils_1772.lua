-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["new"] = function(p1)
		local v_u_2 = p1.TweenService
		local v_u_3 = p1.billboardTemplate
		local function v_u_10(p4, p5)
			if p5 then
				return p5
			else
				local v6 = p4:FindFirstChild("Main")
				if v6 and v6:IsA("BasePart") then
					return v6
				else
					local v7 = p4:FindFirstChild("HumanoidRootPart")
					if v7 and v7:IsA("BasePart") then
						return v7
					else
						local v8 = p4.PrimaryPart
						if v8 then
							return v8
						else
							local v9 = p4:FindFirstChildWhichIsA("BasePart")
							if v9 and v9:IsA("BasePart") then
								return v9
							else
								return nil
							end
						end
					end
				end
			end
		end
		return {
			["getCrateItemChance"] = function(p11, p12, p13)
				for _, v14 in ipairs(p11.crateItems) do
					if v14.itemType == p12 and v14.itemName == p13 then
						return v14.chance
					end
				end
				return nil
			end,
			["formatChanceText"] = function(p15)
				if p15 then
					local v16 = p15 * 10
					local v17 = math.round(v16) / 10
					if v17 == math.floor(v17) then
						return ("%*%%"):format(v17)
					else
						return string.format("%.1f%%", v17)
					end
				else
					return "??%"
				end
			end,
			["createItemBillboard"] = function(p18, p19, p20, p21, p22, p23)
				-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_2
				local v24 = v_u_3:Clone()
				local v25 = v24.Size
				v24.Size = UDim2.new(v25.X.Scale * 0.15, v25.X.Offset * 0.15, v25.Y.Scale * 0.15, v25.Y.Offset * 0.15)
				local v26 = v_u_10(p18, p23)
				if v26 then
					v24.Adornee = v26
				end
				v24.StudsOffset = Vector3.new(0, p22, 0)
				v24.Parent = p18
				v_u_2:Create(v24, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Size"] = v25
				}):Play()
				local v27 = v24:FindFirstChild("Frame")
				if v27 and v27:IsA("Frame") then
					local v28 = v27:FindFirstChild("ItemName")
					if v28 and v28:IsA("TextLabel") then
						v28.Text = p19
					end
					local v29 = v27:FindFirstChild("ItemLuck")
					if v29 and v29:IsA("TextLabel") then
						v29.Text = p20
						v29.TextColor3 = p21
						local v30 = v29:FindFirstChildWhichIsA("UIGradient")
						if v30 then
							v30.Color = ColorSequence.new(p21)
						end
					end
				end
				return v24
			end
		}
	end
}