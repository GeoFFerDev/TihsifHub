-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 28,
		["Type"] = "Baits",
		["Name"] = "Binary Crystal",
		["Description"] = "",
		["Icon"] = "rbxassetid://112945825412686",
		["Tier"] = 7
	},
	["Hidden"] = true,
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1