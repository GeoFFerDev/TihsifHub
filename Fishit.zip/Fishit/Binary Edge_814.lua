-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 404,
		["Type"] = "Fishing Rods",
		["Name"] = "Binary Edge",
		["Description"] = "",
		["Icon"] = "rbxassetid://84094186545615",
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.85, 2, -0.65),
	["OverrideROT"] = CFrame.fromOrientation(0, 0, -1.5707963267948966),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.fromOrientation(0, 1.5707963267948966, -1.5707963267948966),
	["GripC1"] = CFrame.identity,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1