-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
return function(p_u_2, p3, p4)
	-- upvalues: (copy) v_u_1
	v_u_1:BindToRenderStep(p_u_2, p3, p4)
	return function()
		-- upvalues: (ref) v_u_1, (copy) p_u_2
		v_u_1:UnbindFromRenderStep(p_u_2)
	end
end