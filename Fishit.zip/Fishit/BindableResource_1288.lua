-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return function(p1)
	p1:RegisterType("bindableResource", p1.Cmdr.Util.MakeEnumType("BindableResource", { "Chat" }))
end