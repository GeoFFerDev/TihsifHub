-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 649,
		["Type"] = "Fish",
		["Name"] = "Bioluminescent Manta Ray",
		["Description"] = "",
		["Icon"] = "rbxassetid://115522251824285",
		["Tier"] = 6
	},
	["SellPrice"] = 61000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(13600, 15500),
		["Default"] = NumberRange.new(7400, 11500)
	},
	["Probability"] = {
		["Chance"] = 0.000015384615384615384
	},
	["_moduleScript"] = script
}
return v1