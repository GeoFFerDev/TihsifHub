-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 647,
		["Type"] = "Fish",
		["Name"] = "Biolumiscent Octopus",
		["Description"] = "",
		["Icon"] = "rbxassetid://80885775494243",
		["Tier"] = 5
	},
	["SellPrice"] = 5500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(160, 190),
		["Default"] = NumberRange.new(130, 150)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1