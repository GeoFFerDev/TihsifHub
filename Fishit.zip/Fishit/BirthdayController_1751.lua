-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
require(v1.Packages.Thread)
local v_u_2 = require(v1.Packages.Observers)
local v_u_3 = {}
function EmitAll(p4)
	for _, v_u_5 in pairs(p4:GetDescendants()) do
		if v_u_5:IsA("ParticleEmitter") then
			local v_u_6 = v_u_5:GetAttribute("EmitCount")
			local v7 = v_u_5:GetAttribute("EmitDelay") or 0
			local v_u_8 = v_u_5:GetAttribute("EmitDuration")
			if v_u_6 then
				if v7 == 0 then
					v_u_5:Emit(v_u_6)
					if v_u_8 and v_u_8 ~= 0 then
						v_u_5.Enabled = true
						task.delay(v_u_8, function()
							-- upvalues: (copy) v_u_5
							v_u_5.Enabled = false
						end)
					end
				else
					task.delay(v7, function()
						-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_8
						v_u_5:Emit(v_u_6)
						if v_u_8 and v_u_8 ~= 0 then
							v_u_5.Enabled = true
							task.delay(v_u_8, function()
								-- upvalues: (ref) v_u_5
								v_u_5.Enabled = false
							end)
						end
					end)
				end
			end
		end
	end
end
return {
	["Start"] = function(_)
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		local v9 = { (workspace:WaitForChild("Islands")) }
		v_u_2.observeTag("BirthdayFireworks", function(p_u_10)
			-- upvalues: (ref) v_u_3
			local v11 = p_u_10.Parent
			if v11 then
				local v12 = v11.Name
				local v_u_13 = v_u_3[v12]
				if not v_u_13 then
					v_u_3[v12] = {}
					v_u_13 = v_u_3[v12]
				end
				if v_u_13 then
					table.insert(v_u_13, p_u_10)
					return function()
						-- upvalues: (ref) v_u_13, (copy) p_u_10, (ref) v_u_3
						local v14 = table.find(v_u_13, p_u_10)
						if v14 then
							table.remove(v_u_3, v14)
						end
					end
				end
			end
		end, v9)
		task.spawn(function()
			-- upvalues: (ref) v_u_3
			while true do
				repeat
					task.wait(30 * (2 * math.random()))
				until workspace:GetServerTimeNow() <= 1765249200
				for _, v15 in v_u_3 do
					for _, v16 in v15 do
						EmitAll(v16)
					end
					local v17 = 4 * math.random()
					task.wait(v17)
				end
			end
		end)
	end
}