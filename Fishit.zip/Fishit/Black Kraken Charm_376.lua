-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 6,
		["Type"] = "Charms",
		["Name"] = "Black Kraken Charm",
		["Description"] = "Needs a description!",
		["Icon"] = "rbxassetid://133161201566022",
		["NewIcon"] = true,
		["Tier"] = 7
	},
	["Level"] = 300,
	["Uses"] = 600,
	["C0"] = CFrame.identity,
	["C1"] = CFrame.identity,
	["Modifiers"] = {
		["BaseLuck"] = 0
	},
	["FishModifiers"] = {},
	["Downloadable"] = true,
	["_moduleScript"] = script
}
return v1