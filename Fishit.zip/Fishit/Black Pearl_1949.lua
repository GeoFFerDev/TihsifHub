-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Travel the Seas in search for the infamous Black Pearl Ship",
	["AssociatedTier"] = 6
}
local v4 = {}
local v5 = {
	["Id"] = 1,
	["Name"] = "Give Captain Jones a Leviathan Rage mutated fish",
	["Goal"] = 1,
	["Type"] = "Exchange"
}
local v6 = {
	["Metadata"] = {
		["VariantId"] = 23
	}
}
v5.Requirements = v6
local v7 = {
	["Id"] = 2,
	["Name"] = "Find the SECRET Dead Man\'s Compass",
	["Goal"] = 1,
	["Type"] = "Search",
	["Requirements"] = {
		["Object"] = "DeadManCompass"
	}
}
local v8 = {
	["Id"] = 3,
	["Name"] = "Return to the Captain",
	["Goal"] = 1,
	["Type"] = "SpeakWithNPC",
	["Requirements"] = {
		["NPC"] = "Captain Jones",
		["Path"] = 3,
		["Index"] = 2
	}
}
local v9 = {
	["Id"] = 4,
	["Name"] = "Bring Captain a Cursed Kraken",
	["Goal"] = 1,
	["Type"] = "Exchange",
	["Requirements"] = {
		["Id"] = 589
	},
	["AssociatedItem"] = "Cursed Kraken",
	["AssociatedType"] = "Fish"
}
__set_list(v4, 1, {v5, v7, v8, v9})
v3.Objectives = v4
v3.Reward = v2.boatReward("Colossal Pirate Ship")
return v3