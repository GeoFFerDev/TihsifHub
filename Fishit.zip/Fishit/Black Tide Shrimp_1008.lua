-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 595,
		["Type"] = "Fish",
		["Name"] = "Black Tide Shrimp",
		["Description"] = "",
		["Icon"] = "rbxassetid://118553508806655",
		["Tier"] = 5
	},
	["SellPrice"] = 5500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(11.2, 13.1),
		["Default"] = NumberRange.new(9.2, 10.5)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1