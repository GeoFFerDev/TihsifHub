-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 182,
		["Type"] = "Fish",
		["Name"] = "Blackcap Basslet",
		["Description"] = "",
		["Icon"] = "rbxassetid://95659897738388",
		["Tier"] = 2
	},
	["SellPrice"] = 95,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(5.6, 6.3),
		["Default"] = NumberRange.new(3.1, 4)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1