-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 577,
		["Type"] = "Gears",
		["Name"] = "Blacktide Relic",
		["Description"] = "Used to summon the vicious Leviathan",
		["Icon"] = "rbxassetid://80175896713511",
		["Tier"] = 4
	},
	["TradeLocked"] = true,
	["_moduleScript"] = script
}
return v1