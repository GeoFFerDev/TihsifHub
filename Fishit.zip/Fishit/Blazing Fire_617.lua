-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 216,
		["Type"] = "Fishing Rods",
		["Name"] = "Blazing Fire",
		["Description"] = "",
		["Icon"] = "rbxassetid://95655883897541",
		["Tier"] = 6
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1