-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 121,
		["Type"] = "Fish",
		["Name"] = "Bleekers Damsel",
		["Description"] = "",
		["Icon"] = "rbxassetid://116977046936052",
		["Tier"] = 2
	},
	["IgnoreTier"] = true,
	["SellPrice"] = 74,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(5.23, 6.11),
		["Default"] = NumberRange.new(3.22, 4.56)
	},
	["Probability"] = {
		["Chance"] = 0.02857142857142857
	},
	["EventTag"] = "VAL25",
	["_moduleScript"] = script
}
return v1