-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 150,
		["Type"] = "Fish",
		["Name"] = "Blob Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://109329387304752",
		["Tier"] = 6
	},
	["SellPrice"] = 26200,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.5, 5),
		["Default"] = NumberRange.new(2.4, 3)
	},
	["Probability"] = {
		["Chance"] = 0.00002
	},
	["_moduleScript"] = script
}
return v1