-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 23,
		["Type"] = "Enchants",
		["Name"] = "Blob Hunter",
		["Description"] = "Increase all Blob Fish chance by +40%",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 212, 247)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 180, 191)) })
	},
	["Modifiers"] = {
		["BlobMultiplier"] = 0.4
	},
	["_moduleScript"] = script
}
return v1