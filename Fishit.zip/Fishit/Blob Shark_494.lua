-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 82,
		["Type"] = "Fish",
		["Name"] = "Blob Shark",
		["Description"] = "",
		["Icon"] = "rbxassetid://120294742064292",
		["Tier"] = 7
	},
	["SellPrice"] = 98000,
	["Variants"] = { "Color Burn" },
	["Weight"] = {
		["Big"] = NumberRange.new(638.5, 753.3),
		["Default"] = NumberRange.new(532.2, 590.5)
	},
	["Probability"] = {
		["Chance"] = 4e-6
	},
	["_moduleScript"] = script
}
return v1