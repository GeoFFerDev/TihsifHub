-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 350,
		["Type"] = "Fish",
		["Name"] = "Blobby Shieldfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://78472043782085",
		["Tier"] = 4
	},
	["SellPrice"] = 1600,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.3, 4.4),
		["Default"] = NumberRange.new(1.1, 2.2)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["_moduleScript"] = script
}
return v1