-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 440,
		["Type"] = "Fish",
		["Name"] = "Block Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://124410297821349",
		["Tier"] = 4
	},
	["SellPrice"] = 1100,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2, 2.5),
		["Default"] = NumberRange.new(1.2, 1.6)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1