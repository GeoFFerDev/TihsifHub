-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Fishing"] = { Enum.HumanoidStateType.Dead },
	["Footsteps"] = {
		Enum.HumanoidStateType.Dead,
		Enum.HumanoidStateType.Freefall,
		Enum.HumanoidStateType.Swimming,
		Enum.HumanoidStateType.Flying,
		Enum.HumanoidStateType.Climbing,
		Enum.HumanoidStateType.Jumping,
		Enum.HumanoidStateType.Ragdoll,
		Enum.HumanoidStateType.FallingDown
	}
}