-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 439,
		["Type"] = "Fish",
		["Name"] = "Blockmine Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://136270282783680",
		["Tier"] = 2
	},
	["SellPrice"] = 55,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(6, 8),
		["Default"] = NumberRange.new(3, 5)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1