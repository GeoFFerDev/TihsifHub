-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 438,
		["Type"] = "Fish",
		["Name"] = "Blocky Octopus",
		["Description"] = "",
		["Icon"] = "rbxassetid://114941091584027",
		["Tier"] = 4
	},
	["SellPrice"] = 1100,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(295, 352),
		["Default"] = NumberRange.new(150, 240)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1