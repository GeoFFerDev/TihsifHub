-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 342,
		["Type"] = "Fish",
		["Name"] = "Bloodmoon Whale",
		["Description"] = "",
		["Icon"] = "rbxassetid://113886190969614",
		["Tier"] = 7
	},
	["SellPrice"] = 540000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(472112, 525584),
		["Default"] = NumberRange.new(362784, 464176)
	},
	["Probability"] = {
		["Chance"] = 2e-7
	},
	["Events"] = { "Admin - Bloodmoon" },
	["_moduleScript"] = script
}
return v1