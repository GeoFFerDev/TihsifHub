-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 40,
	["ForcedClockTime"] = 0,
	["Music"] = {
		["SoundId"] = "rbxassetid://116369374673509",
		["Volume"] = 0.3
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(92, 86, 124),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(138, 3, 8)
	},
	["Atmosphere"] = {
		["Density"] = 0.288,
		["Glare"] = 0.99,
		["Haze"] = 1.89,
		["Color"] = Color3.fromRGB(166, 0, 3),
		["Decay"] = Color3.fromRGB(166, 0, 3)
	},
	["Clouds"] = {
		["Enabled"] = false
	},
	["Sky"] = script.Sky,
	["WaterColor"] = Color3.fromRGB(131, 62, 62)
}
return v1