-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 16,
		["Type"] = "Variant",
		["Name"] = "Bloodmoon",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(144, 8, 11)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(98, 0, 2)), ColorSequenceKeypoint.new(1, Color3.fromRGB(141, 23, 25)) })
	},
	["Versions"] = 1,
	["Colors"] = 5,
	["SellMultiplier"] = 2.9,
	["Probability"] = {
		["Chance"] = 5
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1