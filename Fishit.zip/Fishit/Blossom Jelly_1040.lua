-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 648,
		["Type"] = "Fish",
		["Name"] = "Blossom Jelly",
		["Description"] = "",
		["Icon"] = "rbxassetid://92800563957185",
		["Tier"] = 5
	},
	["SellPrice"] = 6200,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(210, 230),
		["Default"] = NumberRange.new(165, 190)
	},
	["Probability"] = {
		["Chance"] = 0.00016666666666666666
	},
	["_moduleScript"] = script
}
return v1