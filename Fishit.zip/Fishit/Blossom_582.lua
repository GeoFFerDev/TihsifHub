-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 172,
		["Type"] = "Fishing Rods",
		["Name"] = "Blossom",
		["Description"] = "",
		["Icon"] = "rbxassetid://128521809779947",
		["Tier"] = 100
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(1.15, 0.4, 0.4),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, -0.7853981633974483),
	["_moduleScript"] = script
}
return v1