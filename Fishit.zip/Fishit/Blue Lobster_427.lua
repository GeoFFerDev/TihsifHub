-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 22,
		["Type"] = "Fish",
		["Name"] = "Blue Lobster",
		["Description"] = "",
		["Icon"] = "rbxassetid://79569787883962",
		["Tier"] = 4
	},
	["SellPrice"] = 11355,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.8, 3.5),
		["Default"] = NumberRange.new(1.8, 2.1)
	},
	["Probability"] = {
		["Chance"] = 0.00004
	},
	["_moduleScript"] = script
}
return v1