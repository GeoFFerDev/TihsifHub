-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 636,
		["Type"] = "Fish",
		["Name"] = "Blue Sea Dragon",
		["Description"] = "",
		["Icon"] = "rbxassetid://87051285933726",
		["Tier"] = 5
	},
	["SellPrice"] = 16500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(52, 70),
		["Default"] = NumberRange.new(32, 48)
	},
	["Probability"] = {
		["Chance"] = 0.00006666666666666667
	},
	["_moduleScript"] = script
}
return v1