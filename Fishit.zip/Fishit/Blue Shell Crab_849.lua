-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 437,
		["Type"] = "Fish",
		["Name"] = "Blue Shell Crab",
		["Description"] = "",
		["Icon"] = "rbxassetid://97862084509972",
		["Tier"] = 5
	},
	["SellPrice"] = 5500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(46, 60),
		["Default"] = NumberRange.new(26, 35)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1