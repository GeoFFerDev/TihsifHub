-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 106,
		["Type"] = "Fish",
		["Name"] = "Blue-Banded Goby",
		["Description"] = "",
		["Icon"] = "rbxassetid://137187691311291",
		["Tier"] = 2
	},
	["SellPrice"] = 91,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.14, 2.62),
		["Default"] = NumberRange.new(1.04, 1.56)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1