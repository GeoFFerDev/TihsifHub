-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 597,
		["Type"] = "Fish",
		["Name"] = "Blueface Sunfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://111859394471567",
		["Tier"] = 1
	},
	["SellPrice"] = 20,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2, 2.4),
		["Default"] = NumberRange.new(1.2, 1.5)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1