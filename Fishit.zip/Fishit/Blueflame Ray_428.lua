-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 47,
		["Type"] = "Fish",
		["Name"] = "Blueflame Ray",
		["Description"] = "",
		["Icon"] = "rbxassetid://113303332536600",
		["Tier"] = 5
	},
	["SellPrice"] = 45000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(117.2, 146.8),
		["Default"] = NumberRange.new(73.6, 97.2)
	},
	["Probability"] = {
		["Chance"] = 0.00001075268817204301
	},
	["_moduleScript"] = script
}
return v1