-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 36,
		["Type"] = "Boats",
		["Name"] = "Blueprint Ducky",
		["Description"] = "",
		["Icon"] = "rbxassetid://108700277474616",
		["Tier"] = 100
	},
	["HiddenInShop"] = true,
	["Seats"] = 2,
	["_moduleScript"] = script
}
return v1