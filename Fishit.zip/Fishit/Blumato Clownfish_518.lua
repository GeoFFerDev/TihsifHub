-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 107,
		["Type"] = "Fish",
		["Name"] = "Blumato Clownfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://135433263876257",
		["Tier"] = 2
	},
	["SellPrice"] = 95,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.2, 1.57),
		["Default"] = NumberRange.new(0.53, 0.8)
	},
	["Probability"] = {
		["Chance"] = 0.01818181818181818
	},
	["_moduleScript"] = script
}
return v1