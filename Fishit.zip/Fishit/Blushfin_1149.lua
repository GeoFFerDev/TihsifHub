-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 733,
		["Type"] = "Fish",
		["Name"] = "Blushfin",
		["Description"] = "",
		["Icon"] = "rbxassetid://73275669945741",
		["Tier"] = 1
	},
	["SellPrice"] = 20,
	["Weight"] = {
		["Big"] = NumberRange.new(1.8, 2.5),
		["Default"] = NumberRange.new(1, 1.6)
	},
	["Probability"] = {
		["Chance"] = 0.25
	},
	["EventTag"] = "VAL26",
	["_moduleScript"] = script
}
return v1