-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 732,
		["Type"] = "Fish",
		["Name"] = "Blushwave",
		["Description"] = "",
		["Icon"] = "rbxassetid://115717213749941",
		["Tier"] = 2
	},
	["SellPrice"] = 100,
	["Weight"] = {
		["Big"] = NumberRange.new(3.9, 4.8),
		["Default"] = NumberRange.new(2.8, 3.5)
	},
	["Probability"] = {
		["Chance"] = 0.01
	},
	["EventTag"] = "VAL26",
	["_moduleScript"] = script
}
return v1