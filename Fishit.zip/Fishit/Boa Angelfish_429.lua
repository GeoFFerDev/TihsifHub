-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 45,
		["Type"] = "Fish",
		["Name"] = "Boa Angelfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://132840818442941",
		["Tier"] = 1
	},
	["SellPrice"] = 22,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.6, 2),
		["Default"] = NumberRange.new(1, 1.2)
	},
	["Probability"] = {
		["Chance"] = 0.06666666666666667
	},
	["_moduleScript"] = script
}
return v1