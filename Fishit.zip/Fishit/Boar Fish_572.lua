-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 151,
		["Type"] = "Fish",
		["Name"] = "Boar Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://114009571858522",
		["Tier"] = 1
	},
	["SellPrice"] = 24,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(11.54, 13.15),
		["Default"] = NumberRange.new(6.02, 9.03)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1