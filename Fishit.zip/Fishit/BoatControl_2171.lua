-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("UserInputService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Players")
require(v3:WaitForChild("Packages"):WaitForChild("Net"))
local v5 = require(v3:WaitForChild("AceworksUtils"):WaitForChild("TagEffect"))
local v_u_6 = require(v3:WaitForChild("AceworksUtils"):WaitForChild("Teardown"))
local v7 = v_u_4.LocalPlayer
local v_u_8 = v7.PlayerGui
local v9 = require(v3:WaitForChild("Packages"):WaitForChild("Trove"))
local v_u_10 = require(v3:WaitForChild("Shared"):WaitForChild("BoatsHandlingData"))
local v_u_11 = require(v7:WaitForChild("PlayerScripts").PlayerModule:WaitForChild("ControlModule"))
local v12 = v3:WaitForChild("Assets")
local v13 = v12:WaitForChild("Core Boat Assets")
v12:WaitForChild("Boats")
local v_u_14 = v13:WaitForChild("MobileGui")
local v_u_15 = nil
local v_u_16 = nil
local v17 = v7.Character
local v_u_18 = v17:WaitForChild("Humanoid")
if v_u_18 then
	local v_u_19 = v9.new()
	local v_u_20 = v9.new()
	local v_u_21 = require(script:WaitForChild("getThumbstick"))
	local v_u_22 = require(script:WaitForChild("getFront"))
	local v_u_23 = require(script:WaitForChild("getBack"))
	local v_u_24 = require(script:WaitForChild("resetAssembly"))
	local function v25()
		-- upvalues: (copy) v_u_20, (copy) v_u_19
		v_u_20:Destroy()
		v_u_19:Destroy()
	end
	v_u_19:Add(v_u_18:GetPropertyChangedSignal("SeatPart"):Connect(function()
		-- upvalues: (copy) v_u_18, (ref) v_u_16, (copy) v_u_20, (copy) v_u_24, (copy) v_u_10, (copy) v_u_2, (copy) v_u_14, (copy) v_u_8, (ref) v_u_15, (copy) v_u_1, (copy) v_u_11, (copy) v_u_21, (copy) v_u_22, (copy) v_u_23
		local v26 = v_u_18.SeatPart
		if v26 then
			if v26:IsA("VehicleSeat") then
				local v27 = v26.Parent
				if v27 then
					local v28 = v27:FindFirstChild("Base")
					if v28 then
						local v29 = v27.Name
						if v27:HasTag("Boat") then
							local v30 = v_u_10[v29]
							if v30 then
								local v_u_31 = v28:FindFirstChildWhichIsA("AlignOrientation")
								if v_u_31 then
									local v_u_32 = v28:FindFirstChildWhichIsA("LinearVelocity")
									if v_u_32 then
										if v28:FindFirstChild("Attachment") then
											v_u_16 = v26
											local v33 = game.ReplicatedStorage.Boats:FindFirstChild(v29)
											local v34 = v33 and require(v33) or {}
											local v_u_35 = nil
											local v_u_36 = nil
											local v_u_37 = nil
											local v_u_38 = "Idle"
											local v_u_39 = false
											local v40 = v_u_18:FindFirstChildOfClass("Animator")
											if not v40 then
												v40 = Instance.new("Animator")
												v40.Parent = v_u_18
											end
											local v_u_41 = v34.Animations
											if v_u_41 and v40 then
												print("loading")
												if v_u_41.Idle then
													local v42 = Instance.new("Animation")
													v42.AnimationId = v_u_41.Idle
													v_u_35 = v40:LoadAnimation(v42)
													v_u_35.Looped = true
													v_u_35.Priority = Enum.AnimationPriority.Action2
													v42:Destroy()
													v_u_20:Add(function()
														-- upvalues: (ref) v_u_35
														if v_u_35 then
															v_u_35:Stop()
															v_u_35:Destroy()
														end
													end)
												end
												if v_u_41.Surfing then
													local v43 = Instance.new("Animation")
													v43.AnimationId = v_u_41.Surfing
													v_u_36 = v40:LoadAnimation(v43)
													v_u_36.Looped = true
													v_u_36.Priority = Enum.AnimationPriority.Action2
													v43:Destroy()
													v_u_20:Add(function()
														-- upvalues: (ref) v_u_36
														if v_u_36 then
															v_u_36:Stop()
															v_u_36:Destroy()
														end
													end)
												end
												if v_u_41.SlowSurfing then
													v_u_39 = true
													local v44 = Instance.new("Animation")
													v44.AnimationId = v_u_41.SlowSurfing
													v_u_37 = v40:LoadAnimation(v44)
													v_u_37.Looped = true
													v_u_37.Priority = Enum.AnimationPriority.Action2
													v44:Destroy()
													v_u_20:Add(function()
														-- upvalues: (ref) v_u_37
														if v_u_37 then
															v_u_37:Stop()
															v_u_37:Destroy()
														end
													end)
												end
												if v_u_35 then
													v_u_35:Play(0.2)
												end
											end
											local v_u_45 = nil
											if v_u_2.TouchEnabled then
												local v_u_46 = v_u_14:Clone()
												v_u_20:Add(v_u_46.TouchControlFrame.AccelerateButton.InputBegan:Connect(function()
													-- upvalues: (ref) v_u_45
													v_u_45 = 1
												end))
												v_u_20:Add(v_u_46.TouchControlFrame.AccelerateButton.InputEnded:Connect(function()
													-- upvalues: (ref) v_u_45
													if v_u_45 == 1 then
														v_u_45 = 0
													end
												end))
												v_u_20:Add(v_u_46.TouchControlFrame.BrakeButton.InputBegan:Connect(function()
													-- upvalues: (ref) v_u_45
													v_u_45 = -1
												end))
												v_u_20:Add(v_u_46.TouchControlFrame.BrakeButton.InputEnded:Connect(function()
													-- upvalues: (ref) v_u_45
													if v_u_45 == -1 then
														v_u_45 = 0
													end
												end))
												v_u_20:Add(function()
													-- upvalues: (copy) v_u_46
													v_u_46:Destroy()
												end)
												v_u_46.Enabled = true
												v_u_46.Parent = v_u_8
												v_u_15 = v_u_46
											end
											local v_u_47 = nil
											local v_u_48 = nil
											if v_u_2.GamepadEnabled then
												v_u_20:Add(v_u_2.InputBegan:Connect(function(p49, p50)
													-- upvalues: (ref) v_u_2, (ref) v_u_47, (ref) v_u_48
													if not p50 then
														if p49.KeyCode == Enum.KeyCode.Thumbstick1 then
															for _, v51 in v_u_2:GetGamepadState(Enum.UserInputType.Gamepad1) do
																if v51.KeyCode == Enum.KeyCode.Thumbstick1 then
																	local v52 = v51.Position.X
																	local v53 = v51.Position.Y
																	v_u_47 = v52
																	v_u_48 = v53
																end
															end
														end
													end
												end))
											end
											local v_u_54 = v30.Acceleration or 1
											local v_u_55 = v30.Speed
											local v_u_56 = v30.RotationSpeed
											local _ = v30.LaunchControl
											local v_u_57 = v_u_55 * 0.25 * 0.7
											v_u_20:Add(v_u_1.Heartbeat:Connect(function(p58)
												-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_47, (ref) v_u_48, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_56, (copy) v_u_31, (copy) v_u_55, (ref) v_u_45, (copy) v_u_32, (copy) v_u_54, (copy) v_u_41, (ref) v_u_38, (ref) v_u_35, (ref) v_u_37, (ref) v_u_36, (copy) v_u_57, (ref) v_u_39
												local v59 = false
												if v_u_2.TouchEnabled then
													local v60 = v_u_11:GetMoveVector()
													local v61 = v60.X
													local v62 = v60.Z
													v_u_47 = v61
													v_u_48 = v62
												end
												if v_u_2.GamepadEnabled then
													v59 = true
													local v63, v64 = v_u_21()
													v_u_47 = v63
													v_u_48 = v64
												end
												local v65 = v_u_2:IsKeyDown(Enum.KeyCode.D) or v_u_2:IsKeyDown(Enum.KeyCode.Right)
												local v66 = v_u_2:IsKeyDown(Enum.KeyCode.A) or v_u_2:IsKeyDown(Enum.KeyCode.Left)
												local v67 = v_u_2:IsKeyDown(Enum.KeyCode.W) or v_u_2:IsKeyDown(Enum.KeyCode.Up)
												if not v67 then
													if v59 then
														v67 = v_u_22()
													else
														v67 = v59
													end
												end
												local v68 = v_u_2:IsKeyDown(Enum.KeyCode.S) or v_u_2:IsKeyDown(Enum.KeyCode.Down)
												if v68 then
													v59 = v68
												elseif v59 then
													v59 = v_u_23()
												end
												local v69
												if v_u_47 then
													local v70 = v_u_47
													v69 = math.sign(v70) or nil
												else
													v69 = nil
												end
												local v71
												if v65 then
													v71 = -0.3490658503988659
												elseif v66 then
													v71 = 0.3490658503988659
												elseif v69 then
													local v72 = v69 * -4
													v71 = math.rad(v72)
												else
													v71 = 0
												end
												local v73 = v71 * (p58 * v_u_56 * 2)
												local v74 = v_u_31
												v74.CFrame = v74.CFrame * CFrame.Angles(0, v73, 0)
												local v75 = v_u_55 * -0.25
												if v_u_45 then
													v75 = v_u_45 * v75
												elseif not v67 then
													v75 = not v59 and 0 or -v75
												end
												local v76 = Vector3.new(1, 0, 0) * v75
												v_u_32.VectorVelocity = v_u_32.VectorVelocity:Lerp(v76, p58 * v_u_54)
												if v_u_41 then
													local v77 = v_u_32.VectorVelocity.X
													local v78 = math.abs(v77)
													if v78 < 2 then
														if v_u_38 == "Idle" then
															return
														end
														v_u_38 = "Idle"
														if v_u_35 then
															v_u_35:Stop(0.2)
														end
														if v_u_37 then
															v_u_37:Stop(0.2)
														end
														if v_u_36 then
															v_u_36:Stop(0.2)
														end
														if v_u_35 then
															v_u_35:Play(0.2)
															return
														end
													elseif v_u_57 <= v78 then
														if v_u_38 == "Surfing" then
															return
														end
														v_u_38 = "Surfing"
														if v_u_35 then
															v_u_35:Stop(0.2)
														end
														if v_u_37 then
															v_u_37:Stop(0.2)
														end
														if v_u_36 then
															v_u_36:Stop(0.2)
														end
														if v_u_36 then
															v_u_36:Play(0.2)
															return
														end
													else
														if v_u_38 == "SlowSurfing" then
															return
														end
														v_u_38 = "SlowSurfing"
														if v_u_35 then
															v_u_35:Stop(0.2)
														end
														if v_u_37 then
															v_u_37:Stop(0.2)
														end
														if v_u_36 then
															v_u_36:Stop(0.2)
														end
														if v_u_39 and v_u_37 then
															v_u_37:Play(0.2)
															return
														end
														if v_u_36 then
															v_u_36:Play(0.2)
														end
													end
												end
											end))
										else
											warn("Boat missing Attachment:", v27:GetFullName())
										end
									else
										warn("Boat missing LinearVelocity:", v27:GetFullName())
										return
									end
								else
									warn("Boat missing AlignOrientation:", v27:GetFullName())
									return
								end
							else
								warn("Boat missing boatData:", v27:GetFullName())
								return
							end
						else
							warn("Model is not tagged as a \"Boat\"!")
							return
						end
					else
						warn("Boat missing Base:", v27:GetFullName())
						return
					end
				else
					return
				end
			else
				return
			end
		else
			if v_u_16 then
				v_u_20:Clean()
				local v79 = v_u_16.Parent
				if v79 then
					v79 = v79:FindFirstChild("Base")
				end
				if v79 and v79:IsA("BasePart") then
					v_u_24(v79)
					for _ = 1, 6 do
						pcall(v_u_24, v79)
						task.wait()
					end
				end
				v_u_16 = nil
			end
			return
		end
	end))
	v_u_19:Add(v_u_18.Died:Once(v25))
	v_u_19:Add(v17.Destroying:Once(v25))
	local v80 = v5.configure():ignoreDescendantOf(v3):targetParent():withDefaultConfig({})
	v80:effect("Boat_Core", function(p_u_81, _)
		-- upvalues: (copy) v_u_6, (copy) v_u_1
		return v_u_6.fn(v_u_1.Heartbeat:Connect(function()
			-- upvalues: (copy) p_u_81
			if p_u_81.Anchored then
				p_u_81.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
				p_u_81.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
			end
		end))
	end)
	v80:effect("Boat_Wave", function(p_u_82, p83)
		-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_1
		if p83.ownerUserId == v_u_4.LocalPlayer.UserId then
			return v_u_6.fn(v_u_1.Heartbeat:Connect(function()
				-- upvalues: (copy) p_u_82
				local v84 = p_u_82
				local v85 = CFrame.new
				local v86 = time() * 1
				local v87 = v85(0, math.cos(v86) * math.noise(time() * 0.2) * 0.4, 0)
				local v88 = CFrame.Angles
				local v89 = time() * 1.1
				local v90 = math.sin(v89) * math.noise(100 + time() * 0.3) * 5
				local v91 = math.rad(v90)
				local v92 = time() * 0.9
				local v93 = math.sin(v92) * math.noise(1000 + time() * 0.4) * 5
				v84.C1 = v87 * v88(v91, 0, (math.rad(v93)))
			end))
		end
	end)
end