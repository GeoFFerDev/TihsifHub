-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("Players")
local v_u_4 = nil
local v_u_5 = v3.LocalPlayer
local v6 = v_u_5.PlayerGui
local v_u_7 = require(v2.Packages.MarketplaceService)
local v8 = require(v2.Packages.Signal)
local v_u_9 = require(v2.Packages.Replion).Client
local v10 = require(v2.Packages.Trove)
local v11 = require(v2.Packages.Net)
local v_u_12 = require(v2.Packages.spr)
local v_u_13 = require(v2.Shared.Soundbook)
local v_u_14 = require(v2.Shared.StringLibrary)
local v_u_15 = require(v2.Shared.ItemUtility)
local v_u_16 = require(v2.Shared.TierUtility)
local v_u_17 = require(v2.Shared.BoatsHandlingData)
local v_u_18 = require(v2.Shared.GamePassUtility)
local v_u_19 = require(v2.Modules.CoinProductsUtility)
local v_u_20 = require(v2.Modules.Device)
require(v2.Types.Modifiers)
local v_u_21 = require(v2.Modules.GuiControl)
local v_u_22 = require(v2.Modules.InterfaceHighlight)
local v_u_23 = require(v2.Controllers.TextNotificationController)
local v_u_24 = v11:RemoteFunction("PurchaseBoat")
local v_u_25 = v11:RemoteFunction("SpawnBoat")
local v_u_26 = v11:RemoteFunction("DespawnBoat")
local v_u_27 = v11:RemoteEvent("BoatChanged")
local v_u_28 = v11:RemoteEvent("BoatTeleport")
local v_u_29 = v6:WaitForChild("Boat Shop")
local v30 = v_u_29.Main.Content
local v_u_31 = v30.RightContent
local v_u_32 = v_u_31.Inside
local v_u_33 = v_u_32.BoatData.CurrencyFrame
local v_u_34 = v30.List.ScrollingFrame
local v_u_35 = v_u_32.Teleport
local v_u_36 = v_u_32.TeleportGlow
local v_u_37 = v_u_34.Tile
v_u_37.Parent = nil
local v_u_38 = {}
local v_u_39 = v10.new()
local v_u_40 = v10.new()
local v_u_41 = nil
local v_u_42 = false
local v_u_43 = nil
local v_u_44 = false
local v_u_45 = false
local v_u_46 = v8.new()
local v_u_47 = v_u_16:GetTier("Exclusive")
local v_u_136 = {
	["Start"] = function(p_u_48)
		-- upvalues: (ref) v_u_4, (copy) v_u_9, (copy) v_u_29, (copy) v_u_21, (ref) v_u_41, (copy) v_u_22, (copy) v_u_31, (copy) v_u_35, (copy) v_u_136, (copy) v_u_28, (copy) v_u_23, (copy) v_u_5, (copy) v_u_20
		v_u_4 = v_u_9:WaitReplion("Data")
		v_u_29:GetPropertyChangedSignal("Enabled"):Connect(function()
			-- upvalues: (ref) v_u_29
			local v49 = game.ProximityPromptService.Enabled
			local v50 = not v_u_29.Enabled
			task.wait(0.5)
			local v51 = game.ProximityPromptService.Enabled
			local v52 = not v_u_29.Enabled
			if v49 == v51 and v50 == v52 then
				game.ProximityPromptService.Enabled = v52
			end
		end)
		v_u_21.GuiFocusedSignal:Connect(function(p53)
			-- upvalues: (ref) v_u_29, (copy) p_u_48, (ref) v_u_41, (ref) v_u_4, (ref) v_u_22, (ref) v_u_31
			if p53 == v_u_29 then
				p_u_48:Render()
				p_u_48:OpenInfo((p_u_48:GetDefaultBoatId()))
				if v_u_41 then
					v_u_41()
					v_u_41 = nil
				end
				local v54 = v_u_4:Get("OnboardingStep")
				local v55
				if v_u_4:Get("PlayerOnboarding") == true and v54 ~= nil then
					v55 = v54 < 6
				else
					v55 = false
				end
				if v55 then
					task.defer(function()
						-- upvalues: (ref) v_u_41, (ref) v_u_22, (ref) v_u_31
						v_u_41 = v_u_22.highlight(v_u_31.Action)
					end)
				end
			end
		end)
		v_u_21.GuiUnfocusedSignal:Connect(function(p56)
			-- upvalues: (ref) v_u_29, (copy) p_u_48
			if p56 == v_u_29 then
				p_u_48:Unrender()
			end
		end)
		v_u_21:Hook("Hold Button", v_u_35).Clicked:Connect(function()
			-- upvalues: (ref) v_u_136, (ref) v_u_28, (ref) v_u_21, (ref) v_u_23
			if v_u_136:GetMyBoat() then
				v_u_28:FireServer()
				v_u_21:Close()
			else
				local v57 = {
					["Type"] = "Text",
					["Text"] = "You do not have a boat!",
					["TextColor"] = {
						["R"] = 255,
						["G"] = 0,
						["B"] = 0
					}
				}
				v_u_23:DeliverNotification(v57)
			end
		end)
		v_u_5:GetAttributeChangedSignal("BoatTeleportCooldown"):Connect(TeleportRestrictionChanged)
		TeleportRestrictionChanged()
		v_u_20:_onDeviceChanged(DeviceChanged)
		DeviceChanged()
	end,
	["OwnsBoat"] = function(_, p58)
		-- upvalues: (ref) v_u_4
		for _, v59 in v_u_4:GetExpect({ "Inventory", "Boats" }) do
			if v59.Id == p58 then
				return true
			end
		end
		return false
	end,
	["OpenInfo"] = function(_, p_u_60)
		-- upvalues: (ref) v_u_42, (copy) v_u_15, (copy) v_u_40, (ref) v_u_43, (ref) v_u_4, (copy) v_u_32, (copy) v_u_16, (copy) v_u_17, (copy) v_u_12, (copy) v_u_33, (copy) v_u_14, (copy) v_u_136, (copy) v_u_31, (copy) v_u_18, (copy) v_u_7, (copy) v_u_27, (copy) v_u_21, (copy) v_u_26, (copy) v_u_25, (copy) v_u_23, (copy) v_u_19, (copy) v_u_24, (copy) v_u_13
		if v_u_42 then
			return
		end
		local v_u_61 = v_u_15:GetBoatData(p_u_60)
		if not v_u_61 then
			return
		end
		v_u_42 = true
		v_u_40:Clean()
		v_u_43 = p_u_60
		local v62 = v_u_4:GetExpect({ "Inventory", "Boats" })
		local v63 = nil
		for _, v64 in ipairs(v62) do
			if p_u_60 == v64.Id and v64.Metadata then
				v63 = v64.Metadata
				break
			end
		end
		local v65
		if v63 and v63.Placement then
			v65 = ("%* (#%*)"):format(v_u_61.Data.Name, v63.Placement)
		else
			v65 = v_u_61.Data.Name
		end
		v_u_32.Header.Text = v65
		v_u_32.BoatData.Vector.Image = v_u_61.Data.Icon or ""
		local v66 = v_u_16:GetTier(v_u_61.Data.Tier)
		if v66 then
			local v67 = v66.TierColor.Keypoints[1].Value
			v_u_32.BoatData.Gradient.BackgroundColor3 = v67
			v_u_32.BoatData.UIStroke.Color = v67
			v_u_32.BoatData.Glow.ImageColor3 = v67
			v_u_32.BoatData.Glow.Visible = v66.Tier > 1
			v_u_32.BoatData.TierName.UIGradient.Color = v66.TierColor
			v_u_32.BoatData.TierName.Text = v66.Name
		end
		local v68 = v_u_17[v_u_61.Data.Name]
		if v68 then
			local v69 = v68.RotationSpeed
			local v70 = math.min(v69, 3) / 3
			local v71 = v68.Speed
			local v72 = math.min(v71, 325) / 325
			v_u_12.stop(v_u_32.Stats.HandlingFrame.Bar)
			v_u_12.target(v_u_32.Stats.HandlingFrame.Bar, 1, 3, {
				["Size"] = UDim2.fromScale(v70, 1)
			})
			v_u_12.stop(v_u_32.Stats.SpeedFrame.Bar)
			v_u_12.target(v_u_32.Stats.SpeedFrame.Bar, 1, 3, {
				["Size"] = UDim2.fromScale(v72, 1)
			})
		else
			v_u_32.Stats.HandlingFrame.Bar.Size = UDim2.fromScale(0, 1)
			v_u_32.Stats.SpeedFrame.Bar.Size = UDim2.fromScale(0, 1)
		end
		local function v81()
			-- upvalues: (copy) v_u_61, (ref) v_u_33, (ref) v_u_14, (ref) v_u_136, (copy) p_u_60, (ref) v_u_31, (ref) v_u_18, (ref) v_u_7
			local v73 = v_u_61.Price
			local v74 = v_u_61.LinkedGamePass
			if v74 then
				v_u_33.Counter.Visible = false
				v_u_33.VectorFrame.Visible = false
			elseif v73 then
				v_u_33.Counter.Text = v_u_14:Shorten(v73)
				v_u_33.Counter.Visible = true
				v_u_33.VectorFrame.Visible = true
			else
				v_u_33.Counter.Visible = false
				v_u_33.VectorFrame.Visible = false
			end
			if v_u_136:OwnsBoat(p_u_60) then
				if v_u_136:GetMyBoat() then
					v_u_31.Action.BackgroundColor3 = Color3.fromRGB(229, 29, 92)
					v_u_31.Action.Label.TextColor3 = Color3.fromRGB(255, 255, 255)
					v_u_31.Action.Label.Text = "Despawn"
				else
					v_u_31.Action.BackgroundColor3 = Color3.fromRGB(48, 175, 229)
					v_u_31.Action.Label.TextColor3 = Color3.fromRGB(255, 255, 255)
					v_u_31.Action.Label.Text = "Spawn"
				end
			elseif v74 then
				local v75 = v_u_18:GetGamePassIdFromName(v74)
				local v76 = nil
				if v75 then
					local v79, v80 = v_u_7:GetProductInfoAsync(v75, Enum.InfoType.GamePass):andThen(function(p77)
						if not p77.PriceInRobux then
							return "???"
						end
						local v78 = p77.PriceInRobux
						return tostring(v78)
					end):catch(warn):await()
					if v79 then
						v76 = v80 or v76
					end
				end
				if v76 then
					v_u_31.Action.BackgroundColor3 = Color3.fromRGB(11, 227, 162)
					v_u_31.Action.Label.TextColor3 = Color3.fromRGB(2, 48, 34)
					v_u_31.Action.Label.Text = ("\238\128\130%* Robux"):format(v76)
				else
					v_u_31.Action.BackgroundColor3 = Color3.fromRGB(11, 227, 162)
					v_u_31.Action.Label.TextColor3 = Color3.fromRGB(2, 48, 34)
					v_u_31.Action.Label.Text = "??? Robux"
				end
			elseif v73 then
				v_u_31.Action.BackgroundColor3 = Color3.fromRGB(28, 186, 78)
				v_u_31.Action.Label.TextColor3 = Color3.fromRGB(6, 38, 15)
				v_u_31.Action.Label.Text = "Buy"
			else
				v_u_31.Action.BackgroundColor3 = Color3.fromRGB(218, 218, 218)
				v_u_31.Action.Label.TextColor3 = Color3.fromRGB(0, 0, 0)
				v_u_31.Action.Label.Text = "Not Owned"
			end
		end
		local v_u_82 = v_u_27.OnClientEvent:Connect(v81)
		local v_u_83 = v_u_4:OnArrayInsert({ "Inventory", "Boats" }, v81)
		v81()
		local v_u_84 = v_u_21:Hook("Hold Button", v_u_31.Action)
		local v_u_92 = v_u_84.Clicked:Connect(function()
			-- upvalues: (ref) v_u_136, (ref) v_u_26, (copy) v_u_61, (ref) v_u_18, (copy) p_u_60, (ref) v_u_25, (ref) v_u_23, (ref) v_u_21, (ref) v_u_4, (ref) v_u_19, (ref) v_u_24, (ref) v_u_13
			if v_u_136:GetMyBoat() then
				v_u_26:InvokeServer()
				return
			else
				local v85 = v_u_61.LinkedGamePass
				if not v85 or v_u_18:ClientPromptGamepassFromName(v85) then
					if v_u_136:OwnsBoat(p_u_60) then
						local v86, _, v87 = v_u_25:InvokeServer(v_u_61.Data.Id)
						if v86 then
							TeleportRestrictionChanged()
							v_u_23:DeliverNotification({
								["Type"] = "Text",
								["Text"] = "Spawned boat!",
								["TextColor"] = {
									["R"] = 0,
									["G"] = 255,
									["B"] = 0
								}
							})
							if v87 then
								v_u_21:Close()
								return
							end
						end
					else
						local v88 = v_u_4:Get("OnboardingStep")
						local v89
						if v_u_4:Get("PlayerOnboarding") == true and (v88 ~= nil and v88 < 6) then
							v89 = v_u_61.Data.Id == 1
						else
							v89 = false
						end
						local v90 = not v89 and v_u_61.Price
						if v90 then
							local v91 = v_u_4:GetExpect("Coins")
							if v91 < v90 then
								v_u_19:PurchaseBestCoinPack(v91, v90)
								return
							end
						end
						if v_u_24:InvokeServer(v_u_61.Data.Id) then
							v_u_13.Sounds.StorePurchase:Play()
							v_u_13.Sounds.CoinsChanged:Play()
							v_u_136:OpenInfo(p_u_60)
						end
					end
				end
			end
		end)
		v_u_40:Add(function()
			-- upvalues: (copy) v_u_92, (copy) v_u_84
			v_u_92:Disconnect()
			v_u_84:Destroy()
		end)
		v_u_40:Add(function()
			-- upvalues: (copy) v_u_82, (copy) v_u_83
			v_u_82:Disconnect()
			v_u_83:Disconnect()
		end)
		TeleportRestrictionChanged()
		v_u_31.Visible = true
		v_u_42 = false
	end,
	["CloseInfo"] = function(_)
		-- upvalues: (ref) v_u_42, (copy) v_u_31, (copy) v_u_40, (ref) v_u_43, (copy) v_u_12, (copy) v_u_32
		if not v_u_42 then
			v_u_31.Visible = false
			v_u_40:Clean()
			v_u_43 = nil
			v_u_12.stop(v_u_32.Stats.HandlingFrame.Bar)
			v_u_12.stop(v_u_32.Stats.SpeedFrame.Bar)
			v_u_32.Stats.HandlingFrame.Bar.Size = UDim2.fromScale(0, 1)
			v_u_32.Stats.SpeedFrame.Bar.Size = UDim2.fromScale(0, 1)
		end
	end,
	["Unrender"] = function(p93)
		-- upvalues: (ref) v_u_45, (copy) v_u_39, (ref) v_u_41, (copy) v_u_38, (copy) v_u_46
		if not v_u_45 then
			v_u_45 = true
			v_u_39:Clean()
			if v_u_41 then
				v_u_41()
				v_u_41 = nil
			end
			for _, v94 in v_u_38 do
				v94:Destroy()
			end
			table.clear(v_u_38)
			p93:CloseInfo()
			v_u_45 = false
			v_u_46:Fire()
		end
	end,
	["Render"] = function(p_u_95)
		-- upvalues: (ref) v_u_44, (ref) v_u_45, (copy) v_u_46, (copy) v_u_15, (copy) v_u_37, (copy) v_u_136, (copy) v_u_47, (copy) v_u_14, (copy) v_u_16, (copy) v_u_17, (copy) v_u_21, (copy) v_u_39, (copy) v_u_34, (copy) v_u_38
		if not v_u_44 then
			v_u_44 = true
			if v_u_45 then
				v_u_46:Wait()
			end
			local v96 = v_u_15:GetBoats()
			for _, v_u_97 in ipairs(v96) do
				local v98 = v_u_97.Price
				local v99 = v_u_37:Clone()
				local v100 = v99.Padded.Top.CurrencyFrame
				local v101 = v99.Padded.Top.OwnedFrame
				local v102 = v_u_136:OwnsBoat(v_u_97.Data.Id)
				if v_u_97.HiddenInShop then
					v99.Visible = v102
				end
				if v102 then
					v101.Visible = true
					v100.Visible = false
				elseif v_u_97.LinkedGamePass then
					v100.Counter.Text = "GAMEPASS"
					v100.Counter.UIGradient.Color = v_u_47.TierColor
					v100.Counter.UIStroke.Color = Color3.new(0, 0, 0)
					v100.VectorFrame.Visible = false
				else
					if v98 then
						v100.Counter.Text = v_u_14:Shorten(v98)
						v100.Counter.UIGradient.Enabled = true
						v100.Visible = true
					else
						v100.Visible = false
					end
					v101.Visible = false
				end
				v99.Padded.Top.Label.Text = v_u_97.Data.Name
				v99.BG.Vector.Image = v_u_97.Data.Icon or ""
				local v103 = v_u_16:GetTier(v_u_97.Data.Tier)
				if v103 then
					local v104 = v103.TierColor.Keypoints[1].Value
					v99.BG.Glow.Visible = v103.Tier > 1
					v99.BG.Glow.ImageColor3 = v104
				end
				local v105 = v_u_17[v_u_97.Data.Name]
				if v105 then
					local v106 = (v105.Speed - 100) / 100
					local v107 = (v105.Acceleration - 0.15) / 0.15
					v99.Padded.Bottom.Acceleration.Counter.Text = ("%d%%"):format(100 + v107 * 100)
					v99.Padded.Bottom.TopSpeed.Counter.Text = ("%d%%"):format(100 + v106 * 100)
					local v108 = v99.Padded.Bottom.Passengers.Counter
					local v109 = v_u_97.Seats
					v108.Text = tostring(v109)
					v99.Padded.Bottom.Visible = true
				else
					v99.Padded.Bottom.Visible = false
				end
				local v_u_110 = v_u_21:Hook("Hold Button", v99)
				local v_u_111 = v_u_110.Clicked:Connect(function()
					-- upvalues: (copy) p_u_95, (copy) v_u_97
					p_u_95:OpenInfo(v_u_97.Data.Id)
				end)
				v_u_39:Add(function()
					-- upvalues: (copy) v_u_111, (copy) v_u_110
					v_u_111:Disconnect()
					v_u_110:Destroy()
				end)
				local v112
				if v98 == nil then
					if v_u_97.Order then
						v112 = 100000 + v_u_97.Order
					else
						local v113 = 100000 + v_u_97.Data.Tier * 1000
						local v114 = v_u_97.Data.Name
						v112 = v113 + string.len(v114)
					end
				else
					local v115 = v_u_97.Data.Tier * 1000
					local v116 = v_u_97.Price or 0
					local v117 = v115 + math.log10(v116) * 1000
					local v118 = v_u_97.Data.Name
					v112 = v117 + string.len(v118)
				end
				v99.LayoutOrder = v112
				v99.Parent = v_u_34
				v_u_38[v_u_97.Data.Name] = v99
			end
			v_u_44 = false
		end
	end,
	["GetMyBoat"] = function(_)
		-- upvalues: (copy) v_u_1, (copy) v_u_5
		local v119 = v_u_1:GetTagged("Boat")
		for _, v120 in ipairs(v119) do
			local v121 = v120:GetAttribute("OwnerId")
			if v121 and v121 == v_u_5.UserId then
				return v120
			end
		end
	end,
	["GetDefaultBoatId"] = function(p122)
		-- upvalues: (ref) v_u_4, (copy) v_u_15
		local v123 = v_u_4:Get("OnboardingStep")
		local v124
		if v123 == nil then
			v124 = false
		else
			v124 = v123 < 6
		end
		if v124 then
			local v125 = v_u_4:GetExpect("Coins")
			local v126 = v_u_15:GetBoats()
			local v127 = -1
			local v128 = nil
			for _, v129 in ipairs(v126) do
				local v130 = v129.Price
				if v130 and (v130 <= v125 and v127 < v129.Data.Tier) then
					v127 = v129.Data.Tier
					v128 = v129
				end
			end
			return not v128 and 1 or v128.Data.Id
		else
			local v131 = v_u_4:Get("LastBoatId")
			if v131 and p122:OwnsBoat(v131) then
				return v131
			end
			local v132 = -1
			local v133 = nil
			for _, v134 in v_u_4:GetExpect({ "Inventory", "Boats" }) do
				local v135 = v_u_15:GetBoatData(v134.Id)
				if v135 and v132 < v135.Data.Tier then
					v132 = v135.Data.Tier
					v133 = v135
				end
			end
			return not v133 and 1 or v133.Data.Id
		end
	end
}
function DeviceChanged()
	-- upvalues: (copy) v_u_20, (copy) v_u_34
	local v137
	if v_u_20:IsMobile() then
		v137 = UDim2.new(0.975, 0, 0, 150)
	else
		v137 = UDim2.new(0.975, 0, 0, 230)
	end
	v_u_34.UIGridLayout.CellSize = v137
end
function TeleportRestrictionChanged()
	-- upvalues: (copy) v_u_5, (copy) v_u_136, (copy) v_u_35, (copy) v_u_36
	local v138 = v_u_5:GetAttribute("BoatTeleportCooldown") and true or false
	local v139 = not v_u_136:GetMyBoat() and true or v138
	v_u_35.Visible = not v139
	v_u_36.Visible = not v139
end
return v_u_136