-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["DEV Evil Duck 9000"] = {
		["Speed"] = 1000,
		["RotationSpeed"] = 5,
		["LaunchControl"] = true,
		["Acceleration"] = 0.45
	},
	["Alpha Floaty"] = {
		["Speed"] = 580,
		["RotationSpeed"] = 2,
		["LaunchControl"] = true,
		["Acceleration"] = 0.61
	},
	["Rubber Ducky"] = {
		["Speed"] = 490,
		["RotationSpeed"] = 2,
		["LaunchControl"] = true,
		["Acceleration"] = 0.65
	},
	["Blueprint Ducky"] = {
		["Speed"] = 490,
		["RotationSpeed"] = 2,
		["LaunchControl"] = true,
		["Acceleration"] = 0.65
	},
	["Aura Boat"] = {
		["Speed"] = 280,
		["RotationSpeed"] = 1.6,
		["Acceleration"] = 0.36
	},
	["Ferryman Boat"] = {
		["Speed"] = 290,
		["RotationSpeed"] = 1.3,
		["Acceleration"] = 0.29
	},
	["Burger Boat"] = {
		["Speed"] = 430,
		["RotationSpeed"] = 1.2,
		["Acceleration"] = 0.67
	},
	["Pumpkin Boat"] = {
		["Speed"] = 250,
		["RotationSpeed"] = 1.2,
		["Acceleration"] = 0.27
	},
	["Sharki"] = {
		["Speed"] = 450,
		["RotationSpeed"] = 1.3,
		["Acceleration"] = 1.4,
		["CustomEngineId"] = "rbxassetid://118202079132618"
	},
	["Raft"] = {
		["Speed"] = 175,
		["RotationSpeed"] = 1.1,
		["Acceleration"] = 0.22
	},
	["Banana Pirate Raft"] = {
		["Speed"] = 200,
		["RotationSpeed"] = 1.1,
		["Acceleration"] = 0.24
	},
	["Coral Boat"] = {
		["Speed"] = 200,
		["RotationSpeed"] = 1.1,
		["Acceleration"] = 0.24
	},
	["Flying Dutchman - Top 200"] = {
		["Speed"] = 450,
		["RotationSpeed"] = 1.25,
		["Acceleration"] = 0.5
	},
	["Flying Dutchman - Top 10"] = {
		["Speed"] = 450,
		["RotationSpeed"] = 1.25,
		["Acceleration"] = 0.5
	},
	["Flying Dutchman - Top 1"] = {
		["Speed"] = 450,
		["RotationSpeed"] = 1.25,
		["Acceleration"] = 0.5
	},
	["Submarine Boat"] = {
		["Speed"] = 450,
		["RotationSpeed"] = 1.25,
		["Acceleration"] = 0.5
	},
	["Ancient Ship"] = {
		["Speed"] = 240,
		["RotationSpeed"] = 1.05,
		["Acceleration"] = 0.22
	},
	["Mega Hovercraft"] = {
		["Speed"] = 580,
		["RotationSpeed"] = 0.95,
		["Acceleration"] = 0.74
	},
	["Dinky Fishing Boat"] = {
		["Speed"] = 215,
		["RotationSpeed"] = 1.16,
		["Acceleration"] = 0.25
	},
	["Festive Duck"] = {
		["Speed"] = 410,
		["RotationSpeed"] = 2,
		["LaunchControl"] = true,
		["Acceleration"] = 0.39
	},
	["Frozen Boat"] = {
		["Speed"] = 280,
		["RotationSpeed"] = 1.2,
		["Acceleration"] = 0.32
	},
	["Santa Sleigh"] = {
		["Speed"] = 380,
		["RotationSpeed"] = 2,
		["Acceleration"] = 0.31,
		["CustomIdleId"] = "rbxassetid://83698686825002",
		["CustomEngineId"] = "rbxassetid://76434558497360"
	},
	["Santa Sled"] = {
		["Speed"] = 380,
		["RotationSpeed"] = 2,
		["Acceleration"] = 0.31,
		["CustomIdleId"] = "rbxassetid://83698686825002",
		["CustomEngineId"] = "rbxassetid://76434558497360"
	},
	["Christmas Car"] = {
		["Speed"] = 270,
		["RotationSpeed"] = 1.5,
		["Acceleration"] = 0.3,
		["LaunchControl"] = true
	},
	["Frozen Jetski"] = {
		["Speed"] = 410,
		["RotationSpeed"] = 1.5,
		["Acceleration"] = 1.4
	},
	["Ethereal Jetski"] = {
		["Speed"] = 440,
		["RotationSpeed"] = 1.5,
		["Acceleration"] = 1.4
	},
	["Cursed Jetski"] = {
		["Speed"] = 410,
		["RotationSpeed"] = 1.5,
		["Acceleration"] = 1.4
	},
	["Magma Surfboard"] = {
		["Speed"] = 410,
		["RotationSpeed"] = 1.5,
		["Acceleration"] = 1.4
	},
	["Cruiser Boat"] = {
		["Speed"] = 205,
		["RotationSpeed"] = 1.16,
		["Acceleration"] = 0.27
	},
	["Hyper Boat"] = {
		["Speed"] = 480,
		["RotationSpeed"] = 1.28,
		["Acceleration"] = 0.36
	},
	["Mini Hoverboat"] = {
		["Speed"] = 400,
		["RotationSpeed"] = 1.34,
		["Acceleration"] = 0.42
	},
	["Mini Yacht"] = {
		["Speed"] = 290,
		["RotationSpeed"] = 1.06,
		["Acceleration"] = 0.22
	},
	["Fishing Boat"] = {
		["Speed"] = 230,
		["RotationSpeed"] = 1.1,
		["Acceleration"] = 0.27
	},
	["Highfield Boat"] = {
		["Speed"] = 180,
		["RotationSpeed"] = 1.1,
		["Acceleration"] = 0.27
	},
	["Jetski"] = {
		["Speed"] = 280,
		["RotationSpeed"] = 2,
		["Acceleration"] = 0.36
	},
	["Peppermint Jetski"] = {
		["Speed"] = 280,
		["RotationSpeed"] = 2,
		["Acceleration"] = 0.36
	},
	["Kayak"] = {
		["Speed"] = 165,
		["RotationSpeed"] = 1.07,
		["Acceleration"] = 0.27
	},
	["Small Boat"] = {
		["Speed"] = 135,
		["RotationSpeed"] = 1.05,
		["Acceleration"] = 0.24
	},
	["Speed Boat"] = {
		["Speed"] = 220,
		["RotationSpeed"] = 1.15,
		["Acceleration"] = 0.3
	},
	["Swan Boat"] = {
		["Speed"] = 260,
		["RotationSpeed"] = 1.3,
		["Acceleration"] = 0.28
	},
	["Classic Ducky Boat"] = {
		["Speed"] = 280,
		["RotationSpeed"] = 1.3,
		["Acceleration"] = 0.28
	},
	["Retro Car Boat"] = {
		["Speed"] = 280,
		["RotationSpeed"] = 1.4,
		["Acceleration"] = 0.36
	},
	["Retro Utility Boat"] = {
		["Speed"] = 300,
		["RotationSpeed"] = 0.5,
		["Acceleration"] = 0.16
	},
	["Colossal Pirate Ship"] = {
		["Speed"] = 300,
		["RotationSpeed"] = 1.25,
		["Acceleration"] = 0.3
	}
}
return v1