-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 395,
		["Type"] = "Fish",
		["Name"] = "Boltback Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://87304583998131",
		["Tier"] = 2
	},
	["SellPrice"] = 115,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.2, 0.4),
		["Default"] = NumberRange.new(0.06, 0.12)
	},
	["Probability"] = {
		["Chance"] = 0.01
	},
	["_moduleScript"] = script
}
return v1