-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 1,
		["Type"] = "Charms",
		["Name"] = "Bone Charm",
		["Description"] = "x1.5 Chance of fishing up a Bone Whale!",
		["Icon"] = "rbxassetid://118055229200011",
		["NewIcon"] = true,
		["Tier"] = 6
	},
	["Level"] = 100,
	["Uses"] = 50,
	["Price"] = 70000,
	["C0"] = CFrame.identity,
	["C1"] = CFrame.identity,
	["Modifiers"] = {
		["BaseLuck"] = 0
	},
	["FishModifiers"] = {
		["Bone Whale"] = 0.5
	},
	["Downloadable"] = true,
	["_moduleScript"] = script
}
return v1