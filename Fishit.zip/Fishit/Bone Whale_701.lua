-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 293,
		["Type"] = "Fish",
		["Name"] = "Bone Whale",
		["Description"] = "",
		["Icon"] = "rbxassetid://99804145194043",
		["Tier"] = 7
	},
	["SellPrice"] = 255000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(288230, 310374),
		["Default"] = NumberRange.new(230882, 275681)
	},
	["Probability"] = {
		["Chance"] = 5e-7
	},
	["_moduleScript"] = script
}
return v1