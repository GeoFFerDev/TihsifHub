-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 436,
		["Type"] = "Fish",
		["Name"] = "Boned Arrowhead Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://123712872087272",
		["Tier"] = 1
	},
	["SellPrice"] = 20,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.3, 4),
		["Default"] = NumberRange.new(1.9, 2.5)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1