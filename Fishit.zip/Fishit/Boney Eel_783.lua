-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 351,
		["Type"] = "Fish",
		["Name"] = "Boney Eel",
		["Description"] = "",
		["Icon"] = "rbxassetid://85394749821305",
		["Tier"] = 3
	},
	["SellPrice"] = 450,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.52, 1.9),
		["Default"] = NumberRange.new(0.91, 1.37)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1