-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("CollectionService")
local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Trove)
local v3 = require(v1.Packages.Observers)
local v4 = require(v1.Packages.Replion)
local v_u_5 = require(v1.Shared.TierUtility)
local v_u_6 = require(v1.Shared.ItemUtility)
local v_u_7 = script:WaitForChild("Marker")
local v8 = v4.Client:WaitReplion("Data")
local v_u_9 = false
local v_u_10 = {}
local v_u_11 = v2.new()
local function v_u_19(p12)
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_5, (copy) v_u_11
	if p12.Name == "TreasureHuntRing" then
		p12.Transparency = 0
		p12.Attachment.Tag.Enabled = true
	else
		local v13 = p12:FindFirstChildWhichIsA("Texture")
		if v13 then
			v13.Transparency = 0
		end
		local v14 = p12:FindFirstChildWhichIsA("SelectionBox")
		if v14 then
			v14.Visible = true
		end
		if not p12:FindFirstChild("Marker") then
			local v15 = p12:GetAttribute("LuckyFish")
			if not v15 then
				return
			end
			local v16 = v_u_6:GetItemData(v15)
			if v16 then
				local v17 = v_u_7:Clone()
				v17.Frame.DisplayName.Text = v16.Data.Name
				local v18 = v16.Probability
				if v18 then
					v18 = v_u_5:GetTierFromRarity(v16.Probability.Chance)
				end
				if v18 then
					v17.Frame.DisplayName.UIGradient.Color = v18.TierColor
					v17.Frame.DisplayName.Diamond.UIGradient.Color = v18.TierColor
				end
				v17.Parent = p12
				v_u_11:Add(v17)
			end
		end
	end
end
local function v_u_24(p20)
	if p20.Name == "TreasureHuntRing" then
		p20.Transparency = 1
		p20.Attachment.Tag.Enabled = false
	else
		local v21 = p20:FindFirstChildWhichIsA("Texture")
		if v21 then
			v21.Transparency = 1
		end
		local v22 = p20:FindFirstChildWhichIsA("SelectionBox")
		if v22 then
			v22.Visible = false
		end
		local v23 = p20:FindFirstChild("Marker")
		if v23 then
			v23:Destroy()
		end
	end
end
local function v28(p25)
	-- upvalues: (ref) v_u_9, (copy) v_u_19, (copy) v_u_24, (copy) v_u_10, (copy) v_u_11
	v_u_9 = p25
	local v26
	if p25 then
		v26 = v_u_19
	else
		v26 = v_u_24
	end
	for _, v27 in ipairs(v_u_10) do
		v26(v27)
	end
	if not p25 then
		v_u_11:Clean()
	end
end
v3.observeTag("FishingRadarRegion", function(p_u_29)
	-- upvalues: (ref) v_u_9, (copy) v_u_19, (copy) v_u_10, (copy) v_u_24
	if v_u_9 then
		v_u_19(p_u_29)
		local v30 = v_u_10
		table.insert(v30, p_u_29)
	else
		v_u_24(p_u_29)
		local v31 = v_u_10
		table.insert(v31, p_u_29)
	end
	return function()
		-- upvalues: (ref) v_u_10, (copy) p_u_29
		local v32 = table.find(v_u_10, p_u_29)
		if v32 then
			table.remove(v_u_10, v32)
		end
	end
end)
v8:OnChange("RegionsVisible", v28)
v_u_9 = false
for _, v33 in ipairs(v_u_10) do
	v_u_24(v33)
end
v_u_11:Clean()
return {}