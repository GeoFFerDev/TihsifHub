-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("RunService")
game:GetService("ServerScriptService")
local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
require(v1.Packages.Thread)
local v3 = require(v1.Packages.Net)
require(v1.Packages.Observers)
local v_u_4 = require(v1.Packages.Replion)
local v_u_5 = require(v1.Shared.Soundbook)
local v_u_6 = require(v1.Shared.ItemUtility)
local v_u_7 = require(v1.Shared.PlayerStatsUtility)
local v_u_8 = require(v1.Shared.BountyUtility)
local v_u_9 = require(v1.Shared.TierUtility)
local v_u_10 = require(v1.Shared.StringLibrary)
local v_u_11 = require(v1.Shared.VendorUtility)
local v_u_12 = require(v1.Controllers.TextNotificationController)
require(v1.Types.Modifiers)
local v_u_13 = v3:RemoteEvent("LockBounty")
local v_u_14 = v3:RemoteEvent("UnlockBounty")
local v_u_15 = v3:RemoteFunction("ClaimBounty")
local _ = v2.LocalPlayer
local v_u_16 = nil
local v_u_73 = {
	["SetupBountyBoard"] = function(_, p_u_17, p_u_18)
		-- upvalues: (ref) v_u_16, (copy) v_u_4, (copy) v_u_73
		if not v_u_16 then
			v_u_16 = v_u_4.Client:WaitReplion("Data")
		end
		p_u_18:WaitForChild("Gui")
		p_u_18:WaitForChild("Decal")
		local function v_u_19()
			-- upvalues: (ref) v_u_16, (copy) p_u_17, (ref) v_u_73, (copy) p_u_18
			v_u_16:OnChange({ "Bounty", "Slots", p_u_17 }, function()
				-- upvalues: (ref) v_u_73, (ref) p_u_17, (ref) p_u_18
				v_u_73:UpdateBounty(p_u_17, p_u_18)
			end)
			v_u_73:UpdateBounty(p_u_17, p_u_18)
			v_u_73:RegisterBounty(p_u_17, p_u_18)
		end
		if v_u_16:Get("Bounty") then
			v_u_19()
		else
			local v_u_20 = nil
			v_u_20 = v_u_16:OnChange("Bounty", function()
				-- upvalues: (ref) v_u_20, (copy) v_u_19
				v_u_20:Disconnect()
				v_u_19()
			end)
		end
		local v21 = p_u_18:WaitForChild("Gui")
		if v21 then
			v21.Enabled = true
		end
		local v22 = p_u_18:WaitForChild("Decal")
		if v22 then
			v22.Transparency = 0
		end
	end,
	["RegisterBounty"] = function(_, p_u_23, p24)
		-- upvalues: (ref) v_u_16, (copy) v_u_12, (copy) v_u_73, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15
		local v_u_25 = script.EnrollAttachment:Clone()
		local v_u_26 = script.UnenrollAttachment:Clone()
		local v_u_27 = script.ClaimAttachment:Clone()
		local v_u_28 = 0
		local v_u_29 = script.TimerGui:Clone()
		v_u_29.Enabled = false
		local function v_u_31(_)
			-- upvalues: (ref) v_u_16, (copy) v_u_29
			local v30 = v_u_16:Get({ "Bounty", "LastUpdate" })
			v_u_29.Frame.Remaining:SetAttribute("Expires", v30 + 86400)
			v_u_29.Frame.Remaining:AddTag("DHMSLabel")
			v_u_29.Enabled = true
		end
		local function v_u_34(p32)
			-- upvalues: (ref) v_u_12
			local v33 = {
				["Type"] = "Text",
				["Text"] = p32,
				["TextColor"] = {
					["R"] = 0,
					["G"] = 255,
					["B"] = 0
				}
			}
			v_u_12:DeliverNotification(v33)
		end
		local function v_u_37(p35)
			-- upvalues: (ref) v_u_12
			local v36 = {
				["Type"] = "Text",
				["Text"] = p35,
				["TextColor"] = {
					["R"] = 255,
					["G"] = 0,
					["B"] = 0
				}
			}
			v_u_12:DeliverNotification(v36)
		end
		local function v39()
			-- upvalues: (ref) v_u_73, (copy) p_u_23, (copy) v_u_25, (copy) v_u_26, (copy) v_u_27, (copy) v_u_31, (copy) v_u_29
			local v38 = v_u_73:GetBountySlot(p_u_23)
			if (v38 == nil or v38 and v38.Claimed) and true or false then
				v_u_25.ProximityPrompt.Enabled = false
				v_u_26.ProximityPrompt.Enabled = false
				v_u_27.ProximityPrompt.Enabled = false
				if v38 and v38.Claimed then
					v_u_31(v38)
				else
					v_u_29.Frame.Remaining:SetAttribute("Expires", 0)
					v_u_29.Frame.Remaining:RemoveTag("DHMSLabel")
					v_u_29.Enabled = false
				end
			elseif v38.Locked then
				v_u_25.ProximityPrompt.Enabled = false
				v_u_26.ProximityPrompt.Enabled = true
				v_u_27.ProximityPrompt.Enabled = true
				v_u_29.Frame.Remaining:SetAttribute("Expires", 0)
				v_u_29.Frame.Remaining:RemoveTag("DHMSLabel")
				v_u_29.Enabled = false
			else
				v_u_25.ProximityPrompt.Enabled = true
				v_u_26.ProximityPrompt.Enabled = false
				v_u_27.ProximityPrompt.Enabled = false
				v_u_31(v38)
			end
		end
		v_u_16:OnChange({ "Bounty", "LastUpdate", p_u_23 }, v39)
		v_u_16:OnChange({ "Bounty", "Slots", p_u_23 }, v39)
		v39()
		v_u_25.ProximityPrompt.Triggered:Connect(function()
			-- upvalues: (ref) v_u_73, (copy) p_u_23, (copy) v_u_37, (ref) v_u_28, (ref) v_u_5, (ref) v_u_13, (copy) v_u_34
			local v40 = v_u_73:GetBountySlot(p_u_23)
			if v40 then
				if v40.Claimed then
					v_u_37("Already claimed reward!")
					return
				elseif v40.Locked then
					v_u_37("Already selected this bounty!")
					return
				elseif v_u_28 + 1 <= tick() then
					v_u_28 = tick()
					v_u_5.Sounds.ThickClick:Play()
					v_u_13:FireServer(p_u_23)
					v_u_34("Started bounty!")
				end
			else
				return
			end
		end)
		v_u_26.ProximityPrompt.Triggered:Connect(function()
			-- upvalues: (ref) v_u_73, (copy) p_u_23, (copy) v_u_37, (ref) v_u_28, (ref) v_u_5, (ref) v_u_14, (copy) v_u_34
			local v41 = v_u_73:GetBountySlot(p_u_23)
			if v41 then
				if v41.Claimed then
					v_u_37("Already claimed reward!")
					return
				elseif v41.Locked then
					if v_u_28 + 1 <= tick() then
						v_u_28 = tick()
						v_u_5.Sounds.ThickClick:Play()
						v_u_14:FireServer(p_u_23)
						v_u_34("Removed bounty")
					end
				else
					return
				end
			else
				return
			end
		end)
		v_u_27.ProximityPrompt.Triggered:Connect(function()
			-- upvalues: (ref) v_u_16, (copy) v_u_37, (ref) v_u_73, (copy) p_u_23, (ref) v_u_7, (ref) v_u_8, (ref) v_u_28, (ref) v_u_15, (copy) v_u_34, (ref) v_u_5
			local v_u_42 = v_u_16:GetExpect("EquippedId")
			local v43 = v_u_16:GetExpect("EquippedType")
			if string.len(v43) == 0 or string.len(v_u_42) == 0 then
				v_u_37("You do not have an item equipped!")
				return
			else
				local v_u_44 = v_u_73:GetBountySlot(p_u_23)
				if v_u_44 then
					if v_u_44.Type == v43 then
						if v_u_44.Claimed then
							v_u_37("Already claimed reward!")
							return
						elseif v_u_44.Locked then
							local _ = v_u_44.Metadata
							local v_u_45 = v_u_44.Id
							local v_u_46 = false
							local v_u_47 = false
							local v_u_48 = v_u_44.Metadata
							if v_u_48 then
								v_u_48 = next(v_u_44.Metadata) ~= nil
							end
							if v_u_7:GetItemFromInventory(v_u_16, function(p49)
								-- upvalues: (copy) v_u_45, (copy) v_u_42, (ref) v_u_46, (copy) v_u_48, (copy) v_u_44, (ref) v_u_8, (ref) v_u_47
								if p49.Id ~= v_u_45 then
									return false
								end
								if p49.UUID ~= v_u_42 then
									return false
								end
								if p49.Favorited then
									v_u_46 = true
									return false
								end
								if not v_u_48 then
									return true
								end
								local v50 = {
									["Id"] = p49.Id
								}
								if p49.Metadata and v_u_44.Metadata then
									v50.Metadata = {
										["VariantId"] = p49.Metadata.VariantId,
										["Shiny"] = p49.Metadata.Shiny
									}
								end
								local v51, v52 = v_u_8:MatchArgs(v50, v_u_44.Metadata)
								if v52 then
									v_u_47 = v52
								end
								return v51
							end, "Items") then
								if v_u_28 + 1 <= tick() then
									v_u_28 = tick()
									if v_u_15:InvokeServer(p_u_23, v_u_42) then
										v_u_34("You claimed your bounty reward!")
										v_u_5.Sounds.CoinsChanged:Play()
										v_u_5.Sounds.QuestCompleted:Play()
									else
										v_u_5.Sounds.ThickClick:Play()
									end
								end
							else
								v_u_37(v_u_46 and "You cannot exchange a favorited item" or (v_u_47 and "This is item is missing a characteristic such as mutated or shiny" or "Wrong item equipped!"))
								return
							end
						else
							return
						end
					else
						v_u_37("Wrong item equipped!")
						return
					end
				else
					return
				end
			end
		end)
		v_u_29.Parent = p24
		v_u_25.Parent = p24
		v_u_26.Parent = p24
		v_u_27.Parent = p24
	end,
	["UpdateBounty"] = function(_, p53, p54)
		-- upvalues: (copy) v_u_73, (copy) v_u_6, (copy) v_u_10, (copy) v_u_9, (copy) v_u_11
		local v55 = v_u_73:GetBountySlot(p53)
		if v55 then
			local v56 = v_u_6.GetItemDataFromItemType(v55.Type, v55.Name) or v_u_6.GetItemDataFromItemType(v55.Type, v55.Id)
			if v56 then
				local v57 = nil
				local v58 = v56.Probability
				local v59
				if v58 then
					local v60 = v_u_10
					local v61 = 1 / v58.Chance
					v57 = ("1 in %*"):format((v60:AddCommas((math.ceil(v61)))))
					v59 = v_u_9:GetTierFromRarity(v58.Chance)
				else
					v59 = v_u_9:GetTier(v56.Data.Tier)
				end
				local v62 = p54.Gui.Housing
				local v63 = v62.Inner.Configuration
				if v57 then
					v62.Catch.Text = v57
				end
				if v59 then
					for v64 = 1, 3 do
						local v65 = v62.StarFrame:FindFirstChild((("Star%*"):format(v64)))
						if v65 then
							v65.Visible = v64 <= v59.Tier
						end
					end
				end
				local v66 = false
				local v67 = false
				if v55.Metadata then
					if v55.Metadata.Shiny then
						v63.ShinyFrame.Visible = true
						v66 = true
					end
					if v55.Metadata.VariantId then
						local v68 = v_u_6:GetVariantData(v55.Metadata.VariantId)
						if v68 then
							v63.MutationFrame.Label.Text = v68.Data.Name
							v63.MutationFrame.Label.UIGradient.Color = v68.Data.TierColor
							v63.MutationFrame.Glow.UIGradient.Color = v68.Data.TierColor
							v67 = true
						end
					end
				end
				v63.ShinyFrame.Visible = v66
				v63.MutationFrame.Visible = v67
				v63.Visible = v55.Metadata ~= nil
				v62.Inner.Vector.Image = v56.Data.Icon or ""
				v62.Inner.Tags.ItemName.Text = v56.Data.Name
				if v59 then
					v62.Inner.Tags.ItemName.UIGradient.Color = v59.TierColor
					v62.Inner.Gradient.UIGradient.Color = v59.TierColor
					v62.Inner.UIStroke.UIGradient.Color = v59.TierColor
				end
				if v55.Claimed then
					v62.Header.Text = "CLAIMED"
					v62.Header.TextColor3 = Color3.fromRGB(42, 255, 67)
				else
					v62.Header.Text = "BOUNTY"
					v62.Header.TextColor3 = Color3.fromRGB(255, 255, 255)
				end
				local v69 = v59 and v59.Tier >= 6 and 2 or 3
				local v70 = v_u_11:GetSellPrice({
					["UUID"] = game.JobId,
					["Id"] = v55.Id,
					["Quantity"] = 1,
					["Timestamp"] = -1,
					["Metadata"] = v55.Metadata
				})
				if v70 then
					v62.CurrencyCounter.Counter.Text = v_u_10:AddCommas(v70 * v69)
					v62.CurrencyCounter.Visible = true
				else
					v62.CurrencyCounter.Visible = false
				end
				v62.Visible = v57 ~= nil
				p54.Gui.Enabled = true
			else
				p54.Gui.Enabled = false
			end
		else
			p54.Gui.Enabled = false
			warn("[BountyController] No Bounty found for", p53)
			return
		end
	end,
	["GetBountySlot"] = function(_, p71)
		-- upvalues: (ref) v_u_16
		local v72 = v_u_16:Get("Bounty")
		if v72 then
			return v72.Slots[p71]
		end
	end
}
return v_u_73