-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Modules.Util.TableUtil)
local v_u_3 = require(v1.Shared.ItemUtility)
require(v1.Types.Modifiers)
local v_u_4 = {}
return {
	["GetSpecialFish"] = function(_)
		-- upvalues: (copy) v_u_4
		return v_u_4
	end,
	["MatchArgs"] = function(_, p5, p6)
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		if not p5.Metadata then
			return false, false
		end
		if not p6 then
			return false, false
		end
		local v7 = v_u_2.Count(p6)
		local v8 = 0
		for v9, v10 in p6 do
			local v11 = p5.Metadata[v9]
			if v11 then
				local v12 = nil
				if v9 == "VariantId" then
					local v13 = v_u_3:GetVariantData(v11)
					if v13 then
						v12 = v10 == v13.Data.Id and true or v10 == v13.Data.Name
					end
				else
					v12 = v10 == v11
				end
				if v12 then
					v8 = v8 + 1
				end
			end
		end
		return v7 <= v8, true
	end
}