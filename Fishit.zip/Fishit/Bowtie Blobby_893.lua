-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 487,
		["Type"] = "Fish",
		["Name"] = "Bowtie Blobby",
		["Description"] = "",
		["Icon"] = "rbxassetid://110689311505585",
		["Tier"] = 2
	},
	["SellPrice"] = 58,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(35.19, 65.81),
		["Default"] = NumberRange.new(15.64, 23.46)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1