-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 641,
		["Type"] = "Fish",
		["Name"] = "Brinehead Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://87608465060683",
		["Tier"] = 1
	},
	["SellPrice"] = 20,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.7, 2.4),
		["Default"] = NumberRange.new(1.2, 1.5)
	},
	["Probability"] = {
		["Chance"] = 0.25
	},
	["_moduleScript"] = script
}
return v1