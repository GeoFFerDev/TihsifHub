-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 757,
		["Type"] = "Fish",
		["Name"] = "Broken Heart Nessie",
		["Description"] = "",
		["Icon"] = "rbxassetid://128778303459704",
		["Tier"] = 7
	},
	["SellPrice"] = 490000,
	["Weight"] = {
		["Big"] = NumberRange.new(538000, 681000),
		["Default"] = NumberRange.new(360000, 495000)
	},
	["Probability"] = {
		["Chance"] = 1.6666666666666668e-7
	},
	["EventTag"] = "VAL26",
	["_moduleScript"] = script
}
return v1