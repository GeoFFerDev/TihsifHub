-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 434,
		["Type"] = "Fish",
		["Name"] = "Builderman Guppy",
		["Description"] = "",
		["Icon"] = "rbxassetid://115945392034086",
		["Tier"] = 3
	},
	["SellPrice"] = 330,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.1, 2.5),
		["Default"] = NumberRange.new(1.2, 1.6)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1