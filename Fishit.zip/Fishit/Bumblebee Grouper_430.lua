-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 37,
		["Type"] = "Fish",
		["Name"] = "Bumblebee Grouper",
		["Description"] = "",
		["Icon"] = "rbxassetid://138718017852833",
		["Tier"] = 4
	},
	["SellPrice"] = 3225,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2, 2.5),
		["Default"] = NumberRange.new(1.3, 1.5)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1