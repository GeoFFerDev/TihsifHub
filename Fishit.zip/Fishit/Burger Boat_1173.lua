-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 18,
		["Type"] = "Boats",
		["Name"] = "Burger Boat",
		["Description"] = "",
		["Icon"] = "rbxassetid://140346206781889",
		["Tier"] = 6
	},
	["HiddenInShop"] = true,
	["LinkedGamePass"] = "Burger Boat",
	["Seats"] = 2,
	["_moduleScript"] = script
}
return v1