-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 579,
		["Type"] = "Gears",
		["Name"] = "Burntflame Relic",
		["Description"] = "Used to summon the vicious Leviathan",
		["Icon"] = "rbxassetid://108092584856334",
		["Tier"] = 4
	},
	["TradeLocked"] = true,
	["_moduleScript"] = script
}
return v1