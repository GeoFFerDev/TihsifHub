-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v3 = require(v1.Packages.Replion)
local v4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Packages.spr)
local v_u_6 = require(v1.Modules.GuiControl)
local v7 = v2.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("Exclusive Store"):WaitForChild("Main")
local v_u_8 = script.Parent:WaitForChild("Items")
local function v_u_9()
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_6
	v_u_5.stop(v_u_8)
	v_u_5.target(v_u_8, 1, 2, {
		["CanvasPosition"] = Vector2.new(0, v_u_8.UIListLayout.AbsoluteContentSize.Y * 0.6 + 10)
	})
	if not v_u_6:IsOpen("Exclusive Store") then
		v_u_6:Open("Exclusive Store")
	end
end
local v10 = script.Parent:WaitForChild("Top"):WaitForChild("Above"):WaitForChild("Coins")
if v10 then
	v_u_6:Hook("Hold Button", v10).Clicked:Connect(v_u_9)
end
v4.observeTag("ExclusiveCurrencyButton", function(p11)
	-- upvalues: (copy) v_u_6, (copy) v_u_9
	local v_u_12 = v_u_6:Hook("Hold Button", p11)
	v_u_12.Clicked:Connect(v_u_9)
	return function()
		-- upvalues: (copy) v_u_12
		v_u_12:Destroy()
	end
end)
if v3.Client:WaitReplion("Data") and workspace.CurrentCamera.ViewportSize.Y <= 500 then
	v7.Size = UDim2.fromScale(0.9, 0.9)
end