-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ReplicatedStorage")
local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v3 = require(v1.Packages.Replion)
local v_u_4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Packages.spr)
local v_u_6 = require(v1.Modules.GuiControl)
local v_u_7 = v2.LocalPlayer.PlayerGui
v3.Client:AwaitReplion("Data", function(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7
	local v8 = { v_u_7 }
	v_u_4.observeTag("ButtonScrolling", function(p9)
		-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_4
		local v10 = p9:WaitForChild("Main")
		if workspace.CurrentCamera.ViewportSize.Y <= 500 then
			v10.Size = UDim2.fromScale(0.9, 0.9)
		end
		local v11 = p9:WaitForChild("Main"):WaitForChild("Content")
		if v11 then
			local v_u_12 = v11:WaitForChild("Items")
			local function v_u_13()
				-- upvalues: (ref) v_u_5, (copy) v_u_12, (ref) v_u_6
				v_u_5.stop(v_u_12)
				v_u_5.target(v_u_12, 1, 2, {
					["CanvasPosition"] = Vector2.new(0, v_u_12.UIListLayout.AbsoluteContentSize.Y * 0.6 + 10)
				})
				if not v_u_6:IsOpen("Exclusive Store") then
					v_u_6:Open("Exclusive Store")
				end
			end
			local v14 = v11:WaitForChild("Top"):WaitForChild("Above"):WaitForChild("Coins")
			if v14 then
				v_u_6:Hook("Hold Button", v14).Clicked:Connect(v_u_13)
			end
			v_u_4.observeTag("ExclusiveCurrencyButton", function(p15)
				-- upvalues: (ref) v_u_6, (copy) v_u_13
				local v_u_16 = v_u_6:Hook("Hold Button", p15)
				v_u_16.Clicked:Connect(v_u_13)
				return function()
					-- upvalues: (copy) v_u_16
					v_u_16:Destroy()
				end
			end)
		end
	end, v8)
end)
return {}