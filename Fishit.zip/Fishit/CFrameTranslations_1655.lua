-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Part"] = function(p1)
		return p1.CFrame
	end,
	["MeshPart"] = function(p2)
		return p2.CFrame
	end,
	["Bone"] = function(p3)
		return p3.WorldCFrame
	end,
	["Attachment"] = function(p4)
		return p4.WorldCFrame
	end
}