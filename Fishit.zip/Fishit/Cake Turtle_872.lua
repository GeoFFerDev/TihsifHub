-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 461,
		["Type"] = "Fish",
		["Name"] = "Cake Turtle",
		["Description"] = "",
		["Icon"] = "rbxassetid://74624545968974",
		["Tier"] = 4
	},
	["SellPrice"] = 1100,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(215, 258),
		["Default"] = NumberRange.new(127, 165)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["EventTag"] = "BDAY",
	["_moduleScript"] = script
}
return v1