-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 59,
		["Type"] = "Fish",
		["Name"] = "Candy Butterfly",
		["Description"] = "",
		["Icon"] = "rbxassetid://118627817589849",
		["Tier"] = 2
	},
	["SellPrice"] = 419,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.4, 3),
		["Default"] = NumberRange.new(1.5, 1.8)
	},
	["Probability"] = {
		["Chance"] = 0.0026666666666666666
	},
	["_moduleScript"] = script
}
return v1