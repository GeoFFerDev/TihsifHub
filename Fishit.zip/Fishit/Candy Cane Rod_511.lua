-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 100,
		["Type"] = "Fishing Rods",
		["Name"] = "Candy Cane Rod",
		["Description"] = "EVENT - Christmas 2024",
		["Icon"] = "rbxassetid://82270679061745",
		["NewIcon"] = true,
		["Tier"] = 5
	},
	["EquipAsSkin"] = true,
	["VisualClickPowerPercent"] = 0.4,
	["ClickPower"] = 0.17,
	["Resilience"] = 4.3,
	["Windup"] = NumberRange.new(3.8, 4.4),
	["MaxWeight"] = 50000
}
local v2 = {
	["BaseLuck"] = 3.5,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1