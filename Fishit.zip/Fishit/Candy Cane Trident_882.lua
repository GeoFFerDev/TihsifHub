-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 521,
		["Type"] = "Fishing Rods",
		["Name"] = "Candy Cane Trident",
		["Description"] = "",
		["Icon"] = "rbxassetid://81887444251302",
		["NewIcon"] = true,
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.75, 1.5, -0.25),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, 0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(-0.042, -1, -0.008)) * CFrame.fromOrientation(-1.1344640137963142, 1.5707963267948966, -1.5707963267948966),
	["GripC1"] = CFrame.identity,
	["BobberAnimationDelay"] = 0.4,
	["catchAnimationDelay"] = 0.2,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1