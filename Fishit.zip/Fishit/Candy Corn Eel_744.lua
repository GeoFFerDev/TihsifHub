-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 333,
		["Type"] = "Fish",
		["Name"] = "Candy Corn Eel",
		["Description"] = "",
		["Icon"] = "rbxassetid://93259170550129",
		["Tier"] = 2
	},
	["SellPrice"] = 65,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(7.8, 9.2),
		["Default"] = NumberRange.new(5.3, 7)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "HALLOW25",
	["_moduleScript"] = script
}
return v1