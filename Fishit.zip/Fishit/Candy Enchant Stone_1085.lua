-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 714,
		["Type"] = "Enchant Stones",
		["Name"] = "Candy Enchant Stone",
		["Description"] = "Contains special Valentine enchants!",
		["Icon"] = "rbxassetid://95328220080967",
		["Tier"] = 5
	},
	["Probability"] = {
		["Chance"] = 0.00015384615384615385
	},
	["Enchants"] = {
		["Blob Hunter"] = 15,
		["Glistening II"] = 15,
		["Lovestruck"] = 15,
		["More Hearts"] = 15,
		["Heartbreaker"] = 15,
		["Dynamic Duo"] = 25
	},
	["RecordData"] = true,
	["_moduleScript"] = script
}
return v1