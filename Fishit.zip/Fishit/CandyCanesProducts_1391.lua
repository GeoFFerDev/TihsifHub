-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = require(game.ReplicatedStorage.Shared.RewardInfo)
return {
	[2678577397] = v1.currencyReward(v1.BattlepassCurrency, 1000),
	[2678577751] = v1.currencyReward(v1.BattlepassCurrency, 2500),
	[2678577869] = v1.currencyReward(v1.BattlepassCurrency, 5000),
	[2678578224] = v1.currencyReward(v1.BattlepassCurrency, 12500),
	[2678578371] = v1.currencyReward(v1.BattlepassCurrency, 25000)
}