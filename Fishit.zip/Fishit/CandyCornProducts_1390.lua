-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = require(game.ReplicatedStorage.Shared.RewardInfo)
return {
	[3434855759] = v1.currencyReward("Candy Corns", 1000),
	[3434856879] = v1.currencyReward("Candy Corns", 2500),
	[3434857228] = v1.currencyReward("Candy Corns", 5000),
	[3434856560] = v1.currencyReward("Candy Corns", 12500),
	[3434857436] = v1.currencyReward("Candy Corns", 25000)
}