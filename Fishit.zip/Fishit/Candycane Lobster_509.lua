-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 95,
		["Type"] = "Fish",
		["Name"] = "Candycane Lobster",
		["Description"] = "",
		["Icon"] = "rbxassetid://81306607650028",
		["Tier"] = 4
	},
	["SellPrice"] = 2138,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(18.9, 29.27),
		["Default"] = NumberRange.new(8.4, 12.6)
	},
	["Probability"] = {
		["Chance"] = 0.0005
	},
	["EventTag"] = "XMAS24",
	["_moduleScript"] = script
}
return v1