-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 433,
		["Type"] = "Fish",
		["Name"] = "Cantelope Puffer",
		["Description"] = "",
		["Icon"] = "rbxassetid://136380956166771",
		["Tier"] = 2
	},
	["SellPrice"] = 55,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(4.7, 5.6),
		["Default"] = NumberRange.new(2.7, 3.6)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1