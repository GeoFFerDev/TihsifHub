-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_99 = {
	["__index"] = function(p1, p2)
		-- upvalues: (copy) v_u_99
		if p2 == "GroupTransparency" then
			local v3 = p1.Instance:FindFirstChild("GroupTransparency")
			if v3 then
				return v3
			end
		else
			local v4 = p2 == "GroupColor3" and p1.Instance:FindFirstChild("GroupColor3")
			if v4 then
				return v4
			end
		end
		if p1.__props and p1.__props[p2] ~= nil then
			return p1.__props[p2]
		elseif v_u_99[p2] then
			return v_u_99[p2]
		else
			return p1.Instance[p2]
		end
	end,
	["__newindex"] = function(p5, p6, p7)
		if p6 == "GroupTransparency" then
			local v8 = p5.Instance:FindFirstChild("GroupTransparency")
			if v8 and (typeof(v8) == "Instance" and v8:IsA("NumberValue")) then
				v8.Value = p7
				return
			end
		elseif p6 == "GroupColor3" then
			local v9 = p5.Instance:FindFirstChild("GroupColor3")
			if v9 and (typeof(v9) == "Instance" and v9:IsA("Color3Value")) then
				v9.Value = p7
				return
			end
		end
		if p6:sub(1, 1) == "_" then
			if not p5.__props then
				p5.__props = {}
			end
			p5.__props[p6] = p7
		else
			p5.Instance[p6] = p7
		end
	end,
	["new"] = function(p10, p11)
		-- upvalues: (copy) v_u_99
		local v_u_12 = {
			["__props"] = {}
		}
		if p10 and (typeof(p10) == "Instance" and p10:IsA("Frame")) then
			v_u_12.Instance = p10
		else
			v_u_12.Instance = Instance.new("Frame")
			v_u_12.Instance.Name = "CanvasGroup"
			v_u_12.Instance.BackgroundTransparency = 1
		end
		v_u_12.Instance.ClipsDescendants = p11 ~= false
		local v13 = v_u_99
		setmetatable(v_u_12, v13)
		local v14 = v_u_12.Instance:FindFirstChild("GroupTransparency")
		if v14 and v14:IsA("NumberValue") then
			v_u_12._groupTransparencyValue = v14
		else
			v_u_12._groupTransparencyValue = Instance.new("NumberValue")
			v_u_12._groupTransparencyValue.Name = "GroupTransparency"
			v_u_12._groupTransparencyValue.Value = 0
			v_u_12._groupTransparencyValue.Parent = v_u_12.Instance
		end
		local v15 = v_u_12.Instance:FindFirstChild("GroupColor3")
		if v15 and v15:IsA("Color3Value") then
			v_u_12._groupColor3Value = v15
		else
			v_u_12._groupColor3Value = Instance.new("Color3Value")
			v_u_12._groupColor3Value.Name = "GroupColor3"
			v_u_12._groupColor3Value.Value = Color3.new(1, 1, 1)
			v_u_12._groupColor3Value.Parent = v_u_12.Instance
		end
		v_u_12.Instance:SetAttribute("GroupTransparency", v_u_12._groupTransparencyValue.Value)
		v_u_12.Instance:SetAttribute("GroupColor3_R", v_u_12._groupColor3Value.Value.R)
		v_u_12.Instance:SetAttribute("GroupColor3_G", v_u_12._groupColor3Value.Value.G)
		v_u_12.Instance:SetAttribute("GroupColor3_B", v_u_12._groupColor3Value.Value.B)
		v_u_12._attributeChangedConn = v_u_12.Instance.AttributeChanged:Connect(function(p16)
			-- upvalues: (copy) v_u_12
			if p16 == "GroupTransparency" then
				v_u_12:_refreshAllDescendants()
			elseif p16:find("GroupColor3_") then
				v_u_12:_refreshAllDescendants()
			end
		end)
		v_u_12._descendants = {}
		v_u_12._originalProps = {}
		v_u_12._descendantAddedConn = v_u_12.Instance.DescendantAdded:Connect(function(p17)
			-- upvalues: (copy) v_u_12
			if v_u_12:_isValidGuiObject(p17) then
				v_u_12:_registerDescendant(p17)
			end
		end)
		v_u_12._descendantRemovedConn = v_u_12.Instance.DescendantRemoving:Connect(function(p18)
			-- upvalues: (copy) v_u_12
			if v_u_12:_isValidGuiObject(p18) then
				v_u_12:_unregisterDescendant(p18)
			end
		end)
		if v_u_12:_isValidGuiObject(v_u_12.Instance) then
			v_u_12:_registerDescendant(v_u_12.Instance)
		end
		for _, v19 in ipairs(v_u_12.Instance:GetDescendants()) do
			if v_u_12:_isValidGuiObject(v19) then
				v_u_12:_registerDescendant(v19)
			end
		end
		v_u_12._transparencyChangedConn = v_u_12._groupTransparencyValue.Changed:Connect(function()
			-- upvalues: (copy) v_u_12
			v_u_12.Instance:SetAttribute("GroupTransparency", v_u_12._groupTransparencyValue.Value)
		end)
		v_u_12._colorChangedConn = v_u_12._groupColor3Value.Changed:Connect(function()
			-- upvalues: (copy) v_u_12
			local v20 = v_u_12._groupColor3Value.Value
			v_u_12.Instance:SetAttribute("GroupColor3_R", v20.R)
			v_u_12.Instance:SetAttribute("GroupColor3_G", v20.G)
			v_u_12.Instance:SetAttribute("GroupColor3_B", v20.B)
		end)
		return v_u_12
	end,
	["fromInstance"] = function(p21)
		-- upvalues: (copy) v_u_99
		if typeof(p21) ~= "Instance" or not p21:IsA("Frame") then
			error("CanvasGroup.fromInstance requires a Frame instance")
		end
		return v_u_99.new(p21)
	end,
	["_isValidGuiObject"] = function(_, p_u_22)
		if p_u_22:IsA("UIStroke") or p_u_22:IsA("UIGradient") then
			return true
		end
		if p_u_22:IsA("UIGridStyleLayout") or p_u_22:IsA("UILayout") then
			return false
		end
		local v23 = pcall(function()
			-- upvalues: (copy) p_u_22
			local _ = p_u_22.BackgroundColor3
			local _ = p_u_22.BackgroundTransparency
		end)
		if v23 then
			v23 = p_u_22:IsA("GuiObject") or p_u_22:IsA("UIComponent")
		end
		return v23
	end,
	["_registerDescendant"] = function(p24, p25)
		if not table.find(p24._descendants, p25) then
			local v26 = p24._descendants
			table.insert(v26, p25)
			if p25:IsA("UIStroke") then
				p24._originalProps[p25] = {
					["Color"] = p25.Color,
					["Transparency"] = p25.Transparency
				}
			elseif p25:IsA("UIGradient") then
				p24._originalProps[p25] = {
					["Color"] = p25.Color,
					["Transparency"] = p25.Transparency
				}
			else
				local v27 = p24._originalProps
				local v28 = {
					["BackgroundColor3"] = p25.BackgroundColor3,
					["BackgroundTransparency"] = p25.BackgroundTransparency
				}
				local v29
				if p25:IsA("TextLabel") then
					v29 = p25.TextColor3 or nil
				else
					v29 = nil
				end
				v28.TextColor3 = v29
				local v30
				if p25:IsA("TextLabel") then
					v30 = p25.TextTransparency or nil
				else
					v30 = nil
				end
				v28.TextTransparency = v30
				local v31
				if p25:IsA("ImageLabel") then
					v31 = p25.ImageColor3 or nil
				else
					v31 = nil
				end
				v28.ImageColor3 = v31
				local v32
				if p25:IsA("ImageLabel") then
					v32 = p25.ImageTransparency or nil
				else
					v32 = nil
				end
				v28.ImageTransparency = v32
				v27[p25] = v28
			end
			p24:_applyPropertiesToDescendant(p25)
		end
	end,
	["_unregisterDescendant"] = function(p33, p34)
		local v35 = table.find(p33._descendants, p34)
		if v35 then
			table.remove(p33._descendants, v35)
			local v36 = p33._originalProps[p34]
			if v36 then
				if p34:IsA("UIStroke") then
					p34.Color = v36.Color
					p34.Transparency = v36.Transparency
				elseif p34:IsA("UIGradient") then
					p34.Color = v36.Color
					p34.Transparency = v36.Transparency
				else
					p34.BackgroundColor3 = v36.BackgroundColor3
					p34.BackgroundTransparency = v36.BackgroundTransparency
					if p34:IsA("TextLabel") and v36.TextColor3 then
						p34.TextColor3 = v36.TextColor3
						p34.TextTransparency = v36.TextTransparency
					end
					if p34:IsA("ImageLabel") and v36.ImageColor3 then
						p34.ImageColor3 = v36.ImageColor3
						p34.ImageTransparency = v36.ImageTransparency
					end
				end
				p33._originalProps[p34] = nil
			end
		end
	end,
	["_applyPropertiesToDescendant"] = function(p37, p38)
		local v39 = p37._originalProps[p38]
		if v39 then
			local v40 = p37.Instance:GetAttribute("GroupTransparency")
			local v41 = Color3.new(p37.Instance:GetAttribute("GroupColor3_R"), p37.Instance:GetAttribute("GroupColor3_G"), p37.Instance:GetAttribute("GroupColor3_B"))
			if p38:IsA("UIStroke") then
				p38.Color = p37:_multiplyColors(v39.Color, v41)
				if v40 >= 0.99 then
					p38.Transparency = 1
				else
					p38.Transparency = p37:_combineTransparency(v39.Transparency, v40)
				end
			elseif p38:IsA("UIGradient") then
				p38.Color = p37:_applyColorToColorSequence(v39.Color, v41)
				p38.Transparency = p37:_applyTransparencyToNumberSequence(v39.Transparency, v40)
			else
				p38.BackgroundColor3 = p37:_multiplyColors(v39.BackgroundColor3, v41)
				p38.BackgroundTransparency = p37:_combineTransparency(v39.BackgroundTransparency, v40)
				if p38:IsA("TextLabel") and v39.TextColor3 then
					p38.TextColor3 = p37:_multiplyColors(v39.TextColor3, v41)
					p38.TextTransparency = p37:_combineTransparency(v39.TextTransparency, v40)
				end
				if p38:IsA("ImageLabel") and v39.ImageColor3 then
					p38.ImageColor3 = p37:_multiplyColors(v39.ImageColor3, v41)
					p38.ImageTransparency = p37:_combineTransparency(v39.ImageTransparency, v40)
				end
			end
		else
			return
		end
	end,
	["_applyColorToColorSequence"] = function(p42, p43, p44)
		local v45 = p43.Keypoints
		local v46 = table.create(#v45)
		for v47, v48 in ipairs(v45) do
			local v49 = p42:_multiplyColors(v48.Value, p44)
			v46[v47] = ColorSequenceKeypoint.new(v48.Time, v49)
		end
		return ColorSequence.new(v46)
	end,
	["_applyTransparencyToNumberSequence"] = function(p50, p51, p52)
		local v53 = p51.Keypoints
		local v54 = table.create(#v53)
		for v55, v56 in ipairs(v53) do
			local v57 = p50:_combineTransparency(v56.Value, p52)
			v54[v55] = NumberSequenceKeypoint.new(v56.Time, v57, v56.Envelope)
		end
		return NumberSequence.new(v54)
	end,
	["_multiplyColors"] = function(_, p58, p59)
		return Color3.new(p58.R * p59.R, p58.G * p59.G, p58.B * p59.B)
	end,
	["_combineTransparency"] = function(_, p60, p61)
		return 1 - (1 - p60) * (1 - p61)
	end,
	["_refreshAllDescendants"] = function(p62)
		for _, v63 in ipairs(p62._descendants) do
			p62:_applyPropertiesToDescendant(v63)
		end
	end,
	["GetGroupColor3"] = function(p64)
		return p64._groupColor3Value.Value
	end,
	["SetGroupColor3"] = function(p65, p66)
		p65._groupColor3Value.Value = p66
	end,
	["GetGroupTransparency"] = function(p67)
		return p67._groupTransparencyValue.Value
	end,
	["SetGroupTransparency"] = function(p68, p69)
		p68._groupTransparencyValue.Value = p69
	end,
	["GetInstance"] = function(p70)
		return p70.Instance
	end,
	["SetParent"] = function(p71, p72)
		p71.Instance.Parent = p72
	end,
	["GetParent"] = function(p73)
		return p73.Instance.Parent
	end,
	["GetName"] = function(p74)
		return p74.Instance.Name
	end,
	["SetName"] = function(p75, p76)
		p75.Instance.Name = p76
	end,
	["GetSize"] = function(p77)
		return p77.Instance.Size
	end,
	["SetSize"] = function(p78, p79)
		p78.Instance.Size = p79
	end,
	["GetPosition"] = function(p80)
		return p80.Instance.Position
	end,
	["SetPosition"] = function(p81, p82)
		p81.Instance.Position = p82
	end,
	["GetAnchorPoint"] = function(p83)
		return p83.Instance.AnchorPoint
	end,
	["SetAnchorPoint"] = function(p84, p85)
		p84.Instance.AnchorPoint = p85
	end,
	["GetVisible"] = function(p86)
		return p86.Instance.Visible
	end,
	["SetVisible"] = function(p87, p88)
		p87.Instance.Visible = p88
	end,
	["GetZIndex"] = function(p89)
		return p89.Instance.ZIndex
	end,
	["SetZIndex"] = function(p90, p91)
		p90.Instance.ZIndex = p91
	end,
	["GetLayoutOrder"] = function(p92)
		return p92.Instance.LayoutOrder
	end,
	["SetLayoutOrder"] = function(p93, p94)
		p93.Instance.LayoutOrder = p94
	end,
	["Destroy"] = function(p95)
		if p95._descendantAddedConn then
			p95._descendantAddedConn:Disconnect()
			p95._descendantAddedConn = nil
		end
		if p95._descendantRemovedConn then
			p95._descendantRemovedConn:Disconnect()
			p95._descendantRemovedConn = nil
		end
		if p95._attributeChangedConn then
			p95._attributeChangedConn:Disconnect()
			p95._attributeChangedConn = nil
		end
		if p95._transparencyChangedConn then
			p95._transparencyChangedConn:Disconnect()
			p95._transparencyChangedConn = nil
		end
		if p95._colorChangedConn then
			p95._colorChangedConn:Disconnect()
			p95._colorChangedConn = nil
		end
		local v96 = p95.Instance
		for v97, v98 in pairs(p95._originalProps) do
			if v97 and v97:IsA("Instance") then
				if v97:IsA("UIStroke") then
					v97.Color = v98.Color
					v97.Transparency = v98.Transparency
				elseif v97:IsA("UIGradient") then
					v97.Color = v98.Color
					v97.Transparency = v98.Transparency
				else
					v97.BackgroundColor3 = v98.BackgroundColor3
					v97.BackgroundTransparency = v98.BackgroundTransparency
					if v97:IsA("TextLabel") and v98.TextColor3 then
						v97.TextColor3 = v98.TextColor3
						v97.TextTransparency = v98.TextTransparency
					end
					if v97:IsA("ImageLabel") and v98.ImageColor3 then
						v97.ImageColor3 = v98.ImageColor3
						v97.ImageTransparency = v98.ImageTransparency
					end
				end
			end
		end
		p95._descendants = {}
		p95._originalProps = {}
		if p95.Instance and p95.Instance ~= v96 then
			p95.Instance:Destroy()
		end
		p95.Instance = nil
	end
}
return v_u_99