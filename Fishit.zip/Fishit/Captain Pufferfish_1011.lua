-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 598,
		["Type"] = "Fish",
		["Name"] = "Captain Pufferfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://103089232636826",
		["Tier"] = 5
	},
	["SellPrice"] = 4800,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.92, 1.15),
		["Default"] = NumberRange.new(0.46, 0.74)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1