-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return function(p_u_1)
	local v_u_2 = p_u_1:getInstance("ClickRegion")
	local v_u_3 = Instance.new("CanvasGroup")
	v_u_3.Name = "Caption"
	v_u_3.AnchorPoint = Vector2.new(0.5, 0)
	v_u_3.BackgroundTransparency = 1
	v_u_3.BorderSizePixel = 0
	v_u_3.GroupTransparency = 1
	v_u_3.Position = UDim2.fromOffset(0, 0)
	v_u_3.Visible = true
	v_u_3.ZIndex = 30
	v_u_3.Parent = v_u_2
	local v_u_4 = Instance.new("Frame")
	v_u_4.Name = "Box"
	v_u_4.AutomaticSize = Enum.AutomaticSize.XY
	v_u_4.BackgroundColor3 = Color3.fromRGB(101, 102, 104)
	v_u_4.Position = UDim2.fromOffset(4, 7)
	v_u_4.ZIndex = 12
	v_u_4.Parent = v_u_3
	local v5 = Instance.new("TextLabel")
	v5.Name = "Header"
	v5.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	v5.Text = "Caption"
	v5.TextColor3 = Color3.fromRGB(255, 255, 255)
	v5.TextSize = 14
	v5.TextTruncate = Enum.TextTruncate.None
	v5.TextWrapped = false
	v5.TextXAlignment = Enum.TextXAlignment.Left
	v5.AutomaticSize = Enum.AutomaticSize.X
	v5.BackgroundTransparency = 1
	v5.LayoutOrder = 1
	v5.Size = UDim2.fromOffset(0, 16)
	v5.ZIndex = 18
	v5.Parent = v_u_4
	local v6 = Instance.new("UIListLayout")
	v6.Name = "Layout"
	v6.Padding = UDim.new(0, 8)
	v6.SortOrder = Enum.SortOrder.LayoutOrder
	v6.Parent = v_u_4
	local v7 = Instance.new("UICorner")
	v7.Name = "CaptionCorner"
	v7.Parent = v_u_4
	local v8 = Instance.new("UIPadding")
	v8.Name = "Padding"
	v8.PaddingBottom = UDim.new(0, 12)
	v8.PaddingLeft = UDim.new(0, 12)
	v8.PaddingRight = UDim.new(0, 12)
	v8.PaddingTop = UDim.new(0, 12)
	v8.Parent = v_u_4
	local v_u_9 = Instance.new("Frame")
	v_u_9.Name = "Hotkeys"
	v_u_9.AutomaticSize = Enum.AutomaticSize.Y
	v_u_9.BackgroundTransparency = 1
	v_u_9.LayoutOrder = 3
	v_u_9.Size = UDim2.fromScale(1, 0)
	v_u_9.Visible = false
	v_u_9.Parent = v_u_4
	local v10 = Instance.new("UIListLayout")
	v10.Name = "Layout1"
	v10.Padding = UDim.new(0, 6)
	v10.FillDirection = Enum.FillDirection.Vertical
	v10.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v10.HorizontalFlex = Enum.UIFlexAlignment.None
	v10.ItemLineAlignment = Enum.ItemLineAlignment.Automatic
	v10.VerticalFlex = Enum.UIFlexAlignment.None
	v10.SortOrder = Enum.SortOrder.LayoutOrder
	v10.Parent = v_u_9
	local v11 = Instance.new("ImageLabel")
	v11.Name = "Key1"
	v11.Image = "rbxasset://textures/ui/Controls/key_single.png"
	v11.ImageTransparency = 0.7
	v11.ScaleType = Enum.ScaleType.Slice
	v11.SliceCenter = Rect.new(5, 5, 23, 24)
	v11.AutomaticSize = Enum.AutomaticSize.X
	v11.BackgroundTransparency = 1
	v11.LayoutOrder = 1
	v11.Size = UDim2.fromOffset(0, 30)
	v11.ZIndex = 15
	v11.Parent = v_u_9
	local v12 = Instance.new("UIPadding")
	v12.Name = "Inset"
	v12.PaddingLeft = UDim.new(0, 8)
	v12.PaddingRight = UDim.new(0, 8)
	v12.Parent = v11
	local v_u_13 = Instance.new("TextLabel")
	v_u_13.AutoLocalize = false
	v_u_13.Name = "LabelContent"
	v_u_13.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	v_u_13.Text = ""
	v_u_13.TextColor3 = Color3.fromRGB(189, 190, 190)
	v_u_13.TextSize = 14
	v_u_13.AutomaticSize = Enum.AutomaticSize.X
	v_u_13.BackgroundTransparency = 1
	v_u_13.Position = UDim2.fromOffset(0, -1)
	v_u_13.Size = UDim2.fromScale(1, 1)
	v_u_13.ZIndex = 16
	v_u_13.Parent = v11
	local v_u_14 = Instance.new("ImageLabel")
	v_u_14.Name = "Caret"
	v_u_14.Image = "rbxasset://LuaPackages/Packages/_Index/UIBlox/UIBlox/AppImageAtlas/img_set_1x_1.png"
	v_u_14.ImageColor3 = Color3.fromRGB(101, 102, 104)
	v_u_14.ImageRectOffset = Vector2.new(260, 440)
	v_u_14.ImageRectSize = Vector2.new(16, 8)
	v_u_14.AnchorPoint = Vector2.new(0, 0.5)
	v_u_14.BackgroundTransparency = 1
	v_u_14.Position = UDim2.new(0, 0, 0, 4)
	v_u_14.Rotation = 180
	v_u_14.Size = UDim2.fromOffset(16, 8)
	v_u_14.ZIndex = 12
	v_u_14.Parent = v_u_3
	local v_u_15 = Instance.new("ImageLabel")
	v_u_15.Name = "DropShadow"
	v_u_15.Image = "rbxasset://LuaPackages/Packages/_Index/UIBlox/UIBlox/AppImageAtlas/img_set_1x_1.png"
	v_u_15.ImageColor3 = Color3.fromRGB(0, 0, 0)
	v_u_15.ImageRectOffset = Vector2.new(217, 486)
	v_u_15.ImageRectSize = Vector2.new(25, 25)
	v_u_15.ImageTransparency = 0.45
	v_u_15.ScaleType = Enum.ScaleType.Slice
	v_u_15.SliceCenter = Rect.new(12, 12, 13, 13)
	v_u_15.BackgroundTransparency = 1
	v_u_15.Position = UDim2.fromOffset(0, 5)
	v_u_15.Size = UDim2.new(1, 0, 0, 48)
	v_u_15.Parent = v_u_3
	v_u_4:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) v_u_15, (copy) v_u_4
		v_u_15.Size = UDim2.new(1, 0, 0, v_u_4.AbsoluteSize.Y + 8)
	end)
	local v16 = p_u_1.captionJanitor
	local _, v_u_17 = p_u_1:clipOutside(v_u_3)
	v_u_17.AutomaticSize = Enum.AutomaticSize.None
	v16:add(v_u_3:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) v_u_3, (copy) v_u_17
		local v18 = v_u_3.AbsoluteSize
		v_u_17.Size = UDim2.fromOffset(v18.X, v18.Y)
	end))
	local v19 = v_u_3.AbsoluteSize
	v_u_17.Size = UDim2.fromOffset(v19.X, v19.Y)
	local v_u_20 = false
	local v_u_21 = v_u_3.Box.Header
	local v_u_22 = game:GetService("UserInputService")
	local function v27(p23)
		-- upvalues: (copy) v_u_22, (copy) v_u_3, (copy) p_u_1, (copy) v_u_21, (copy) v_u_13, (copy) v_u_9
		local v24 = v_u_22.KeyboardEnabled
		local v25 = v_u_3:GetAttribute("CaptionText") or ""
		local v26 = v25 == "_hotkey_"
		if v24 or not v26 then
			v_u_21.Text = v25
			v_u_21.Visible = not v26
			if p23 then
				v_u_13.Text = p23.Name
				v_u_9.Visible = true
			end
			if not v24 then
				v_u_9.Visible = false
			end
		else
			p_u_1:setCaption()
		end
	end
	v_u_3:GetAttributeChangedSignal("CaptionText"):Connect(v27)
	local v28 = Enum.EasingStyle.Quad
	local v_u_29 = TweenInfo.new(0.2, v28, Enum.EasingDirection.In)
	local v_u_30 = TweenInfo.new(0.2, v28, Enum.EasingDirection.Out)
	local v_u_31 = game:GetService("TweenService")
	local v_u_32 = game:GetService("RunService")
	local function v_u_47(p33)
		-- upvalues: (ref) v_u_20, (copy) v_u_14, (copy) v_u_3, (copy) v_u_2, (copy) v_u_17, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_32
		if v_u_20 then
			if p33 == nil then
				p33 = v_u_20
			end
			local v34 = not p33
			if v34 == nil then
				v34 = v_u_20
			end
			local v35 = UDim2.new(0.5, 0, 1, v34 and 10 or 2)
			local v36
			if p33 == nil then
				v36 = v_u_20
			else
				v36 = p33
			end
			local v37 = UDim2.new(0.5, 0, 1, v36 and 10 or 2)
			if p33 then
				local v38 = v_u_14.Position.Y.Offset
				v_u_14.Position = UDim2.fromOffset(0, v38)
				v_u_3.AutomaticSize = Enum.AutomaticSize.XY
				v_u_3.Size = UDim2.fromOffset(32, 53)
			else
				local v39 = v_u_3.AbsoluteSize
				v_u_3.AutomaticSize = Enum.AutomaticSize.Y
				v_u_3.Size = UDim2.fromOffset(v39.X, v39.Y)
			end
			local v_u_40 = nil
			local function v44()
				-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_14, (ref) v_u_40
				local v41 = v_u_2.AbsolutePosition.X - v_u_3.AbsolutePosition.X + v_u_2.AbsoluteSize.X / 2 - v_u_14.AbsoluteSize.X / 2
				local v42 = v_u_14.Position.Y.Offset
				local v43 = UDim2.fromOffset(v41, v42)
				if v_u_40 ~= v41 then
					v_u_40 = v41
					v_u_14.Position = UDim2.fromOffset(0, v42)
					task.wait()
				end
				v_u_14.Position = v43
			end
			v_u_17.Position = v35
			v44()
			local v45 = v_u_31:Create(v_u_17, p33 and v_u_29 or v_u_30, {
				["Position"] = v37
			})
			local v_u_46 = v_u_32.Heartbeat:Connect(v44)
			v45:Play()
			v45.Completed:Once(function()
				-- upvalues: (copy) v_u_46
				v_u_46:Disconnect()
			end)
		end
	end
	v16:add(v_u_2:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) v_u_47
		v_u_47()
	end))
	v_u_47(false)
	v16:add(p_u_1.toggleKeyAdded:Connect(v27))
	for v48, _ in pairs(p_u_1.bindedToggleKeys) do
		local v49 = v_u_22.KeyboardEnabled
		local v50 = v_u_3:GetAttribute("CaptionText") or ""
		local v51 = v50 == "_hotkey_"
		if v49 or not v51 then
			v_u_21.Text = v50
			v_u_21.Visible = not v51
			if v48 then
				v_u_13.Text = v48.Name
				v_u_9.Visible = true
			end
			if not v49 then
				v_u_9.Visible = false
			end
		else
			p_u_1:setCaption()
		end
		break
	end
	v16:add(p_u_1.fakeToggleKeyChanged:Connect(v27))
	local v52 = p_u_1.fakeToggleKey
	if v52 then
		local v53 = v_u_22.KeyboardEnabled
		local v54 = v_u_3:GetAttribute("CaptionText") or ""
		local v55 = v54 == "_hotkey_"
		if v53 or not v55 then
			v_u_21.Text = v54
			v_u_21.Visible = not v55
			if v52 then
				v_u_13.Text = v52.Name
				v_u_9.Visible = true
			end
			if not v53 then
				v_u_9.Visible = false
			end
		else
			p_u_1:setCaption()
		end
	end
	local function v_u_61(p56)
		-- upvalues: (ref) v_u_20, (copy) p_u_1, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_3, (copy) v_u_47, (copy) v_u_22, (copy) v_u_21, (copy) v_u_9
		if v_u_20 == p56 then
			return
		else
			local v57 = p_u_1.joinedFrame
			if v57 and string.match(v57.Name, "Dropdown") then
				p56 = false
			end
			v_u_20 = p56
			v_u_31:Create(v_u_3, p56 and v_u_29 or v_u_30, {
				["GroupTransparency"] = p56 and 0 or 1
			}):Play()
			v_u_47()
			local v58 = v_u_22.KeyboardEnabled
			local v59 = v_u_3:GetAttribute("CaptionText") or ""
			local v60 = v59 == "_hotkey_"
			if v58 or not v60 then
				v_u_21.Text = v59
				v_u_21.Visible = not v60
				if not v58 then
					v_u_9.Visible = false
				end
			else
				p_u_1:setCaption()
			end
		end
	end
	local v_u_62 = require(p_u_1.iconModule)
	v16:add(p_u_1.stateChanged:Connect(function(p63)
		-- upvalues: (copy) v_u_62, (copy) p_u_1, (copy) v_u_61
		if p63 == "Viewing" then
			local v64 = v_u_62.captionLastClosedClock
			local v65 = (v64 and os.clock() - v64 or 999) < 0.3 and 0 or 0.5
			task.delay(v65, function()
				-- upvalues: (ref) p_u_1, (ref) v_u_61
				if p_u_1.activeState == "Viewing" then
					v_u_61(true)
				end
			end)
		else
			v_u_62.captionLastClosedClock = os.clock()
			v_u_61(false)
		end
	end))
	return v_u_3
end