-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 76,
		["Type"] = "Fishing Rods",
		["Name"] = "Carbon Rod",
		["Description"] = "",
		["Icon"] = "rbxassetid://124099699625912",
		["Tier"] = 1
	},
	["VisualClickPowerPercent"] = 0.04,
	["ClickPower"] = 0.071,
	["Resilience"] = 3.3,
	["Windup"] = NumberRange.new(3.5, 3.8499999999999996),
	["Price"] = 750,
	["MaxWeight"] = 20
}
local v2 = {
	["BaseLuck"] = 0.3,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1