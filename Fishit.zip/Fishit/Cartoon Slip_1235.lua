-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 8,
		["Type"] = "Emotes",
		["Name"] = "Cartoon Slip",
		["Description"] = "",
		["Icon"] = "rbxassetid://128556841180969",
		["Tier"] = 4
	},
	["AnimationId"] = "rbxassetid://126824750384152",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["PlaybackSpeed"] = 1,
	["Looped"] = false,
	["RequiresTarget"] = false,
	["MaxDistance"] = 15,
	["Effect"] = "CartoonSlip",
	["_moduleScript"] = script
}
return v1