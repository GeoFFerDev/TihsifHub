-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Limited Time Kohana Event!",
	["AssociatedTier"] = 1,
	["Expirable"] = false
}
local v4 = {}
local v5 = {
	["Goal"] = 20,
	["Id"] = 1,
	["Name"] = "Catch 20 fish in Kohana Volcano!",
	["Requirements"] = {
		["Location"] = "Kohana Volcano"
	},
	["Type"] = "Catch"
}
__set_list(v4, 1, {v5})
v3.Objectives = v4
v3.Reward = v2.potionReward("Luck I Potion", 2)
return v3