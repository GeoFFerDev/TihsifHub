-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Special event pass! Earn Doubloons for limited time",
	["AssociatedTier"] = 3,
	["Expirable"] = true,
	["ExpirationSettings"] = {
		["Type"] = "Duration",
		["Value"] = 14400
	}
}
local v4 = {}
local v5 = {
	["Goal"] = 3,
	["Id"] = 1,
	["Name"] = "Catch 3 Rare Fish",
	["Requirements"] = {
		["Tier"] = 3
	},
	["Type"] = "Catch"
}
__set_list(v4, 1, {v5})
v3.Objectives = v4
v3.Reward = v2.currencyReward(v2.BattlepassCurrency, 200)
return v3