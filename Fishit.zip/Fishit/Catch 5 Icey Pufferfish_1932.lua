-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Special event pass! Earn Doubloons for limited time",
	["AssociatedTier"] = 2,
	["Expirable"] = true,
	["ExpirationSettings"] = {
		["Type"] = "Duration",
		["Value"] = 14400
	}
}
local v4 = {}
local v5 = {
	["Goal"] = 5,
	["Id"] = 1,
	["Name"] = "Catch 5 Icey Pufferfish",
	["Requirements"] = {
		["Fish"] = "Icey Pufferfish"
	},
	["Type"] = "Catch",
	["AssociatedType"] = "Fish",
	["AssociatedItem"] = "Icey Pufferfish"
}
__set_list(v4, 1, {v5})
v3.Objectives = v4
v3.Reward = v2.currencyReward(v2.BattlepassCurrency, 600)
return v3