-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Special event pass! Earn Doubloons for limited time",
	["AssociatedTier"] = 6,
	["Expirable"] = true,
	["ExpirationSettings"] = {
		["Type"] = "Duration",
		["Value"] = 14400
	}
}
local v4 = {}
local v5 = {
	["Goal"] = 1,
	["Id"] = 1,
	["Name"] = "Catch a Mythic Fish",
	["Requirements"] = {
		["Tier"] = 6
	},
	["Type"] = "Catch"
}
__set_list(v4, 1, {v5})
v3.Objectives = v4
v3.Reward = v2.currencyReward(v2.BattlepassCurrency, 2000)
return v3