-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 183,
		["Type"] = "Fish",
		["Name"] = "Catfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://98970734819318",
		["Tier"] = 3
	},
	["SellPrice"] = 422,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(64.6, 131.6),
		["Default"] = NumberRange.new(33.3, 49.9)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1