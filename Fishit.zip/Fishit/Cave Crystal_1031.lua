-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 20221,
		["Type"] = "Gears",
		["Name"] = "Cave Crystal",
		["Description"] = "Equip and click to activate Crystalized mutation buff for 30 minutes!",
		["Icon"] = "rbxassetid://97893112975687",
		["Tier"] = 5
	},
	["UseQuantity"] = true,
	["TradeLocked"] = true,
	["Consumable"] = true,
	["_moduleScript"] = script
}
return v1