-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = require(v_u_1.Packages.Replion)
local v4 = require(v_u_1.Packages.Net)
local v_u_5 = require(v_u_1.Packages.spr)
local v_u_6 = require(v_u_1.Shared.Soundbook)
local v_u_7 = require(v_u_1.Controllers.TextNotificationController)
local v_u_8 = v4:RemoteFunction("ConsumeCaveCrystal")
return function()
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_1, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7
	if v_u_3.Client:GetReplion("Data") then
		local v9, v10 = v_u_8:InvokeServer()
		if v9 then
			local v11 = game:GetService("Players")
			local v12 = game:GetService("Debris")
			local v13 = v_u_1:WaitForChild("VFX")
			local v14 = v11.LocalPlayer.Character
			if v14 then
				local v15 = v14:FindFirstChild("HumanoidRootPart")
				local v16 = v15 and v13:FindFirstChild("CrystalfallActivation")
				if v16 then
					local v17 = v16:Clone()
					v17.Parent = v15
					if v17:IsA("BasePart") then
						v17.CFrame = v15.CFrame
						v17.Anchored = false
						v17.CanCollide = false
						v17.Massless = true
						local v18 = Instance.new("WeldConstraint")
						v18.Part0 = v15
						v18.Part1 = v17
						v18.Parent = v17
					end
					for _, v19 in v17:GetDescendants() do
						if v19:IsA("ParticleEmitter") then
							local v20 = v19:GetAttribute("EmitCount")
							if not v20 then
								local v21 = v19.Name
								v20 = tonumber(v21) or 10
							end
							v19:Emit(v20)
						end
					end
					v12:AddItem(v17, 3)
				end
			end
			v_u_6.Sounds.RadarToggle:Play().PlaybackSpeed = 1.2
			v_u_5.stop(v_u_2)
			v_u_2.ExposureCompensation = 0.5
			v_u_5.target(v_u_2, 1, 2, {
				["ExposureCompensation"] = 0
			})
			local v22 = v_u_2:FindFirstChildWhichIsA("ColorCorrectionEffect")
			if v22 then
				v_u_5.stop(v22)
				v22.TintColor = Color3.fromRGB(120, 200, 255)
				v22.Brightness = 0.3
				v_u_5.target(v22, 1, 1, {
					["TintColor"] = Color3.fromRGB(255, 255, 255),
					["Brightness"] = 0.04
				})
			end
			v_u_7:DeliverNotification({
				["Type"] = "Text",
				["Text"] = "Crystalized buff activated!",
				["TextColor"] = {
					["R"] = 120,
					["G"] = 200,
					["B"] = 255
				}
			})
		else
			v_u_7:DeliverNotification({
				["Type"] = "Text",
				["Text"] = v10 or "Failed to activate!",
				["TextColor"] = {
					["R"] = 255,
					["G"] = 100,
					["B"] = 100
				}
			})
		end
	else
		return
	end
end