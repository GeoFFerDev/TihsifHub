-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 14,
		["Type"] = "Potions",
		["Name"] = "Cave Crystal",
		["Description"] = "Crystalized mutation is obtainable!",
		["Icon"] = "rbxassetid://97893112975687",
		["Tier"] = 5
	},
	["Duration"] = 1800,
	["Modifiers"] = {
		["CrystalizedMutation"] = 0.5
	},
	["VFX"] = "Mutation Potion",
	["_moduleScript"] = script
}
return v1