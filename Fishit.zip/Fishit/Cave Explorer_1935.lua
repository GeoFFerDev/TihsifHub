-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Collect a bunch of fish from this limited cave",
	["AssociatedTier"] = 3
}
local v4 = {}
local v5 = {
	["Goal"] = 300,
	["Id"] = 1,
	["Name"] = "Catch 300 fish at Christmas Cave",
	["Type"] = "Catch",
	["Requirements"] = {
		["Location"] = "Christmas Cave"
	},
	["TrackQuestCFrame"] = CFrame.new(Vector3.new(1154.313, 19.267, 1552.781))
}
__set_list(v4, 1, {v5})
v3.Objectives = v4
v3.Reward = v2.fishingRodReward("Arctic Explorer")
return v3