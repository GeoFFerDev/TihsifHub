-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 352,
		["Type"] = "Fish",
		["Name"] = "Cavern Dweller",
		["Description"] = "",
		["Icon"] = "rbxassetid://110427632040144",
		["Tier"] = 6
	},
	["SellPrice"] = 85000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3965, 4852),
		["Default"] = NumberRange.new(2934, 3371)
	},
	["Probability"] = {
		["Chance"] = 0.00001
	},
	["_moduleScript"] = script
}
return v1