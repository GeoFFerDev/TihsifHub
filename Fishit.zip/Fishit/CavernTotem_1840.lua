-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
game:GetService("Players")
game:GetService("RunService")
local v2 = require(v1.Packages.Net)
local v3 = require(v1.Packages.Replion)
local v_u_4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Packages.Trove)
local v_u_6 = require(v1.Shared.PlayerStatsUtility)
local v_u_7 = require(v1.Shared.ItemUtility)
local v_u_8 = require(v1.Shared.Soundbook)
local v_u_9 = require(v1.Controllers.TextNotificationController)
local v_u_10 = require(v1:WaitForChild("Packages"):WaitForChild("spr"))
local v_u_11 = v3.Client:WaitReplion("Data")
local v_u_12 = v2:RemoteEvent("PlaceCavernTotemItem")
local v_u_13 = {
	["Builderman Guppy"] = Color3.fromRGB(99, 165, 80),
	["Shedletsky Guppy"] = Color3.fromRGB(165, 138, 95),
	["Brighteyes Guppy"] = Color3.fromRGB(170, 72, 72),
	["Guest Guppy"] = Color3.fromRGB(52, 97, 165)
}
local function v_u_21(p14)
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_13, (copy) v_u_8
	if v_u_11 then
		local v15 = p14:GetAttribute("Type")
		if v_u_11:GetExpect("IronCavernTotems")[v15] then
			local v16 = p14.PrimaryPart
			local v17 = p14:WaitForChild("Beam Thing", 5)
			local v18 = v17:WaitForChild("NeonPart", 5)
			local v19 = p14:WaitForChild("Movement", 5)
			if v16 then
				if v17 then
					if v18 then
						if v19 then
							v_u_10.target(v19, 1, 3, {
								["Pivot"] = v19:GetAttribute("TargetCF")
							})
							v_u_10.target(v16, 0.5, 1, {
								["Color"] = v_u_13[v15]
							})
							v_u_10.target(v18, 0.5, 1, {
								["Color"] = v_u_13[v15]
							})
							for _, v20 in pairs(v17:GetDescendants()) do
								if v20:IsA("Beam") then
									v20.Enabled = true
								end
							end
							if v16 and (workspace.CurrentCamera.CFrame.Position - v16.Position).Magnitude <= 500 then
								v_u_8.Sounds.TotemActivated:Play()
							end
						end
					else
						return
					end
				else
					return
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
v3.Client:AwaitReplion("Data", function(p_u_22)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_13, (copy) v_u_21, (copy) v_u_7, (copy) v_u_6, (copy) v_u_9, (copy) v_u_12
	v_u_4.observeTag("CavernTotem", function(p_u_23)
		-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_21, (copy) p_u_22, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_12
		local v_u_24 = v_u_5.new()
		local v_u_25 = p_u_23.Parent.Parent
		local v_u_26 = v_u_25:GetAttribute("Type")
		if v_u_26 then
			local v27 = v_u_25:WaitForChild("Beam Thing", 5)
			if v27 then
				local v28 = v27:WaitForChild("NeonPart", 5)
				if v28 then
					for _, v29 in pairs(v27:GetDescendants()) do
						if v29:IsA("Beam") then
							v29.Enabled = false
						end
					end
					v_u_13[v_u_26] = v28.Color
					p_u_23.Color = Color3.fromRGB(0, 0, 0)
					v28.Color = Color3.fromRGB(0, 0, 0)
					local function v31()
						-- upvalues: (copy) p_u_23, (ref) v_u_21, (copy) v_u_25, (ref) v_u_24
						local v30 = p_u_23:FindFirstChild("ProximityPrompt")
						if v30 then
							v30:Destroy()
						end
						v_u_21(v_u_25)
						if v_u_24 then
							v_u_24:Destroy()
							v_u_24 = nil
						end
					end
					if p_u_22:GetExpect({ "IronCavernTotems" })[v_u_26] or false then
						return v31()
					end
					local v32 = p_u_23:FindFirstChild("ProximityPrompt")
					if not v32 then
						v32 = Instance.new("ProximityPrompt")
						v32.ObjectText = ""
						v32.ActionText = "Place Item"
						v32.ClickablePrompt = true
						v32.RequiresLineOfSight = false
						v32.MaxActivationDistance = 15
						v32.GamepadKeyCode = Enum.KeyCode.DPadDown
						v32.Style = Enum.ProximityPromptStyle.Custom
						v32.Parent = p_u_23
					end
					v_u_24:Add(v32.Triggered:Connect(function()
						-- upvalues: (ref) v_u_7, (copy) v_u_26, (ref) v_u_6, (ref) p_u_22, (ref) v_u_9, (ref) v_u_12
						local v_u_33 = v_u_7.GetItemDataFromItemType("Items", v_u_26)
						if v_u_33 then
							if v_u_6:GetItemFromInventory(p_u_22, function(p34)
								-- upvalues: (copy) v_u_33
								return p34.Id == v_u_33.Data.Id
							end) then
								v_u_12:FireServer(v_u_26)
							else
								local v35 = v_u_9
								local v36 = {
									["Type"] = "Text",
									["Text"] = ("You need a %*!"):format(v_u_26),
									["TextColor"] = {
										["R"] = 255,
										["G"] = 0,
										["B"] = 0
									},
									["CustomDuration"] = 3
								}
								v35:DeliverNotification(v36)
							end
						else
							return
						end
					end))
					p_u_22:OnChange("IronCavernTotems", function()
						-- upvalues: (ref) p_u_22, (copy) v_u_26, (ref) v_u_7, (copy) p_u_23, (ref) v_u_21, (copy) v_u_25, (ref) v_u_24
						if p_u_22:GetExpect({ "IronCavernTotems" })[v_u_26] or false then
							if v_u_7.GetItemDataFromItemType("Items", v_u_26) then
								local v37 = p_u_23:FindFirstChild("ProximityPrompt")
								if v37 then
									v37:Destroy()
								end
								v_u_21(v_u_25)
								if v_u_24 then
									v_u_24:Destroy()
									v_u_24 = nil
								end
							end
						else
							return
						end
					end)
					return function()
						-- upvalues: (ref) v_u_24
						if v_u_24 then
							v_u_24:Destroy()
							v_u_24 = nil
						end
					end
				end
			end
		else
			return
		end
	end)
end)
return {}