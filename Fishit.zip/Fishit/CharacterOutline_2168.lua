-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = require(v1.Packages.Trove)
return {
	["Init"] = function(_)
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		local v4 = v_u_2.LocalPlayer.Character
		if v4 then
			local v_u_5 = v_u_3.new()
			v_u_5:Add(v4.ChildRemoved:Connect(function(p6)
				if p6:IsA("Model") then
					local _ = p6.Name == "!!!EQUIPPED_TOOL!!!"
				end
			end))
			v_u_5:Add(v4.ChildAdded:Connect(function(p7)
				if p7:IsA("Model") and (p7.Name == "!!!EQUIPPED_TOOL!!!" and not p7:HasTag("FishingRod")) then
					local v8 = Instance.new("Highlight")
					v8.DepthMode = Enum.HighlightDepthMode.Occluded
					v8.FillColor = Color3.fromRGB(0, 0, 0)
					v8.OutlineColor = Color3.fromRGB(0, 0, 0)
					v8.FillTransparency = 1
					v8.OutlineTransparency = 0.7
					v8.Parent = p7
				end
			end))
			v4.Destroying:Once(function()
				-- upvalues: (copy) v_u_5
				v_u_5:Destroy()
			end)
		end
	end
}