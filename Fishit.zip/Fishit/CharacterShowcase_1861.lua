-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("RunService")
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
require(v_u_1.Packages.Replion)
local v3 = require(v_u_1.Packages.Observers)
local v_u_4 = require(v_u_1.Packages.Promise)
local v_u_5 = require(v_u_1.Packages.Trove)
require(v_u_1.Packages.Thread)
require(v_u_1.Shared.Constants)
require(v_u_1.Modules.Animations)
local v_u_6 = {}
local v7 = {
	["CycleAnimations"] = {
		{
			["Name"] = "Idle",
			["ID"] = require(v_u_1.Boats["Magma Surfboard"]).Animations.Idle
		},
		{
			["Name"] = "SlowSurfing",
			["ID"] = require(v_u_1.Boats["Magma Surfboard"]).Animations.SlowSurfing
		},
		{
			["Name"] = "Surfing",
			["ID"] = require(v_u_1.Boats["Magma Surfboard"]).Animations.Surfing
		}
	},
	["RigType"] = "LimitedRig3"
}
v_u_6["Boat Stand"] = v7
local v_u_8 = {}
local v_u_11 = v_u_4.promisify(function(p9)
	-- upvalues: (copy) v_u_2
	local v10 = p9.Character
	if v10 then
		v10 = v10:FindFirstChildWhichIsA("Humanoid")
	end
	if v10 then
		return v10:GetAppliedDescription()
	else
		return v_u_2:GetHumanoidDescriptionFromUserId(p9.UserId)
	end
end)
local function v_u_18(p12, p_u_13, p14, p_u_15)
	-- upvalues: (copy) v_u_8
	if not v_u_8[p12] then
		v_u_8[p12] = {}
	end
	local v16, v17 = pcall(function()
		-- upvalues: (copy) p_u_13, (copy) p_u_15
		return p_u_13:LoadAnimation(p_u_15)
	end)
	if v16 then
		v17.Priority = Enum.AnimationPriority.Action4
		v17.Looped = true
		v_u_8[p12][p14] = v17
		return v17
	end
end
local function v_u_27(p19, p20, p21)
	-- upvalues: (copy) v_u_8, (copy) v_u_18
	if v_u_8[p19] == nil then
		v_u_8[p19] = {}
	end
	for _, v22 in ipairs(p21) do
		local v23 = v_u_8[p19]
		if v23 then
			local v24 = v23[v22.Name]
			if not v24 then
				local v25 = Instance.new("Animation")
				v25.AnimationId = v22.ID
				v24 = v_u_18(p19, p20, v22.Name, v25)
			end
			if v24 then
				for _, v26 in pairs(v23) do
					v26:Stop()
				end
				v24:Play()
				task.wait(v24.Length)
			end
			task.wait(3)
		end
	end
end
local function v_u_37(p28)
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_4, (copy) v_u_11, (copy) v_u_2, (copy) v_u_5, (copy) v_u_27
	local v_u_29 = v_u_6[p28.Name]
	if v_u_29 then
		local v30 = p28:WaitForChild("CharacterSpawnPart", 100000)
		local v31 = v_u_1.Assets:FindFirstChild(v_u_29.RigType)
		if v31 then
			local v_u_32 = v31:Clone()
			v_u_32:WaitForChild("Head")
			v_u_32:WaitForChild("HumanoidRootPart")
			local v_u_33 = v_u_32.Humanoid
			local v_u_34 = v_u_33.Animator
			v_u_32:PivotTo(v30.CFrame)
			v_u_32.Parent = workspace
			v_u_4.try(v_u_11, v_u_2.LocalPlayer):andThen(function(p35)
				-- upvalues: (copy) v_u_33
				v_u_33:ApplyDescription(p35)
			end):catch(warn):await()
			local v_u_36 = v_u_5.new()
			v_u_36:Add(task.spawn(function()
				-- upvalues: (ref) v_u_27, (copy) v_u_32, (copy) v_u_34, (copy) v_u_29
				while true do
					task.wait()
					v_u_27(v_u_32, v_u_34, v_u_29.CycleAnimations)
				end
			end))
			return function()
				-- upvalues: (copy) v_u_36
				v_u_36:Destroy()
			end
		end
	end
end
v3.observeTag("CharacterShowcase", function(p38)
	-- upvalues: (copy) v_u_37
	return v_u_37(p38)
end)
return {}