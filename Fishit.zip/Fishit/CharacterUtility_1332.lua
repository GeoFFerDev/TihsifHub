-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.ReplicatedStorage
local v_u_2 = require(v1.Packages.Trove)
local v3 = require(v1.Shared.PlayerEvents)
local v_u_4 = {}
local v_u_5 = {}
local v_u_22 = {
	["LockPlayer"] = function(_, p6, p7)
		-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_22
		local v8 = v_u_4[p6]
		if v8 then
			if not v_u_5[p6][p7] then
				local v9 = v8:Extend()
				v_u_5[p6][p7] = v9
				v9:Add(p6.CharacterAdded:Connect(function(p10)
					-- upvalues: (ref) v_u_22
					task.wait(0)
					v_u_22:_removeWalkSpeed(p10)
				end))
				local v11 = p6.Character
				if v11 then
					v_u_22:_removeWalkSpeed(v11)
				end
			end
		else
			return
		end
	end,
	["UnlockPlayer"] = function(_, p12, p13)
		-- upvalues: (copy) v_u_5, (copy) v_u_22
		local v14 = v_u_5[p12]
		if v14 then
			local v15 = v14[p13]
			if v15 then
				v15:Destroy()
				v_u_5[p12][p13] = nil
				if next(v_u_5[p12]) == nil then
					v_u_22:_restoreWalkSpeed(p12)
				end
			end
		else
			return
		end
	end,
	["_removeWalkSpeed"] = function(_, p16)
		p16:FindFirstChild("HumanoidRootPart")
		local v17 = p16:FindFirstChildWhichIsA("Humanoid")
		if v17 then
			v17:SetAttribute("PreviousWalkingSpeed", v17.WalkSpeed)
			v17:SetAttribute("WalkingSpeedLocked", true)
			v17.WalkSpeed = 4
		end
	end,
	["_restoreWalkSpeed"] = function(_, p18)
		local v19 = p18.Character
		if v19 then
			local v20 = v19:FindFirstChildWhichIsA("Humanoid")
			if v20 then
				v19:FindFirstChild("HumanoidRootPart")
				local v21 = v20:GetAttribute("PreviousWalkingSpeed")
				if v21 then
					v20.WalkSpeed = v21
				end
				v20:SetAttribute("WalkingSpeedLocked", nil)
			end
		else
			return
		end
	end
}
v3:PlayerAdded(function(p23)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_5
	v_u_4[p23] = v_u_2.new()
	v_u_5[p23] = {}
end)
v3:PlayerRemoving(function(p24)
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v25 = v_u_5[p24]
	if v25 then
		for v26, v27 in v25 do
			v27:Destroy()
			v_u_5[p24][v26] = nil
		end
		v_u_5[p24] = nil
	end
	local v28 = v_u_4[p24]
	if v28 then
		v28:Destroy()
		v_u_4[p24] = nil
	end
end)
return v_u_22