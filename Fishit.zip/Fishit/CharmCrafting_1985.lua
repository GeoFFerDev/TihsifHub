-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v3 = require(v1.Packages.Net)
local v4 = require(v1.Packages.Trove)
local v5 = require(v1.Packages.Signal)
local v_u_6 = require(v1.Shared.ItemUtility)
local v_u_7 = require(v1.Shared.TierUtility)
local v_u_8 = require(v1.Shared.PlayerStatsUtility)
local v_u_9 = require(v1.Shared.Soundbook)
local v_u_10 = require(v1.Modules.GuiControl)
local v_u_11 = v2.LocalPlayer
v_u_11.PlayerGui:WaitForChild("Crafting")
local v_u_12 = v3:RemoteFunction("StartCrafting")
local v_u_13 = v3:RemoteFunction("CancelCrafting")
local v_u_14 = v3:RemoteFunction("ConfirmCrafting")
local v15 = script.Parent.Parent:WaitForChild("Styles"):WaitForChild("CharmCrafting")
local v_u_16 = v15.Frame.ActiveTile.Fish.Scroll.Tile
v_u_16.Parent = nil
local v_u_17 = v15.Frame.ActiveTile.Info.Frame.Sample
v_u_17.Parent = nil
local v_u_18 = false
local v_u_19 = v5.new()
local v_u_20 = false
local v_u_21 = v4.new()
local v_u_22 = nil
local function v_u_58(p23, p24, p25)
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_17, (copy) v_u_21, (copy) v_u_16
	local v26 = v_u_6.GetItemDataFromItemType(p24, p25)
	if v26 then
		local v27 = p23:WaitForChild("Frame", 5)
		if v27 then
			local v28 = v27.ActiveTile.Info
			local v29 = v27.ActiveTile.Perk
			local v30 = v27.ActiveTile.Fish
			local _ = v26.Data.Id
			local v31 = v26.Data.Name
			local v32 = v26.Uses or 0
			local v33 = v26.Level or 0
			local v34 = v26.Modifiers.BaseLuck or 0
			local v35
			if v26.Probabiltity then
				v35 = v_u_7:GetTierFromRarity(v26.Probability.Chance)
			else
				v35 = v_u_7:GetTier(v26.Data.Tier)
			end
			local v36 = v28.Display
			v27.Label.Text = v26.Data.Name
			v27.Box.UIStroke.UIGradient.Color = v35.TierColor
			v36.UIStroke.UIGradient.Color = v35.TierColor
			v36.Inner.Glow.UIGradient.Color = v35.TierColor
			v36.Inner.ItemName.Text = v31
			v36.Inner.Vector.Image = v26.Data.Icon or ""
			if v35.Tier >= 5 then
				v27.Box.UIStroke.UIGradient:AddTag("AnimateTier")
				v36.UIStroke.UIGradient:AddTag("AnimateTier")
				v36.Inner.Glow.UIGradient:AddTag("AnimateTier")
			end
			v28.Frame.Level.Counter.Text = ("%d"):format(v33)
			v28.Frame.Uses.Counter.Text = ("%d"):format(v32)
			local v37 = v28.Frame.Luck.Counter
			local v38 = v34 * 100
			v37.Text = ("%*%%"):format((math.round(v38)))
			v28.Frame.Luck.Visible = v34 > 0
			if v26.Modifiers then
				for v39, v40 in v26.Modifiers do
					if v39 ~= "BaseLuck" then
						local v41, v42 = v_u_8:GetModifierDisplayName(v39)
						if v41 then
							local v43
							if v41:find("Multi") or v39:find("Multiplier") then
								local v44 = (1 + v40) * 10
								v43 = ("x%*"):format(math.round(v44) / 10)
							else
								local v45 = v40 * 100
								v43 = ("%*%%"):format((math.round(v45)))
							end
							local v46 = v_u_17:Clone()
							v46.Label.Text = ("%*:"):format(v41)
							v46.Counter.Text = v43
							v46.Counter.UIGradient.Color = ColorSequence.new(v42)
							local v47 = v40 * 100
							v46.LayoutOrder = math.abs(v47)
							v46.Parent = v28.Frame
							v_u_21:Add(v46)
						end
					end
				end
			end
			local v48 = false
			if v26.FishModifiers then
				for v49, v50 in v26.FishModifiers do
					local v51 = v_u_6.GetItemDataFromItemType("Fish", v49)
					if v51 then
						local v52 = string.len(v49)
						local v53
						if v51.Probabiltity then
							v52 = 1 / v51.Probability.Chance
							v53 = v_u_7:GetTierFromRarity(v51.Probability.Chance)
						else
							v53 = v_u_7:GetTier(v51.Data.Tier)
						end
						local v54 = v_u_16:Clone()
						local v55 = (v50 + 1) * 10
						local v56 = math.floor(v55) / 10
						v54.Inner.Top.Counter.Text = ("x%* Chance"):format(v56)
						v54.Inner.Glow.UIGradient.Color = v53.TierColor
						v54.UIStroke.UIGradient.Color = v53.TierColor
						v54.Inner.Configuration.ItemName.Text = v51.Data.Name
						v54.Inner.Vector.Image = v51.Data.Icon or ""
						v54.LayoutOrder = v52
						v54.Parent = v27.ActiveTile.Fish.Scroll
						v_u_21:Add(v54)
						v48 = true
					end
				end
			end
			local v57
			if v26.Perks then
				for _, _ in v26.Perks do

				end
				v57 = true
			else
				v57 = false
			end
			v29.Visible = v57
			v30.Visible = v48
		end
	else
		return
	end
end
local function v75(p59, p60, p_u_61, p_u_62)
	-- upvalues: (ref) v_u_22, (ref) v_u_20, (ref) v_u_18, (copy) v_u_21, (copy) v_u_10, (copy) v_u_11, (copy) v_u_13, (copy) v_u_19, (copy) v_u_14, (copy) v_u_9, (copy) v_u_12, (copy) v_u_58
	v_u_22 = p59
	if not v_u_20 then
		v_u_18 = false
		v_u_20 = true
		v_u_21:Clean()
		local v63 = p59.Frame.Close
		local v_u_64 = p59.Frame.Craft
		local v_u_65 = v_u_64.Counter
		local v_u_66 = v_u_10:Hook("Hold Button", v63)
		local v67 = v_u_10:Hook("Hold Button", v_u_64)
		v_u_66.Clicked:Connect(function()
			-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_18, (ref) v_u_19
			v_u_11:SetAttribute("InstantCraftReroll", nil)
			v_u_13:InvokeServer()
			v_u_18 = false
			v_u_19:Fire(false)
		end)
		v67.Clicked:Connect(function()
			-- upvalues: (ref) v_u_18, (ref) v_u_14, (ref) v_u_9, (ref) v_u_19, (ref) v_u_12, (copy) p_u_61
			if v_u_18 then
				if v_u_14:InvokeServer() then
					v_u_9.Sounds.CraftSound:Play()
					v_u_18 = false
					v_u_19:Fire(false)
				end
			elseif v_u_12:InvokeServer(p_u_61) then
				v_u_18 = true
				v_u_19:Fire(true)
			end
		end)
		local function v68()
			-- upvalues: (ref) v_u_11, (copy) v_u_64
			if v_u_11:GetAttribute("InstantCraftReroll") then
				v_u_64.Visible = false
			else
				v_u_64.Visible = true
			end
		end
		local function v71(p69)
			-- upvalues: (ref) v_u_18, (ref) v_u_10, (copy) p_u_62, (copy) v_u_65, (ref) v_u_11, (copy) v_u_64
			local v70 = v_u_18
			if not (p69 or v70) then
				v_u_10:Unlock()
				p_u_62()
			end
			if v_u_65 and v_u_65.Parent then
				v_u_65.Text = v70 and "CONFIRM" or "START CRAFTING"
			end
			if v_u_11:GetAttribute("InstantCraftReroll") then
				v_u_64.Visible = false
			else
				v_u_64.Visible = true
			end
		end
		local v_u_72 = v_u_11:GetAttributeChangedSignal("InstantCraftReroll"):Connect(v68)
		if v_u_11:GetAttribute("InstantCraftReroll") then
			v_u_64.Visible = false
		else
			v_u_64.Visible = true
		end
		local v_u_73 = v_u_19:Connect(v71)
		local v74 = v_u_18
		if v_u_65 and v_u_65.Parent then
			v_u_65.Text = v74 and "CONFIRM" or "START CRAFTING"
		end
		if v_u_11:GetAttribute("InstantCraftReroll") then
			v_u_64.Visible = false
		else
			v_u_64.Visible = true
		end
		v_u_21:Add(function()
			-- upvalues: (copy) v_u_66, (ref) v_u_72, (ref) v_u_73
			v_u_66:Destroy()
			v_u_72:Disconnect()
			v_u_73:Disconnect()
		end)
		v_u_58(p59, p60, p_u_61)
		v_u_20 = false
	end
end
v_u_10.GuiFocusedSignal:Connect(function(_)
	-- upvalues: (copy) v_u_11, (copy) v_u_13, (ref) v_u_18, (copy) v_u_19
	task.wait(0.1)
	v_u_11:SetAttribute("InstantCraftReroll", nil)
	v_u_13:InvokeServer()
	v_u_18 = false
	v_u_19:Fire(false)
end)
return v75