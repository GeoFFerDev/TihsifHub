-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Packages.Trove)
local v_u_3 = require(v1.Shared.ItemUtility)
local v_u_4 = require(v1.Shared.TierUtility)
local v_u_5 = require(v1.Shared.PlayerStatsUtility)
require(v1.Modules.ColorUtility)
local v_u_6 = require(script.Parent.Parent.TileInteraction)
local v_u_7 = {}
v_u_7.__index = v_u_7
function v_u_7.new(p8, p9, p10, p11, p12, p13, p14, p15, p16)
	-- upvalues: (copy) v_u_7, (copy) v_u_2
	local v17 = v_u_7
	local v18 = setmetatable({}, v17)
	v18._tileTemplate = p8
	v18._scrollFrame = p9
	v18._focusPanel = p10
	v18._infoFrame = p11
	v18._sampleFrame = p12
	v18._fishTileTemplate = p13
	v18._fishScrollFrame = p14
	v18._perkTileTemplate = p15
	v18._perkFrame = p16
	v18._tiles = {}
	v18._focusTrove = v_u_2.new()
	v18._selectedCharmId = nil
	return v18
end
function v_u_7.GetCacheKey(_, p19)
	-- upvalues: (copy) v_u_3
	local v20 = v_u_3.GetItemDataFromItemType("Charms", p19.Id)
	return v20 and v20.Data.Id or 0
end
function v_u_7.Create(p_u_21, p22, p_u_23)
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v24 = v_u_3.GetItemDataFromItemType("Charms", p22.Id)
	if not v24 then
		return nil
	end
	local v_u_25 = v24.Data.Name
	local v_u_26 = v24.Data.Id
	local v27 = p_u_21._tiles[v_u_26]
	if v27 then
		return v27
	end
	local v28 = p_u_23.GuiControl
	local v_u_29 = p_u_23.PlayerReplion
	local v_u_30 = p_u_21._tileTemplate:Clone()
	local v31
	if v24.Modifiers and v24.Modifiers.BaseLuck then
		v31 = v24.Modifiers.BaseLuck * 10000
	else
		v31 = string.len(v_u_25)
	end
	local v32 = v_u_4:GetTier(v24.Data.Tier)
	if v32 then
		local v33 = v32.TierColor.Keypoints[1].Value
		v_u_30.Label.TextColor3 = v33
		v_u_30.UIStroke.Color = v33
		v_u_30.BG.Glow.UIGradient.Color = v32.TierColor
	end
	v_u_30.Label.Text = v_u_25 or ""
	v_u_30.BG.VectorBig.Image = v24.Data.Icon or ""
	local v34 = v28:Hook("Hold Button", v_u_30)
	v34.Clicked:Connect(function()
		-- upvalues: (copy) p_u_21, (copy) v_u_25, (copy) v_u_26, (copy) p_u_23
		p_u_21:_selectCharm(v_u_25, v_u_26, p_u_23)
	end)
	v34.Cleaner:Add(v_u_29:OnChange({ "EquippedCharmId" }, function()
		-- upvalues: (copy) v_u_29, (copy) v_u_30, (copy) v_u_26
		local v35 = v_u_29:GetExpect({ "EquippedCharmId" })
		v_u_30.UIStroke.Enabled = v35 == v_u_26
	end))
	local v36 = v_u_29:GetExpect({ "EquippedCharmId" })
	v_u_30.UIStroke.Enabled = v36 == v_u_26
	v_u_30.LayoutOrder = v31
	v_u_30.Parent = p_u_21._scrollFrame
	p_u_21._tiles[v_u_26] = v_u_30
	return v_u_30
end
function v_u_7._selectCharm(p37, p38, p_u_39, p40)
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_6
	local v41 = p40.PlayerReplion
	local v42
	if (v41:GetExpect("CharmModifiers")[p38] or 0) > 0 then
		v42 = {
			["Id"] = p_u_39,
			["Quantity"] = 1
		}
	else
		v42 = v_u_5:GetItemFromInventory(v41, function(p43)
			-- upvalues: (copy) p_u_39
			return p43.Id == p_u_39
		end, "Charms")
	end
	if v42 then
		p37:FocusCharm(v42, p40)
		local v44 = v_u_3.GetItemDataFromItemType("Charms", p38)
		local v45 = v_u_6
		if v44 then
			v44 = v44.Level
		end
		v45:EquipCharm(p38, v44)
	end
end
function v_u_7.FocusCharm(p46, p47, p48)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	p46:DestroyFocus()
	local v49 = v_u_3.GetItemDataFromItemType("Charms", p47.Id)
	if v49 then
		local v_u_50 = p48.PlayerReplion
		local v_u_51 = v49.Data.Id
		local v_u_52 = v49.Data.Name
		local v_u_53 = v49.Uses or 0
		local v54 = v49.Level or 0
		local v55 = v49.Modifiers and (v49.Modifiers.BaseLuck or 0) or 0
		local v56
		if v49.Probability then
			v56 = v_u_4:GetTierFromRarity(v49.Probability.Chance)
		else
			v56 = v_u_4:GetTier(v49.Data.Tier)
		end
		local v_u_57 = p46._infoFrame.Display
		v_u_57.UIStroke.UIGradient.Color = v56.TierColor
		v_u_57.Inner.Glow.UIGradient.Color = v56.TierColor
		v_u_57.Inner.ItemName.Text = v_u_52
		v_u_57.Inner.Vector.Image = v49.Data.Icon or ""
		local function v62()
			-- upvalues: (copy) v_u_50, (copy) v_u_52, (ref) v_u_5, (copy) v_u_51, (copy) v_u_57, (copy) v_u_53
			v_u_50:GetExpect("EquippedCharmId")
			local v58 = v_u_50:GetExpect("CharmModifiers")[v_u_52]
			local v60 = v_u_5:GetItemFromInventory(v_u_50, function(p59)
				-- upvalues: (ref) v_u_51
				return p59.Id == v_u_51
			end, "Charms")
			local v61 = v60 and v60.Quantity or 0
			if v61 > 0 then
				v_u_57.Inner.Quantity.Text = ("x%d"):format(v61)
				v_u_57.Inner.Quantity.Visible = true
			else
				v_u_57.Inner.Quantity.Visible = false
			end
			if v58 then
				v_u_57.Inner.Remaining.Text = ("%d / %d"):format(v58, v_u_53)
				v_u_57.Inner.Remaining.Visible = true
			else
				v_u_57.Inner.Remaining.Visible = false
			end
		end
		p46._focusTrove:Add(v_u_50:OnChange({ "CharmModifiers" }, v62))
		p46._focusTrove:Add(v_u_50:OnChange({ "Inventory", "Charms" }, v62))
		p46._focusTrove:Add(v_u_50:OnChange({ "EquippedCharmId" }, v62))
		v62()
		p46._infoFrame.Frame.Level.Counter.Text = ("%d"):format(v54)
		p46._infoFrame.Frame.Uses.Counter.Text = ("%d"):format(v_u_53)
		local v63 = p46._infoFrame.Frame.Luck.Counter
		local v64 = v55 * 100
		v63.Text = ("%*%%"):format((math.round(v64)))
		p46._infoFrame.Frame.Luck.Visible = v55 > 0
		if v49.Modifiers then
			for v65, v66 in v49.Modifiers do
				if v65 ~= "BaseLuck" then
					local v67, v68 = v_u_5:GetModifierDisplayName(v65)
					if v67 then
						local v69
						if v67:find("Multi") or v65:find("Multiplier") then
							local v70 = (1 + v66) * 10
							v69 = ("x%*"):format(math.round(v70) / 10)
						else
							local v71 = v66 * 100
							v69 = ("%*%%"):format((math.round(v71)))
						end
						local v72 = p46._sampleFrame:Clone()
						v72.Label.Text = ("%*:"):format(v67)
						v72.Counter.Text = v69
						v72.Counter.UIGradient.Color = ColorSequence.new(v68)
						local v73 = v66 * 100
						v72.LayoutOrder = math.abs(v73)
						v72.Parent = p46._infoFrame.Frame
						p46._focusTrove:Add(v72)
					end
				end
			end
		end
		local v74 = false
		if v49.FishModifiers then
			for v75, v76 in v49.FishModifiers do
				local v77 = v_u_3.GetItemDataFromItemType("Fish", v75)
				if v77 then
					local v78 = string.len(v75)
					local v79
					if v77.Probability then
						v78 = 1 / v77.Probability.Chance
						v79 = v_u_4:GetTierFromRarity(v77.Probability.Chance)
					else
						v79 = v_u_4:GetTier(v77.Data.Tier)
					end
					local v80 = p46._fishTileTemplate:Clone()
					local v81 = v80.Inner.Top.Counter
					local v82 = (v76 + 1) * 10
					v81.Text = ("x%* Chance"):format(math.floor(v82) / 10)
					v80.Inner.Glow.UIGradient.Color = v79.TierColor
					v80.UIStroke.UIGradient.Color = v79.TierColor
					v80.Inner.Configuration.ItemName.Text = v77.Data.Name
					v80.Inner.Vector.Image = v77.Data.Icon or ""
					v80.LayoutOrder = v78
					v80.Parent = p46._fishScrollFrame
					p46._focusTrove:Add(v80)
					v74 = true
				end
			end
		end
		local v83
		if v49.Perks then
			for _, _ in v49.Perks do

			end
			v83 = true
		else
			v83 = false
		end
		p46._perkFrame.Visible = v83
		p46._fishScrollFrame.Parent.Visible = v74
		p46._focusPanel.Visible = true
		p46._selectedCharmId = v_u_51
	end
end
function v_u_7.DestroyFocus(p84)
	p84._focusTrove:Clean()
	p84._focusPanel.Visible = false
	p84._selectedCharmId = nil
end
function v_u_7.GetSelectedCharmId(p85)
	return p85._selectedCharmId
end
function v_u_7.GetTile(p86, p87)
	return p86._tiles[p87]
end
function v_u_7.GetAllTiles(p88)
	return p88._tiles
end
function v_u_7.DestroyAll(p89)
	p89:DestroyFocus()
	for _, v90 in p89._tiles do
		v90:Destroy()
	end
	table.clear(p89._tiles)
end
return v_u_7