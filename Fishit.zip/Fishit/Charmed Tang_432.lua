-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 18,
		["Type"] = "Fish",
		["Name"] = "Charmed Tang",
		["Description"] = "",
		["Icon"] = "rbxassetid://115703943090504",
		["Tier"] = 3
	},
	["SellPrice"] = 393,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.4, 3),
		["Default"] = NumberRange.new(1.5, 1.8)
	},
	["Probability"] = {
		["Chance"] = 0.003076923076923077
	},
	["_moduleScript"] = script
}
return v1