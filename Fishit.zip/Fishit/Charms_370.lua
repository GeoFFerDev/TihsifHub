-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
local v2 = game:GetService("ReplicatedStorage")
local v3 = require(v2.Packages.Loader)
require(v2.Types.Modifiers)
local v4 = v3.LoadChildren(script)
if v1:IsServer() then
	require(v2.Modules.Util.TableUtil)
	local v5 = -1
	for _, v6 in v4 do
		local v7 = v6.Data.Id
		v5 = math.max(v5, v7)
	end
	local v8 = {}
	for v9, v10 in v4 do
		if v8[v10.Data.Id] then
			task.spawn(error, (("[ITEMS] DUPLICATE ENTRY FOUND: %* - %*"):format(v9, v10.Data.Name)))
		end
		v8[v10.Data.Id] = true
	end
	table.clear(v8)
end
return v4