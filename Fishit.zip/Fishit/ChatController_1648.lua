-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TextChatService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v2.Packages.Replion)
require(v2.Packages.Net)
local v_u_5 = require(v2.Shared.ChatTags)
require(v2.Shared.Leaderboards)
require(v2.Shared.TierUtility):GetTierFromRarity(2e-6)
local _ = v_u_3.LocalPlayer
local v_u_19 = {
	["Init"] = function(_)
		-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_19
		function v_u_1.OnIncomingMessage(p6)
			-- upvalues: (ref) v_u_3, (ref) v_u_19
			local v7 = Instance.new("TextChatMessageProperties")
			if p6.TextSource then
				local v8 = p6.TextSource.UserId
				local v9 = v_u_3:GetPlayerByUserId(v8)
				if v9 then
					v9 = v_u_19:_getChatTag(v9)
				end
				if v9 then
					local v10 = v9.TagColor:ToHex()
					local v11, v12, v13 = v9.TagColor:ToHSV()
					local v14 = Color3.fromHSV(v11, v12 * 0.3, v13):ToHex()
					v7.PrefixText = ("<b><font color=\"#%*\">%*</font></b> "):format(v10, v9.Tag)
					v7.Text = ("<font color=\"#%*\">%*</font>"):format(v14, p6.Text)
				end
				local v15 = TopFishLeaderboard and TopFishLeaderboard:Find("OrderedUserIds", v8)
				if v15 then
					v7.PrefixText = v7.PrefixText .. ("<font color=\"#ffba26\">[#%*]</font> "):format(v15)
				end
				v7.PrefixText = v7.PrefixText .. p6.PrefixText
			end
			return v7
		end
	end,
	["Start"] = function(_)
		-- upvalues: (copy) v_u_4, (copy) v_u_1
		v_u_4.Client:AwaitReplion("Data", function(_)
			-- upvalues: (ref) v_u_1
			local v16 = v_u_1:WaitForChild("TextChannels"):WaitForChild("RBXGeneral")
			v16:DisplaySystemMessage("<b><font size=\"20\" color=\"rgb(69, 255, 112)\">Welcome! </font></b>Please report any \240\159\144\158 bugs you find in our group")
			v16:DisplaySystemMessage("<b><font size=\"18\" color=\"rgb(112, 236, 255)\">[Tip]: </font></b>Start your adventure by equipping your Fishing Rod! Click, hold and release to begin!")
		end)
		TopFishLeaderboard = v_u_4.Client:WaitReplion("Monthly Caught Fish")
	end,
	["_getChatTag"] = function(_, p17)
		-- upvalues: (copy) v_u_5
		for _, v18 in ipairs(v_u_5) do
			if v18.PlayerCondition then
				if v18.PlayerCondition(p17) then
					return v18
				end
			elseif p17:GetAttribute(v18.PlayerAttribute) and true or false then
				return v18
			end
		end
	end
}
return v_u_19