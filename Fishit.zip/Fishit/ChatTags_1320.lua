-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared:WaitForChild("ValidUsers"))
return {
	{
		["Tag"] = "[Owner]",
		["TagColor"] = Color3.fromRGB(255, 25, 25),
		["PlayerAttribute"] = "Dev",
		["PlayerCondition"] = function(p3)
			-- upvalues: (copy) v_u_2
			return table.find(v_u_2.Owners, p3.UserId) and true or false
		end
	},
	{
		["Tag"] = "[Duck Developer]",
		["TagColor"] = Color3.fromRGB(251, 255, 17),
		["PlayerAttribute"] = "Dev",
		["PlayerCondition"] = function(p4)
			return p4.UserId == 33372493
		end
	},
	{
		["Tag"] = "[Developer]",
		["TagColor"] = Color3.fromRGB(251, 255, 17),
		["PlayerAttribute"] = "Dev",
		["PlayerCondition"] = function(p5)
			-- upvalues: (copy) v_u_2
			return table.find(v_u_2.Developers, p5.UserId) and true or false
		end
	},
	{
		["Tag"] = "[Contributor]",
		["TagColor"] = Color3.fromRGB(178, 70, 255),
		["PlayerAttribute"] = "Contributor"
	},
	{
		["Tag"] = "[Content]",
		["TagColor"] = Color3.fromRGB(255, 153, 223),
		["PlayerAttribute"] = "ContentCreator"
	},
	{
		["Tag"] = "[Senior Staff]",
		["TagColor"] = Color3.fromRGB(255, 124, 17),
		["PlayerAttribute"] = "SeniorStaff"
	},
	{
		["Tag"] = "[Staff]",
		["TagColor"] = Color3.fromRGB(17, 255, 112),
		["PlayerAttribute"] = "Staff"
	},
	{
		["Tag"] = "[Tester]",
		["TagColor"] = Color3.fromRGB(155, 255, 183),
		["PlayerAttribute"] = "Tester"
	},
	{
		["Tag"] = "[VIP]",
		["TagColor"] = Color3.fromRGB(255, 205, 26),
		["PlayerAttribute"] = "VIP"
	}
}