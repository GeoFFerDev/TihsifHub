-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 462,
		["Type"] = "Fish",
		["Name"] = "Cherry Spearfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://104081643218472",
		["Tier"] = 5
	},
	["SellPrice"] = 5500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(237, 285),
		["Default"] = NumberRange.new(140, 182)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["EventTag"] = "BDAY",
	["_moduleScript"] = script
}
return v1