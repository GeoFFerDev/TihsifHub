-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent.Parent.Symbol).named("Children")