-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 527,
		["Type"] = "Fish",
		["Name"] = "Chill Santa Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://121122529050682",
		["Tier"] = 2
	},
	["SellPrice"] = 58,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(7.1, 8.5),
		["Default"] = NumberRange.new(5.2, 6.5)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1