-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 19,
		["Type"] = "Lanterns",
		["Name"] = "Chinese New Years Lantern",
		["Description"] = "",
		["Icon"] = "rbxassetid://122787314801521",
		["Tier"] = 4
	},
	["GripC0"] = CFrame.new(Vector3.new(0, 2, 1.1)) * CFrame.fromOrientation(0, 1.5707963267948966, -0.17453292519943295),
	["_moduleScript"] = script
}
return v1