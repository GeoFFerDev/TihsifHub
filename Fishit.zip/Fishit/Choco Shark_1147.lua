-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.UserPriority).IsValidTestSession() and 0.000018181818181818182 or 0.000013333333333333333
return {
	["Data"] = {
		["Id"] = 744,
		["Type"] = "Fish",
		["Name"] = "Choco Shark",
		["Description"] = "",
		["Icon"] = "rbxassetid://108699083842154",
		["Tier"] = 6
	},
	["SellPrice"] = 45000,
	["Weight"] = {
		["Big"] = NumberRange.new(2300, 2800),
		["Default"] = NumberRange.new(1400, 1900)
	},
	["Probability"] = {
		["Chance"] = v2
	},
	["Events"] = { "Valentines Event" },
	["EventTag"] = "VAL26",
	["_moduleScript"] = script
}