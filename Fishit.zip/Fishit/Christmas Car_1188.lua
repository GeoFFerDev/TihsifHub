-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 21,
		["Type"] = "Boats",
		["Name"] = "Christmas Car",
		["Description"] = "",
		["Icon"] = "rbxassetid://98191794999434",
		["Tier"] = 5
	},
	["HiddenInShop"] = true,
	["Seats"] = 2,
	["_moduleScript"] = script
}
return v1