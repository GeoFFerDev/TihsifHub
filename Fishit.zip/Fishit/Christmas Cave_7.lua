-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 5,
	["ForcedClockTime"] = 4,
	["Ambiance"] = {
		["SoundId"] = "rbxassetid://107746626275082",
		["Volume"] = 0.15
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(21, 21, 72),
		["OutdoorAmbient"] = Color3.fromRGB(56, 58, 141)
	},
	["Atmosphere"] = {
		["Offset"] = 1,
		["Density"] = 0.42,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(74, 103, 134),
		["Decay"] = Color3.fromRGB(13, 25, 56)
	},
	["ColorCorrection"] = {
		["TintColor"] = Color3.fromRGB(231, 206, 255)
	},
	["Clouds"] = {
		["Enabled"] = false
	}
}
return v1