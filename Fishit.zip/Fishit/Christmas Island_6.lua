-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 1
}
local v2 = {
	["Priority"] = 5,
	["Music"] = {
		["SoundId"] = "rbxassetid://115233533502718",
		["Volume"] = 0.1
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(75, 69, 106),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(132, 73, 73)
	},
	["Atmosphere"] = {
		["Density"] = 0.4,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(212, 233, 255),
		["Decay"] = Color3.fromRGB(219, 175, 255)
	},
	["Clouds"] = {
		["Color"] = Color3.fromRGB(169, 239, 255)
	}
}
v1.Day = v2
local v3 = {
	["Priority"] = 5,
	["Music"] = {
		["SoundId"] = "rbxassetid://115233533502718",
		["Volume"] = 0.1
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(98, 71, 117),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(82, 70, 144)
	},
	["Atmosphere"] = {
		["Density"] = 0.4,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(212, 233, 255),
		["Decay"] = Color3.fromRGB(219, 175, 255)
	},
	["Clouds"] = {
		["Color"] = Color3.fromRGB(169, 239, 255)
	}
}
v1.Night = v3
return v1