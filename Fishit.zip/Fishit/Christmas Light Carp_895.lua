-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 474,
		["Type"] = "Fish",
		["Name"] = "Christmas Light Carp",
		["Description"] = "",
		["Icon"] = "rbxassetid://122388564298702",
		["Tier"] = 3
	},
	["SellPrice"] = 320,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(4.8, 6.1),
		["Default"] = NumberRange.new(3, 4.4)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1