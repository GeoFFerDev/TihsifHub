-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 557,
		["Type"] = "Fishing Rods",
		["Name"] = "Christmas Parasol",
		["Description"] = "",
		["Icon"] = "rbxassetid://75092312119606",
		["NewIcon"] = true,
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0, 1, 0.6),
	["OverrideROT"] = CFrame.fromOrientation(0, 3.141592653589793, 0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.fromOrientation(-1.5707963267948966, 0, 0),
	["GripC1"] = CFrame.identity,
	["BobberAnimationDelay"] = 0.22,
	["catchAnimationDelay"] = 0.2,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1