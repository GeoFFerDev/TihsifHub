-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 511,
		["Type"] = "Fish",
		["Name"] = "Christmas Penguin",
		["Description"] = "",
		["Icon"] = "rbxassetid://87582231890415",
		["Tier"] = 5
	},
	["SellPrice"] = 19000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.2, 1.5),
		["Default"] = NumberRange.new(0.4, 1)
	},
	["Probability"] = {
		["Chance"] = 0.000033333333333333335
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1