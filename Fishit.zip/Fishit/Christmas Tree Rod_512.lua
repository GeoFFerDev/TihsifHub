-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 101,
		["Type"] = "Fishing Rods",
		["Name"] = "Christmas Tree Rod",
		["Description"] = "EVENT - Christmas 2024",
		["Icon"] = "rbxassetid://78639604918154",
		["Tier"] = 4
	},
	["VisualClickPowerPercent"] = 0.13,
	["ClickPower"] = 0.13,
	["Resilience"] = 4.3,
	["Windup"] = NumberRange.new(2.8, 4.34),
	["MaxWeight"] = 500
}
local v2 = {
	["BaseLuck"] = 1.8,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1