-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 529,
		["Type"] = "Fish",
		["Name"] = "Christmas Wreath Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://132653247906739",
		["Tier"] = 2
	},
	["SellPrice"] = 58,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(6.6, 7.84),
		["Default"] = NumberRange.new(2.93, 4.4)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1