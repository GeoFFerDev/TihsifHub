-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
game:GetService("Players")
local v2 = require(v1.Packages.Observers)
local v3 = require(v1.Packages.Thread)
local _ = require(v1.Packages.Replion).Client
require(v1.Modules.GuiControl)
local v_u_4 = {}
v2.observeTag("ChristmasColorStrobe", function(p5)
	-- upvalues: (copy) v_u_4
	local v_u_6 = {}
	local v_u_7 = {}
	local v_u_12 = p5.ChildAdded:Connect(function(p8)
		-- upvalues: (copy) v_u_7, (copy) v_u_6
		if p8:IsA("BasePart") then
			local v9 = v_u_7
			table.insert(v9, p8)
			if table.find(v_u_6, p8.Color) == nil then
				local v10 = v_u_6
				local v11 = p8.Color
				table.insert(v10, v11)
			end
		end
	end)
	for _, v13 in ipairs(p5:GetChildren()) do
		if v13:IsA("BasePart") then
			table.insert(v_u_7, v13)
			if table.find(v_u_6, v13.Color) == nil then
				local v14 = v13.Color
				table.insert(v_u_6, v14)
			end
		end
	end
	local function v_u_20()
		-- upvalues: (copy) v_u_7, (copy) v_u_6
		for _, v15 in ipairs(v_u_7) do
			local v16 = v15.Color
			local v17 = table.clone(v_u_6)
			local v18 = table.find(v17, v16)
			if v18 then
				table.remove(v17, v18)
			end
			local v19
			if #v17 > 0 then
				v19 = v17[math.random(1, #v17)]
			else
				v19 = BrickColor.Random().Color
			end
			if v19 then
				v15.Color = v19
			end
		end
	end
	local v21 = v_u_4
	table.insert(v21, v_u_20)
	return function()
		-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_7, (ref) v_u_4, (copy) v_u_20
		v_u_12:Disconnect()
		table.clear(v_u_6)
		table.clear(v_u_7)
		local v22 = table.find(v_u_4, v_u_20)
		if v22 then
			table.remove(v_u_4, v22)
		end
	end
end)
v3:Execute(0.5, function()
	-- upvalues: (copy) v_u_4
	for _, v23 in ipairs(v_u_4) do
		v23()
	end
end)
return {}