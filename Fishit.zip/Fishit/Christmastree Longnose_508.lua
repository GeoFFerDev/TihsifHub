-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 93,
		["Type"] = "Fish",
		["Name"] = "Christmastree Longnose",
		["Description"] = "",
		["Icon"] = "rbxassetid://121538254026074",
		["Tier"] = 3
	},
	["SellPrice"] = 190,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8.98, 11.88),
		["Default"] = NumberRange.new(5.88, 7.32)
	},
	["Probability"] = {
		["Chance"] = 0.002857142857142857
	},
	["EventTag"] = "XMAS24",
	["_moduleScript"] = script
}
return v1