-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 6,
		["Type"] = "Baits",
		["Name"] = "Chroma Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://123495869001051",
		["Tier"] = 5
	},
	["Price"] = 290000,
	["Modifiers"] = {
		["BaseLuck"] = 1
	},
	["_moduleScript"] = script
}
return v1