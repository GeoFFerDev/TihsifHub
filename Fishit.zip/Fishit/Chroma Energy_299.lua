-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 43,
		["Type"] = "Baits",
		["Name"] = "Chroma Energy",
		["Description"] = "",
		["Icon"] = "rbxassetid://133909794693637",
		["Tier"] = 7
	},
	["Hidden"] = true,
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1