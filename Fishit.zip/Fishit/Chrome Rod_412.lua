-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 7,
		["Type"] = "Fishing Rods",
		["Name"] = "Chrome Rod",
		["Description"] = "Ol\' reliable\'",
		["Icon"] = "rbxassetid://83222944871842",
		["Tier"] = 4
	},
	["ClickPower"] = 0.14,
	["Resilience"] = 4.1,
	["Windup"] = NumberRange.new(3.6, 5.67),
	["Price"] = 437000,
	["MaxWeight"] = 90000
}
local v2 = {
	["BaseLuck"] = 2.8,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1