-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 53,
		["Type"] = "Fish",
		["Name"] = "Chrome Tuna",
		["Description"] = "",
		["Icon"] = "rbxassetid://103021560011734",
		["Tier"] = 4
	},
	["SellPrice"] = 4050,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(83.2, 154.6),
		["Default"] = NumberRange.new(54.5, 95.4)
	},
	["Probability"] = {
		["Chance"] = 0.00011111111111111112
	},
	["_moduleScript"] = script
}
return v1