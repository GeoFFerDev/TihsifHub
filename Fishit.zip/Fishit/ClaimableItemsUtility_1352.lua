-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
require(v1.Packages.Replion)
local v_u_2 = require(v1.Shared.PlayerStatsUtility)
local v_u_3 = require(v1.Shared.ItemUtility)
local v_u_4 = require(v1.Shared.InventoryMapping)
local v_u_5 = {
	["Diamond Rod"] = {
		["ItemType"] = "Fishing Rods",
		["RequiredIdentifier"] = "Diamond Key",
		["RequiredItemType"] = "Gears"
	},
	["Overlord\'s Trident"] = {
		["ItemType"] = "Fishing Rods",
		["RequiredIdentifier"] = "Ruin Key",
		["RequiredItemType"] = "Gears"
	}
}
return {
	["GetAllItems"] = function(_)
		-- upvalues: (copy) v_u_5
		return v_u_5
	end,
	["Get"] = function(_, p6)
		-- upvalues: (copy) v_u_5
		return v_u_5[p6]
	end,
	["Check"] = function(_, p7, p8)
		-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
		local v9 = v_u_5[p8]
		if v9 then
			if v9.RequiredQuest and p7:Find("CompletedQuests", v9.RequiredQuest) == nil then
				return false, ("You have not completed quest: %*"):format(v9.RequiredQuest)
			else
				local v_u_10 = v_u_3.GetItemDataFromItemType(v9.RequiredItemType, v9.RequiredIdentifier)
				if v_u_10 then
					local v11 = v_u_4[v9.RequiredItemType]
					if v11 then
						if v_u_2:GetItemFromInventory(p7, function(p12)
							-- upvalues: (copy) v_u_10
							return p12.Id == v_u_10.Data.Id
						end, v11) then
							local v_u_13 = v_u_3.GetItemDataFromItemType(v9.ItemType, p8)
							if v_u_13 then
								local v14 = v_u_4[v9.ItemType]
								if v14 then
									if v_u_2:GetItemFromInventory(p7, function(p15)
										-- upvalues: (copy) v_u_13
										return p15.Id == v_u_13.Data.Id
									end, v14) then
										return false, "You already own this item!"
									else
										return true
									end
								else
									return false, "No_Item_Category"
								end
							else
								return false, "No_Item_Data"
							end
						else
							return false, ("You do not own %*"):format(v_u_10.Data.Name)
						end
					else
						return false, "No_Claim_Category"
					end
				else
					return false, "No_Claim_Data"
				end
			end
		else
			return false, "No_Item"
		end
	end
}