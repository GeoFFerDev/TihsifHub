-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 432,
		["Type"] = "Fish",
		["Name"] = "Classic Angler",
		["Description"] = "",
		["Icon"] = "rbxassetid://116353079150728",
		["Tier"] = 4
	},
	["SellPrice"] = 1100,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8, 10),
		["Default"] = NumberRange.new(5, 6)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1