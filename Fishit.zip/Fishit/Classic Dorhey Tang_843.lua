-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 431,
		["Type"] = "Fish",
		["Name"] = "Classic Dorhey Tang",
		["Description"] = "",
		["Icon"] = "rbxassetid://108600494137652",
		["Tier"] = 2
	},
	["SellPrice"] = 55,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.8, 4.6),
		["Default"] = NumberRange.new(2.2, 2.9)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1