-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 30,
		["Type"] = "Boats",
		["Name"] = "Classic Ducky Boat",
		["Description"] = "",
		["Icon"] = "rbxassetid://78793168204308",
		["Tier"] = 5
	},
	["HiddenInShop"] = true,
	["Seats"] = 4,
	["_moduleScript"] = script
}
return v1