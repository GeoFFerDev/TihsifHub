-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 430,
		["Type"] = "Fish",
		["Name"] = "Classic Goldfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://101426127102104",
		["Tier"] = 1
	},
	["SellPrice"] = 20,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.2, 2.6),
		["Default"] = NumberRange.new(1.3, 1.7)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1