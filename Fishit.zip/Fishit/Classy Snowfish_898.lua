-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 500,
		["Type"] = "Fish",
		["Name"] = "Classy Snowfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://139745082927999",
		["Tier"] = 4
	},
	["SellPrice"] = 1200,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(40.17, 78.43),
		["Default"] = NumberRange.new(17.85, 26.78)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1