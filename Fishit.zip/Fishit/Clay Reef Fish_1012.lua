-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 599,
		["Type"] = "Fish",
		["Name"] = "Clay Reef Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://105362745763927",
		["Tier"] = 2
	},
	["SellPrice"] = 55,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(3.1, 3.7),
		["Default"] = NumberRange.new(1.8, 2.4)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1