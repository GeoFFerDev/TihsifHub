-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new()
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3._toClean = {}
	return v3
end
function v_u_1.Add(p4, p5)
	if typeof(p5) == "table" then
		local v6 = p5.Destroy
		if typeof(v6) ~= "function" then
			error("Object does not have a Destroy method.")
		end
	end
	local v7 = p4._toClean
	table.insert(v7, p5)
end
function v_u_1.Destroy(p8)
	for _, v9 in ipairs(p8._toClean) do
		if typeof(v9) == "RBXScriptConnection" then
			v9:Disconnect()
		else
			v9:Destroy()
		end
	end
end
v_u_1.Clean = v_u_1.Destroy
return v_u_1