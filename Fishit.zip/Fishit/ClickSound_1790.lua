-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v_u_3 = require(v1.Shared.Soundbook)
v2.observeTag("ClickSound", function(p4)
	-- upvalues: (copy) v_u_3
	local v_u_5 = p4.Activated:Connect(function()
		-- upvalues: (ref) v_u_3
		v_u_3.Sounds.ThickClick:Play()
	end)
	return function()
		-- upvalues: (copy) v_u_5
		v_u_5:Disconnect()
	end
end)
return {}