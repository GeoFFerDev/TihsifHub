-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v_u_3 = require(v1.Packages.spr)
local v_u_4 = v2.LocalPlayer.PlayerGui:WaitForChild("!!! Click Effect")
local v_u_5 = v_u_4:WaitForChild("Tile")
v_u_5.Parent = nil
local v_u_6 = {}
v_u_6.__index = v_u_6
function v_u_6.new()
	-- upvalues: (copy) v_u_6
	local v7 = v_u_6
	return setmetatable({
		["Tiles"] = {}
	}, v7)
end
function v_u_6.Destroy(p8)
	-- upvalues: (copy) v_u_3
	for _, v9 in ipairs(p8.Tiles) do
		local v10 = v9:FindFirstChildWhichIsA("UIScale")
		if v10 then
			v_u_3.stop(v10)
		end
		v_u_3.stop(v9)
		v9:Destroy()
	end
	table.clear(p8.Tiles)
end
function v_u_6.Activate(p_u_11, p12)
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_3
	local v_u_13 = v_u_5:Clone()
	v_u_13.BackgroundTransparency = 0
	v_u_13.UIScale.Scale = 0
	v_u_13.Position = UDim2.fromOffset(p12.X, p12.Y)
	v_u_13.Visible = true
	v_u_13.Parent = v_u_4
	v_u_3.target(v_u_13.UIScale, 100, 600, {
		["Scale"] = 0.75 + math.random() * 0.5
	})
	v_u_3.target(v_u_13, 100, 600, {
		["BackgroundTransparency"] = 1
	})
	local v14 = p_u_11.Tiles
	local v15 = v_u_13
	table.insert(v14, v15)
	task.delay(2, function()
		-- upvalues: (copy) p_u_11, (ref) v_u_13, (ref) v_u_3
		local v16 = table.find(p_u_11.Tiles, v_u_13)
		if v16 then
			table.remove(p_u_11.Tiles, v16)
		end
		v_u_3.stop(v_u_13.UIScale)
		v_u_3.stop(v_u_13)
		v_u_13:Destroy()
		v_u_13 = nil
	end)
end
return v_u_6