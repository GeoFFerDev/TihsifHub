-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("ReplicatedStorage")
local v2 = shared.GBMod("GetRemote")
local v3 = shared.GBMod("Signal")
local v_u_4 = shared.GBMod("SignalConnection")
local v_u_5 = v2("Function", "Get")
local v_u_6 = v2("Event", "ConfigChanged")
local v_u_7 = v3.new()
local v_u_8 = v3.new()
local v_u_9 = {}
local v_u_10 = false
local function v_u_15(p11)
	-- upvalues: (copy) v_u_15
	local v12 = {}
	for v13, v14 in pairs(p11) do
		if type(v14) == "table" then
			v12[v13] = v_u_15(v14)
		else
			v12[v13] = v14
		end
	end
	return v12
end
function v1.WaitForConfigsReady(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_8
	if not v_u_10 then
		v_u_8:Wait()
	end
end
function v1.Get(p16, p17, p18)
	-- upvalues: (ref) v_u_9
	if typeof(p17) ~= "table" and typeof(p17) ~= "string" then
		error("Config path must be a string or list of strings.")
		return nil
	end
	p16:WaitForConfigsReady()
	local v19 = p18 or v_u_9
	for _, v20 in typeof(p17) == "string" and { p17 } or p17 do
		v19 = v19[v20]
		if v19 == nil then
			return nil
		end
	end
	return v19
end
function v1.OnChanged(p_u_21, p22, p_u_23)
	-- upvalues: (copy) v_u_7
	local v_u_24 = type(p22) == "string" and { p22 } or p22
	return v_u_7:Connect(function(p25, p26)
		-- upvalues: (ref) v_u_24, (copy) p_u_23, (copy) p_u_21
		for _, v27 in p25 do
			local v28 = true
			for v29, v30 in v_u_24 do
				if v27.path[v29] == nil then
					break
				end
				if v27.path[v29] ~= v30 then
					v28 = false
					break
				end
			end
			if v28 then
				p_u_23(p_u_21:Get(v_u_24), p_u_21:Get(v_u_24, p26))
				return
			end
		end
	end)
end
function v1.OnReady(_, p_u_31)
	-- upvalues: (ref) v_u_10, (ref) v_u_9, (copy) v_u_4, (copy) v_u_8
	if not v_u_10 then
		return v_u_8:Once(function()
			-- upvalues: (copy) p_u_31, (ref) v_u_9
			p_u_31(v_u_9)
		end)
	end
	task.spawn(p_u_31, v_u_9)
	return v_u_4.new()
end
function v1.IsReady(_)
	-- upvalues: (ref) v_u_10
	return v_u_10
end
function v1.Init(_)
	-- upvalues: (copy) v_u_6, (ref) v_u_10, (copy) v_u_15, (ref) v_u_9, (copy) v_u_7, (copy) v_u_5, (copy) v_u_8
	v_u_6.OnClientEvent:Connect(function(p32)
		-- upvalues: (ref) v_u_10, (ref) v_u_15, (ref) v_u_9, (ref) v_u_7
		if v_u_10 then
			local v33 = v_u_15(v_u_9)
			for _, v34 in p32 do
				local v35 = v_u_9
				for v36, v37 in v34.path do
					if v36 == #v34.path then
						v35[v37] = v34.newValue
					else
						v35 = v35[v37]
					end
				end
			end
			v_u_7:Fire(p32, v33)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8
		v_u_9 = v_u_5:InvokeServer()
		v_u_10 = true
		v_u_8:Fire(v_u_9)
	end)
end
return v1