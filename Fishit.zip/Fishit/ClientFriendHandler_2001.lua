-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("Players")
local v_u_3 = shared.GBMod("ClientInfoHandler")
local v_u_4 = {}
local v_u_5 = 0
local function v_u_13()
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (ref) v_u_5
	local v_u_6 = 0
	local v10, v11 = pcall(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_4
		local v7 = v_u_2:GetFriendsAsync(v_u_2.LocalPlayer.UserId)
		while true do
			local v8 = v7:GetCurrentPage()
			for _, v9 in ipairs(v8) do
				if v_u_2:GetPlayerByUserId(v9.Id) then
					v_u_6 = v_u_6 + 1
				end
				v_u_4[v9.Id] = true
			end
			if v7.IsFinished then
				return
			end
			v7:AdvanceToNextPageAsync()
		end
	end)
	local v12 = v_u_3:GetClientInfo("hasFriendsOnline") or false
	if v12 == true and v_u_6 <= 0 then
		v_u_3:UpdateClientInfo("totalFriendPlaytime", (v_u_3:GetClientInfo("totalFriendPlaytime") or 0) + os.time() - v_u_3:GetClientInfo("friendClockStart"))
	elseif v_u_6 > 0 and v12 == false then
		v_u_3:UpdateClientInfo("friendClockStart", os.time())
	end
	v_u_5 = v_u_6
	v_u_3:UpdateClientInfo("hasFriendsOnline", v_u_5 > 0)
	return v10, v11
end
function v1.Init(_)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_5, (copy) v_u_13
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13
		v_u_2.PlayerAdded:Connect(function(p14)
			-- upvalues: (ref) v_u_4, (ref) v_u_5
			if v_u_4[p14.UserId] then
				v_u_5 = v_u_5 + 1
			end
		end)
		v_u_2.PlayerRemoving:Connect(function(p15)
			-- upvalues: (ref) v_u_4, (ref) v_u_5
			if v_u_4[p15.UserId] then
				v_u_5 = v_u_5 - 1
			end
		end)
		v_u_13()
		while task.wait(600) do
			v_u_13()
		end
	end)
end
return v1