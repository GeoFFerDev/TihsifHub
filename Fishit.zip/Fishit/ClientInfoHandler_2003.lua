-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("MarketplaceService")
local v3 = shared.GBMod("GetRemote")
local v_u_4 = shared.GBMod("ClientSessionPreservation")
local v_u_5 = v3("Event", "ClientInfoChanged")
local v6 = v3("Function", "GetProductPrice")
local v_u_7 = {
	["device"] = true,
	["deviceSubType"] = true,
	["inputType"] = true
}
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = false
function v_u_1.UpdateClientInfo(_, p11, p12)
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_7, (ref) v_u_10, (copy) v_u_5
	if v_u_9[p11] ~= p12 then
		v_u_9[p11] = p12
		v_u_4:UpdateStoredData(p11, p12)
		for v13 in v_u_7 do
			if not v_u_9[v13] then
				return
			end
		end
		if v_u_10 then
			return
		end
		v_u_10 = true
		task.defer(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_5, (ref) v_u_9
			v_u_10 = false
			v_u_5:FireServer(v_u_9)
		end)
	end
end
function v_u_1.GetClientInfo(_, p14)
	-- upvalues: (copy) v_u_9
	return v_u_9[p14]
end
for v15, v16 in v_u_4:GetStoredData() do
	v_u_1:UpdateClientInfo(v15, v16)
end
function v6.OnClientInvoke(p_u_17, p_u_18)
	-- upvalues: (copy) v_u_8, (copy) v_u_2
	if v_u_8[p_u_17] then
		return v_u_8[p_u_17]
	end
	local v19, v20 = pcall(function()
		-- upvalues: (ref) v_u_2, (copy) p_u_17, (copy) p_u_18
		return v_u_2:GetProductInfo(p_u_17, p_u_18)
	end)
	if not v19 then
		return nil
	end
	v_u_8[p_u_17] = v20
	return v20.PriceInRobux
end
v_u_5.OnClientEvent:Connect(function(p21, p22)
	-- upvalues: (copy) v_u_1
	v_u_1:UpdateClientInfo(p21, p22)
end)
return v_u_1