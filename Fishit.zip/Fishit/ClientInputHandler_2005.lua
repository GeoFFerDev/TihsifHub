-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("VRService")
local v_u_4 = shared.GBMod("ClientInfoHandler")
local v_u_5 = shared.GBMod("Signal").new()
local v_u_6 = nil
function v_u_1.GetDeviceType(_)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v7 = (v_u_2.VREnabled or v_u_3.VREnabled) and "vr" or (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "mobile" or (v_u_2.GamepadEnabled and not v_u_2.KeyboardEnabled and "console" or (v_u_2.KeyboardEnabled and "pc" or "unknown")))
	local v8 = "unknown"
	if v7 == "mobile" then
		local v9 = workspace.CurrentCamera
		if v9 then
			local v10 = v9.ViewportSize.X
			local v11 = v9.ViewportSize.Y
			local v12 = math.max(v10, v11)
			local v13 = v9.ViewportSize.X
			local v14 = v9.ViewportSize.Y
			local v15 = v12 / math.min(v13, v14)
			if v15 > 1.8 then
				return v7, "phone"
			elseif v15 <= 1.7 then
				return v7, "tablet"
			else
				return v7, "phone"
			end
		end
	else
		if v7 == "console" then
			local v16 = v_u_2:GetImageForKeyCode(Enum.KeyCode.ButtonX)
			if string.find(v16, "Xbox") then
				return v7, "xbox"
			elseif string.find(v16, "PlayStation") then
				return v7, "playstation"
			else
				return v7, "unknown"
			end
		end
		if v7 == "vr" then
			return v7, "unknown"
		end
		v8 = v7 == "pc" and "unknown" or v8
	end
	return v7, v8
end
function v_u_1.OnInputTypeChanged(_, p17)
	-- upvalues: (copy) v_u_5
	return v_u_5:Connect(p17)
end
function v_u_1.GetCurrentInputType(_)
	-- upvalues: (ref) v_u_6, (copy) v_u_2
	if not v_u_6 then
		if v_u_2.GamepadEnabled then
			v_u_6 = "gamepad"
		elseif v_u_2.TouchEnabled then
			v_u_6 = "touch"
		else
			v_u_6 = "keyboard"
		end
	end
	return v_u_6
end
function v_u_1.Init(p18)
	-- upvalues: (ref) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_1, (copy) v_u_2
	local v19, v20 = p18:GetDeviceType()
	v_u_4:UpdateClientInfo("inputType", v_u_1:GetCurrentInputType())
	v_u_4:UpdateClientInfo("deviceSubType", v20)
	v_u_4:UpdateClientInfo("device", v19)
	v_u_2.LastInputTypeChanged:Connect(function(p21)
		-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_4
		local v22 = p21 == Enum.UserInputType.Keyboard and "keyboard" or (p21 == Enum.UserInputType.Touch and "touch" or (string.match(tostring(p21), "Gamepad") and "gamepad" or nil))
		if v22 and (v22 ~= v_u_6 and v_u_6 ~= v22) then
			v_u_6 = v22
			v_u_5:Fire(v_u_6)
			v_u_4:UpdateClientInfo("inputType", v_u_6)
		end
	end)
	v_u_2.InputChanged:Connect(function(p23)
		-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_4
		if p23.UserInputType == Enum.UserInputType.MouseMovement and v_u_6 ~= "keyboard" then
			v_u_6 = "keyboard"
			v_u_5:Fire(v_u_6)
			v_u_4:UpdateClientInfo("inputType", v_u_6)
		end
	end)
end
return v_u_1