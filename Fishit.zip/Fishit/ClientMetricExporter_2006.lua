-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("Players")
local v3 = shared.GBMod("GetRemote")
local v_u_4 = shared.GBMod("MetricCollector")
local v_u_5 = v3("Event", "ExportClientMetrics")
function v1.Init(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_5
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_2
		while task.wait(1) do
			v_u_4:ReportMetric("PhysicsFps", workspace:GetRealPhysicsFPS())
			v_u_4:ReportMetric("Ping", v_u_2.LocalPlayer:GetNetworkPing())
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_5
		while task.wait(10) do
			v_u_5:FireServer((v_u_4:ReadAndResetAllMetrics()))
		end
	end)
end
return v1