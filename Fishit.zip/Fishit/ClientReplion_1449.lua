-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.Parent.Parent.Freeze)
local v_u_2 = require(script.Parent.Parent.Internal.Utils)
local v_u_3 = require(script.Parent.Parent.Parent.Signal)
require(script.Parent.Parent.Internal.Types)
local v_u_4 = require(script.Parent.Parent.Internal.Signals)
local v_u_5 = {}
v_u_5.__index = v_u_5
function v_u_5.new(p6)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	local v7 = {
		["Data"] = p6[3],
		["Tags"] = p6[5],
		["ReplicateTo"] = p6[3],
		["_channel"] = p6[2],
		["_beforeDestroy"] = v_u_3.new(),
		["_signals"] = v_u_4.new()
	}
	local v8 = v_u_5
	return setmetatable(v7, v8)
end
function v_u_5.__tostring(p9)
	return ("Replion<%*>"):format(p9._channel)
end
function v_u_5.BeforeDestroy(p10, p11)
	return p10._beforeDestroy:Connect(p11)
end
function v_u_5.OnDataChange(p12, p13)
	return p12._signals:Connect("onDataChange", "__root", p13)
end
function v_u_5.OnChange(p14, p15, p16)
	return p14._signals:Connect("onChange", p15, p16)
end
function v_u_5.OnDescendantChange(p17, p18, p19)
	return p17._signals:Connect("onDescendantChange", p18, p19)
end
function v_u_5.OnArrayInsert(p20, p21, p22)
	return p20._signals:Connect("onArrayInsert", p21, p22)
end
function v_u_5.OnArrayRemove(p23, p24, p25)
	return p23._signals:Connect("onArrayRemove", p24, p25)
end
function v_u_5._set(p26, p27, p28)
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v29 = v_u_2.getPathTable(p27)
	if v_u_1.Dictionary.getIn(p26.Data, v29) == p28 then
		return p28
	end
	local v30 = v_u_1.Dictionary.setIn(p26.Data, v29, p28)
	local v31 = p26.Data
	p26.Data = v30
	p26._signals:FireEvent("onDataChange", "__root", v30, v29)
	p26._signals:FireChange(p27, v30, v31)
	return p28
end
function v_u_5._update(p32, p33, p34)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v37 = v_u_1.Dictionary.map(p34 or p33, function(p35, p36)
		-- upvalues: (ref) v_u_2, (ref) v_u_1
		if p35 == v_u_2.SerializedNone then
			p35 = v_u_1.None
		end
		return p35, p36
	end)
	local v38 = p32.Data
	if p34 == nil then
		local v39 = v_u_1.Dictionary.merge(p32.Data, v37)
		p32.Data = v39
		p32._signals:FireEvent("onDataChange", "__root", v39, {})
		for v40, v41 in v37 do
			p32._signals:FireEvent("onChange", v40, v_u_2.getValue(v41), v38[v40])
		end
	else
		local v42 = v_u_2.getPathTable(p33)
		local v43 = v_u_1.Dictionary.mergeIn(p32.Data, v42, v37)
		p32.Data = v43
		p32._signals:FireEvent("onDataChange", "__root", v43, v42)
		for v44, v45 in v37 do
			local v46 = v_u_1.List.push(v42, v44)
			local v47 = v_u_1.Dictionary.getIn(v38, v46)
			p32._signals:FireEvent("onChange", v46, v_u_2.getValue(v45), v47)
		end
		p32._signals:FireChange(p33, v43, v38)
	end
end
function v_u_5._increase(p48, p49, p50)
	return p48:_set(p49, p48:GetExpect(p49) + p50)
end
function v_u_5._decrease(p51, p52, p53)
	return p51:_increase(p52, -p53)
end
function v_u_5._insert(p54, p55, p56, p57)
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v58 = v_u_2.getPathTable(p55)
	local v59 = v_u_1.Dictionary.getIn(p54.Data, v58)
	local v60 = ("\"%*\" is not a valid path!"):format((v_u_2.getPathString(p55)))
	local v61 = assert(v59, v60)
	local v62 = p57 or #v61 + 1
	local v63 = v_u_1.List.insert(v61, v62, p56)
	local v64 = p54.Data
	local v65 = v_u_1.Dictionary.setIn(p54.Data, v58, v63)
	p54.Data = v65
	p54._signals:FireEvent("onDataChange", "__root", v65, v58)
	p54._signals:FireEvent("onArrayInsert", v58, v62, p56)
	p54._signals:FireChange(v58, v65, v64)
end
function v_u_5._remove(p66, p67, p68)
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v69 = v_u_2.getPathTable(p67)
	local v70 = v_u_1.Dictionary.getIn(p66.Data, v69)
	local v71 = ("\"%*\" is not a valid path!"):format((v_u_2.getPathString(p67)))
	local v72 = assert(v70, v71)
	local v73 = p68 or #v72
	local v74 = v72[v73]
	local v75 = v_u_1.List.remove(v72, v73)
	local v76 = p66.Data
	local v77 = v_u_1.Dictionary.setIn(p66.Data, v69, v75)
	p66.Data = v77
	p66._signals:FireEvent("onDataChange", "__root", v77, v69)
	p66._signals:FireEvent("onArrayRemove", p67, v73, v74)
	p66._signals:FireChange(p67, v77, v76)
	return v74
end
function v_u_5._clear(p78, p79)
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v80 = v_u_2.getPathTable(p79)
	local v81 = p78.Data
	local v82 = v_u_1.Dictionary.setIn(p78.Data, v80, {})
	p78.Data = v82
	p78._signals:FireEvent("onDataChange", "__root", v82, v80)
	p78._signals:FireChange(p79, v82, v81)
end
function v_u_5.Find(p83, p84, p85)
	local v86 = p83:Get(p84)
	if v86 then
		local v87 = table.find(v86, p85)
		if v87 then
			return v87, p85
		end
	end
end
function v_u_5.Get(p88, p89)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	return v_u_1.Dictionary.getIn(p88.Data, v_u_2.getPathTable(p89))
end
function v_u_5.GetExpect(p90, p91, p92)
	-- upvalues: (copy) v_u_2
	assert(p91, "Path is required!")
	local v93 = p92 or ("\"%*\" is not a valid path!"):format((v_u_2.getPathString(p91)))
	local v94 = p90:Get(p91)
	if v94 == nil then
		error(v93)
	end
	return v94
end
function v_u_5.Destroy(p95)
	if not p95.Destroyed then
		p95.Destroyed = true
		p95._beforeDestroy:Fire(p95)
		p95._beforeDestroy:DisconnectAll()
		p95._signals:Destroy()
	end
end
return v_u_5