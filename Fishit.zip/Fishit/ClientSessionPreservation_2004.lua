-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TeleportService")
shared.GBMod("Signal")
shared.GBMod("GetRemote")
local v_u_3 = {
	["sessionId"] = true,
	["joinTime"] = true,
	["friendClockStart"] = true,
	["hasFriendsOnline"] = true,
	["totalFriendPlaytime"] = true
}
function v1.UpdateStoredData(p4, p5, p6)
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	if v_u_3[p5] ~= nil then
		local v7 = p4:GetStoredData()
		v7[p5] = p6
		v_u_2:SetTeleportSetting("GAMEBEAST_SESSION", v7)
	end
end
function v1.GetStoredData(_)
	-- upvalues: (copy) v_u_2
	return v_u_2:GetTeleportSetting("GAMEBEAST_SESSION") or {}
end
return v1