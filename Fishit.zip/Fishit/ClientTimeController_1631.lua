-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("SoundService")
game:GetService("RunService")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("CollectionService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("Lighting")
local v6 = game:GetService("Players")
local v_u_7 = require(v4.Packages.Observers)
local v_u_8 = require(v4.Packages.Replion)
local v9 = require(v4.Packages.Trove)
local v10 = require(v4.Packages.Signal)
require(v4.Packages.Net)
local v_u_11 = require(v4.Packages.spr)
local v_u_12 = require(v4.Shared.AreaUtility)
require(v4.Shared.TimeConfiguration)
local v_u_13 = require(v4.Packages.Loader).LoadDescendants(v_u_5.LightingProfiles)
local v_u_14 = require(v4.Controllers.TextNotificationController)
local v_u_15 = nil
local v_u_16 = v6.LocalPlayer
local _ = v_u_16.PlayerGui
local v_u_17 = {}
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = v9.new()
local v_u_22 = v9.new()
local v_u_23 = v9.new()
local v_u_24 = v9.new()
local v_u_25 = nil
local v_u_26 = false
local v_u_27 = false
local v_u_28 = nil
local v_u_29 = false
local v_u_30 = v_u_5:WaitForChild("Sky"):Clone()
local v_u_71 = {
	["NightTime"] = false,
	["NightTimeChanged"] = v10.new(),
	["Init"] = function(_)
		-- upvalues: (ref) v_u_15, (copy) v_u_8, (copy) v_u_71, (copy) v_u_5, (copy) v_u_16, (ref) v_u_19, (copy) v_u_13, (copy) v_u_17, (ref) v_u_20, (ref) v_u_18, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (copy) v_u_7
		v_u_15 = v_u_8.Client:WaitReplion("Time")
		v_u_15:OnChange("Time", function(p31)
			-- upvalues: (ref) v_u_71, (ref) v_u_5
			local v32 = v_u_71:_getLightingProfile()
			local v33
			if v32 then
				v33 = v32.ForcedClockTime
			else
				v33 = nil
			end
			if not v33 then
				v_u_5.ClockTime = p31
			end
			v_u_71:_updateTextLabels()
			v_u_71:_setNightTime(v_u_71:IsNightTime())
		end)
		workspace:GetAttributeChangedSignal("ClockTime"):Connect(function()
			-- upvalues: (ref) v_u_71
			v_u_71:_updateTextLabels()
			v_u_71:_setNightTime(v_u_71:IsNightTime())
		end)
		local function v_u_37()
			-- upvalues: (ref) v_u_16, (ref) v_u_19, (ref) v_u_71, (ref) v_u_13
			local v34 = v_u_16:GetAttribute("LocationName")
			local v35 = (v34 == "Lost Isle" or (v34 == "Sisyphus Statue" or (v34 == "Treasure Hall" or v34 == "Treasure Room"))) and "Lost Isle" or ((v34 == "Ancient Ruin" or v34 == "Crystalline Passage") and "Crystalline Passage" or v34)
			if not v_u_19 or v_u_19 ~= v35 then
				if v_u_19 then
					v_u_71:RemoveAmbianceOverride(v_u_19)
				end
				v_u_19 = v35
				local v36 = v_u_13[v35]
				if v36 then
					v_u_71:AddAmbianceOverride(v35, v36.Priority)
				end
			end
		end
		v_u_8.Client:AwaitReplion("Events", function(p38)
			-- upvalues: (ref) v_u_17, (ref) v_u_20, (ref) v_u_18, (ref) v_u_19, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_71, (ref) v_u_16, (copy) v_u_37
			p38:OnArrayRemove("Events", function(_, p39)
				-- upvalues: (ref) v_u_17, (ref) v_u_20, (ref) v_u_18, (ref) v_u_19, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29
				if typeof(p39) == "string" and p39:find("Admin") then
					table.clear(v_u_17)
					v_u_20 = nil
					v_u_18 = nil
					v_u_19 = nil
					v_u_25 = nil
					v_u_26 = false
					v_u_27 = false
					v_u_28 = nil
					v_u_29 = false
				end
				UpdateLighting()
			end)
			p38:OnArrayInsert("Events", function(_, p40)
				-- upvalues: (ref) v_u_17, (ref) v_u_20, (ref) v_u_18, (ref) v_u_19, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29
				if typeof(p40) == "string" and p40:find("Admin") then
					table.clear(v_u_17)
					v_u_20 = nil
					v_u_18 = nil
					v_u_19 = nil
					v_u_25 = nil
					v_u_26 = false
					v_u_27 = false
					v_u_28 = nil
					v_u_29 = false
				end
				UpdateLighting()
			end)
			UpdateLighting()
			v_u_71:_updateLocationLabels()
			task.delay(2, function()
				-- upvalues: (ref) v_u_16, (ref) v_u_19, (ref) v_u_37
				if v_u_16:GetAttribute("LocationName") ~= v_u_19 then
					v_u_37()
				end
			end)
		end)
		v_u_16:GetAttributeChangedSignal("LocationName"):Connect(function()
			-- upvalues: (copy) v_u_37, (ref) v_u_71
			v_u_37()
			v_u_71:_updateLocationLabels()
		end)
		v_u_71.NightTimeChanged:Connect(function()
			UpdateLighting()
		end)
		v_u_7.observeCharacter(function(p41, p42)
			-- upvalues: (ref) v_u_16, (ref) v_u_20, (ref) v_u_17, (copy) v_u_37
			if p41 == v_u_16 then
				task.wait(0.5)
				p42:WaitForChild("HumanoidRootPart")
				v_u_20 = nil
				table.clear(v_u_17)
				v_u_37()
			end
		end)
	end,
	["IsNightTime"] = function(_)
		local v43 = workspace:GetAttribute("ClockTime")
		return v43 < 7 and true or v43 > 17.783
	end,
	["_setNightTime"] = function(_, p44)
		-- upvalues: (copy) v_u_71
		if p44 ~= v_u_71.NightTime then
			v_u_71.NightTime = p44
			v_u_71.NightTimeChanged:Fire()
		end
	end,
	["RefreshAmbiancePriority"] = function(_)
		-- upvalues: (copy) v_u_17, (ref) v_u_18
		if #v_u_17 > 0 then
			table.sort(v_u_17, function(p45, p46)
				return p45.Priority > p46.Priority
			end)
		end
		local v47 = v_u_17[1]
		if v47 then
			v_u_18 = v47.Name
		else
			v_u_18 = nil
		end
		UpdateLighting()
	end,
	["RemoveAmbianceOverride"] = function(_, p48)
		-- upvalues: (copy) v_u_17, (ref) v_u_19, (copy) v_u_71
		for v49, v50 in ipairs(v_u_17) do
			if v50.Name == p48 then
				table.remove(v_u_17, v49)
				break
			end
		end
		v_u_19 = nil
		v_u_71:RefreshAmbiancePriority()
	end,
	["AddAmbianceOverride"] = function(_, p51, p52)
		-- upvalues: (copy) v_u_17, (copy) v_u_71
		for _, v53 in ipairs(v_u_17) do
			if v53.Name == p51 then
				return false
			end
		end
		local v54 = v_u_17
		table.insert(v54, {
			["Name"] = p51,
			["Priority"] = p52
		})
		v_u_71:RefreshAmbiancePriority()
		return true
	end,
	["_updateTextLabels"] = function(_)
		-- upvalues: (copy) v_u_3
		local v55 = workspace:GetAttribute("ClockTime")
		local v56 = math.floor(v55)
		local v57 = v55 - math.floor(v55)
		local v58 = v55 >= 12 and "PM" or "AM"
		local v59 = math.fmod(v56, 12)
		local v60 = v57 * 60
		local v61 = ("%02i:%02i %s"):format(v59, math.floor(v60), v58)
		for _, v62 in ipairs((v_u_3:GetTagged("ClockLabel"))) do
			v62.Text = v61
		end
	end,
	["_updateLocationLabels"] = function(_)
		-- upvalues: (copy) v_u_16, (copy) v_u_12, (copy) v_u_3
		local v63 = v_u_16:GetAttribute("LocationName")
		if v63 then
			local v64 = v_u_12:GetArea(v63)
			local v65 = v64 and (v64.Hidden or v64.ComingSoon) and "???" or v63
			for _, v66 in ipairs((v_u_3:GetTagged("LocationLabel"))) do
				v66.Text = v65
			end
			if not v_u_16:GetAttribute("Loading") then
				UpdateLocationNotification(v65)
			end
		end
	end,
	["_getLightingProfile"] = function(_)
		-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_71, (ref) v_u_18
		if next(v_u_13) ~= nil then
			local v67 = v_u_8.Client:GetReplion("Events")
			if v67 then
				if v67:Find("Events", "Admin - Night Celebration") then
					return v_u_13["Admin - Night Celebration"], "Admin - Night Celebration"
				end
				if v67:Find("Events", "Admin - Bloodmoon") then
					return v_u_13.Bloodmoon, "Bloodmoon"
				end
				if v67:Find("Events", "Admin - Purple Bloodmoon") then
					return v_u_13["Purple Bloodmoon"], "Purple Bloodmoon"
				end
			end
			local v68 = v_u_71.NightTime and "Night" or "Day"
			local v69
			if v_u_18 then
				v69 = v_u_13[v_u_18]
			else
				v69 = nil
			end
			if not v69 then
				return v_u_13[v68], v68
			end
			if v67 then
				v67 = v67:Get("Events")
			end
			if v67 then
				for _, v70 in ipairs(v67) do
					if v70 ~= "Day" and (v70 ~= "Night" and v69[v70]) then
						return v69[v70]
					end
				end
			end
			return v69[v68] or v69, v_u_18
		end
	end
}
function UpdateLocationNotification(p72)
	-- upvalues: (copy) v_u_14
	local v73 = {
		["Type"] = "Location",
		["Text"] = p72,
		["TextColor"] = {
			["R"] = 255,
			["G"] = 255,
			["B"] = 255
		}
	}
	v_u_14:DeliverNotification(v73)
end
function UpdateLighting()
	-- upvalues: (ref) v_u_27, (copy) v_u_71, (ref) v_u_20, (copy) v_u_21, (ref) v_u_28, (copy) v_u_22, (copy) v_u_23, (ref) v_u_25, (copy) v_u_2, (copy) v_u_5, (copy) v_u_24, (copy) v_u_30, (ref) v_u_26, (copy) v_u_1, (ref) v_u_29, (copy) v_u_11
	if not v_u_27 then
		v_u_27 = true
		local v74, v75 = v_u_71:_getLightingProfile()
		if v74 then
			if typeof(v75) == "string" then
				local v76 = v_u_20
				if typeof(v76) == "string" and v_u_20 == v75 then
					v_u_27 = false
					return
				end
			end
			v_u_20 = v75
			if v74.WaitForSignal then
				workspace:GetAttributeChangedSignal(v74.SignalName):Wait()
				workspace:SetAttribute(v74.SignalName, nil)
			end
			v_u_21:Clean()
			if not v74.Ambiance or v74.Ambiance and v_u_28 ~= v74.Ambiance.SoundId then
				v_u_22:Clean()
				v_u_28 = nil
			end
			if not v74.Music or v74.Music and v_u_28 ~= v74.Music.SoundId then
				v_u_23:Clean()
				v_u_25 = nil
			end
			if v74.Lighting then
				local v_u_77 = v_u_2:Create(v_u_5, TweenInfo.new(3, Enum.EasingStyle.Quart), v74.Lighting)
				v_u_77.Completed:Once(function()
					-- upvalues: (copy) v_u_77
					v_u_77:Destroy()
				end)
				v_u_21:Add(function()
					-- upvalues: (copy) v_u_77
					v_u_77:Cancel()
				end)
				v_u_77:Play()
			end
			local v78 = v_u_5:FindFirstChildOfClass("Atmosphere")
			if v78 and v74.Atmosphere then
				local v_u_79 = v_u_2:Create(v78, TweenInfo.new(3, Enum.EasingStyle.Quart), v74.Atmosphere)
				v_u_79.Completed:Once(function()
					-- upvalues: (copy) v_u_79
					v_u_79:Destroy()
				end)
				v_u_21:Add(function()
					-- upvalues: (copy) v_u_79
					v_u_79:Cancel()
				end)
				v_u_79:Play()
			end
			local v80 = v_u_5:FindFirstChildWhichIsA("ColorCorrectionEffect")
			if v80 then
				local v81 = not v74.ColorCorrection and {} or v74.ColorCorrection
				if not v81.Brightness then
					v81.Brightness = 0.04
				end
				if not v81.TintColor then
					v81.TintColor = Color3.fromRGB(255, 255, 255)
				end
				local v_u_82 = v_u_2:Create(v80, TweenInfo.new(3, Enum.EasingStyle.Quart), v81)
				v_u_82.Completed:Once(function()
					-- upvalues: (copy) v_u_82
					v_u_82:Destroy()
				end)
				v_u_21:Add(function()
					-- upvalues: (copy) v_u_82
					v_u_82:Cancel()
				end)
				v_u_82:Play()
			end
			local v83 = workspace.Terrain:FindFirstChildOfClass("Clouds")
			if v83 and v74.Clouds then
				local v84 = v74.Clouds.Enabled
				if typeof(v84) == "boolean" then
					v83.Enabled = v74.Clouds.Enabled
				else
					v83.Enabled = true
					local v_u_85 = v_u_2:Create(v83, TweenInfo.new(3, Enum.EasingStyle.Quart), v74.Clouds)
					v_u_85.Completed:Once(function()
						-- upvalues: (copy) v_u_85
						v_u_85:Destroy()
					end)
					v_u_21:Add(function()
						-- upvalues: (copy) v_u_85
						v_u_85:Cancel()
					end)
					v_u_85:Play()
				end
			end
			local v86 = v74.Sky
			if v86 then
				v_u_24:Clean()
				local v87 = v_u_5:FindFirstChildOfClass("Sky")
				if v87.SkyboxUp ~= v86.SkyboxUp then
					local v88 = v_u_24:Clone(v86)
					v_u_24:Add(function()
						-- upvalues: (ref) v_u_30, (ref) v_u_5
						v_u_30:Clone().Parent = v_u_5
					end)
					v87:Destroy()
					v88.Parent = v_u_5
				end
			else
				v_u_24:Clean()
			end
			local v89 = v74.Music
			if v89 and not v_u_26 then
				v_u_26 = true
				if not v_u_25 or v_u_25 ~= v89.SoundId then
					local v_u_90 = Instance.new("Sound")
					v_u_90.Name = "Music"
					v_u_90.Volume = 0
					v_u_90.SoundId = v89.SoundId
					v_u_90.Looped = true
					v_u_90.Parent = v_u_1
					local v_u_91 = v_u_2:Create(v_u_90, TweenInfo.new(0.2, Enum.EasingStyle.Quart), {
						["Volume"] = v89.Volume
					})
					v_u_91.Completed:Once(function()
						-- upvalues: (copy) v_u_91
						v_u_91:Destroy()
					end)
					v_u_23:Add(function()
						-- upvalues: (copy) v_u_91, (ref) v_u_2, (copy) v_u_90
						task.spawn(function()
							-- upvalues: (ref) v_u_91, (ref) v_u_2, (ref) v_u_90
							if v_u_91.PlaybackState == Enum.PlaybackState.Playing then
								v_u_91:Cancel()
							end
							local v_u_92 = v_u_2:Create(v_u_90, TweenInfo.new(0.2, Enum.EasingStyle.Quart), {
								["Volume"] = 0
							})
							v_u_92.Completed:Once(function()
								-- upvalues: (copy) v_u_92, (ref) v_u_90
								v_u_92:Destroy()
								v_u_90:Destroy()
							end)
							v_u_92:Play()
						end)
					end)
					v_u_91:Play()
					v_u_90:Play()
					v_u_25 = v89.SoundId
				end
				v_u_26 = false
			end
			local v93 = v74.Ambiance
			if v93 and not v_u_29 then
				v_u_29 = true
				if not v_u_28 or v_u_28 ~= v93.SoundId then
					local v_u_94 = Instance.new("Sound")
					v_u_94.Name = "Ambience"
					v_u_94.Volume = 0
					v_u_94.SoundId = v93.SoundId
					v_u_94.Looped = true
					v_u_94.Parent = v_u_1
					local v_u_95 = v_u_2:Create(v_u_94, TweenInfo.new(0.2, Enum.EasingStyle.Quart), {
						["Volume"] = v93.Volume
					})
					v_u_95.Completed:Once(function()
						-- upvalues: (copy) v_u_95
						v_u_95:Destroy()
					end)
					v_u_22:Add(function()
						-- upvalues: (copy) v_u_95, (ref) v_u_2, (copy) v_u_94
						task.spawn(function()
							-- upvalues: (ref) v_u_95, (ref) v_u_2, (ref) v_u_94
							if v_u_95.PlaybackState == Enum.PlaybackState.Playing then
								v_u_95:Cancel()
							end
							local v_u_96 = v_u_2:Create(v_u_94, TweenInfo.new(0.2, Enum.EasingStyle.Quart), {
								["Volume"] = 0
							})
							v_u_96.Completed:Once(function()
								-- upvalues: (copy) v_u_96, (ref) v_u_94
								v_u_96:Destroy()
								v_u_94:Destroy()
							end)
							v_u_96:Play()
						end)
					end)
					v_u_95:Play()
					v_u_94:Play()
					v_u_28 = v93.SoundId
				end
				v_u_29 = false
			end
			local v97 = v74.WaterColor or Color3.fromRGB(72, 129, 118)
			local v98 = workspace.Terrain
			if v98.WaterColor == v97 then
				v_u_11.stop(v98)
				v98.WaterColor = v97
			else
				v_u_11.stop(v98)
				v_u_11.target(v98, 1, 3, {
					["WaterColor"] = v97
				})
			end
			local v99 = v74.ForcedClockTime
			if v99 then
				v_u_71._tweenTime(v99)
			else
				local v100 = workspace:GetAttribute("ClockTime")
				local v101 = v100 - v_u_5.ClockTime
				if math.abs(v101) >= 0.1 then
					v_u_71._tweenTime(v100)
				else
					v_u_5.ClockTime = v100
				end
			end
		end
		v_u_27 = false
	end
end
function v_u_71._tweenTime(p102)
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v_u_103 = v_u_2:Create(v_u_5, TweenInfo.new(0.5, Enum.EasingStyle.Quart), {
		["ClockTime"] = p102
	})
	v_u_103.Completed:Once(function()
		-- upvalues: (copy) v_u_103
		v_u_103:Destroy()
	end)
	v_u_103:Play()
end
return v_u_71