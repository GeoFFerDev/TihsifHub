-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
local v_u_2 = require(script.Parent.Internal.Utils)
local v3 = require(script.Parent.Parent.Signal)
local v4 = require(script.Parent.Internal.Network)
local v_u_5 = require(script.ClientReplion)
require(script.Parent.Internal.Types)
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = v3.new()
local v_u_10 = v3.new()
local function v_u_15(p11, p12)
	-- upvalues: (copy) v_u_2, (copy) v_u_8
	for v13, v14 in p11 do
		if v14.thread == p12 then
			table.remove(p11, v13)
			if v14.async then
				v_u_2.safeCancelThread(p12)
			else
				task.spawn(p12)
			end
			v_u_8[p12] = nil
			return
		end
	end
end
local function v_u_21(p16)
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7
	local v17 = p16[2]
	if not v_u_6[v17] then
		local v18 = v_u_5.new(p16)
		v_u_6[v17] = v18
		v_u_6[p16[1]] = v18
		v_u_9:Fire(v18)
		local v19 = v_u_7[v17]
		if v19 then
			for _, v20 in v19 do
				task.spawn(v20.thread, v18)
			end
			v_u_7[v17] = nil
		end
	end
end
local v46 = {
	["OnReplionAdded"] = function(_, p22)
		-- upvalues: (copy) v_u_9
		return v_u_9:Connect(p22)
	end,
	["OnReplionRemoved"] = function(_, p23)
		-- upvalues: (copy) v_u_10
		return v_u_10:Connect(p23)
	end,
	["OnReplionAddedWithTag"] = function(p24, p_u_25, p_u_26)
		return p24:OnReplionAdded(function(p27)
			-- upvalues: (copy) p_u_25, (copy) p_u_26
			local v28 = p27.Tags
			if v28 and table.find(v28, p_u_25) ~= nil then
				p_u_26(p27)
			end
		end)
	end,
	["OnReplionRemovedWithTag"] = function(p29, p_u_30, p_u_31)
		return p29:OnReplionRemoved(function(p32)
			-- upvalues: (copy) p_u_30, (copy) p_u_31
			local v33 = p32.Tags
			if v33 and table.find(v33, p_u_30) ~= nil then
				p_u_31(p32)
			end
		end)
	end,
	["GetReplion"] = function(_, p34)
		-- upvalues: (copy) v_u_6
		return v_u_6[p34]
	end,
	["WaitReplion"] = function(_, p35, p36)
		-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15
		local v37 = v_u_6[p35]
		if v37 then
			return v37
		end
		local v38 = coroutine.running()
		local v39 = v_u_7[p35]
		if not v39 then
			v39 = {}
			v_u_7[p35] = v39
		end
		if p36 then
			v_u_8[v38] = task.delay(p36, v_u_15, v39, v38)
		end
		table.insert(v39, {
			["thread"] = v38
		})
		return coroutine.yield()
	end,
	["AwaitReplion"] = function(_, p40, p41, p42)
		-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15
		local v43 = v_u_6[p40]
		if v43 then
			return p41(v43)
		end
		local v_u_44 = v_u_7[p40]
		if not v_u_44 then
			v_u_44 = {}
			v_u_7[p40] = v_u_44
		end
		local v_u_45 = coroutine.create(p41)
		if p42 then
			v_u_8[v_u_45] = task.delay(p42, v_u_15, v_u_44, v_u_45)
		end
		table.insert(v_u_44, {
			["thread"] = v_u_45,
			["async"] = true
		})
		return function()
			-- upvalues: (ref) v_u_15, (copy) v_u_44, (copy) v_u_45
			v_u_15(v_u_44, v_u_45)
		end
	end
}
if not v_u_2.ShouldMock and v1:IsClient() then
	local v47 = v4.get("Added")
	local v48 = v4.get("Removed")
	local v49 = v4.get("Update")
	local v50 = v4.get("Set")
	local v51 = v4.get("UpdateReplicateTo")
	local v52 = v4.get("ArrayUpdate")
	v47.OnClientEvent:Connect(function(p53)
		-- upvalues: (copy) v_u_21
		local v54 = p53[1]
		if type(v54) == "table" then
			for _, v55 in p53 do
				v_u_21(v55)
			end
		else
			v_u_21(p53)
		end
	end)
	v48.OnClientEvent:Connect(function(p56)
		-- upvalues: (copy) v_u_6, (copy) v_u_10
		local v57 = v_u_6[p56]
		if v57 then
			v_u_6[p56] = nil
			v_u_6[v57._channel] = nil
			v_u_10:Fire(v57)
			v57:Destroy()
		end
	end)
	v49.OnClientEvent:Connect(function(p58, p59, p60)
		-- upvalues: (copy) v_u_6
		local v61 = v_u_6[p58]
		if v61 then
			v61:_update(p59, p60)
		end
	end)
	v51.OnClientEvent:Connect(function(p62, p63)
		-- upvalues: (copy) v_u_6
		local v64 = v_u_6[p62]
		if v64 then
			v64.ReplicateTo = p63
		end
	end)
	v50.OnClientEvent:Connect(function(p65, p66, p67)
		-- upvalues: (copy) v_u_6
		local v68 = v_u_6[p65]
		if v68 then
			v68:_set(p66, p67)
		end
	end)
	v52.OnClientEvent:Connect(function(p69, p70, ...)
		-- upvalues: (copy) v_u_6
		local v71 = v_u_6[p69]
		if v71 then
			if p70 == "i" then
				v71:_insert(...)
				return
			end
			if p70 == "r" then
				v71:_remove(...)
				return
			end
			if p70 == "c" then
				v71:_clear(...)
			end
		end
	end)
end
return table.freeze(v46)