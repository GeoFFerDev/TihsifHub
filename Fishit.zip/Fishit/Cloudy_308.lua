-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Cloudy",
	["Icon"] = "rbxassetid://72258943070104",
	["Description"] = "Increases luck",
	["Tier"] = 2,
	["Duration"] = 900,
	["Modifiers"] = {
		["BaseLuck"] = 0.2
	},
	["WeatherMachine"] = true,
	["WeatherMachinePrice"] = 20000
}
return v1