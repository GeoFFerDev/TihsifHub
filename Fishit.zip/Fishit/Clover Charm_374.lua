-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 4,
		["Type"] = "Charms",
		["Name"] = "Clover Charm",
		["Description"] = "+10% Luck everywhere",
		["Icon"] = "rbxassetid://103007743773683",
		["NewIcon"] = true,
		["Tier"] = 3
	},
	["Level"] = 5,
	["Uses"] = 20,
	["Price"] = 5000,
	["C0"] = CFrame.identity,
	["C1"] = CFrame.identity,
	["Modifiers"] = {
		["BaseLuck"] = 0.1
	},
	["Downloadable"] = true,
	["_moduleScript"] = script
}
return v1