-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 64,
		["Type"] = "Fish",
		["Name"] = "Clownfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://98117815811053",
		["Tier"] = 1
	},
	["SellPrice"] = 19,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.8, 1),
		["Default"] = NumberRange.new(0.5, 0.6)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1