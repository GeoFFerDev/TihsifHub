-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("RunService")
local v3 = game:GetService("StarterGui")
local v4 = game:GetService("Players").LocalPlayer
local v5 = script:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Util"))
local v7 = require(v1:WaitForChild("Shared"):WaitForChild("UserPriority"))
if v2:IsClient() == false then
	error("Server scripts cannot require the client library. Please require the server library to use Cmdr in your own code.")
end
local v8 = v7:GetPriorityLevel(v4) >= 3 and {
	[Enum.KeyCode.F2] = true
} or {}
local v9 = {
	["ReplicatedRoot"] = script,
	["RemoteFunction"] = script:WaitForChild("CmdrFunction"),
	["RemoteEvent"] = script:WaitForChild("CmdrEvent"),
	["ActivationKeys"] = v8,
	["Enabled"] = true,
	["MashToEnable"] = false,
	["ActivationUnlocksMouse"] = false,
	["HideOnLostFocus"] = true,
	["PlaceName"] = "Cmdr",
	["Util"] = v_u_6,
	["Events"] = {}
}
local v_u_13 = setmetatable(v9, {
	["__index"] = function(p_u_10, p11)
		local v_u_12 = p_u_10.Dispatcher[p11]
		if v_u_12 and type(v_u_12) == "function" then
			return function(_, ...)
				-- upvalues: (copy) v_u_12, (copy) p_u_10
				return v_u_12(p_u_10.Dispatcher, ...)
			end
		end
	end
})
v_u_13.Registry = require(v5.Registry)(v_u_13)
v_u_13.Dispatcher = require(v5.Dispatcher)(v_u_13)
if v3:WaitForChild("Cmdr") and (wait() and v4:WaitForChild("PlayerGui"):FindFirstChild("Cmdr") == nil) then
	v3.Cmdr:Clone().Parent = v4.PlayerGui
end
local v_u_14 = require(script.CmdrInterface)(v_u_13)
function v_u_13.SetActivationKeys(p15, p16)
	-- upvalues: (copy) v_u_6
	p15.ActivationKeys = v_u_6.MakeDictionary(p16)
end
function v_u_13.SetPlaceName(p17, p18)
	-- upvalues: (copy) v_u_14
	p17.PlaceName = p18
	v_u_14.Window:UpdateLabel()
end
function v_u_13.SetEnabled(p19, p20)
	p19.Enabled = p20
end
function v_u_13.SetActivationUnlocksMouse(p21, p22)
	p21.ActivationUnlocksMouse = p22
end
function v_u_13.Show(p23)
	-- upvalues: (copy) v_u_14
	if p23.Enabled then
		v_u_14.Window:Show()
	end
end
function v_u_13.Hide(_)
	-- upvalues: (copy) v_u_14
	v_u_14.Window:Hide()
end
function v_u_13.Toggle(p24)
	-- upvalues: (copy) v_u_14
	if not p24.Enabled then
		return p24:Hide()
	end
	v_u_14.Window:SetVisible(not v_u_14.Window:IsVisible())
end
function v_u_13.SetMashToEnable(p25, p26)
	p25.MashToEnable = p26
	if p26 then
		p25:SetEnabled(false)
	end
end
function v_u_13.SetHideOnLostFocus(p27, p28)
	p27.HideOnLostFocus = p28
end
function v_u_13.HandleEvent(p29, p30, p31)
	p29.Events[p30] = p31
end
if v2:IsServer() == false then
	v_u_13.Registry:RegisterTypesIn(script:WaitForChild("Types"))
	v_u_13.Registry:RegisterCommandsIn(script:WaitForChild("Commands"))
end
v_u_13.RemoteEvent.OnClientEvent:Connect(function(p32, ...)
	-- upvalues: (ref) v_u_13
	if v_u_13.Events[p32] then
		v_u_13.Events[p32](...)
	end
end)
require(script.DefaultEventHandlers)(v_u_13)
return v_u_13