-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 19,
		["Type"] = "Fish",
		["Name"] = "Coal Tang",
		["Description"] = "",
		["Icon"] = "rbxassetid://92488575546885",
		["Tier"] = 2
	},
	["SellPrice"] = 74,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.3, 1.7),
		["Default"] = NumberRange.new(0.9, 1)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1