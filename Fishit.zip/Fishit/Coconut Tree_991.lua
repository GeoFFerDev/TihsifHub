-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 583,
		["Type"] = "Fishing Rods",
		["Name"] = "Coconut Tree",
		["Description"] = "",
		["Icon"] = "rbxassetid://109491421550890",
		["NewIcon"] = true,
		["Tier"] = 3
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0, 2, 1.25),
	["OverrideROT"] = CFrame.fromOrientation(0, 3.141592653589793, -0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.fromOrientation(1.5707963267948966, 2.792526803190927, 0),
	["GripC1"] = CFrame.fromOrientation(0, -3.141592653589793, 0),
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1