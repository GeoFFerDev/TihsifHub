-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v3 = require(v1.Packages.Net)
local v_u_4 = require(v1.Modules.GuiControl)
local v_u_5 = require(v1.Controllers.TextNotificationController)
local v6 = v2.LocalPlayer.PlayerGui:WaitForChild("Exclusive Store").Main.Content.Items["Codes Frame"]
local v_u_7 = v6.Inputs.Redeem
local v_u_8 = v6.Inputs.Small.Input
local v_u_9 = v3:RemoteFunction("RedeemCode")
return {
	["Start"] = function(_)
		-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9
		v_u_4:Hook("Hold Button", v_u_7).Clicked:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v10 = v_u_8.Text
			if string.len(v10) == 0 then
				local v11 = {
					["Type"] = "Text",
					["Text"] = "Please input a code!",
					["TextColor"] = {
						["R"] = 255,
						["G"] = 83,
						["B"] = 71
					}
				}
				return v_u_5:DeliverNotification(v11)
			else
				local v12, v13 = v_u_9:InvokeServer(v10)
				if v12 then
					v_u_8.Text = ""
					local v14 = {
						["Type"] = "Text",
						["Text"] = "Redeemed code!",
						["TextColor"] = {
							["R"] = 0,
							["G"] = 255,
							["B"] = 0
						}
					}
					v_u_5:DeliverNotification(v14)
				elseif v13 then
					local v15 = {
						["Type"] = "Text",
						["Text"] = v13,
						["TextColor"] = {
							["R"] = 255,
							["G"] = 83,
							["B"] = 71
						}
					}
					v_u_5:DeliverNotification(v15)
				end
			end
		end)
	end
}