-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("ReplicatedStorage")
local v_u_2 = shared.GBMod("InternalCohorts")
function v1.GetCohortMembershipStatusAsync(_, p3, p4)
	-- upvalues: (copy) v_u_2
	return v_u_2:GetCohortMembershipStatusAsync(p3, p4)
end
return v1