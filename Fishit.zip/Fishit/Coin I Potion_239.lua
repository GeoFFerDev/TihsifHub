-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 2,
		["Type"] = "Potions",
		["Name"] = "Coin I Potion",
		["Description"] = "Boosts coins when selling",
		["Icon"] = "rbxassetid://73891090126407",
		["Tier"] = 2
	},
	["Hidden"] = true,
	["SingleProductId"] = 2676109377,
	["TenProductId"] = 2676109066,
	["Duration"] = 1800,
	["Modifiers"] = {},
	["VFX"] = "Coin Potion",
	["_moduleScript"] = script
}
return v1