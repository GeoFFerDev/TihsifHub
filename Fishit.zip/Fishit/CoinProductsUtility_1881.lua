-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = require(v1.Packages.MarketplaceService)
require(v1.Packages.Replion)
local v_u_4 = require(v1.Shared.Products.CoinProducts)
local v_u_17 = {
	["PurchaseBestCoinPack"] = function(_, p5, p6)
		-- upvalues: (copy) v_u_17, (copy) v_u_3, (copy) v_u_2
		local v_u_7 = v_u_17:_getBestCoinPackId(p5, p6)
		return pcall(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_2, (copy) v_u_7
			return v_u_3:PromptProductPurchase(v_u_2, v_u_7)
		end)
	end,
	["_getBestCoinPackId"] = function(_, p8, p9)
		-- upvalues: (copy) v_u_4
		local v10 = {}
		for v11, v12 in v_u_4 do
			local v13 = {
				["ProductId"] = v11,
				["Value"] = v12.Value
			}
			table.insert(v10, v13)
		end
		table.sort(v10, function(p14, p15)
			return p14.Value < p15.Value
		end)
		for _, v16 in ipairs(v10) do
			if p9 <= p8 + v16.Value then
				return v16.ProductId
			end
		end
		return v10[#v10].ProductId
	end
}
return v_u_17