-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	[2672015131] = {
		["Value"] = 1000
	},
	[2672015276] = {
		["Value"] = 6500
	},
	[2672015581] = {
		["Value"] = 15000
	},
	[2672015764] = {
		["Value"] = 45000
	}
}
local v2 = {
	["Value"] = 100000,
	["BonusItems"] = {
		{
			["ItemType"] = "Baits",
			["Identifier"] = "Bag-O-Gold"
		}
	}
}
v1[2672016438] = v2
local v3 = {
	["Value"] = 500000,
	["BonusItems"] = {
		{
			["ItemType"] = "Fishing Rods",
			["Identifier"] = "Abyssal Chroma"
		}
	}
}
v1[3354034695] = v3
return v1