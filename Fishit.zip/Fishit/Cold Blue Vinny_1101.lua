-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 703,
		["Type"] = "Fish",
		["Name"] = "Cold Blue Vinny",
		["Description"] = "",
		["Icon"] = "rbxassetid://105788855924839",
		["Tier"] = 1
	},
	["SellPrice"] = 22,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1, 1.2),
		["Default"] = NumberRange.new(0.4, 0.8)
	},
	["Probability"] = {
		["Chance"] = 0.125
	},
	["_moduleScript"] = script
}
return v1