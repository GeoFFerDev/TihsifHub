-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 15,
		["Type"] = "Variant",
		["Name"] = "Color Burn",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 222, 193)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 222, 193)) })
	},
	["Versions"] = 1,
	["Colors"] = 2,
	["SellMultiplier"] = 2.42,
	["Probability"] = {
		["Chance"] = 0.71
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1