-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	{
		["Primary"] = Color3.fromRGB(105, 102, 95),
		["Secondary"] = Color3.fromRGB(199, 172, 120),
		["Tertiary"] = Color3.fromRGB(99, 95, 98),
		["Quaternary"] = Color3.fromRGB(99, 95, 98)
	},
	{
		["Primary"] = Color3.fromRGB(108, 88, 75),
		["Secondary"] = Color3.fromRGB(99, 95, 98),
		["Tertiary"] = Color3.fromRGB(159, 161, 172),
		["Quaternary"] = Color3.fromRGB(91, 93, 105)
	},
	{
		["Primary"] = Color3.fromRGB(124, 92, 70),
		["Secondary"] = Color3.fromRGB(202, 203, 209),
		["Tertiary"] = Color3.fromRGB(254, 243, 187),
		["Quaternary"] = Color3.fromRGB(159, 161, 172)
	}
}