-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["AddStripes"] = function(_, p1)
		local v2 = {}
		for v3 = 0, 7 do
			local v4 = v3 / 7
			local v5 = v3 % 2 + 1
			local v6 = ColorSequenceKeypoint.new
			local v7 = p1[v5]
			table.insert(v2, v6(v4, v7))
		end
		return ColorSequence.new(v2)
	end,
	["BlendColors"] = function(_, p8)
		if #p8 == 0 then
			return ColorSequence.new(Color3.new(1, 1, 1))
		end
		if #p8 == 1 then
			return p8[1]
		end
		local v9 = {}
		for v10, v11 in ipairs(p8) do
			local v12 = (v10 - 1) / #p8
			local v13 = v10 / #p8
			local v14 = v10 == #p8 and 1 or v13 - 0.05
			for _, v15 in ipairs(v11.Keypoints) do
				local v16 = v15.Time / #p8
				local v17 = ColorSequenceKeypoint.new
				local v18 = v12 + v16
				local v19 = math.min(v18, v14)
				local v20 = v15.Value
				table.insert(v9, v17(v19, v20))
			end
		end
		return ColorSequence.new(v9)
	end
}