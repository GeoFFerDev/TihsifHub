-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return { Color3.fromRGB(21, 115, 255), Color3.fromRGB(255, 192, 32), Color3.fromRGB(204, 222, 234) }