-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 39,
		["Type"] = "Boats",
		["Name"] = "Colossal Pirate Ship",
		["Description"] = "",
		["Icon"] = "rbxassetid://74038884398639",
		["Tier"] = 6
	},
	["HiddenInShop"] = true,
	["Seats"] = 15,
	["_moduleScript"] = script
}
return v1