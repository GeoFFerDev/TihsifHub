-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 996,
		["Type"] = "Gears",
		["Name"] = "Common Present",
		["Description"] = "Give this to Santa at the Toy Factory!",
		["Icon"] = "rbxassetid://112387350402121",
		["Tier"] = 1
	},
	["Present"] = true,
	["RecordData"] = true,
	["SellPrice"] = 1,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1, 1.25),
		["Default"] = NumberRange.new(0.5, 0.75)
	},
	["Probability"] = {
		["Chance"] = 0.025
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1