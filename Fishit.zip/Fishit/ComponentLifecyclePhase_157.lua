-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = require(script.Parent.Symbol)
return require(script.Parent.strict)({
	["Init"] = v1.named("init"),
	["Render"] = v1.named("render"),
	["ShouldUpdate"] = v1.named("shouldUpdate"),
	["WillUpdate"] = v1.named("willUpdate"),
	["DidMount"] = v1.named("didMount"),
	["DidUpdate"] = v1.named("didUpdate"),
	["WillUnmount"] = v1.named("willUnmount"),
	["ReconcileChildren"] = v1.named("reconcileChildren"),
	["Idle"] = v1.named("idle")
}, "ComponentLifecyclePhase")