-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 237,
		["Type"] = "Fish",
		["Name"] = "Conch Shell",
		["Description"] = "",
		["Icon"] = "rbxassetid://139285110672806",
		["Tier"] = 2
	},
	["SellPrice"] = 72,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.22, 0.38),
		["Default"] = NumberRange.new(0.1, 0.16)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1