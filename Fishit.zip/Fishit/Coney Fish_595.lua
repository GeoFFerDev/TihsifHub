-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 184,
		["Type"] = "Fish",
		["Name"] = "Coney Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://126049387807805",
		["Tier"] = 3
	},
	["SellPrice"] = 287,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(27.3, 35.2),
		["Default"] = NumberRange.new(15.4, 22.2)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1