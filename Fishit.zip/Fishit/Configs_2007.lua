-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = shared.GBMod("ClientConfigs")
function v1.Get(_, p3)
	-- upvalues: (copy) v_u_2
	return v_u_2:Get(p3)
end
function v1.Observe(p_u_4, p_u_5, p_u_6)
	local v_u_7 = p_u_4:OnChanged(p_u_5, p_u_6)
	task.spawn(function()
		-- upvalues: (copy) p_u_4, (copy) p_u_5, (copy) v_u_7, (copy) p_u_6
		local v8 = p_u_4:Get(p_u_5)
		if v_u_7.Connected then
			p_u_6(v8, nil)
		end
	end)
	return v_u_7
end
function v1.OnChanged(_, p9, p10)
	-- upvalues: (copy) v_u_2
	return v_u_2:OnChanged(p9, p10)
end
function v1.OnReady(_, p11)
	-- upvalues: (copy) v_u_2
	return v_u_2:OnReady(p11)
end
function v1.IsReady(_)
	-- upvalues: (copy) v_u_2
	return v_u_2:IsReady()
end
function v1.GetForPlayer(_, _, _)
	error("Configs:GetForPlayer is a server-only method. Use :Get instead.")
end
function v1.ObserveForPlayer(_, _, _, _)
	error("Configs:ObserveForPlayer is a server-only method. Use :Observe instead.")
end
function v1.OnChangedForPlayer(_, _, _, _)
	error("Configs:OnChangedForPlayer is a server-only method. Use :OnChanged instead.")
end
return v1