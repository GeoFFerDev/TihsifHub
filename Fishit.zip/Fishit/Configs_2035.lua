-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("ReplicatedStorage")
local v_u_2 = shared.GBMod("InternalConfigs")
function v1.Get(_, p3)
	-- upvalues: (copy) v_u_2
	return v_u_2:Get(nil, p3)
end
function v1.GetForPlayer(_, p4, p5)
	-- upvalues: (copy) v_u_2
	return v_u_2:Get(p4, p5)
end
function v1.Observe(p_u_6, p_u_7, p_u_8)
	local v_u_9 = p_u_6:OnChanged(p_u_7, p_u_8)
	task.spawn(function()
		-- upvalues: (copy) p_u_6, (copy) p_u_7, (copy) v_u_9, (copy) p_u_8
		local v10 = p_u_6:Get(p_u_7)
		if v_u_9.Connected then
			p_u_8(v10, nil)
		end
	end)
	return v_u_9
end
function v1.ObserveForPlayer(p_u_11, p_u_12, p_u_13, p_u_14)
	local v_u_15 = p_u_11:OnChangedForPlayer(p_u_12, p_u_13, p_u_14)
	task.spawn(function()
		-- upvalues: (copy) p_u_11, (copy) p_u_12, (copy) p_u_13, (copy) v_u_15, (copy) p_u_14
		local v16 = p_u_11:GetForPlayer(p_u_12, p_u_13)
		if v_u_15.Connected then
			p_u_14(v16, nil)
		end
	end)
	return v_u_15
end
function v1.OnChanged(_, p17, p18)
	-- upvalues: (copy) v_u_2
	return v_u_2:OnChanged(nil, p17, p18)
end
function v1.OnChangedForPlayer(_, p19, p20, p21)
	-- upvalues: (copy) v_u_2
	return v_u_2:OnChanged(p19, p20, p21)
end
function v1.OnReady(_, p22)
	-- upvalues: (copy) v_u_2
	return v_u_2:OnReady(p22)
end
function v1.IsReady(_)
	-- upvalues: (copy) v_u_2
	return v_u_2:IsReady()
end
return v1