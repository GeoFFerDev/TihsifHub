-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return function()
	local v_u_1 = require(script.Parent.Config)
	it("should accept valid configuration", function()
		-- upvalues: (copy) v_u_1
		local v2 = v_u_1.new()
		local v3 = v2.get()
		expect(v3.elementTracing).to.equal(false)
		v2.set({
			["elementTracing"] = true
		})
		expect(v3.elementTracing).to.equal(true)
	end)
	it("should reject invalid configuration keys", function()
		-- upvalues: (copy) v_u_1
		local v_u_4 = v_u_1.new()
		local v5, v6 = pcall(function()
			-- upvalues: (copy) v_u_4
			v_u_4.set({
				["garblegoop"] = true
			})
		end)
		expect(v5).to.equal(false)
		expect(v6:find("garblegoop")).to.be.ok()
	end)
	it("should reject invalid configuration values", function()
		-- upvalues: (copy) v_u_1
		local v_u_7 = v_u_1.new()
		local v8, v9 = pcall(function()
			-- upvalues: (copy) v_u_7
			v_u_7.set({
				["elementTracing"] = "Hello there!"
			})
		end)
		expect(v8).to.equal(false)
		expect(v9:find("elementTracing")).to.be.ok()
		expect(v9:find("Hello there!")).to.be.ok()
	end)
end