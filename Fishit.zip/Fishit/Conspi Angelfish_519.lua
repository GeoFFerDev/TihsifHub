-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 108,
		["Type"] = "Fish",
		["Name"] = "Conspi Angelfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://70666845671780",
		["Tier"] = 1
	},
	["SellPrice"] = 19,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(5.3, 6),
		["Default"] = NumberRange.new(2.35, 3.53)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1