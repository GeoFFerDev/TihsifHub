-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
local v2 = game:GetService("ReplicatedStorage")
v1:IsServer()
v1:IsClient()
require(v2.Packages.Replion)
local v_u_3 = require(v2.Shared.ItemUtility)
local v16 = {
	["ClickDelay"] = 0.14,
	["CooldownTime"] = 1,
	["FishingRange"] = 80,
	["AutoFishingLevel"] = 0,
	["MaxInventorySize"] = 4500,
	["MaxItemSize"] = 400,
	["EnchantingLevel"] = 10,
	["SecondEnchantingLevel"] = 200,
	["TradingLevel"] = 20,
	["TradableItemTypes"] = {
		"Fish",
		"Gears",
		"Enchant Stones",
		"Emotes"
	},
	["PaidTradableItemTypes"] = { "Fishing Rods" },
	["AutoSellTiers"] = { 5, 6, 7 },
	["FishingDistance"] = 125,
	["GameVersion"] = 28,
	["StoreNotification"] = 28,
	["Flags"] = {
		["NewYears"] = 1767204600,
		["NewYearsPad"] = 1767330000,
		["PirateCoveEndTime"] = 1769994000,
		["WeeklyLimitedEndTime"] = 1770508800,
		["VolcanoWeeklyLimitedTime"] = 1771113600,
		["ValentineEndTime"] = 1772323200
	},
	["GetClickTiming"] = function(_, _, p4)
		local _ = p4 and p4.ClickPowerMultiplier
		return 0.19
	end,
	["CountInventorySize"] = function(_, p5)
		-- upvalues: (copy) v_u_3
		if not p5 or p5.Destroyed then
			return 0, 0
		end
		local v6 = p5:GetExpect("Inventory")
		local v7 = { "Gears", "Enchant Stones", "Trophies" }
		local v8 = 0
		local v9 = 0
		for _, v10 in ipairs(v6.Items) do
			local v11 = v_u_3:GetItemData(v10.Id)
			if v11 then
				local v12 = v11.Data.Type
				if v12 == "Fish" then
					v9 = v9 + 1
				elseif table.find(v7, v12) then
					v8 = v8 + 1
				end
			end
		end
		return v9, v8 + #v6.Totems + #v6.Potions
	end,
	["GetPower"] = function(_, p13)
		local v14 = Random.new(p13):NextInteger(4, 10)
		local v15 = 1.5707963267948966 + (workspace:GetServerTimeNow() - p13) * v14
		return (1 - math.sin(v15)) / 2
	end
}
return v16