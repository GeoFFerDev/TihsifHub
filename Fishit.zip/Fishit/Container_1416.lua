-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return function(p_u_1)
	local v2 = game:GetService("GuiService")
	local v3 = p_u_1.isOldTopbar
	local v4 = {}
	local v5 = v2:GetGuiInset()
	local v6 = v2:IsTenFootInterface()
	local v7 = v6 and 10 or (v3 and 12 or v5.Y - 46)
	local v_u_8 = Instance.new("ScreenGui")
	v_u_8:SetAttribute("StartInset", v7)
	v_u_8.Name = "TopbarStandard"
	v_u_8.Enabled = true
	v_u_8.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_8.IgnoreGuiInset = true
	v_u_8.ResetOnSpawn = false
	v_u_8.ScreenInsets = Enum.ScreenInsets.TopbarSafeInsets
	v4[v_u_8.Name] = v_u_8
	v_u_8.DisplayOrder = p_u_1.baseDisplayOrder
	p_u_1.baseDisplayOrderChanged:Connect(function()
		-- upvalues: (copy) v_u_8, (copy) p_u_1
		v_u_8.DisplayOrder = p_u_1.baseDisplayOrder
	end)
	local v9 = Instance.new("Frame")
	local v10 = v3 and 2 or 0
	local v_u_11
	if v6 then
		v10 = v10 + 13
		v_u_11 = 50
	else
		v_u_11 = -2
	end
	v9.Name = "Holders"
	v9.BackgroundTransparency = 1
	v9.Position = UDim2.new(0, 0, 0, v10)
	v9.Size = UDim2.new(1, 0, 1, v_u_11)
	v9.Visible = true
	v9.ZIndex = 1
	v9.Parent = v_u_8
	local v_u_12 = v_u_8:Clone()
	local v_u_13 = v_u_12.Holders
	local v_u_14 = game:GetService("GuiService")
	local function v15()
		-- upvalues: (copy) v_u_13, (copy) v_u_14, (ref) v_u_11
		v_u_13.Size = UDim2.new(1, 0, 0, v_u_14.TopbarInset.Height + v_u_11)
	end
	v_u_12.Name = "TopbarCentered"
	v_u_12.ScreenInsets = Enum.ScreenInsets.None
	p_u_1.baseDisplayOrderChanged:Connect(function()
		-- upvalues: (copy) v_u_12, (copy) p_u_1
		v_u_12.DisplayOrder = p_u_1.baseDisplayOrder
	end)
	v4[v_u_12.Name] = v_u_12
	v_u_14:GetPropertyChangedSignal("TopbarInset"):Connect(v15)
	v_u_13.Size = UDim2.new(1, 0, 0, v_u_14.TopbarInset.Height + v_u_11)
	local v_u_16 = v_u_8:Clone()
	v_u_16.Name = v_u_16.Name .. "Clipped"
	v_u_16.DisplayOrder = v_u_16.DisplayOrder + 1
	p_u_1.baseDisplayOrderChanged:Connect(function()
		-- upvalues: (copy) v_u_16, (copy) p_u_1
		v_u_16.DisplayOrder = p_u_1.baseDisplayOrder + 1
	end)
	v4[v_u_16.Name] = v_u_16
	local v_u_17 = v_u_12:Clone()
	v_u_17.Name = v_u_17.Name .. "Clipped"
	v_u_17.DisplayOrder = v_u_17.DisplayOrder + 1
	p_u_1.baseDisplayOrderChanged:Connect(function()
		-- upvalues: (copy) v_u_17, (copy) p_u_1
		v_u_17.DisplayOrder = p_u_1.baseDisplayOrder + 1
	end)
	v4[v_u_17.Name] = v_u_17
	if v3 then
		task.defer(function()
			-- upvalues: (copy) v_u_14, (copy) p_u_1
			local function v18()
				-- upvalues: (ref) v_u_14, (ref) p_u_1
				if v_u_14.MenuIsOpen then
					p_u_1.setTopbarEnabled(false, true)
				else
					p_u_1.setTopbarEnabled()
				end
			end
			v_u_14:GetPropertyChangedSignal("MenuIsOpen"):Connect(v18)
			if v_u_14.MenuIsOpen then
				p_u_1.setTopbarEnabled(false, true)
			else
				p_u_1.setTopbarEnabled()
			end
		end)
	end
	local v19 = Instance.new("ScrollingFrame")
	v19:SetAttribute("IsAHolder", true)
	v19.Name = "Left"
	v19.Position = UDim2.fromOffset(v7, 0)
	v19.Size = UDim2.new(1, -24, 1, 0)
	v19.BackgroundTransparency = 1
	v19.Visible = true
	v19.ZIndex = 1
	v19.Active = false
	v19.ClipsDescendants = true
	v19.HorizontalScrollBarInset = Enum.ScrollBarInset.None
	v19.CanvasSize = UDim2.new(0, 0, 1, -1)
	v19.AutomaticCanvasSize = Enum.AutomaticSize.X
	v19.ScrollingDirection = Enum.ScrollingDirection.X
	v19.ScrollBarThickness = 0
	v19.BorderSizePixel = 0
	v19.Selectable = false
	v19.ScrollingEnabled = false
	v19.ElasticBehavior = Enum.ElasticBehavior.Never
	v19.Parent = v9
	local v20 = Instance.new("UIListLayout")
	v20.Padding = UDim.new(0, v7)
	v20.FillDirection = Enum.FillDirection.Horizontal
	v20.SortOrder = Enum.SortOrder.LayoutOrder
	v20.VerticalAlignment = Enum.VerticalAlignment.Bottom
	v20.HorizontalAlignment = Enum.HorizontalAlignment.Left
	v20.Parent = v19
	local v21 = v19:Clone()
	v21.ScrollingEnabled = false
	v21.UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v21.Name = "Center"
	v21.Parent = v_u_13
	local v22 = v19:Clone()
	v22.UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Right
	v22.Name = "Right"
	v22.AnchorPoint = Vector2.new(1, 0)
	v22.Position = UDim2.new(1, -12, 0, 0)
	v22.Parent = v9
	return v4
end