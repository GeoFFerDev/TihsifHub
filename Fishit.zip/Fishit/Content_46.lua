-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return { "rbxassetid://107631662821019", "rbxassetid://124285589496045", "rbxassetid://73584898979097" }