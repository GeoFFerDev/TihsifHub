-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 229,
		["Type"] = "Fishing Rods",
		["Name"] = "Continuum",
		["Description"] = "",
		["Icon"] = "rbxassetid://130099517650165",
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(1.1, 2.5, 1.5),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, -1.7453292519943295),
	["_moduleScript"] = script
}
return v1