-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 67,
		["Type"] = "Fish",
		["Name"] = "Copperband Butterfly",
		["Description"] = "",
		["Icon"] = "rbxassetid://79518413256091",
		["Tier"] = 2
	},
	["SellPrice"] = 76,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2, 2.5),
		["Default"] = NumberRange.new(1.3, 1.5)
	},
	["Probability"] = {
		["Chance"] = 0.05
	},
	["_moduleScript"] = script
}
return v1