-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 38,
		["Type"] = "Boats",
		["Name"] = "Coral Boat",
		["Description"] = "",
		["Icon"] = "rbxassetid://130062988982461",
		["Tier"] = 3
	},
	["HiddenInShop"] = true,
	["Seats"] = 2,
	["_moduleScript"] = script
}
return v1