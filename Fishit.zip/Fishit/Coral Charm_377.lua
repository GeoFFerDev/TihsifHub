-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 10,
		["Type"] = "Charms",
		["Name"] = "Coral Charm",
		["Description"] = "Needs a description!",
		["Icon"] = "rbxassetid://129103716673614",
		["NewIcon"] = true,
		["Tier"] = 2
	},
	["Level"] = 10,
	["Uses"] = 100,
	["C0"] = CFrame.identity,
	["C1"] = CFrame.identity,
	["Modifiers"] = {
		["BaseLuck"] = 0
	},
	["FishModifiers"] = {},
	["Downloadable"] = true,
	["_moduleScript"] = script
}
return v1