-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 17,
		["Type"] = "Lanterns",
		["Name"] = "Coral Lantern",
		["Description"] = "",
		["Icon"] = "rbxassetid://79640818747976",
		["Tier"] = 3
	},
	["GripC0"] = CFrame.new(Vector3.new(0, 1.8, -1.4)) * CFrame.fromOrientation(0, -1.5707963267948966, 0),
	["_moduleScript"] = script
}
return v1