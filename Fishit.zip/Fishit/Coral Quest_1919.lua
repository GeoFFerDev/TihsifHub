-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Collect Corals for Dorian",
	["AssociatedTier"] = 2
}
local v4 = {}
local v5 = {
	["Id"] = 1,
	["Name"] = "Collect 30 corals!",
	["Goal"] = 30,
	["Type"] = "Search",
	["Requirements"] = {
		["Object"] = "Coral"
	}
}
local v6 = {
	["Id"] = 2,
	["Name"] = "Handover corals to Dorian",
	["Goal"] = 1,
	["Type"] = "SpeakWithNPC",
	["Requirements"] = {
		["NPC"] = "Dorian",
		["Path"] = 1,
		["Index"] = 2
	}
}
__set_list(v4, 1, {v5, v6})
v3.Objectives = v4
v3.NPC = "Dorian"
v3.Reward = v2.lanternReward("Coral Lantern")
v3.Ordered = true
return v3