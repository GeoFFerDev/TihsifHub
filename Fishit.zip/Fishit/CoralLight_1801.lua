-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = require(v_u_2.Packages.Replion)
local v_u_4 = require(v_u_2.Packages.Observers)
local v5 = require(v_u_2.Packages.Trove)
require(v_u_2.Packages.Signal)
local v_u_6 = nil
local v_u_7 = v5.new()
local function v_u_15(p_u_8)
	-- upvalues: (copy) v_u_7
	local v9, v10, v11 = p_u_8.Color:ToHSV()
	local v12 = Instance.new("PointLight")
	v12.Brightness = 0.7
	v12.Range = 14
	local v13 = Color3.fromHSV
	local v14 = v10 + 0.2
	v12.Color = v13(v9, math.min(v14, 1), v11)
	v12.Parent = p_u_8
	p_u_8.Material = Enum.Material.Neon
	v_u_7:Add(v12)
	v_u_7:Add(function()
		-- upvalues: (copy) p_u_8
		p_u_8.Material = Enum.Material.SmoothPlastic
	end)
end
v3.Client:AwaitReplion("Time", function(_)
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (copy) v_u_1, (copy) v_u_15, (copy) v_u_7, (copy) v_u_4
	v_u_6 = require(v_u_2.Controllers.ClientTimeController)
	v_u_6.NightTimeChanged:Connect(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_1, (ref) v_u_15, (ref) v_u_7
		if v_u_6.NightTime then
			for _, v16 in ipairs(v_u_1:GetTagged("CoralLight")) do
				v_u_15(v16)
			end
		else
			v_u_7:Clean()
		end
	end)
	v_u_4.observeTag("CoralLight", function(p17)
		-- upvalues: (ref) v_u_6, (ref) v_u_15
		if v_u_6.NightTime then
			v_u_15(p17)
		end
		return function() end
	end, { workspace })
end)
return {}