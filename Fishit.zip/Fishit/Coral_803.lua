-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 392,
		["Type"] = "Fish",
		["Name"] = "Coral",
		["Description"] = "",
		["Icon"] = "rbxassetid://96235449127344",
		["Tier"] = 1
	},
	["SellPrice"] = 25,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.2, 0.4),
		["Default"] = NumberRange.new(0.06, 0.12)
	},
	["Probability"] = {
		["Chance"] = 0.16666666666666666
	},
	["_moduleScript"] = script
}
return v1