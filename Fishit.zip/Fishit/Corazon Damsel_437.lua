-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 31,
		["Type"] = "Fish",
		["Name"] = "Corazon Damsel",
		["Description"] = "",
		["Icon"] = "rbxassetid://117026260439113",
		["Tier"] = 1
	},
	["SellPrice"] = 19,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.6, 2),
		["Default"] = NumberRange.new(1, 1.2)
	},
	["Probability"] = {
		["Chance"] = 0.5
	},
	["_moduleScript"] = script
}
return v1