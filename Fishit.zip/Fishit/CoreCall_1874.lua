-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("StarterGui")
return function(p2, ...)
	-- upvalues: (copy) v_u_1
	local v3 = 0
	local v4 = nil
	while v3 < 10 do
		v3 = v3 + 1
		local v5, v6 = pcall(v_u_1[p2], v_u_1, ...)
		if v5 then
			return v6
		end
		if v3 == 10 then
			error("Error calling " .. p2 .. " even after 10 tries: " .. tostring(v6))
		end
		task.wait(1)
	end
	return v4
end