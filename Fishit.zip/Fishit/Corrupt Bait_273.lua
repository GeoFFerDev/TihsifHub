-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 15,
		["Type"] = "Baits",
		["Name"] = "Corrupt Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://115453224698341",
		["Tier"] = 6
	},
	["Price"] = 1148484,
	["Modifiers"] = {
		["BaseLuck"] = 2.2,
		["ShinyMultiplier"] = 0.1,
		["MutationMultiplier"] = 0.1
	},
	["_moduleScript"] = script
}
return v1