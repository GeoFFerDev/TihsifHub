-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 1,
		["Type"] = "Variant",
		["Name"] = "Corrupt",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(165, 20, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(83, 3, 223)) })
	},
	["Versions"] = 1,
	["Colors"] = 5,
	["SellMultiplier"] = 3.5,
	["Probability"] = {
		["Chance"] = 0.5
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1