-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 40,
		["Type"] = "Baits",
		["Name"] = "Cosmic Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://105265284728535",
		["Tier"] = 6
	},
	["Modifiers"] = {
		["GalaxyMultiplierMultiplier"] = 1
	},
	["_moduleScript"] = script
}
return v1