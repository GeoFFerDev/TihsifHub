-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
require(v2.Packages.Observers)
local v3 = require(v2.Packages.Thread)
local v_u_4 = require(v2.Shared.Constants)
v3:Execute(2, function()
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v5 = workspace:GetServerTimeNow()
	local v6 = v_u_1:GetTagged("DHMSLabel")
	for _, v7 in ipairs(v6) do
		local v8 = v7:GetAttribute("LinkedFlag")
		local v9 = v7:GetAttribute("MarkOffsale")
		local v10
		if v8 then
			v10 = v_u_4.Flags[v8]
		else
			v10 = nil
		end
		local v11 = v10 or v7:GetAttribute("Expires")
		if v11 then
			local v12 = v11 - v5
			local v13 = math.max(v12, 0)
			local v14
			if v9 and v13 == 0 then
				v14 = "OFFSALE!"
			else
				local v15 = v13 % 86400
				local v16 = v13 / 86400
				local v17 = math.floor(v16)
				local v18 = v15 / 3600
				local v19 = math.floor(v18)
				local v20 = v15 % 3600 / 60
				local v21 = math.floor(v20)
				local v22 = v13 % 60
				local v23 = math.floor(v22)
				local v24 = math.floor(v17)
				if v24 == 0 then
					v14 = ("%dH %dM %dS"):format(v19, v21, v23)
				else
					v14 = ("%dD %dH %dM %dS"):format(v24, v19, v21, v23)
				end
			end
			v7.Text = v14
		end
	end
	local v25 = v_u_1:GetTagged("TimeLabel")
	for _, v26 in ipairs(v25) do
		local v27 = (v26:GetAttribute("Expires") or 0) - v5
		local v28 = math.max(v27, 0)
		local v29 = v28 % 86400
		local v30 = v28 / 86400
		local v31 = math.floor(v30)
		local v32 = v29 / 3600
		local v33 = math.floor(v32)
		local v34 = v29 % 3600 / 60
		local v35 = math.floor(v34)
		local v36 = v28 % 60
		v26.Text = ("%d:%d:%d:%d"):format(v31, v33, v35, (math.floor(v36)))
	end
end)
return {}