-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v2 = game:GetService("ReplicatedStorage")
local v3 = require(v2.Packages.Observers)
local v_u_4 = require(v2.Modules.Util.FormatUtil)
v3.observeTag("CountdownTimer", function(p_u_5)
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v_u_6 = p_u_5:GetAttribute("Timestamp")
	if v_u_6 then
		v_u_1.Heartbeat:Connect(function()
			-- upvalues: (copy) v_u_6, (copy) p_u_5, (ref) v_u_4
			if v_u_6 - os.time() > 0 then
				p_u_5.Text = v_u_4.toDHMS(v_u_6 - os.time(), true)
			else
				p_u_5.Text = "NOW!"
			end
		end)
	end
end)
return {}