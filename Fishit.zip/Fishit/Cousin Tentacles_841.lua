-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 429,
		["Type"] = "Fish",
		["Name"] = "Cousin Tentacles",
		["Description"] = "",
		["Icon"] = "rbxassetid://84052975001558",
		["Tier"] = 5
	},
	["SellPrice"] = 5500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(6, 8),
		["Default"] = NumberRange.new(3, 5)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["EventTag"] = "CLASSIC25",
	["_moduleScript"] = script
}
return v1