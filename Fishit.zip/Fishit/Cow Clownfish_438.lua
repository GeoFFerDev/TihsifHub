-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 57,
		["Type"] = "Fish",
		["Name"] = "Cow Clownfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://88952725333000",
		["Tier"] = 4
	},
	["SellPrice"] = 1044,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.9, 1.1),
		["Default"] = NumberRange.new(0.6, 0.7)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["_moduleScript"] = script
}
return v1