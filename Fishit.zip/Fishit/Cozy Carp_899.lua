-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 515,
		["Type"] = "Fish",
		["Name"] = "Cozy Carp",
		["Description"] = "",
		["Icon"] = "rbxassetid://132774419130197",
		["Tier"] = 1
	},
	["SellPrice"] = 22,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(4, 6.5),
		["Default"] = NumberRange.new(2.2, 3.5)
	},
	["Probability"] = {
		["Chance"] = 0.25
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1