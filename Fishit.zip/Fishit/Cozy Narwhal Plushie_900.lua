-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 492,
		["Type"] = "Fish",
		["Name"] = "Cozy Narwhal Plushie",
		["Description"] = "",
		["Icon"] = "rbxassetid://117646921482495",
		["Tier"] = 4
	},
	["SellPrice"] = 1700,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.2, 3.5),
		["Default"] = NumberRange.new(1.3, 1.8)
	},
	["Probability"] = {
		["Chance"] = 0.0006666666666666666
	},
	["EventTag"] = "XMAS25",
	["_moduleScript"] = script
}
return v1