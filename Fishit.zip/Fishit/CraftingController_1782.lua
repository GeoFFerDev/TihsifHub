-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Players")
local v3 = require(v1.Packages.Trove)
local v_u_4 = require(v1.Packages.Replion)
require(v1.Packages.MarketplaceService)
local v_u_5 = require(v1.Shared.TierUtility)
local v_u_6 = require(v1.Shared.ItemUtility)
local v_u_7 = require(v1.Shared.CraftingItems)
local v_u_8 = require(v1.Shared.InventoryMapping)
local v_u_9 = require(v1.Shared.RewardInfo)
local v_u_10 = require(v1.Shared.Soundbook)
local v_u_11 = require(v1.Modules.GuiControl)
local v_u_12 = require(v1.Shared.PolicyWrapper)
local v_u_13 = require(v1.Controllers.ModelProjectionController)
local v_u_14 = require(v1.Controllers.TextNotificationController)
require(v1.Types.Modifiers)
local v_u_15 = v2.LocalPlayer
local v16 = v_u_15.PlayerGui
local v_u_17 = nil
local v_u_18 = v16:WaitForChild("Crafting")
local v_u_19 = v_u_18.Frame.Frame.Right
local v_u_20 = v_u_18.Frame.Left
local v_u_21 = v_u_20.ScrollingFrame.CraftTile
v_u_21.Parent = nil
local v_u_22 = v_u_20.ScrollingFrame.PaidTile
v_u_22.Parent = nil
local v_u_23 = v_u_19.ScrollingFrame.IngredientTile
v_u_23.Parent = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = v3.new()
local v_u_27 = {}
local function v_u_30(p28)
	-- upvalues: (copy) v_u_14
	local v29 = {
		["Type"] = "Text",
		["Text"] = p28,
		["TextColor"] = {
			["R"] = 255,
			["G"] = 0,
			["B"] = 0
		}
	}
	v_u_14:DeliverNotification(v29)
end
function v_u_27.Start(_)
	-- upvalues: (ref) v_u_17, (copy) v_u_4, (copy) v_u_19, (copy) v_u_15, (copy) v_u_27, (copy) v_u_10, (copy) v_u_11, (ref) v_u_24, (copy) v_u_30, (copy) v_u_7, (copy) v_u_18
	v_u_17 = v_u_4.Client:WaitReplion("Data")
	local v_u_31 = v_u_19.Options.BuyButton.Button
	local v32 = v_u_19.Options.CraftButton.Button
	v_u_15:GetAttributeChangedSignal("InstantCraftReroll"):Connect(function()
		-- upvalues: (ref) v_u_15, (ref) v_u_27, (ref) v_u_10
		local v33 = v_u_15:GetAttribute("InstantCraftReroll")
		if v33 then
			v_u_27:Expand(v33)
			v_u_27:Show3D(v33)
			v_u_10.Sounds.CraftSound:Play()
		end
	end)
	v_u_11:Hook("Hold Button", v32).Clicked:Connect(function()
		-- upvalues: (ref) v_u_24, (ref) v_u_30, (ref) v_u_7, (ref) v_u_17, (ref) v_u_27
		if v_u_24 then
			local v34 = v_u_7.Items[v_u_24]
			if v34 then
				if v_u_7:Verify(v_u_17, v34) then
					if v_u_17:Find("CompletedQuests", "Kohana Gatekeeper") then
						v_u_27:Show3D(v_u_24)
					else
						v_u_30("You must complete the Kohana Gatekeeper quest!")
					end
				else
					v_u_30("You don\'t own all resources!")
					return
				end
			else
				v_u_30("Unknown item selected!")
				return
			end
		else
			v_u_30("Nothing was selected!")
			return
		end
	end)
	v_u_11.GuiUnfocusedSignal:Connect(function(p35)
		-- upvalues: (ref) v_u_18, (ref) v_u_27
		if p35 == v_u_18 then
			v_u_27:Clear()
		end
	end)
	local v_u_36 = nil
	v_u_36 = v_u_11.GuiFocusedSignal:Connect(function(p37)
		-- upvalues: (ref) v_u_18, (ref) v_u_36, (ref) v_u_27
		if p37 == v_u_18 then
			v_u_36:Disconnect()
			v_u_27:_render()
			v_u_27:Expand("Winged Charm")
		end
	end)
	if v_u_17:Find("CompletedQuests", "Kohana Gatekeeper") then
		v_u_31:SetAttribute("DevProductId", 3531959716)
		v_u_31:AddTag("DevProductPrice")
		v_u_31:AddTag("DevProductPurchase")
	else
		local v_u_38 = v_u_11:Hook("Hold Button", v_u_31)
		v_u_38.Clicked:Connect(function()
			-- upvalues: (ref) v_u_30
			v_u_30("You must complete the Kohana Gatekeeper quest!")
		end)
		v_u_17:OnArrayInsert("CompletedQuests", function(_, p39)
			-- upvalues: (ref) v_u_17, (copy) v_u_38, (copy) v_u_31
			if p39 == "Kohana Gatekeeper" or v_u_17:Find("CompletedQuests", "Kohana Gatekeeper") then
				v_u_38:Destroy()
				v_u_31:SetAttribute("DevProductId", 3531959716)
				v_u_31:AddTag("DevProductPrice")
				v_u_31:AddTag("DevProductPurchase")
			end
		end)
	end
end
function v_u_27._render(_)
	-- upvalues: (copy) v_u_12, (copy) v_u_15, (copy) v_u_27, (copy) v_u_7
	local v40, v41 = v_u_12:_getPolicy(v_u_15)
	if v40 and v41 and not v41.ArePaidRandomItemsRestricted then
		v_u_27:_renderItem("Astryx Core", true)
	end
	for v42, _ in pairs(v_u_7.Items) do
		v_u_27:_renderItem(v42, false)
	end
end
function v_u_27._renderItem(_, p_u_43, p_u_44)
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_22, (copy) v_u_21, (copy) v_u_11, (copy) v_u_27, (copy) v_u_20
	local v45 = v_u_6.GetItemDataFromItemType(p_u_44 and "Gears" or "Charms", p_u_43)
	if v45 then
		local v46
		if v45.Probability then
			v46 = v_u_5:GetTier(v45.Probability.Chance)
		else
			v46 = v_u_5:GetTier(v45.Data.Tier)
		end
		local v47 = p_u_44 and 10000 or 100
		local v48
		if p_u_44 then
			v48 = v_u_22
		else
			v48 = v_u_21
		end
		local v49 = v48:Clone()
		if not p_u_44 then
			local v50 = v49.UIStroke:FindFirstChildWhichIsA("UIGradient")
			if v50 then
				v50.Color = v46.TierColor
				v50:AddTag("AnimateTier")
			end
			local v51 = v49.Box.UIStroke:FindFirstChildWhichIsA("UIGradient")
			if v51 then
				v51.Color = v46.TierColor
				v51:AddTag("AnimateTier")
			end
			v49.Box.Glow.UIGradient.Color = v46.TierColor
			v49.Box.Glow.UIGradient:AddTag("AnimateTier")
		end
		v49.Box.Icon.Image = v45.Data.Icon or ""
		v49.ItemName.Text = v45.Data.Name or ""
		v_u_11:Hook("Hold Button", v49).Clicked:Connect(function()
			-- upvalues: (ref) v_u_27, (copy) p_u_43, (copy) p_u_44
			v_u_27:Expand(p_u_43, p_u_44)
		end)
		local v52 = v46.Tier * -v47
		local v53 = v45.Data.Name
		v49.LayoutOrder = v52 - string.len(v53)
		v49.Parent = v_u_20.ScrollingFrame
	end
end
function v_u_27.Clear(_)
	-- upvalues: (copy) v_u_19, (copy) v_u_26, (ref) v_u_24
	v_u_19.Visible = false
	v_u_26:Clean()
	v_u_24 = nil
end
function v_u_27.Expand(_, p54, p55)
	-- upvalues: (copy) v_u_26, (ref) v_u_24, (copy) v_u_7, (copy) v_u_9, (copy) v_u_19, (copy) v_u_6, (copy) v_u_5, (copy) v_u_23, (copy) v_u_27
	v_u_26:Clean()
	v_u_24 = p54
	local v56 = {}
	if p55 then
		for v57, _ in pairs(v_u_7.Weighted) do
			local v58 = v_u_9.charmReward
			table.insert(v56, v58(v57, 1))
		end
	else
		v56 = v_u_7.Items[p54].Ingredients
	end
	v_u_19.ScrollingFrame.Header.Text = p55 and "RANDOM CHANCE" or "Required Materials"
	for _, v59 in pairs(v56) do
		local v_u_60 = v_u_6.GetItemDataFromItemType(v59.Type, v59.Identifier)
		if v_u_60 then
			local v61
			if v_u_60.Probability then
				v61 = v_u_5:GetTierFromRarity(v_u_60.Probability.Chance)
			else
				v61 = v_u_5:GetTier(v_u_60.Data.Tier)
			end
			if v61 then
				local v_u_62 = v59.Quantity or 1
				local v63 = v_u_23:Clone()
				local v_u_64 = v63.Count
				local v_u_65 = v63.Paid
				v_u_65.Visible = p55
				v63.UIGradient.Color = v61.TierColor
				v63.UIStroke.UIGradient.Color = v61.TierColor
				v63.Box.UIStroke.UIGradient.Color = v61.TierColor
				v63.Box.Glow.UIGradient.Color = v61.TierColor
				v63.Box.Icon.Image = v_u_60.Data.Icon or ""
				v63.ItemName.Text = v_u_60.Data.Name or ""
				if v61.Tier >= 5 then
					v63.UIStroke.UIGradient:AddTag("AnimateTier")
					v63.Box.UIStroke.UIGradient:AddTag("AnimateTier")
					v63.Box.Glow.UIGradient:AddTag("AnimateTier")
				else
					v63.UIStroke.UIGradient:RemoveTag("AnimateTier")
					v63.Box.UIStroke.UIGradient:RemoveTag("AnimateTier")
					v63.Box.Glow.UIGradient:RemoveTag("AnimateTier")
				end
				local v68 = p55 and function()
					-- upvalues: (ref) v_u_7, (copy) v_u_60, (copy) v_u_65, (copy) v_u_64
					local v66 = v_u_7.Weighted[v_u_60.Data.Name]
					if v66 then
						v_u_65.Text = ("%*%% Chance"):format(v66)
					else
						v_u_65.Text = "?? Chance"
					end
					v_u_64.Text = "x1"
				end or function(p67)
					-- upvalues: (copy) v_u_64, (copy) v_u_62
					v_u_64.Text = ("%* / %*"):format(p67, v_u_62)
				end
				local v69 = v_u_27:ObserveTile(v59.Type, v59.Identifier, v68)
				if v69 then
					v_u_26:Add(v69)
				end
				v63.LayoutOrder = -v61.Tier
				v63.Parent = v_u_19.ScrollingFrame
				v_u_26:Add(v63)
			else
				warn((("[Error] Unable to draw tile for %* %* due to missing tier data!"):format(v59.Type, v59.Identifier)))
			end
		end
	end
	v_u_19.Options.BuyButton.Visible = p55 and true or false
	v_u_19.Options.CraftButton.Visible = not p55
	v_u_19.Visible = true
end
function v_u_27.Show3D(_, p70, p71)
	-- upvalues: (ref) v_u_25, (copy) v_u_11, (copy) v_u_13
	v_u_25 = p70
	v_u_11:Close(true)
	v_u_13:Focus("Charms", p70, p71)
	v_u_11:Lock()
end
function v_u_27.ObserveTile(_, p72, p73, p_u_74)
	-- upvalues: (copy) v_u_8, (copy) v_u_6, (ref) v_u_17
	local v_u_75 = nil
	local v76 = v_u_8[p72] or "Items"
	local v_u_77 = v_u_6.GetItemDataFromItemType(p72, p73)
	if v_u_77 then
		local v_u_78 = { "Inventory", v76 }
		local function v82()
			-- upvalues: (ref) v_u_17, (copy) v_u_78, (copy) v_u_77, (copy) p_u_74
			local v79 = 0
			local v80 = v_u_17:Get(v_u_78)
			if v80 then
				for _, v81 in ipairs(v80) do
					if v81.Id == v_u_77.Data.Id then
						v79 = v79 + (v81.Quantity or 1)
					end
				end
			end
			p_u_74(v79)
		end
		task.defer(v82)
		v_u_75 = v_u_17:OnChange(v_u_78, v82)
	else
		warn((("Unable to observe charm tile with data: %* - %*!"):format(p72, p73)))
		p_u_74(0)
	end
	return function()
		-- upvalues: (ref) v_u_75
		if v_u_75 then
			v_u_75:Disconnect()
		end
	end
end
return v_u_27