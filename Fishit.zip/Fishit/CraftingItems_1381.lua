-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
require(v1.Packages.Replion)
local v_u_2 = require(v1.Shared.ItemUtility)
local v_u_3 = require(v1.Shared.InventoryMapping)
local v4 = require(v1.Shared.RewardInfo)
local v_u_5 = require(v1.Shared.PlayerStatsUtility)
require(v1.Types.Modifiers)
local v6 = {}
local v7 = {
	["Winged Charm"] = {
		["Ingredients"] = { v4.itemReward("Rope", 2), v4.itemReward("Driftwood", 1) },
		["Minigame"] = "Basic",
		["Reward"] = v4.charmReward("Winged Charm", 1)
	},
	["Oculus Charm"] = {
		["Ingredients"] = {
			v4.itemReward("Veilshard", 2),
			v4.itemReward("Cave Crystal", 1),
			v4.itemReward("Embercrux", 1),
			v4.itemReward("Pyrafruit Relic", 1)
		},
		["Minigame"] = "Basic",
		["Reward"] = v4.charmReward("Oculus Charm", 1)
	},
	["Anchor Charm"] = {
		["Ingredients"] = { v4.itemReward("Pyrafruit Relic", 1), v4.itemReward("Embercrux", 1) },
		["Minigame"] = "Basic",
		["Reward"] = v4.charmReward("Anchor Charm", 1)
	},
	["Hook Charm"] = {
		["Ingredients"] = { v4.itemReward("Rope", 3) },
		["Minigame"] = "Basic",
		["Reward"] = v4.charmReward("Hook Charm", 1)
	}
}
v6.Items = v7
v6.Weighted = {
	["Hook Charm"] = 60,
	["Winged Charm"] = 25,
	["Anchor Charm"] = 10,
	["Oculus Charm"] = 5
}
function v6.Verify(_, p8, p9)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5
	local v10 = #p9.Ingredients
	local v11 = 0
	local v12 = {}
	for _, v13 in ipairs(p9.Ingredients) do
		local v_u_14 = v_u_2.GetItemDataFromItemType(v13.Type, v13.Identifier)
		if v_u_14 then
			local v_u_15 = v13.Quantity or 1
			local v17, v18 = v_u_5:GetItemFromInventory(p8, function(p16)
				-- upvalues: (copy) v_u_14, (copy) v_u_15
				if p16.Id == v_u_14.Data.Id then
					return v_u_15 <= (p16.Quantity or 1)
				else
					return false
				end
			end, v_u_3[v13.Type] or "Items")
			if v17 then
				local v19 = v_u_2.GetItemDataFromItemType(v18.Category, v17.Id)
				if v19 then
					local v20
					if v_u_14.Data.Id == v19.Data.Id then
						v20 = v_u_14.Data.Type == v19.Data.Type
					else
						v20 = false
					end
					if v20 then
						v11 = v11 + 1
						local v21 = v17.UUID
						table.insert(v12, v21)
					end
				end
			end
		end
	end
	return v11 == v10, v12
end
return v6