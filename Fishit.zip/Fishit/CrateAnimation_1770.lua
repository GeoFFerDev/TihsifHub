-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(script.Parent.CreateParticleHost)
local v_u_5 = require(script.Parent.RenderStepped)
local v_u_6 = require(script.Parent.Easing)
local v_u_7 = require(script.Parent.Emit)
local v8 = require(v_u_1.Packages.Net)
local v_u_9 = require(v_u_1.SkinCrates)
local v_u_10 = require(v_u_1.EmoteCrates)
local v_u_11 = require(v_u_1.Shared.Soundbook)
local v_u_12 = require(script.Parent.CrateAnimationHelpers.MathUtils)
local v_u_13 = require(script.Parent.CrateAnimationHelpers.ModelUtils)
local v_u_14 = require(script.Parent.CrateAnimationHelpers.ItemModelUtils)
local v_u_15 = require(script.Parent.CrateAnimationHelpers.ParticleUtils)
local v_u_16 = require(script.Parent.CrateAnimationHelpers.AnimationUtils)
local v_u_17 = require(script.Parent.CrateAnimationHelpers.RollingAnimation)
local v_u_18 = require(script.Parent.CrateAnimationHelpers.BillboardUtils)
local v_u_19 = v8:RemoteEvent("CrateItemCollected")
local v_u_20 = script:WaitForChild("CrateItemBillboard")
return {
	["new"] = function(p21)
		-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_4, (copy) v_u_14, (copy) v_u_15, (copy) v_u_7, (copy) v_u_16, (copy) v_u_5, (copy) v_u_6, (copy) v_u_12, (copy) v_u_17, (copy) v_u_18, (copy) v_u_3, (copy) v_u_20, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_2, (copy) v_u_19
		local v22 = p21.Assets
		local v23 = p21.Settings
		local v_u_24 = p21.ItemUtility
		local v25 = p21.ModelDownloader
		local v_u_26 = p21.Debris
		local v27 = p21.activeEggs
		local v_u_28 = require(v_u_1.Shared.TierUtility)
		local v_u_29 = v23.Timings
		local v_u_30 = v23.Other
		local v31 = {
			["CreateParticleHost"] = v_u_4,
			["Assets"] = v22,
			["Settings"] = v23
		}
		local v32 = v_u_13.new(v31)
		local v33 = v_u_14.new({
			["ItemUtility"] = v_u_24,
			["ModelDownloader"] = v25
		})
		local v34 = {
			["CreateParticleHost"] = v_u_4,
			["Emit"] = v_u_7,
			["Assets"] = v22,
			["Debris"] = v_u_26
		}
		local v35 = v_u_15.new(v34)
		local v36 = v_u_16.new({
			["RenderStepped"] = v_u_5,
			["Easing"] = v_u_6,
			["Settings"] = v23,
			["activeEggs"] = v27,
			["Bezier"] = v_u_12.Bezier,
			["autoControlPoint"] = v_u_12.autoControlPoint
		})
		local v37 = v_u_17.new({
			["RenderStepped"] = v_u_5,
			["Easing"] = v_u_6,
			["getItemToShow"] = v33.getItemToShow,
			["normalizeItemModel"] = v32.normalizeItemModel,
			["ensurePrimaryPart"] = v32.ensurePrimaryPart,
			["setModelBaseParts"] = v32.setModelBaseParts
		})
		local v38 = {
			["TweenService"] = v_u_3,
			["billboardTemplate"] = v_u_20
		}
		local v39 = v_u_18.new(v38)
		local v_u_40 = v32.createCaseModel
		local v_u_41 = v32.normalizeItemModel
		local v_u_42 = v32.ensurePrimaryPart
		local v_u_43 = v32.setModelBaseParts
		local v_u_44 = v33.getItemToShow
		local v_u_45 = v35.emitParticles
		local v_u_46 = v36.scaleModelIn
		local v_u_47 = v36.moveModelToOffset
		local v_u_48 = v36.bounceModel
		local v_u_49 = v36.hopSpinModel
		local v_u_50 = v36.shakeModel
		local v_u_51 = v36.animateLid
		local _ = v36.applyLegendaryLight
		local v_u_52 = v37.performRollingAnimation
		local v_u_53 = v39.getCrateItemChance
		local v_u_54 = v39.formatChanceText
		local v_u_55 = v39.createItemBillboard
		local v_u_56 = v_u_12.lookAtTarget
		local function v_u_60(p57)
			if not p57 then
				return false
			end
			local v58 = false
			for _, v59 in ipairs(p57.Items) do
				if v59.Currency == "ItemReward" then
					if v59.CurrencyRewardInfo[1] ~= "Emotes" then
						return false
					end
					v58 = true
				end
			end
			return v58
		end
		return {
			["performAnimation"] = function(p61)
				-- upvalues: (ref) v_u_9, (ref) v_u_10, (copy) v_u_60, (copy) v_u_40, (copy) v_u_29, (ref) v_u_11, (copy) v_u_46, (copy) v_u_47, (copy) v_u_56, (copy) v_u_45, (copy) v_u_49, (copy) v_u_30, (copy) v_u_48, (copy) v_u_50, (copy) v_u_51, (ref) v_u_6, (ref) v_u_5, (copy) v_u_44, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43, (ref) v_u_12, (ref) v_u_2, (ref) v_u_19, (copy) v_u_52, (copy) v_u_24, (copy) v_u_28, (copy) v_u_53, (copy) v_u_54, (copy) v_u_55, (ref) v_u_3, (copy) v_u_26
				local v_u_62 = p61.player
				local v63 = p61.origin
				local v64 = p61.position
				local v65 = p61.caseId
				local v66 = v_u_9[v65] or (v_u_10[v65] or nil)
				local v67
				if v66 then
					v67 = v66.Color
				else
					v67 = v66
				end
				local v68 = v_u_60(v66)
				local v_u_69, v70 = v_u_40(p61)
				local v_u_71 = v_u_69.PrimaryPart
				assert(v_u_71)
				task.wait((p61.partyIndex - 1) * v_u_29.DelayPerCase)
				local _ = v_u_29.legendaryEffectDuration
				local v72 = v_u_62.Character
				assert(v72)
				local v73 = v72.PrimaryPart
				assert(v73)
				local v74 = v73:GetPivot().Position
				if v68 then
					v_u_11.Sounds.EmoteCrate:Play(v73)
				end
				if not v68 then
					v_u_11.Sounds.CrateSpawn:Play(v_u_71)
				end
				v_u_46(v_u_69)
				v_u_47(v_u_69, v63, v64)
				v_u_69:PivotTo(v_u_56(v_u_69:GetPivot(), v74))
				v_u_45("Impact", v64, v_u_29.ImpactParticleLifetime, false)
				if not v68 then
					v_u_11.Sounds.CrateLand:Play(v_u_71)
				end
				local v75 = v_u_69:GetPivot()
				if v68 then
					v_u_49(v_u_69, v75, 1, v_u_30.BounceHeight * 1.15, v_u_29.BounceDuration * 1.1, 0.75)
					task.wait(0.15)
				else
					v_u_48(v_u_69, v75)
					task.wait(v_u_29.DramaticPauseDuration)
					task.wait(0.1)
					local v76 = v_u_69:GetPivot()
					if not v68 then
						v_u_11.Sounds.CrateShake:Play(v_u_71)
					end
					v_u_50(v_u_69, p61, v76)
				end
				if v70.Parent then
					v70:Destroy()
				end
				local v77 = v_u_69:GetPivot()
				local v_u_78 = v_u_69:WaitForChild("Light")
				local v79 = v_u_78:FindFirstChildOfClass("SurfaceLight")
				assert(v79)
				v79.Enabled = true
				local v80 = v_u_69:FindFirstChild("Top")
				if v80 then
					v_u_51(v80, v_u_29.LidOpenDegrees)
				end
				if not v68 then
					v_u_11.Sounds.CrateOpen:Play(v_u_71)
					v_u_45("Open", v_u_71.Position, v_u_29.OpenParticleLifetime, true, v67)
				end
				if v68 then
					local v_u_81 = 1 + -0.6799999999999999 * v_u_6.ExpoInOut(0.8933333333333334)
					local v_u_82 = v_u_71.Position
					local v_u_83 = false
					local v_u_84 = Instance.new("Highlight")
					v_u_84.Name = "EmoteCrateShrinkHighlight"
					v_u_84.Adornee = v_u_69
					v_u_84.FillColor = Color3.new(1, 1, 1)
					v_u_84.FillTransparency = 1
					v_u_84.OutlineColor = Color3.new(1, 1, 1)
					v_u_84.OutlineTransparency = 1
					v_u_84.Parent = workspace
					v_u_5(function(_, p85)
						-- upvalues: (ref) v_u_83, (ref) v_u_82, (copy) v_u_71, (ref) v_u_45, (ref) v_u_29, (ref) v_u_11, (copy) v_u_78, (copy) v_u_81, (ref) v_u_6, (copy) v_u_69, (copy) v_u_84
						local v86 = math.max(0, p85)
						local v87 = v86 / 0.75
						local v88 = math.clamp(v87, 0, 1)
						local v89 = (v86 - 0.67) / 0.22
						local v90 = math.clamp(v89, 0, 1)
						if v86 >= 0.67 and not v_u_83 then
							v_u_83 = true
							v_u_82 = v_u_71.Position
							v_u_45("EmoteReveal", v_u_82, v_u_29.OpenParticleLifetime)
							v_u_11.Sounds.CrateLand:Play(v_u_71)
							v_u_78.Transparency = 1
						end
						local v91
						if v90 > 0 then
							v91 = v_u_81 + (0.0001 - v_u_81) * v_u_6.ExpoIn(v90)
						else
							v91 = 1 + -0.6799999999999999 * v_u_6.ExpoInOut(v88)
						end
						v_u_69:ScaleTo((math.max(0.0001, v91)))
						local v92 = 1 - v_u_6.ExpoInOut(v88) * 0.88
						local v93 = math.clamp(v92, 0, 1)
						if v90 > 0 then
							v93 = math.clamp(v90, 0, 1)
						end
						v_u_84.FillTransparency = v93
						if v90 > 0 then
							for _, v94 in ipairs(v_u_69:GetDescendants()) do
								if v94:IsA("BasePart") then
									v94.Transparency = math.clamp(v90, 0, 1)
								end
							end
						end
					end, 0.89, true):Wait()
					local v95
					if v_u_83 then
						v95 = v_u_82
					else
						v_u_82 = v_u_71.Position
						v_u_45("EmoteReveal", v_u_82, v_u_29.OpenParticleLifetime)
						v_u_11.Sounds.CrateLand:Play(v_u_71)
						v_u_78.Transparency = 1
						v95 = v_u_82
					end
					v_u_84:Destroy()
					v_u_69:Destroy()
					local v96 = v_u_44(p61.itemType, p61.itemName, p61.itemId, p61.caseId, v_u_62.UserId)
					if v96 then
						local v_u_97 = v_u_41(v96)
						v_u_42(v_u_97)
						v_u_43(v_u_97)
						for _, v98 in ipairs(v_u_97:GetDescendants()) do
							if v98:IsA("BasePart") then
								v98.Anchored = false
							end
						end
						local v99 = v_u_97.PrimaryPart
						assert(v99)
						v99.Anchored = true
						v_u_97.Parent = workspace
						v_u_97:PivotTo(CFrame.new(v95 + Vector3.new(0, 2.4, 0)))
						v_u_97:PivotTo(v_u_56(v_u_97:GetPivot(), v74))
						local v_u_100 = v_u_97:GetPivot()
						v_u_5(function(_, p101)
							-- upvalues: (copy) v_u_62, (ref) v_u_12, (copy) v_u_100, (copy) v_u_97, (ref) v_u_6
							local v102 = v_u_62.Character
							assert(v102)
							local v103 = v102.PrimaryPart
							assert(v103)
							local v104 = v103:GetPivot().Position
							local v105 = v_u_12.Bezier(v_u_100.Position, v_u_12.autoControlPoint(v_u_100.Position, v104), v104)
							local v106 = CFrame.new(v105(p101)) * v_u_100.Rotation
							local v107 = v104.X
							local v108 = v106.Y
							local v109 = v104.Z
							local v110 = Vector3.new(v107, v108, v109)
							v_u_97:PivotTo((v106.Position - v110).Magnitude < 0.001 and v106 and v106 or CFrame.lookAt(v106.Position, v110))
							local v111 = v_u_97
							local v112 = 1 - v_u_6.ExpoIn(p101) * 0.92
							v111:ScaleTo((math.max(0.02, v112)))
						end, (v_u_29.ItemFlyIntoPlayerDuration + 0.2) * 2.4, true):Wait()
						local v113 = v_u_2.LocalPlayer
						if v113 and v113 == v_u_62 then
							v_u_19:FireServer(p61.itemType, p61.itemId)
						end
						v_u_97:Destroy()
					else
						warn("Could not load emote reveal model for:", p61.itemType, p61.itemName)
					end
				else
					local v114 = v_u_69:GetExtentsSize().Y
					v_u_11.Sounds.CrateItemRoll:Play(v_u_71)
					local v115, v116 = v_u_52(p61, v77, v74, v_u_62.UserId, v114)
					local v_u_117 = v115
					if not v_u_117 then
						local v118 = v_u_44(p61.itemType, p61.itemName, p61.itemId, p61.caseId, v_u_62.UserId)
						if not v118 then
							warn("Could not load item model for:", p61.itemType, p61.itemName)
							v_u_69:Destroy()
							return
						end
						v_u_117 = v_u_41(v118)
						v_u_42(v_u_117)
						v_u_117.Parent = workspace
						v_u_117:PivotTo(v77)
					end
					v_u_117:PivotTo(v_u_56(v_u_117:GetPivot(), v74))
					local v_u_119 = v_u_117:GetPivot()
					if v116 and v116 < v_u_119.Position.Y then
						v_u_119 = CFrame.new(v_u_119.Position.X, v116, v_u_119.Position.Z) * v_u_119.Rotation
					end
					local v_u_120 = v_u_30.ItemLookAtPlayerFloatHeight * 0.4
					local v121 = v_u_24.GetItemDataFromItemType(p61.itemType, p61.itemId)
					local v122 = v_u_28:GetTier(1)
					if v121 and (v121.Data and v121.Data.Tier) then
						v122 = v_u_28:GetTier(v121.Data.Tier)
					end
					local v123 = v_u_53(p61, p61.itemType, p61.itemName)
					local v124 = ("%* - %*"):format(v122.Name, (v_u_54(v123)))
					local v125 = v122.TierColor.Keypoints[1].Value
					local v126 = v_u_55(v_u_117, p61.itemName, v124, v125, v_u_117:GetExtentsSize().Y / 2 + 1.5)
					local v127 = v_u_117.PrimaryPart
					assert(v127)
					if v123 and v123 < 0.1 then
						v_u_11.Sounds.CrateItemRare:Play(v127)
					else
						v_u_11.Sounds.CrateItemNormal:Play(v127)
					end
					v_u_45("Reveal", v_u_117.Main.Position, v_u_29.OpenParticleLifetime, true, v125)
					v_u_5(function(_, p128)
						-- upvalues: (ref) v_u_30, (ref) v_u_119, (copy) v_u_120, (copy) v_u_62, (ref) v_u_117
						local v129 = 4.71238898038469 * p128 * v_u_30.ItemLookAtPlayerFloatRate
						local v130 = math.sin(v129)
						local v131 = -math.abs(v130)
						local v132 = v_u_119
						local v133 = v131 * v_u_120
						local v134 = v132 + Vector3.new(0, v133, 0)
						local v135 = v_u_62.Character
						assert(v135)
						local v136 = v135.PrimaryPart
						assert(v136)
						local v137 = v136:GetPivot().Position
						local v138 = v137.X
						local v139 = v134.Y
						local v140 = v137.Z
						local v141 = Vector3.new(v138, v139, v140)
						v_u_117:PivotTo((v134.Position - v141).Magnitude < 0.001 and v134 and v134 or CFrame.lookAt(v134.Position, v141))
					end, v_u_29.ItemLookAtPlayerDuration + 2, true):Wait()
					local v142 = v126.Size
					v_u_3:Create(v126, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = UDim2.new(v142.X.Scale * 0.15, v142.X.Offset * 0.15, v142.Y.Scale * 0.15, v142.Y.Offset * 0.15)
					}):Play()
					v_u_26:AddItem(v126, 0.2)
					local v_u_143 = v_u_117:GetPivot()
					v_u_5(function(_, p144)
						-- upvalues: (copy) v_u_62, (ref) v_u_12, (copy) v_u_143, (ref) v_u_117, (ref) v_u_6
						local v145 = v_u_62.Character
						assert(v145)
						local v146 = v145.PrimaryPart
						assert(v146)
						local v147 = v146:GetPivot().Position
						local v148 = v_u_12.Bezier(v_u_143.Position, v_u_12.autoControlPoint(v_u_143.Position, v147), v147)
						local v149 = CFrame.new(v148(p144)) * v_u_143.Rotation
						local v150 = v147.X
						local v151 = v149.Y
						local v152 = v147.Z
						local v153 = Vector3.new(v150, v151, v152)
						v_u_117:PivotTo((v149.Position - v153).Magnitude < 0.001 and v149 and v149 or CFrame.lookAt(v149.Position, v153))
						v_u_117:ScaleTo(1 - v_u_6.ExpoIn(p144))
					end, v_u_29.ItemFlyIntoPlayerDuration, true):Wait()
					local v154 = v_u_2.LocalPlayer
					if v154 and v154 == v_u_62 then
						v_u_19:FireServer(p61.itemType, p61.itemId)
					end
					v_u_117:Destroy()
					v79.Enabled = false
					if v80 and not v68 then
						v_u_51(v80, -v_u_29.LidOpenDegrees)
					end
					v_u_45("Explode", v_u_71.Position, v_u_29.OpenParticleLifetime, true)
					v_u_78.Transparency = 1
					v_u_5(function(_, p155)
						-- upvalues: (copy) v_u_69
						local v156 = math.clamp(p155, 0, 1)
						local v157 = v156 / 0.35
						local v158 = math.clamp(v157, 0, 1)
						local v159 = (v156 - 0.35) / 0.65
						local v160 = math.clamp(v159, 0, 1)
						local v161 = v156 < 0.35 and v158 * 0.10000000000000009 + 1 or v160 * -1.0999 + 1.1
						v_u_69:ScaleTo((math.max(0.0001, v161)))
						for _, v162 in ipairs(v_u_69:GetChildren()) do
							if v162:IsA("BasePart") then
								v162.Transparency = math.clamp(v156, 0, 1)
							end
						end
					end, v_u_29.GrowScaleDuration, true):Wait()
					v_u_69:Destroy()
					return
				end
			end
		}
	end
}