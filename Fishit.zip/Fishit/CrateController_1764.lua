-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("Debris")
local v5 = v2:WaitForChild("Assets")
local v6 = require(v2.Packages.Net)
local v_u_7 = require(v2.Shared.ItemUtility)
local v_u_8 = require(v2.SkinCrates)
local v_u_9 = require(v2.EmoteCrates)
local v10 = require(v2.Modules.ModelDownloader)
local v_u_11 = require(v2.Modules.GuiControl)
local v12 = script.Modules
local v13 = require(v12.CrateAnimation)
local v_u_14 = v6:RemoteEvent("RollSkinCrate")
local v_u_15 = v6:RemoteEvent("RollEmoteCrate")
local v16 = {
	["Timings"] = {
		["DelayPerCase"] = 0.075,
		["TrailLifetime"] = 0.35,
		["UpscaleDuration"] = 0.75,
		["MoveDuration"] = 0.75,
		["BounceDuration"] = 0.55,
		["DramaticPauseDuration"] = 1,
		["ShakePreDuration"] = 1.75,
		["ShakePostDuration"] = 1,
		["PauseDuration"] = 5,
		["OpenTime"] = 0.15,
		["LidOpenDegrees"] = 160,
		["ItemLookAtPlayerDuration"] = 2.5,
		["ItemFlyIntoPlayerDuration"] = 0.7,
		["GrowScaleDuration"] = 0.1,
		["ImpactParticleLifetime"] = 0.5,
		["OpenParticleLifetime"] = 1.5,
		["legendaryEffectDuration"] = { 0.9, 1.3 }
	},
	["Other"] = {
		["BounceHeight"] = 2.25,
		["ShakePitchMagnitude"] = -30,
		["ShakePitchA"] = 1.5,
		["ShakePitchB"] = 7,
		["ItemLookAtPlayerFloatRate"] = 0.5,
		["ItemLookAtPlayerFloatHeight"] = 5,
		["GrowScale"] = 3
	}
}
local v17 = {
	["Name"] = "CaseOpeningController",
	["Priority"] = 50
}
local v_u_18 = {}
local v_u_19 = 0
local v_u_20 = v13.new({
	["Assets"] = v5,
	["Settings"] = v16,
	["ItemUtility"] = v_u_7,
	["ModelDownloader"] = v10,
	["Debris"] = v4,
	["activeEggs"] = v_u_18
})
local function v_u_56(p_u_21, p22, p23)
	-- upvalues: (copy) v_u_18
	local v24 = p22 or 1
	local v_u_25 = 360 / (v24 * 6)
	local v_u_26
	if typeof(p_u_21) == "Instance" then
		local v27 = p_u_21.Character
		if not v27 then
			return nil
		end
		assert(v27)
		local v28 = v27.PrimaryPart
		if not v28 then
			return nil
		end
		assert(v28)
		local v29 = v27:FindFirstChildOfClass("Humanoid")
		if not v29 then
			return nil
		end
		assert(v29)
		p_u_21 = v27:GetPivot()
		v_u_26 = p_u_21.Position
	else
		v_u_26 = p_u_21.Position
	end
	local v_u_30 = {}
	for v31, _ in pairs(v_u_18) do
		if not v31.completed then
			local v32 = v31.position
			table.insert(v_u_30, v32)
		end
	end
	if p23 then
		for _, v33 in ipairs(p23) do
			table.insert(v_u_30, v33)
		end
	end
	local v_u_34 = RaycastParams.new()
	v_u_34.IgnoreWater = false
	v_u_34.RespectCanCollide = false
	local function v53()
		-- upvalues: (ref) p_u_21, (copy) v_u_25, (ref) v_u_26, (copy) v_u_34, (copy) v_u_30
		local _, v35, _ = p_u_21:ToOrientation()
		local v36 = v35 + 1.5707963267948966
		local v37 = { -1, 1 }
		for v38 = 10, 50 do
			for v39 = 0, 180, v_u_25 do
				for _, v40 in ipairs(v37) do
					local v41 = v39 * v40
					local v42 = 5 + v38
					local v43 = math.rad(v41) - v36
					local v44 = v_u_26
					local v45 = v42 * math.cos(v43)
					local v46 = v42 * math.sin(v43)
					local v47 = v44 + Vector3.new(v45, 0, v46)
					local v48 = workspace:Raycast(v47 + Vector3.new(0, 10, 0), Vector3.new(0, -25, 0), v_u_34)
					if v48 then
						assert(v48)
						local v49 = v48.Instance
						if v49 then
							assert(v49)
						else
							v48 = nil
						end
					else
						v48 = nil
					end
					if v48 then
						assert(v48)
						local v50 = v48.Position
						local v51 = false
						for _, v52 in ipairs(v_u_30) do
							if (v50 - v52).Magnitude <= 10 then
								v51 = true
								break
							end
						end
						if not v51 then
							local _ = v48.Instance
							if true then
								return v50
							end
						end
					end
				end
			end
		end
		return nil
	end
	local v54 = {}
	for _ = 1, v24 do
		local v55 = v53()
		if not v55 then
			return nil
		end
		assert(v55)
		table.insert(v54, v55)
		table.insert(v_u_30, v55)
	end
	return v54
end
local function v_u_66(p57)
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_7
	local v58 = v_u_8[p57] or v_u_9[p57] or nil
	if not v58 then
		return {}
	end
	local v59 = {}
	for _, v60 in ipairs(v58.Items) do
		local v61 = v60.CurrencyRewardInfo
		local v62 = v61[1]
		local v63 = v61[2]
		local v64 = v_u_7.GetItemDataFromItemType(v62, v63)
		if v64 then
			local v65 = {
				["itemType"] = v62,
				["itemName"] = v64.Data.Name,
				["chance"] = v60.Chance
			}
			table.insert(v59, v65)
		end
	end
	return v59
end
local function v_u_81(p67, p68, p69, p70, p71, p72, p73)
	-- upvalues: (copy) v_u_56, (copy) v_u_66, (copy) v_u_18, (ref) v_u_19, (copy) v_u_20, (copy) v_u_11
	local v74 = {}
	local v75
	if p73 then
		v75 = v_u_56(CFrame.new(p72), 1)
	else
		v75 = v_u_56(p67, 1)
	end
	if not v75 then
		warn("NO POSITIONS TO SPAWN CASES")
		return 0
	end
	local v76 = v_u_66(p71)
	for v77, v78 in ipairs(v75) do
		local v79 = {
			["player"] = p67,
			["origin"] = p72,
			["position"] = v78,
			["partyCount"] = #v75,
			["partyIndex"] = v77,
			["priority"] = 1,
			["itemType"] = p68,
			["itemName"] = p69,
			["itemId"] = p70,
			["caseId"] = p71,
			["completed"] = false,
			["crateItems"] = v76
		}
		table.insert(v74, v79)
		v_u_18[v79] = true
	end
	v_u_19 = v_u_19 + #v75
	for _, v_u_80 in ipairs(v74) do
		task.spawn(function()
			-- upvalues: (ref) v_u_20, (copy) v_u_80, (ref) v_u_18, (ref) v_u_19, (ref) v_u_11
			v_u_20.performAnimation(v_u_80)
			v_u_80.completed = true
			v_u_18[v_u_80] = nil
			v_u_19 = v_u_19 - 1
			if v_u_19 <= 0 then
				v_u_19 = 0
				v_u_11:Unlock()
			end
		end)
	end
	return #v75
end
function v17.Start(_)
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_3, (copy) v_u_7, (copy) v_u_1, (copy) v_u_11, (copy) v_u_81, (copy) v_u_14, (copy) v_u_15
	local function v93(p82, p83, p84)
		-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_3, (ref) v_u_7, (ref) v_u_1, (ref) v_u_11, (ref) v_u_81
		if v_u_8[p82] or (v_u_9[p82] or nil) then
			local v85 = v_u_3:JSONDecode(p83)
			local v86, v87, _, _ = table.unpack(v85)
			local v88 = v_u_7.GetItemDataFromItemType(v86, v87)
			if v88 then
				local v89 = v88.Data.Name
				local v90 = p84 or v_u_1.LocalPlayer
				if v90 then
					local v91 = v90.Character
					if v91 and v91.PrimaryPart then
						local v92 = v90 == v_u_1.LocalPlayer
						if v92 then
							v_u_11:Lock()
							v_u_11:Close(true)
							v_u_11:Lock()
						end
						if v_u_81(v90, v86, v89, v87, p82, v91:GetPivot().Position, true) == 0 and v92 then
							v_u_11:Unlock()
						end
					end
				else
					return
				end
			else
				return
			end
		else
			return
		end
	end
	v_u_14.OnClientEvent:Connect(v93)
	v_u_15.OnClientEvent:Connect(v93)
end
return v17