-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 186,
		["Type"] = "Fish",
		["Name"] = "Crater Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://101895900955177",
		["Tier"] = 2
	},
	["SellPrice"] = 93,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(19.8, 31.4),
		["Default"] = NumberRange.new(8.7, 13.3)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1