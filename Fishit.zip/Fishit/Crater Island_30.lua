-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 1,
	["ForcedClockTime"] = 3,
	["Ambiance"] = {
		["SoundId"] = "rbxassetid://72824921678704",
		["Volume"] = 0.13
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(79, 94, 141),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(106, 67, 67)
	},
	["Atmosphere"] = {
		["Density"] = 0.275,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(205, 244, 255),
		["Decay"] = Color3.fromRGB(236, 210, 239)
	},
	["Clouds"] = {
		["Color"] = Color3.fromRGB(139, 224, 255)
	}
}
return v1