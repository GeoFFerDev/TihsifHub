-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return function(p1)
	local v2 = typeof(p1) == "CFrame" and p1 and p1 or CFrame.new(p1)
	local v3 = Instance.new("Part")
	v3.Anchored = true
	v3.CanCollide = false
	v3.Transparency = 1
	v3.Material = Enum.Material.SmoothPlastic
	v3.CastShadow = false
	v3.Size = Vector3.new()
	v3.CFrame = v2
	v3.Name = "host"
	local v4 = Instance.new("Attachment")
	v4.Parent = v3
	v3.Parent = workspace
	return v3, v4
end