-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 41,
		["Type"] = "Baits",
		["Name"] = "Crescendo Eye",
		["Description"] = "",
		["Icon"] = "rbxassetid://104719247388079",
		["Tier"] = 7
	},
	["Hidden"] = true,
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1