-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 662,
		["Type"] = "Fishing Rods",
		["Name"] = "Crescendo Scythe",
		["Description"] = "",
		["Icon"] = "rbxassetid://85849336523037",
		["NewIcon"] = true,
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.6, 1.65, 0),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, -0.6108652381980153),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0.256)) * CFrame.fromOrientation(-1.5707963267948966, 0, 0),
	["GripC1"] = CFrame.identity,
	["BobberAnimationDelay"] = 0.2,
	["catchAnimationDelay"] = 0.3,
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1