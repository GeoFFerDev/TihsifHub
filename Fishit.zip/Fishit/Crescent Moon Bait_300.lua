-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 44,
		["Type"] = "Baits",
		["Name"] = "Crescent Moon Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://86397133250130",
		["Tier"] = 4
	},
	["Hidden"] = true,
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1