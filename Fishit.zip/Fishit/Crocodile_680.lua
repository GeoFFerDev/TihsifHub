-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 263,
		["Type"] = "Fish",
		["Name"] = "Crocodile",
		["Description"] = "",
		["Icon"] = "rbxassetid://89886287478220",
		["Tier"] = 6
	},
	["SellPrice"] = 29500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(6228, 7638),
		["Default"] = NumberRange.new(3546, 5419)
	},
	["Probability"] = {
		["Chance"] = 0.00002
	},
	["_moduleScript"] = script
}
return v1