-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 8,
		["Type"] = "Lanterns",
		["Name"] = "Crossroads Lantern",
		["Description"] = "",
		["Icon"] = "rbxassetid://137866406161729",
		["Tier"] = 4
	},
	["GripC0"] = CFrame.new(Vector3.new(-1.15, 1, 0)) * CFrame.fromOrientation(0, 0, 0),
	["_moduleScript"] = script
}
return v1