-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 396,
		["Type"] = "Fishing Rods",
		["Name"] = "Crowned Hacker",
		["Description"] = "",
		["Icon"] = "rbxassetid://72183094963947",
		["Tier"] = 5
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0, 2, 0.65),
	["OverrideROT"] = CFrame.fromOrientation(0, -3.141592653589793, -0.5235987755982988),
	["GripC0"] = CFrame.new(Vector3.new(0, -1.1, 0)) * CFrame.fromOrientation(-0.6108652381980153, -0.3490658503988659, 0),
	["GripC1"] = CFrame.fromOrientation(0, 0.3490658503988659, 0),
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1