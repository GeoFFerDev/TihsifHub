-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 13,
		["Type"] = "Boats",
		["Name"] = "Cruiser Boat",
		["Description"] = "",
		["Icon"] = "rbxassetid://125445664731545",
		["Tier"] = 100
	},
	["HiddenInShop"] = true,
	["Seats"] = 4,
	["_moduleScript"] = script
}
return v1