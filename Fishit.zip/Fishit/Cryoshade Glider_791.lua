-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 379,
		["Type"] = "Fish",
		["Name"] = "Cryoshade Glider",
		["Description"] = "",
		["Icon"] = "rbxassetid://107008051913908",
		["Tier"] = 7
	},
	["SellPrice"] = 120000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(14500, 17200),
		["Default"] = NumberRange.new(10500, 11500)
	},
	["Probability"] = {
		["Chance"] = 2.222222222222222e-6
	},
	["_moduleScript"] = script
}
return v1