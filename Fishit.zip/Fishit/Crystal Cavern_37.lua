-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 50,
	["ForcedClockTime"] = 3,
	["Music"] = {
		["SoundId"] = "rbxassetid://131068840299889",
		["Volume"] = 0.18
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(109, 83, 131)
	},
	["Atmosphere"] = {
		["Color"] = Color3.fromRGB(195, 190, 255)
	},
	["WaterColor"] = Color3.fromRGB(57, 81, 120)
}
return v1