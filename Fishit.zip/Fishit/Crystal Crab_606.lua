-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 195,
		["Type"] = "Fish",
		["Name"] = "Crystal Crab",
		["Description"] = "",
		["Icon"] = "rbxassetid://110188263756245",
		["Tier"] = 7
	},
	["SellPrice"] = 162000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(140962, 155306),
		["Default"] = NumberRange.new(110524, 130962)
	},
	["Probability"] = {
		["Chance"] = 1.3333333333333334e-6
	},
	["_moduleScript"] = script
}
return v1