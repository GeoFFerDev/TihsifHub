-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 5,
	["ForcedClockTime"] = 0,
	["Music"] = {
		["SoundId"] = "rbxassetid://86467598625737",
		["Volume"] = 0.1
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(68, 118, 124)
	}
}
return v1