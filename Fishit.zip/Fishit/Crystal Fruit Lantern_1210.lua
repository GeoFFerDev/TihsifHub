-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 5,
		["Type"] = "Lanterns",
		["Name"] = "Crystal Fruit Lantern",
		["Description"] = "",
		["Icon"] = "rbxassetid://137840056377319",
		["Tier"] = 3
	},
	["GripC0"] = CFrame.new(Vector3.new(0, 1.3, 0.9)) * CFrame.fromOrientation(0, 1.5707963267948966, -0.17453292519943295),
	["_moduleScript"] = script
}
return v1