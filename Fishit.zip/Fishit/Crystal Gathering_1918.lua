-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Help the Hank find his sunken diary in exchange for a Pickaxe!",
	["AssociatedTier"] = 4
}
local v4 = {}
local v5 = {
	["Id"] = 1,
	["Name"] = "Fish up Hank\'s Diary",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Reconcile"] = true,
	["Requirements"] = {
		["Id"] = 20222
	},
	["AssociatedItem"] = "Hank\'s Diary",
	["AssociatedType"] = "Gears",
	["QuestItem"] = true
}
local v6 = {
	["Id"] = 2,
	["Name"] = "Return the Diary to Hank",
	["Goal"] = 1,
	["Type"] = "Exchange",
	["Requirements"] = {
		["Id"] = 20222
	}
}
__set_list(v4, 1, {v5, v6})
v3.Objectives = v4
v3.NPC = "Hank"
v3.Ordered = true
v3.Reward = v2.itemReward("Pickaxe", 1)
return v3