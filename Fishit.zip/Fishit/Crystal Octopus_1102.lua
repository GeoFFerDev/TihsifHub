-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 693,
		["Type"] = "Fish",
		["Name"] = "Crystal Octopus",
		["Description"] = "",
		["Icon"] = "rbxassetid://123563903708414",
		["Tier"] = 5
	},
	["SellPrice"] = 4500,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(32, 38),
		["Default"] = NumberRange.new(25, 29)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1