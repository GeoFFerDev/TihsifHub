-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 690,
		["Type"] = "Fish",
		["Name"] = "Crystal Oni Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://138465254082175",
		["Tier"] = 3
	},
	["SellPrice"] = 350,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(4.1, 4.8),
		["Default"] = NumberRange.new(2.3, 3.5)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1