-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 645,
		["Type"] = "Fish",
		["Name"] = "Crystal Pufferfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://112088257164749",
		["Tier"] = 4
	},
	["SellPrice"] = 1100,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.6, 1),
		["Default"] = NumberRange.new(0.2, 0.5)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["_moduleScript"] = script
}
return v1