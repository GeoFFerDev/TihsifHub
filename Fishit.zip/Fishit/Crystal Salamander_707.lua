-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 296,
		["Type"] = "Fish",
		["Name"] = "Crystal Salamander",
		["Description"] = "",
		["Icon"] = "rbxassetid://129118256536866",
		["Tier"] = 5
	},
	["SellPrice"] = 4325,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.61, 0.88),
		["Default"] = NumberRange.new(0.24, 0.44)
	},
	["Probability"] = {
		["Chance"] = 0.00016666666666666666
	},
	["_moduleScript"] = script
}
return v1