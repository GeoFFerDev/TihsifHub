-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
game:GetService("RunService")
require(v_u_1.Packages.Net)
local v3 = require(v_u_1.Packages.Replion)
local v_u_4 = require(v_u_1.Packages.Observers)
local v_u_5 = require(v_u_1.Packages.Trove)
require(v_u_1.Packages.spr)
v3.Client:AwaitReplion("Data", function(p_u_6)
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v_u_7 = require(v_u_1.Controllers.TextNotificationController)
	local v_u_8 = require(v_u_1.Controllers.PromptController)
	local v_u_9 = require(v_u_1.Controllers.PurchaseScreenBlackoutController)
	local v_u_10 = require(v_u_1.Shared.Soundbook)
	v_u_4.observeTag("CrystalCavernFastTravel", function(p11)
		-- upvalues: (ref) v_u_5, (ref) v_u_2, (copy) p_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_10, (copy) v_u_9
		local v_u_12 = v_u_5.new()
		local v13 = p11:WaitForChild("StartTeleport", 30)
		if v13 then
			local v14 = v13:WaitForChild("TELEPORT_PROMPT", 30)
			if v14 then
				local v15 = v14:WaitForChild("ProximityPrompt", 40)
				if v15 then
					local v_u_16 = p11:WaitForChild("TeleportTo", 30)
					if v_u_16 then
						local v_u_17 = false
						v_u_12:Add(v15.Triggered:Connect(function(p18)
							-- upvalues: (ref) v_u_2, (ref) p_u_6, (ref) v_u_7, (ref) v_u_17, (ref) v_u_8, (copy) v_u_16, (ref) v_u_10, (ref) v_u_9
							if p18 then
								if p18 == v_u_2.LocalPlayer then
									local v_u_19 = p18.Character
									if v_u_19 then
										if v_u_19:FindFirstChildWhichIsA("Humanoid") then
											local v20 = p_u_6:GetExpect("Level") or 0
											if v20 then
												local v21 = p_u_6:GetExpect("CandyCorns") or 0
												if v21 then
													if v20 < 30 then
														local v22 = {
															["Type"] = "Text",
															["Text"] = "You need to be < LEVEL 30+ >",
															["TextColor"] = {
																["R"] = 255,
																["G"] = 0,
																["B"] = 0
															}
														}
														v_u_7:DeliverNotification(v22)
														return
													elseif v21 < 10000 then
														local v23 = {
															["Type"] = "Text",
															["Text"] = "You need at least < 10,000 > Candy Corns \240\159\142\131!",
															["TextColor"] = {
																["R"] = 255,
																["G"] = 0,
																["B"] = 0
															}
														}
														v_u_7:DeliverNotification(v23)
														return
													elseif not v_u_17 then
														v_u_17 = true
														local v24, v25 = v_u_8:FirePrompt("Teleport to Crystal Cavern?"):catch(warn):await()
														if v24 and v25 then
															task.delay(2, function()
																-- upvalues: (copy) v_u_19, (ref) v_u_16
																if v_u_19 and v_u_19:IsDescendantOf(workspace) then
																	v_u_19:PivotTo(v_u_16.CFrame * CFrame.new(0, 5, 0))
																end
															end)
															v_u_10.Sounds.TeleportActivated:Play()
															v_u_9.blackoutScreen(v_u_16.CFrame, true)
														end
														v_u_17 = false
													end
												else
													return
												end
											else
												return
											end
										else
											return
										end
									else
										return
									end
								else
									return
								end
							else
								return
							end
						end))
						return function()
							-- upvalues: (ref) v_u_12
							if v_u_12 then
								v_u_12:Destroy()
								v_u_12 = nil
							end
						end
					end
				end
			else
				return
			end
		else
			return
		end
	end)
end)
return {}