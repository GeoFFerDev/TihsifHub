-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("CollectionService")
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v3 = require(v1.Packages.Observers)
local v_u_4 = require(v1.Packages.Trove)
local v5 = require(v1.Packages.Replion)
local v_u_6 = require(v1.Shared.PlayerStatsUtility)
local v_u_7 = Color3.fromRGB(120, 200, 255)
local v_u_8 = TweenInfo.new(1.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = nil
local function v_u_16()
	-- upvalues: (ref) v_u_12, (copy) v_u_6
	if not v_u_12 then
		return false
	end
	local v_u_13 = v_u_12:Get("EquippedId")
	if not v_u_13 or v_u_13 == "" then
		return false
	end
	local v15 = v_u_6:GetItemFromInventory(v_u_12, function(p14)
		-- upvalues: (copy) v_u_13
		return p14.UUID == v_u_13
	end, "Items")
	return v15 and v15.Id == 20220 and true or false
end
local function v_u_26(p17)
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (copy) v_u_7, (copy) v_u_2, (copy) v_u_8, (copy) v_u_9
	if v_u_10[p17] then
		return
	else
		local v18 = v_u_4.new()
		v_u_10[p17] = v18
		if p17 then
			local v19 = Instance.new("Highlight")
			v19.FillColor = v_u_7
			v19.OutlineColor = Color3.fromRGB(180, 140, 255)
			v19.FillTransparency = 0.5
			v19.OutlineTransparency = 0
			v19.DepthMode = Enum.HighlightDepthMode.Occluded
			v19.Parent = p17
			v18:Add(v19)
			local v_u_20 = v_u_2:Create(v19, v_u_8, {
				["FillTransparency"] = 0.8
			})
			v_u_20:Play()
			v18:Add(function()
				-- upvalues: (copy) v_u_20
				v_u_20:Cancel()
			end)
			local v21 = Instance.new("PointLight")
			v21.Color = v_u_7
			v21.Brightness = 2
			v21.Range = 12
			v21.Parent = p17
			v18:Add(v21)
			local v_u_22 = v_u_2:Create(v21, v_u_8, {
				["Brightness"] = 0.8
			})
			v_u_22:Play()
			v18:Add(function()
				-- upvalues: (copy) v_u_22
				v_u_22:Cancel()
			end)
			local v_u_23 = p17:FindFirstChildWhichIsA("ProximityPrompt")
			if v_u_23 then
				local v24 = v_u_9
				table.insert(v24, v_u_23)
				v_u_23.Enabled = true
				v18:Add(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_23
					local v25 = table.find(v_u_9, v_u_23)
					if v25 then
						table.remove(v_u_9, v25)
					end
				end)
			end
		else
			v18:Destroy()
			v_u_10[p17] = nil
		end
	end
end
local function v_u_30()
	-- upvalues: (copy) v_u_16, (copy) v_u_11, (copy) v_u_26, (copy) v_u_10
	if v_u_16() then
		for v27, _ in v_u_11 do
			v_u_26(v27)
		end
	else
		for v28, _ in v_u_10 do
			local v29 = v_u_10[v28]
			if v29 then
				v29:Destroy()
				v_u_10[v28] = nil
			end
		end
	end
end
v3.observeTag("GlowingCrystal", function(p_u_31)
	-- upvalues: (copy) v_u_11, (copy) v_u_16, (copy) v_u_26, (copy) v_u_10
	v_u_11[p_u_31] = function() end
	if v_u_16() then
		v_u_26(p_u_31)
	end
	return function()
		-- upvalues: (ref) v_u_11, (copy) p_u_31, (ref) v_u_10
		v_u_11[p_u_31] = nil
		local v32 = p_u_31
		local v33 = v_u_10[v32]
		if v33 then
			v33:Destroy()
			v_u_10[v32] = nil
		end
	end
end, { workspace })
v5.Client:AwaitReplion("Data", function(p34)
	-- upvalues: (ref) v_u_12, (copy) v_u_30
	v_u_12 = p34
	p34:OnChange("EquippedId", function()
		-- upvalues: (ref) v_u_30
		v_u_30()
	end)
	p34:OnChange("Inventory", function()
		-- upvalues: (ref) v_u_30
		v_u_30()
	end)
	v_u_30()
end)
return {}