-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 692,
		["Type"] = "Fish",
		["Name"] = "Crystalized Crab",
		["Description"] = "",
		["Icon"] = "rbxassetid://102239856997450",
		["Tier"] = 4
	},
	["SellPrice"] = 1400,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(12.2, 14.5),
		["Default"] = NumberRange.new(9.3, 11.7)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["_moduleScript"] = script
}
return v1