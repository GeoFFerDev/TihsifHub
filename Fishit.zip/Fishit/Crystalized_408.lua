-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 24,
		["Type"] = "Variant",
		["Name"] = "Crystalized",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(1, 59, 42)), ColorSequenceKeypoint.new(1, Color3.fromRGB(3, 217, 153)) })
	},
	["Versions"] = 1,
	["Colors"] = 4,
	["SellMultiplier"] = 2.5,
	["Probability"] = {
		["Chance"] = 0.7
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1