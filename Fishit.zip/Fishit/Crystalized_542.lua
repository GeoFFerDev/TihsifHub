-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 134,
		["Type"] = "Fishing Rods",
		["Name"] = "Crystalized",
		["Description"] = "",
		["Icon"] = "rbxassetid://103493787682868",
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1