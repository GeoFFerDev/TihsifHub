-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Priority"] = 1,
	["ForcedClockTime"] = 0,
	["Music"] = {
		["SoundId"] = "rbxassetid://76307225323873",
		["Volume"] = 0.22
	},
	["Lighting"] = {
		["Ambient"] = Color3.fromRGB(106, 95, 162),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0),
		["ColorShift_Top"] = Color3.fromRGB(0, 0, 0),
		["OutdoorAmbient"] = Color3.fromRGB(106, 67, 67)
	},
	["Atmosphere"] = {
		["Density"] = 0.275,
		["Glare"] = 0.2,
		["Haze"] = 2.24,
		["Color"] = Color3.fromRGB(80, 103, 255),
		["Decay"] = Color3.fromRGB(236, 210, 239)
	},
	["Clouds"] = {
		["Color"] = Color3.fromRGB(139, 224, 255)
	}
}
return v1