-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Catch the SECRET fish within Crystal Depths for a special reward!",
	["AssociatedTier"] = 7
}
local v4 = {}
local v5 = {
	["Id"] = 3,
	["Name"] = "Exchange a Cursed Kraken",
	["Goal"] = 1,
	["Type"] = "Exchange",
	["Requirements"] = {
		["Id"] = 589
	},
	["AssociatedItem"] = "Cursed Kraken",
	["AssociatedType"] = "Fish"
}
local v6 = {
	["Id"] = 4,
	["Name"] = "Catch an Elpirate Gran Maja",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Requirements"] = {
		["Id"] = 661
	},
	["AssociatedItem"] = "Elpirate Gran Maja",
	["AssociatedType"] = "Fish"
}
local v7 = {
	["Id"] = 5,
	["Name"] = "Catch a Legendary Crystalized mutation fish at Crystal Depths",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 5,
		["Variant"] = "Crystalized"
	}
}
__set_list(v4, 1, {{
	["Id"] = 1,
	["Name"] = "Own an Element Rod",
	["Goal"] = 1,
	["Type"] = "ElementRodOwner",
	["AssociatedItem"] = "Element Rod",
	["AssociatedType"] = "Fishing Rods"
}, {
	["Id"] = 2,
	["Name"] = "Own a Singularity Bait",
	["Goal"] = 1,
	["Type"] = "SingularityBaitOwner",
	["AssociatedItem"] = "Singularity Bait",
	["AssociatedType"] = "Baits"
}, v5, v6, v7})
v3.Objectives = v4
v3.Reward = v2.baitReward("Aetherion Bait")
return v3