-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 5,
		["Type"] = "Emotes",
		["Name"] = "Cupid Bow Pose",
		["Description"] = "",
		["Icon"] = "rbxassetid://114220387862552",
		["Tier"] = 5
	},
	["AnimationId"] = "rbxassetid://114493984403163",
	["AnimationPriority"] = Enum.AnimationPriority.Action2,
	["VFXStartDelay"] = 1,
	["PlaybackSpeed"] = 1,
	["Looped"] = true,
	["Effect"] = "CupidBowPose",
	["_moduleScript"] = script
}
return v1