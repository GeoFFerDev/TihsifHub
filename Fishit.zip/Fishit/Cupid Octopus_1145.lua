-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.UserPriority).IsValidTestSession() and 0.0005 or 0.0003333333333333333
return {
	["Data"] = {
		["Id"] = 745,
		["Type"] = "Fish",
		["Name"] = "Cupid Octopus",
		["Description"] = "",
		["Icon"] = "rbxassetid://82155168095486",
		["Tier"] = 4
	},
	["SellPrice"] = 3000,
	["Weight"] = {
		["Big"] = NumberRange.new(0.52, 0.67),
		["Default"] = NumberRange.new(0.32, 0.44)
	},
	["Probability"] = {
		["Chance"] = v2
	},
	["Events"] = { "Valentines Event" },
	["EventTag"] = "VAL26",
	["_moduleScript"] = script
}