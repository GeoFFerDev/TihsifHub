-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 25,
		["Type"] = "Variant",
		["Name"] = "Cupid",
		["Description"] = "",
		["Icon"] = "",
		["TierColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 76, 148)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 124, 170)) })
	},
	["Versions"] = 1,
	["Colors"] = 4,
	["SellMultiplier"] = 2.7,
	["Probability"] = {
		["Chance"] = 0.4
	},
	["Modifiers"] = {},
	["_moduleScript"] = script
}
return v1