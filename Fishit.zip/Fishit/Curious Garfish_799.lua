-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 387,
		["Type"] = "Fish",
		["Name"] = "Curious Garfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://110265016364630",
		["Tier"] = 2
	},
	["SellPrice"] = 68,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8.4, 9.5),
		["Default"] = NumberRange.new(6, 7)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1