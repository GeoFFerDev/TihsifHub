-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Replion)
local v3 = require(v1.Packages.Observers)
local v_u_4 = require(v1.Packages.NumberSpinner)
local v_u_5 = require(v1.Packages.spr)
local v_u_6 = require(v1.Shared.StringLibrary)
local v_u_7 = require(v1.Modules.CurrencyUtility)
local v_u_8 = require(v1.Modules.CurrencyUtility.Currency)
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {}
local function v_u_19(p12, p13)
	-- upvalues: (copy) v_u_5
	local v14 = p12:FindFirstChild("FadeLabel")
	if v14 then
		local v15 = v14.Position
		local v16 = v15 + UDim2.fromOffset(0, 10)
		local v_u_17 = v14:Clone()
		v_u_17.Name = "RBX_TEXT_EFFECT"
		v_u_17.Position = v16
		v_u_17.Text = ("+%*"):format(p13)
		v_u_17.Visible = true
		v_u_17.Parent = p12
		v_u_5.target(v_u_17, 1, 1.5, {
			["Position"] = v15
		})
		task.delay(0.4, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_17
			v_u_5.target(v_u_17, 1, 3, {
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			})
			local v18 = v_u_17:FindFirstChild("UIStroke")
			if v18 then
				v_u_5.target(v18, 1, 3, {
					["Transparency"] = 1
				})
			end
			task.wait(0.6)
			if v18 then
				v_u_5.stop(v18)
			end
			v_u_5.stop(v_u_17)
			v_u_17:Destroy()
		end)
	end
end
local function v_u_30(p20, p21, p22)
	-- upvalues: (copy) v_u_9, (copy) v_u_11, (copy) v_u_6, (copy) v_u_19, (copy) v_u_10
	v_u_9[p20] = p21
	local v23 = v_u_11[p20]
	if v23 then
		local v24 = p21 - p22
		local v25 = v_u_6:Shorten(p21)
		local v26 = v_u_6:Shorten(v24)
		for _, v27 in ipairs(v23) do
			if v24 > 0 then
				task.spawn(v_u_19, v27, v26)
			end
			v27.Text = v25
		end
	end
	local v28 = v_u_10[p20]
	if v28 then
		for _, v29 in ipairs(v28) do
			v29.Counter.Value = p21
		end
	end
end
v3.observeTag("CurrencyCounter", function(p_u_31)
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_4, (copy) v_u_6
	local v32 = p_u_31:GetAttribute("CurrencyType") or "Coins"
	if v_u_7:GetCurrency(v32) then
		local v33 = v_u_9[v32]
		if not v33 then
			v_u_9[v32] = 0
			v33 = v_u_9[v32]
		end
		local v_u_34 = v_u_10[v32]
		if not v_u_34 then
			v_u_10[v32] = {}
			v_u_34 = v_u_10[v32]
		end
		local v_u_35 = v_u_11[v32]
		if not v_u_35 then
			v_u_11[v32] = {}
			v_u_35 = v_u_11[v32]
		end
		if p_u_31:HasTag("LiveUpdateCounter") then
			local v36 = p_u_31:FindFirstChildWhichIsA("UIGradient")
			if v36 then
				p_u_31.TextColor3 = v36.Color.Keypoints[1].Value
				v36:Destroy()
			end
			local v37 = v_u_4.fromGuiObject(p_u_31)
			v37.Prefix = ""
			v37.Suffix = ""
			v37.Commas = true
			v37.Decimals = 0
			v37.Duration = 0.4
			v37.ZeroPadding = 0
			v37.Value = v33
			table.insert(v_u_34, {
				["Instance"] = p_u_31,
				["Counter"] = v37
			})
		else
			p_u_31.Text = v_u_6:Shorten(v33)
			table.insert(v_u_35, p_u_31)
		end
		return function()
			-- upvalues: (copy) p_u_31, (ref) v_u_34, (ref) v_u_35
			if p_u_31:HasTag("LiveUpdateCounter") then
				local v38 = nil
				for v39, v40 in ipairs(v_u_34) do
					if v40.Instance == p_u_31 then
						v38 = v39
						break
					end
				end
				if v38 then
					table.remove(v_u_34, v38)
					return
				end
			else
				local v41 = table.find(v_u_35, p_u_31)
				if v41 then
					table.remove(v_u_35, v41)
				end
			end
		end
	end
end)
v2.Client:AwaitReplion("Data", function(p42)
	-- upvalues: (copy) v_u_8, (copy) v_u_30
	for v_u_43, v44 in v_u_8 do
		local v45 = p42:Get(v44.Path)
		if v45 then
			v_u_30(v_u_43, v45, 0)
		end
		p42:OnChange(v44.Path, function(p46, p47)
			-- upvalues: (ref) v_u_30, (copy) v_u_43
			v_u_30(v_u_43, p46, p47)
		end)
	end
end)
return {}