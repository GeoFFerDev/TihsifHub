-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script:WaitForChild("Currency"))
return {
	["GetCurrency"] = function(_, p2)
		-- upvalues: (copy) v_u_1
		return v_u_1[p2]
	end
}