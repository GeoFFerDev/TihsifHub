-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Coins"] = {
		["Icon"] = "rbxassetid://87861169766396",
		["Singular"] = "Coin",
		["Prefix"] = "Coins",
		["TextColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 220, 78)), ColorSequenceKeypoint.new(0.379, Color3.fromRGB(255, 220, 78)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 155, 67)) }),
		["Path"] = { "Coins" }
	},
	["Doubloons"] = {
		["Icon"] = "rbxassetid://76318880536984",
		["Singular"] = "Doubloon",
		["Prefix"] = "Doubloons",
		["TextColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(222, 157, 100)), ColorSequenceKeypoint.new(1, Color3.fromRGB(222, 132, 29)) }),
		["Path"] = { "Doubloons" }
	},
	["Tix"] = {
		["Icon"] = "rbxassetid://93538147482272",
		["Singular"] = "Tix",
		["Prefix"] = "Tix",
		["TextColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(229, 255, 57)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(244, 255, 123)) }),
		["Path"] = { "Tix" }
	},
	["Candy Canes"] = {
		["Icon"] = "rbxassetid://74264628546027",
		["Singular"] = "Candy Cane",
		["Prefix"] = "Candy Canes",
		["TextColor"] = ColorSequence.new({
			ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)),
			ColorSequenceKeypoint.new(0.1, Color3.fromRGB(245, 245, 245)),
			ColorSequenceKeypoint.new(0.7, Color3.fromRGB(186, 155, 155)),
			ColorSequenceKeypoint.new(1, Color3.fromRGB(236, 179, 179))
		}),
		["Path"] = { "CandyCanes" }
	},
	["Valentines Coins"] = {
		["Icon"] = "rbxassetid://72658991743974",
		["Singular"] = "Valentines Coin",
		["Prefix"] = "Valentines Coins",
		["TextColor"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 105, 140)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 182, 193)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 80, 120)) }),
		["Path"] = { "ValentinesCoins" }
	}
}
return v1