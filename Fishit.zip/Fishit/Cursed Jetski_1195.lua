-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 41,
		["Type"] = "Boats",
		["Name"] = "Cursed Jetski",
		["Description"] = "",
		["Icon"] = "rbxassetid://97377995231500",
		["Tier"] = 7
	},
	["HiddenInShop"] = true,
	["Seats"] = 2,
	["_moduleScript"] = script
}
return v1