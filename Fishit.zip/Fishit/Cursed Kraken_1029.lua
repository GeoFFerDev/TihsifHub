-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 589,
		["Type"] = "Fish",
		["Name"] = "Cursed Kraken",
		["Description"] = "",
		["Icon"] = "rbxassetid://88584771745160",
		["Tier"] = 7
	},
	["SellPrice"] = 350000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(570000, 600000),
		["Default"] = NumberRange.new(490000, 560000)
	},
	["Probability"] = {
		["Chance"] = 2.857142857142857e-7
	},
	["_moduleScript"] = script
}
return v1