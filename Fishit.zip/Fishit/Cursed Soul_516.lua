-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 223,
		["Type"] = "Fishing Rods",
		["Name"] = "Cursed Soul",
		["Description"] = "",
		["Icon"] = "rbxassetid://106333241367500",
		["Tier"] = 7
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.5, 1.3, 1.5),
	["_moduleScript"] = script
}
return v1