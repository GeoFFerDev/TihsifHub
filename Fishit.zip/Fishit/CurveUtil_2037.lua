-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Debris")
game:GetService("Workspace")
game:GetService("ReplicatedStorage")
local v_u_2 = CFrame.Angles(0, 0, 0)
local v_u_3 = CFrame.Angles(0.2617993877991494, 0, 0)
local v_u_4 = CFrame.Angles(-1.0471975511965976, 0, 0)
local function v_u_10(p5, p6, p7)
	-- upvalues: (copy) v_u_1
	local v8 = workspace:FindFirstChild("CurveParts")
	if not v8 then
		v8 = Instance.new("Folder")
		v8.Name = "CurveParts"
		v8.Parent = workspace
	end
	local v9 = Instance.new("Part")
	v9.Size = Vector3.new(0.4, 0.4, 0.4)
	v9.Name = p6
	v9.Anchored = true
	v9.CFrame = p5
	v9.CanCollide = false
	v9.CanTouch = false
	v9.CanQuery = false
	v9.BrickColor = p7 or BrickColor.Red()
	v9.Parent = v8
	v_u_1:AddItem(v9, 3)
end
local function v_u_16(p11, p12, p13, p14, p15)
	if p13 ~= p12 then
		return (p11 - p12) * (p15 - p14) / (p13 - p12) + p14
	end
	warn("Range of zero")
end
return {
	["Bezier"] = function(p17, p18, p19, p20)
		return p18:Lerp(p19, p17):Lerp(p19:Lerp(p20, p17), p17)
	end,
	["GetCurveBetween"] = function(p21)
		-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_16, (copy) v_u_4, (copy) v_u_10
		local v22 = p21.start
		local v23 = p21.finish
		local v24 = p21.numPoints or 50
		local v25 = p21.curveHeight
		local v26 = p21.visiualize
		local v27 = p21.middle
		local v28 = p21.withRotation
		local v29 = p21.yRotation or CFrame.Angles(0, 0, 0)
		if not (v22 and v23) then
			return warn("Missing start/end of the curve")
		end
		local v30 = {}
		local v31 = (v22 + v23) / 2
		if not v27 then
			local v32 = v31.X
			local v33 = v31.Z
			v27 = Vector3.new(v32, v25, v33)
		end
		for v34 = 1, v24 do
			local v35 = v34 / v24
			local v36 = v22:Lerp(v27, v35):Lerp(v27:Lerp(v23, v35), v35)
			local v37
			if v35 <= 0.5 then
				v37 = v_u_2:Lerp(v_u_3, v_u_16(v35, 0, 0.5, 0, 1))
			else
				v37 = v_u_3:Lerp(v_u_4, v_u_16(v35, 0.5, 1, 0, 1))
			end
			local v38 = CFrame.new(v36) * v29
			if v28 then
				v38 = v38 * v37 or v38
			end
			if v26 then
				v_u_10(v38, v34 == 1 and "Start" or (v34 == v24 and "End" or v34), v34 == 1 and BrickColor.Blue() or (v34 == v24 and BrickColor.Green() or nil))
			end
			table.insert(v30, v38)
		end
		return v30
	end
}