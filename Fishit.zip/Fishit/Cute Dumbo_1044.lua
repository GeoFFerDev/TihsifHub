-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 654,
		["Type"] = "Fish",
		["Name"] = "Cute Dumbo",
		["Description"] = "",
		["Icon"] = "rbxassetid://121632552320211",
		["Tier"] = 5
	},
	["SellPrice"] = 7777,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.3, 0.4),
		["Default"] = NumberRange.new(0.1, 0.25)
	},
	["Probability"] = {
		["Chance"] = 0.00012858428700012858
	},
	["Events"] = { "Radiant" },
	["_moduleScript"] = script
}
return v1