-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 4,
		["Type"] = "Emotes",
		["Name"] = "Cute Idle",
		["Description"] = "",
		["Icon"] = "rbxassetid://126883873715595",
		["Tier"] = 3
	},
	["AnimationId"] = "rbxassetid://78087615433339",
	["AnimationPriority"] = Enum.AnimationPriority.Action3,
	["VFXStartDelay"] = 0.3,
	["PlaybackSpeed"] = 1,
	["Looped"] = true,
	["Effect"] = "CuteIdle",
	["_moduleScript"] = script
}
return v1