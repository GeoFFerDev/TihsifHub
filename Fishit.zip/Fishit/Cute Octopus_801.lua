-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 382,
		["Type"] = "Fish",
		["Name"] = "Cute Octopus",
		["Description"] = "",
		["Icon"] = "rbxassetid://101240566251348",
		["Tier"] = 3
	},
	["SellPrice"] = 402,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(8.5, 10.7),
		["Default"] = NumberRange.new(5.4, 6.4)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1