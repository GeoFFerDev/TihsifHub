-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 748,
		["Type"] = "Fishing Rods",
		["Name"] = "Cute Ribbon",
		["Description"] = "",
		["Icon"] = "rbxassetid://87373171977723",
		["NewIcon"] = true,
		["Tier"] = 4
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0, 2, 0.95),
	["OverrideROT"] = CFrame.fromOrientation(0, 3.141592653589793, -0.7853981633974483),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.fromOrientation(1.5707963267948966, 2.792526803190927, 0),
	["GripC1"] = CFrame.fromOrientation(0, -3.141592653589793, 0),
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1