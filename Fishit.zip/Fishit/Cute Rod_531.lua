-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 123,
		["Type"] = "Fishing Rods",
		["Name"] = "Cute Rod",
		["Description"] = "The spirit of Valentine\'s Day is upon you.",
		["Icon"] = "rbxassetid://103281741610796",
		["Tier"] = 95
	},
	["EquipAsSkin"] = true,
	["VisualClickPowerPercent"] = 0.15,
	["ClickPower"] = 0.09,
	["Resilience"] = 4.2,
	["Windup"] = NumberRange.new(3.29, 4.4799999999999995),
	["MaxWeight"] = 5000
}
local v2 = {
	["BaseLuck"] = 1.3,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1