-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 600,
		["Type"] = "Fish",
		["Name"] = "Cutlass Runner",
		["Description"] = "",
		["Icon"] = "rbxassetid://112094341423425",
		["Tier"] = 4
	},
	["SellPrice"] = 1100,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.2, 2.6),
		["Default"] = NumberRange.new(1.3, 1.7)
	},
	["Probability"] = {
		["Chance"] = 0.001
	},
	["_moduleScript"] = script
}
return v1