-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ProximityPromptService")
game:GetService("HttpService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = require(v2.Packages.Replion)
local v_u_5 = require(v2.Packages.Observers)
local v6 = require(v2.Packages.Loader)
local v7 = require(v2.Packages.Net)
require(v2.Shared.CutsceneUtility)
local v_u_8 = require(v2.ModelProvider)
local v_u_9 = require(v2.Modules.GuiControl)
local v_u_10 = require(v2.Controllers.MainlineQuestController)
require(script.Internal.Transition)
require(v2.Types.Fishing)
require(v2.Types.Modifiers)
local v_u_11 = v7:RemoteEvent("ReplicateCutscene")
local v_u_12 = v7:RemoteEvent("StopCutscene")
local v_u_13 = v_u_3.LocalPlayer
local v_u_14 = v_u_13.PlayerGui
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = false
local v_u_18 = nil
local v19 = script:WaitForChild("Cutscenes")
local v_u_20 = v6.LoadChildren(v19)
local v_u_53 = {
	["Start"] = function(_)
		-- upvalues: (ref) v_u_15, (copy) v_u_4
		v_u_15 = v_u_4.Client:WaitReplion("Data")
	end,
	["Init"] = function(_)
		-- upvalues: (copy) v_u_11, (copy) v_u_53, (copy) v_u_12, (copy) v_u_5, (copy) v_u_13, (ref) v_u_16
		v_u_11.OnClientEvent:Connect(function(...)
			-- upvalues: (ref) v_u_53
			v_u_53:Play(...)
		end)
		v_u_12.OnClientEvent:Connect(function()
			-- upvalues: (ref) v_u_53
			v_u_53:Stop()
		end)
		v_u_5.observeCharacter(function(p21, p22)
			-- upvalues: (ref) v_u_13, (ref) v_u_16, (ref) v_u_53
			if p21 == v_u_13 then
				local v_u_23 = false
				local v24 = p22:WaitForChild("Humanoid")
				local v_u_25 = nil
				local function v26()
					-- upvalues: (ref) v_u_23, (ref) v_u_25, (ref) v_u_16, (ref) v_u_53
					if v_u_23 then
						return
					else
						if v_u_25 and v_u_25.Connected then
							v_u_25:Disconnect()
						end
						v_u_23 = true
						if not (v_u_16 and v_u_16:find("Admin")) then
							v_u_53:Stop()
						end
					end
				end
				v_u_25 = v24.Died:Once(v26)
				return v26
			end
		end)
	end,
	["GetCutsceneModule"] = function(_, p27)
		-- upvalues: (copy) v_u_20
		return v_u_20[p27]
	end,
	["Play"] = function(_, p28, p_u_29, p_u_30, p31, p32, p33, p34)
		-- upvalues: (ref) v_u_16, (ref) v_u_17, (copy) v_u_13, (copy) v_u_53, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (ref) v_u_18, (copy) v_u_10, (copy) v_u_1, (ref) v_u_15, (copy) v_u_14
		tick()
		if v_u_16 and v_u_16:find("Admin") then
			return
		elseif v_u_17 and not p28:find("Admin") then
			return
		else
			v_u_16 = p28
			local v_u_35 = p_u_29 == v_u_13.Character and true or p28:find("Admin")
			if v_u_35 then
				v_u_17 = true
				v_u_53:Stop()
			end
			v_u_9:FishingLock()
			local v_u_36 = v_u_8:GetModel(v_u_13, "Fish", {
				["Id"] = p31,
				["Metadata"] = p32
			}, false)
			if v_u_36 or p33 ~= nil and p33 ~= true then
				local v37 = v_u_53:GetCutsceneModule(p28)
				local v38 = v_u_3:GetPlayerFromCharacter(p_u_29)
				if v37 or v38 then
					local v39 = v_u_13.Character
					if v39 then
						local v40 = v39:FindFirstChildWhichIsA("Humanoid")
						if v40 then
							if v40.Health <= 0 then
								return
							elseif v40:GetState() ~= Enum.HumanoidStateType.Dead then
								local v_u_41 = v37.new(v38, p_u_29, p34)
								if v_u_41 then
									v_u_41.Cleaner:Add(function()
										-- upvalues: (copy) v_u_35, (ref) v_u_17, (ref) v_u_16
										if v_u_35 then
											v_u_17 = false
										end
										v_u_16 = nil
									end)
									v_u_41.Cleaner:Add(task.delay(60, function()
										-- upvalues: (copy) v_u_35, (ref) v_u_17, (ref) v_u_16
										if v_u_35 then
											v_u_17 = false
										end
										v_u_16 = nil
									end))
									v_u_18 = v_u_41
									if v_u_35 and v_u_10:IsEnabled() then
										v_u_10:SetEnabled(false)
										v_u_41.Cleaner:Add(function()
											-- upvalues: (ref) v_u_10
											if not v_u_10:IsEnabled() then
												v_u_10:SetEnabled(true)
											end
										end)
									end
									v_u_41.Cleaner:Add(function()
										-- upvalues: (ref) v_u_1, (copy) v_u_35, (ref) v_u_9, (copy) v_u_36, (ref) v_u_13
										v_u_1.Enabled = true
										if v_u_35 then
											v_u_9:SetHUDVisibility(true)
										end
										if v_u_36 then
											v_u_36:Destroy()
										end
										v_u_13:SetAttribute("IgnoreFOV", false)
										v_u_1.Enabled = true
										v_u_9:FishingUnlock()
									end)
									local v_u_42 = false
									local function v44(p43)
										-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_9
										if not v_u_42 then
											if not p43 then
												task.wait(0.1)
											end
											if v_u_35 then
												v_u_9:SetHUDVisibility(false)
											end
										end
									end
									local v_u_45 = v_u_15:OnChange("AutoFishing", function()
										-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_9
										if not v_u_42 then
											task.wait(0.1)
											if v_u_35 then
												v_u_9:SetHUDVisibility(false)
											end
										end
									end)
									local v_u_46 = v_u_13:GetAttributeChangedSignal("InCutscene"):Connect(function()
										-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_9
										if not v_u_42 then
											task.wait(0.1)
											if v_u_35 then
												v_u_9:SetHUDVisibility(false)
											end
										end
									end)
									local v_u_47 = v_u_14.Backpack:GetPropertyChangedSignal("Enabled"):Connect(function()
										-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_9
										if not v_u_42 then
											task.wait(0.1)
											if v_u_35 then
												v_u_9:SetHUDVisibility(false)
											end
										end
									end)
									local v_u_48 = v_u_14.Fishing:GetPropertyChangedSignal("Enabled"):Connect(function()
										-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_9
										if not v_u_42 then
											task.wait(0.1)
											if v_u_35 then
												v_u_9:SetHUDVisibility(false)
											end
										end
									end)
									local v_u_49 = v_u_14.Fishing.Main:GetPropertyChangedSignal("Visible"):Connect(function()
										-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_9
										if not v_u_42 then
											task.wait(0.1)
											if v_u_35 then
												v_u_9:SetHUDVisibility(false)
											end
										end
									end)
									v_u_41.Cleaner:Add(function()
										-- upvalues: (ref) v_u_42, (copy) v_u_47, (copy) v_u_48, (copy) v_u_49, (copy) v_u_45, (copy) v_u_46, (ref) v_u_9
										v_u_42 = true
										v_u_47:Disconnect()
										v_u_48:Disconnect()
										v_u_49:Disconnect()
										v_u_45:Disconnect()
										v_u_46:Disconnect()
										v_u_9:SetHUDVisibility(true)
										task.spawn(function()
											-- upvalues: (ref) v_u_9
											for _ = 1, 10 do
												v_u_9:SetHUDVisibility(true)
												task.wait(0.05)
											end
										end)
									end)
									task.spawn(v44, true)
									if v_u_35 then
										local v50 = v_u_13:GetAttribute("LocationName")
										if v50 ~= "Christmas Cave" and (v50 ~= "Crystalline Passage" and (v50 ~= "Ancient Ruin" and v50 ~= "Esoteric Depths")) then
											v_u_1.Enabled = false
										end
										v_u_9:SetHUDVisibility(false)
									end
									v_u_13:SetAttribute("IgnoreFOV", true)
									local v51, v52 = pcall(function()
										-- upvalues: (copy) v_u_41, (copy) p_u_29, (copy) p_u_30, (copy) v_u_36, (copy) v_u_35
										v_u_41:Play(p_u_29, p_u_30, v_u_36, v_u_35)
									end)
									if not v51 then
										warn(v52)
										return
									end
								else
									if v_u_35 then
										v_u_17 = false
									end
									v_u_16 = nil
								end
							end
						else
							return
						end
					else
						return
					end
				else
					return
				end
			else
				print("No fish model could be made!", p31, p32)
				v_u_17 = false
				return
			end
		end
	end,
	["Stop"] = function(_)
		-- upvalues: (ref) v_u_18, (ref) v_u_16, (copy) v_u_9
		if v_u_18 then
			pcall(function()
				-- upvalues: (ref) v_u_18
				v_u_18:Destroy()
			end)
			v_u_16 = nil
			v_u_9:SetHUDVisibility(true)
		end
	end
}
return v_u_53