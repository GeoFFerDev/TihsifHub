-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = require(v_u_1.Packages.Net)
local v3 = require(v_u_1.Packages.Loader)
require(v_u_1.Shared.ItemUtility)
local v_u_4 = require(v_u_1.Shared.TierUtility)
local v5 = script:WaitForChild("Data")
local v_u_6 = v3.LoadChildren(v5)
require(v_u_1.Types.Modifiers)
local v_u_7 = v2:RemoteEvent("ReplicateCutscene")
v2:RemoteEvent("StopCutscene")
return {
	["HideAll"] = function(_)
		-- upvalues: (copy) v_u_1
		local v8 = require(v_u_1.Modules.GuiControl)
		v8:Close(true)
		v8:Lock()
		v8:SetHUDVisibility(false)
	end,
	["GetCutsceneData"] = function(_, p9, p10)
		-- upvalues: (copy) v_u_6, (copy) v_u_4
		local v11 = v_u_6[p9]
		if v11 then
			return v11
		end
		local v12 = p10 and v_u_6[v_u_4:GetTierFromRarity(p10).Name]
		if v12 then
			return v12
		end
	end,
	["ReplicateFor"] = function(_, p13, p_u_14, p_u_15, p_u_16)
		-- upvalues: (copy) v_u_7
		for _, v_u_17 in p13 do
			if v_u_17:GetAttribute("ServerCutsceneBlocker") then
				task.defer(function()
					-- upvalues: (copy) v_u_17, (ref) v_u_7, (copy) p_u_14, (copy) p_u_15, (copy) p_u_16
					if v_u_17:GetAttribute("ServerCutsceneBlocker") then
						v_u_17:GetAttributeChangedSignal("ServerCutsceneBlocker"):Wait()
						v_u_7:FireClient(v_u_17, p_u_14, p_u_15.character, p_u_15.origin, p_u_15.fishIdentifier, p_u_15.metaData, p_u_16)
					end
				end)
			else
				v_u_7:FireClient(v_u_17, p_u_14, p_u_15.character, p_u_15.origin, p_u_15.fishIdentifier, p_u_15.metaData, p_u_16)
			end
		end
	end,
	["Replicate"] = function(_, p18, p19, p20, p21, p22, p23, p24)
		-- upvalues: (copy) v_u_7
		v_u_7:FireClient(p19, p18, p20, p21, p22, p23, p24)
	end
}