-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 716,
		["Type"] = "Fish",
		["Name"] = "Cutsie Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://100031149264544",
		["Tier"] = 4
	},
	["SellPrice"] = 1500,
	["Weight"] = {
		["Big"] = NumberRange.new(13.1, 14.6),
		["Default"] = NumberRange.new(9.4, 12.2)
	},
	["Probability"] = {
		["Chance"] = 0.0006666666666666666
	},
	["EventTag"] = "VAL26",
	["_moduleScript"] = script
}
return v1