-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 390,
		["Type"] = "Fish",
		["Name"] = "Cypress Ratua",
		["Description"] = "",
		["Icon"] = "rbxassetid://120326003916500",
		["Tier"] = 2
	},
	["SellPrice"] = 65,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(4.5, 4.8),
		["Default"] = NumberRange.new(2.2, 3.3)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1