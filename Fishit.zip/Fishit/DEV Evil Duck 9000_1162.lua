-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 9,
		["Type"] = "Boats",
		["Name"] = "DEV Evil Duck 9000",
		["Description"] = "",
		["Icon"] = "rbxassetid://110068359141967",
		["Tier"] = 1000
	},
	["HiddenInShop"] = true,
	["Seats"] = 1,
	["_moduleScript"] = script
}
return v1