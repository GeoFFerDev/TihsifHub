-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("GuiService")
game:GetService("RunService")
local v_u_1 = game:GetService("TweenService")
local v_u_2 = game:GetService("ContentProvider")
local v_u_3 = game:GetService("UserInputService")
local v4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("Players")
local v_u_6 = require(v4.Packages.Replion)
require(v4.Packages.Thread)
local v7 = require(v4.Packages.Trove)
local v8 = require(v4.Packages.Net)
require(v4.Modules.CurrencyUtility)
require(v4.Shared.StringLibrary)
local v_u_9 = require(v4.Shared.Soundbook)
local v_u_10 = require(v4.Shared.ItemUtility)
require(v4.Shared.TierUtility)
local v_u_11 = require(v4.Shared.DailyRewardsUtility)
require(v4.Shared.RewardInfo)
local v_u_12 = require(v4.Modules.GuiControl)
local v_u_13 = require(v4.Modules.InputControl)
require(v4.Controllers.PromptController)
local v_u_14 = require(v4.Modules.Device)
local v_u_15 = require(v4.Shared.Constants)
local v_u_16 = nil
local v_u_17 = v5.LocalPlayer
local v18 = v_u_17.PlayerGui
local v_u_19 = v18:WaitForChild("!!! Update Log")
local v_u_20 = v18:WaitForChild("!!! Daily Login")
local v21 = v_u_20.Main.MainFrame
local v_u_22 = v21.Content
local v_u_23 = v21.ProgressBar
local v_u_24 = v8:RemoteFunction("ClaimDailyLogin")
local v_u_25 = v8:RemoteEvent("RecievedDailyRewards")
local v_u_26 = v8:RemoteEvent("UpdateChangeLog")
local v_u_27 = false
local v_u_28 = {
	0.06,
	0.2,
	0.34,
	0.48,
	0.62,
	0.78,
	1
}
local v_u_29 = {}
local v30 = {
	["ActiveDay"] = {
		["Image"] = "rbxassetid://125448249763547",
		["HoverImage"] = ""
	},
	["InactiveDay"] = {
		["Image"] = "rbxassetid://85341066062909",
		["HoverImage"] = ""
	},
	["NormalDay"] = {
		["Image"] = "rbxassetid://72156093853240",
		["HoverImage"] = ""
	},
	["FinalDay"] = {
		["Image"] = "rbxassetid://130884365093528",
		["HoverImage"] = ""
	},
	["ClaimedButton"] = {
		["Image"] = "rbxassetid://131222119201378",
		["HoverImage"] = "",
		["Outline"] = Color3.fromRGB(59, 59, 59)
	},
	["ClaimButton"] = {
		["Image"] = "rbxassetid://74200413420801",
		["HoverImage"] = "rbxassetid://122490084115477",
		["Outline"] = Color3.fromRGB(10, 90, 33)
	},
	["Unfilled"] = {
		["Image"] = "rbxassetid://113519249638685"
	},
	["Filled"] = {
		["Image"] = "rbxassetid://94287407798844"
	}
}
v_u_29.Buttons = v30
local v_u_31 = v7.new()
local v_u_32 = nil
local v_u_84 = {
	["ShowDailyReward"] = function(_, p33)
		-- upvalues: (copy) v_u_2, (copy) v_u_20, (copy) v_u_84, (copy) v_u_12
		pcall(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_20
			v_u_2:PreloadAsync({ v_u_20.Dots, v_u_20.Sparkles, v_u_20.Vignette })
		end)
		v_u_20.Main.Streak.Text = ("Your Streak: %*"):format(p33.Streak)
		v_u_84:Update()
		v_u_12:Lock()
		v_u_12:Open("!!! Daily Login", true)
	end,
	["Init"] = function(_)
		-- upvalues: (copy) v_u_12, (copy) v_u_20, (ref) v_u_27, (copy) v_u_84, (copy) v_u_9, (copy) v_u_31, (copy) v_u_13, (copy) v_u_25, (ref) v_u_32, (ref) v_u_16
		v_u_12:Hook("Hold Button", v_u_20.Main.MainFrame.Close).Clicked:Connect(function()
			-- upvalues: (ref) v_u_27, (ref) v_u_84, (ref) v_u_12
			if v_u_27 then
				v_u_12:Close(true)
			else
				v_u_84:ShowLog()
			end
		end)
		v_u_12.GuiUnfocusedSignal:Connect(function(p34)
			-- upvalues: (ref) v_u_20, (ref) v_u_9, (ref) v_u_31, (ref) v_u_12
			if p34 == v_u_20 then
				v_u_9.Sounds.CoinsChanged:Play().Volume = 0.6
				v_u_31:Clean()
				v_u_12:Unlock()
			end
		end)
		v_u_13:RegisterInput({ Enum.KeyCode.X }, { function()
				-- upvalues: (ref) v_u_12
				return v_u_12:IsOpen("!!! Daily Login")
			end }, function()
			-- upvalues: (ref) v_u_12
			v_u_12:Close(true)
			v_u_12:Unlock()
		end)
		v_u_25.OnClientEvent:Connect(function(p_u_35)
			-- upvalues: (ref) v_u_32, (ref) v_u_16, (ref) v_u_84
			v_u_32 = p_u_35
			local v36 = v_u_16
			if v36 then
				v36 = v_u_16:Get("PlayerOnboarding")
			end
			if v36 and v_u_16:Find("CompletedQuests", "First 5 Catch Experience") == nil then
				local v_u_37 = nil
				v_u_37 = v_u_16:OnChange("CompletedQuests", function(p38)
					-- upvalues: (ref) v_u_37, (ref) v_u_84, (copy) p_u_35
					if table.find(p38, "First 5 Catch Experience") then
						v_u_37:Disconnect()
						v_u_84:ShowDailyReward(p_u_35)
					end
				end)
			else
				v_u_84:ShowDailyReward(p_u_35)
			end
		end)
		playTween(v_u_20.Sparkles1)
		playTween(v_u_20.Sparkles2)
	end,
	["Start"] = function(_)
		-- upvalues: (ref) v_u_16, (copy) v_u_6, (copy) v_u_17, (copy) v_u_24, (copy) v_u_14, (copy) v_u_19, (copy) v_u_12, (ref) v_u_27, (copy) v_u_84, (copy) v_u_26
		v_u_16 = v_u_6.Client:WaitReplion("Data")
		task.spawn(function()
			-- upvalues: (ref) v_u_17, (ref) v_u_16, (ref) v_u_24
			while true do
				local v39 = 0.5
				if v_u_17:GetAttribute("Loading") then
					v_u_17:GetAttributeChangedSignal("Loading"):Wait()
					v39 = v39 + 1
				end
				task.wait(v39)
				if workspace:GetServerTimeNow() >= v_u_16:GetExpect("LastLogin") + 86400 then
					v_u_24:InvokeServer()
				end
			end
		end)
		v_u_14:RegisterDeviceChanged(RefreshConsoleInputs)
		task.spawn(RefreshConsoleInputs)
		local v40 = v_u_19.Main.Content
		local v_u_41 = v40.Pages
		local v_u_42 = v40.Selection
		local v_u_43 = v40.UIPageLayout
		local v_u_44 = {}
		for _, v45 in ipairs(v_u_41:GetChildren()) do
			if v45:IsA("GuiObject") then
				table.insert(v_u_44, v45)
			end
		end
		table.sort(v_u_44, function(p46, p47)
			return p46.LayoutOrder < p47.LayoutOrder
		end)
		task.defer(function(p48)
			-- upvalues: (copy) v_u_42, (copy) v_u_41, (copy) v_u_44, (copy) v_u_43
			v_u_42.Visible = true
			v_u_41.Visible = true
			local v49 = v_u_41:FindFirstChild(p48)
			if v49 then
				for _, v50 in ipairs(v_u_44) do
					v50.Visible = false
				end
				v49.Visible = true
			end
			v_u_43:JumpTo(v_u_41)
		end, v_u_44[1].Name)
		v_u_12.GuiFocusedSignal:Once(function(p51)
			-- upvalues: (ref) v_u_19, (copy) v_u_44, (copy) v_u_42, (copy) v_u_41, (copy) v_u_43
			if p51 == v_u_19 then
				task.wait(0.1)
				local v52 = v_u_44[1].Name
				v_u_42.Visible = true
				v_u_41.Visible = true
				local v53 = v_u_41:FindFirstChild(v52)
				if v53 then
					for _, v54 in ipairs(v_u_44) do
						v54.Visible = false
					end
					v53.Visible = true
				end
				v_u_43:JumpTo(v_u_41)
			end
		end)
		v_u_12.GuiUnfocusedSignal:Connect(function(p55)
			-- upvalues: (ref) v_u_19, (copy) v_u_42, (copy) v_u_41, (copy) v_u_44, (copy) v_u_43
			if p55 == v_u_19 then
				v_u_42.Visible = true
				v_u_41.Visible = true
				for _, v56 in ipairs(v_u_44) do
					v56.Visible = false
				end
				v_u_43:JumpTo(v_u_42)
			end
		end)
		v_u_12:Hook("Hold Button", v_u_19.Main.Toggle).Clicked:Connect(function()
			-- upvalues: (copy) v_u_42, (copy) v_u_41, (copy) v_u_44, (copy) v_u_43
			v_u_42.Visible = true
			v_u_41.Visible = true
			for _, v57 in ipairs(v_u_44) do
				v57.Visible = false
			end
			v_u_43:JumpTo(v_u_42)
		end)
		v_u_43:GetPropertyChangedSignal("CurrentPage"):Connect(function()
			-- upvalues: (copy) v_u_43, (ref) v_u_19, (copy) v_u_41
			local v58 = v_u_43.CurrentPage
			v_u_19.Main.Toggle.Visible = v58 == v_u_41
		end)
		for _, v_u_59 in ipairs(v_u_42:GetChildren()) do
			if v_u_59:IsA("GuiButton") then
				v_u_12:Hook("Hold Button", v_u_59).Clicked:Connect(function()
					-- upvalues: (copy) v_u_59, (copy) v_u_42, (copy) v_u_41, (copy) v_u_44, (copy) v_u_43
					local v60 = v_u_59.Name
					v_u_42.Visible = true
					v_u_41.Visible = true
					local v61 = v_u_41:FindFirstChild(v60)
					if v61 then
						for _, v62 in ipairs(v_u_44) do
							v62.Visible = false
						end
						v61.Visible = true
					end
					v_u_43:JumpTo(v_u_41)
				end)
			end
		end
		local v_u_63 = v_u_19.Main.Top.Exit
		if workspace:GetServerTimeNow() < v_u_16:GetExpect("LastLogin") + 86400 then
			v_u_27 = true
			v_u_84:ShowLog()
		end
		v_u_12:Hook("Hold Button", v_u_63).Clicked:Connect(function()
			-- upvalues: (copy) v_u_63, (ref) v_u_12, (ref) v_u_26
			if v_u_63:GetAttribute("Unlock") == true then
				v_u_12:Unlock()
			end
			v_u_26:FireServer()
			v_u_12:Close()
		end)
	end,
	["ShowLog"] = function(_)
		-- upvalues: (ref) v_u_16, (copy) v_u_15, (copy) v_u_12, (ref) v_u_27
		local v64 = false
		if v_u_16 then
			local v65 = v_u_16:GetExpect("LastGameVersion") or 0
			if v_u_16:GetExpect("Level") >= 10 then
				v64 = v_u_15.GameVersion ~= v65
			end
		end
		if v64 then
			v_u_12:Open("!!! Update Log", true)
		elseif not v_u_27 then
			v_u_12:Close(true)
		end
	end,
	["Update"] = function(_)
		-- upvalues: (ref) v_u_16, (copy) v_u_11, (copy) v_u_22, (ref) v_u_32, (copy) v_u_10, (copy) v_u_23, (copy) v_u_29, (copy) v_u_28
		local v66 = v_u_16:GetExpect("LoginStreak")
		local v67 = v_u_16:Get("ClaimedWeeklyBoat")
		local _, v68 = v_u_11:GetReward(v66)
		local v69 = v_u_22["7"]
		local v70 = nil
		local v71 = nil
		if v67 and (v_u_32 and v_u_32.CurrencyRewardInfo.Type ~= "Boats") then
			local v72 = v_u_11:GetMaxReward()
			v70 = v_u_10.GetItemDataFromItemType(v72.Type, v72.Identifier)
			v71 = v72.Quantity
		else
			local v73 = v_u_11:GetRewards()
			local v74 = v73[#v73]
			if v74 then
				v70 = v_u_10.GetItemDataFromItemType(v74.Type, v74.Identifier)
				v71 = v74.Quantity
			end
		end
		if v70 and v71 then
			v69.Vector.Image = v70.Data.Icon or ""
			v69.Quantity.Text = ("x%*"):format(v71 or 0)
		else
			v69.Vector.Visible = false
			v69.Quantity.Visible = false
		end
		for v75 = 1, #v_u_11:GetRewards() do
			local v76 = ("%*"):format(v75)
			local v77 = v_u_22:FindFirstChild(v76)
			if v77 then
				local v78 = v_u_23.Markers:FindFirstChild(v76)
				if v78 then
					local v79 = v75 == v66
					local v80 = v75 <= v66
					local v81 = v80 and v_u_29.Buttons.Filled or v_u_29.Buttons.Unfilled
					local v82 = v77:FindFirstChild("Button")
					if v82 then
						v82.Visible = v79
					end
					v78.Image = v81.Image
					v78.Icon.Visible = v80
				end
			end
		end
		local v83 = v_u_28[v68] or 0
		v_u_23.Fill.Size = UDim2.fromScale(v83, 1)
	end
}
function GetOriginalPosition(p85)
	local v86 = p85:GetAttribute("OriginalPosition")
	if v86 then
		return v86
	end
	local v87 = p85.Position
	p85:SetAttribute("OriginalPosition", v87)
	return v87
end
function RefreshConsoleInputs(p88)
	-- upvalues: (copy) v_u_20, (copy) v_u_3, (copy) v_u_14
	local v89 = v_u_20.Main.MainFrame.Close
	if p88 then
		local _ = p88.UserInputType
	else
		v_u_3:GetLastInputType()
	end
	if v_u_14:_getDevice() == "Console" then
		v89.Vector.Image = v_u_3:GetImageForKeyCode(Enum.KeyCode.ButtonX)
		v89.Vector.Visible = true
	else
		v89.Vector.Visible = false
	end
end
function playTween(p90)
	-- upvalues: (copy) v_u_1, (copy) v_u_31
	local v91 = GetOriginalPosition(p90)
	if v91 then
		p90.Position = v91 - UDim2.fromOffset(0, 10)
		local v_u_92 = v_u_1:Create(p90, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In, -1, true), {
			["Position"] = v91
		})
		v_u_31:Add(function()
			-- upvalues: (copy) v_u_92
			v_u_92:Cancel()
			v_u_92:Destroy()
		end)
		v_u_92:Play()
	end
end
return v_u_84