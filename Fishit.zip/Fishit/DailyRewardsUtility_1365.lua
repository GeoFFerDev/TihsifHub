-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v_u_3 = v2.potionReward("Luck II Potion", 1)
local v_u_4 = {
	v2.currencyReward("Coins", 250),
	v2.potionReward("Luck I Potion", 1),
	v2.potionReward("Mutation I Potion", 1),
	v2.currencyReward("Coins", 350),
	v2.potionReward("Luck I Potion", 2),
	v2.currencyReward("Coins", 500),
	v2.boatReward("Dinky Fishing Boat")
}
local v_u_5 = #v_u_4
return {
	["Cycle"] = v_u_5,
	["GetRewards"] = function(_)
		-- upvalues: (copy) v_u_4
		return v_u_4
	end,
	["GetMaxReward"] = function(_)
		-- upvalues: (copy) v_u_3
		return v_u_3
	end,
	["GetReward"] = function(_, p6, p7)
		-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_4
		local v8 = p6 % v_u_5
		if p6 > 0 and v8 == 0 then
			v8 = v_u_5
		end
		if v8 == v_u_5 and p7 then
			return v_u_3
		elseif v_u_4[v8] then
			return v_u_4[v8], v8
		else
			return v_u_4[1], 1
		end
	end
}