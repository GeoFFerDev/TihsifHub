-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 153,
		["Type"] = "Fish",
		["Name"] = "Dark Eel",
		["Description"] = "",
		["Icon"] = "rbxassetid://135880333888900",
		["Tier"] = 2
	},
	["SellPrice"] = 96,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(10.2, 12.7),
		["Default"] = NumberRange.new(6.2, 8.5)
	},
	["Probability"] = {
		["Chance"] = 0.02
	},
	["_moduleScript"] = script
}
return v1