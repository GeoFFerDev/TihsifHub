-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 8,
		["Type"] = "Baits",
		["Name"] = "Dark Matter Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://77040147828550",
		["Tier"] = 6
	},
	["Price"] = 630000,
	["Modifiers"] = {
		["BaseLuck"] = 1.7,
		["ShinyMultiplier"] = 0.05,
		["XPMultiplier"] = 0.05
	},
	["_moduleScript"] = script
}
return v1