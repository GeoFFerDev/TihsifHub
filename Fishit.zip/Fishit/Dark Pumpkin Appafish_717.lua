-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 316,
		["Type"] = "Fish",
		["Name"] = "Dark Pumpkin Appafish",
		["Description"] = "",
		["Icon"] = "rbxassetid://128070497580785",
		["Tier"] = 6
	},
	["SellPrice"] = 54000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2441, 3215),
		["Default"] = NumberRange.new(1351, 2027)
	},
	["Probability"] = {
		["Chance"] = 0.00001
	},
	["EventTag"] = "HALLOW25",
	["_moduleScript"] = script
}
return v1