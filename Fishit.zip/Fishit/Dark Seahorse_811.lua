-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 397,
		["Type"] = "Fishing Rods",
		["Name"] = "Dark Seahorse",
		["Description"] = "",
		["Icon"] = "rbxassetid://72298144263287",
		["NewIcon"] = true,
		["Tier"] = 6
	},
	["IsSkin"] = true,
	["OverrideC0"] = Vector3.new(0.8, 1.5, -0.5),
	["OverrideROT"] = CFrame.fromOrientation(0, -1.5707963267948966, -0.5235987755982988),
	["GripC0"] = CFrame.new(Vector3.new(0, -1, 0)) * CFrame.fromOrientation(1.5707963267948966, 2.792526803190927, 0),
	["GripC1"] = CFrame.fromOrientation(0, -3.141592653589793, 0),
	["UseNewRodGrip"] = true,
	["_moduleScript"] = script
}
return v1