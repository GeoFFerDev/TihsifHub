-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 210,
		["Type"] = "Fish",
		["Name"] = "Dark Tentacle",
		["Description"] = "",
		["Icon"] = "rbxassetid://82928155035287",
		["Tier"] = 3
	},
	["SellPrice"] = 392,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.55, 1.94),
		["Default"] = NumberRange.new(0.92, 1.32)
	},
	["Probability"] = {
		["Chance"] = 0.0033333333333333335
	},
	["_moduleScript"] = script
}
return v1