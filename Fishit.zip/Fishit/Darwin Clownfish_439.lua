-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 71,
		["Type"] = "Fish",
		["Name"] = "Darwin Clownfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://109996187340520",
		["Tier"] = 3
	},
	["SellPrice"] = 869,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(0.9, 1.1),
		["Default"] = NumberRange.new(0.6, 0.7)
	},
	["Probability"] = {
		["Chance"] = 0.0013333333333333333
	},
	["_moduleScript"] = script
}
return v1