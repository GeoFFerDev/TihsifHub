-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("ReplicatedStorage")
local v_u_2 = {}
function v1.Set(_, p3, p4)
	-- upvalues: (copy) v_u_2
	v_u_2[p3] = p4
end
function v1.Get(_, p5)
	-- upvalues: (copy) v_u_2
	return v_u_2[p5]
end
return v1