-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("DataStoreService"):GetDataStore((game:GetService("RunService"):IsStudio() and "Studio" or "") .. "_Gamebeast_Backup")
function v1.Set(_, p_u_3, p_u_4)
	-- upvalues: (copy) v_u_2
	local v5, v6 = pcall(function()
		-- upvalues: (ref) v_u_2, (copy) p_u_3, (copy) p_u_4
		v_u_2:SetAsync(p_u_3, p_u_4)
	end)
	if not v5 then
		warn("Failed to save backup data for key \'" .. p_u_3 .. "\': " .. tostring(v6))
	end
	return v5
end
function v1.Update(_, p_u_7, p_u_8)
	-- upvalues: (copy) v_u_2
	local v9, v10 = pcall(function()
		-- upvalues: (ref) v_u_2, (copy) p_u_7, (copy) p_u_8
		v_u_2:UpdateAsync(p_u_7, p_u_8)
	end)
	if not v9 then
		warn("Failed to update backup data for key \'" .. p_u_7 .. "\': " .. tostring(v10))
	end
	return v9
end
function v1.Get(_, p_u_11)
	-- upvalues: (copy) v_u_2
	local v12, v13 = pcall(function()
		-- upvalues: (ref) v_u_2, (copy) p_u_11
		return v_u_2:GetAsync(p_u_11)
	end)
	if v12 then
		return v12, v13
	end
	warn("Failed to retrieve backup data for key \'" .. p_u_11 .. "\': " .. tostring(v13))
	return nil
end
function v1.Init(_) end
return v1