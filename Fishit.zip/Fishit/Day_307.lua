-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "Day",
	["Icon"] = "rbxassetid://114264573242328",
	["Duration"] = 4320000,
	["AreaConfiguration"] = {
		["Fish"] = {},
		["Variants"] = {},
		["Modifiers"] = {}
	}
}
local v2 = {
	["Fish"] = {
		["Jungle - Hourglass Diamond"] = { "Hourglass Diamond Artifact" },
		["Jungle - Arrow"] = { "Arrow Artifact" },
		["Jungle - Crescent"] = { "Crescent Artifact" },
		["Jungle - Diamond"] = { "Diamond Artifact" },
		["Travis Fish"] = { "Trav Grupper" },
		["Christmas Express"] = { "Train Wheel" }
	},
	["Variants"] = {
		["Disco Party"] = { "Disco" }
	},
	["Modifiers"] = {}
}
v1.LinkedEvents = v2
v1.Fish = {}
v1.Variants = {}
v1.Modifiers = {
	["BaseLuck"] = 0
}
return v1