-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 166,
		["Type"] = "Fish",
		["Name"] = "Dead Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://72777968915255",
		["Tier"] = 1
	},
	["SellPrice"] = 19,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(2.8, 3.6),
		["Default"] = NumberRange.new(1.5, 2.3)
	},
	["Probability"] = {
		["Chance"] = 0.25
	},
	["_moduleScript"] = script
}
return v1