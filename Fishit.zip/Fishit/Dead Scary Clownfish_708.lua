-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 301,
		["Type"] = "Fish",
		["Name"] = "Dead Scary Clownfish",
		["Description"] = "",
		["Icon"] = "rbxassetid://130326949380133",
		["Tier"] = 2
	},
	["SellPrice"] = 65,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1.6, 2),
		["Default"] = NumberRange.new(1, 1.2)
	},
	["Probability"] = {
		["Chance"] = 0.01
	},
	["EventTag"] = "HALLOW25",
	["_moduleScript"] = script
}
return v1