-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 303,
		["Type"] = "Fish",
		["Name"] = "Dead Spooky Koi Fish",
		["Description"] = "",
		["Icon"] = "rbxassetid://94754294966347",
		["Tier"] = 4
	},
	["SellPrice"] = 1180,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(11.5, 14.6),
		["Default"] = NumberRange.new(7.7, 10.4)
	},
	["Probability"] = {
		["Chance"] = 0.0005
	},
	["EventTag"] = "HALLOW25",
	["_moduleScript"] = script
}
return v1