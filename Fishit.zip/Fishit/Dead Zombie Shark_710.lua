-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 302,
		["Type"] = "Fish",
		["Name"] = "Dead Zombie Shark",
		["Description"] = "",
		["Icon"] = "rbxassetid://74502211632455",
		["Tier"] = 7
	},
	["SellPrice"] = 66000,
	["Variants"] = { "Color Burn" },
	["Weight"] = {
		["Big"] = NumberRange.new(7552, 9520),
		["Default"] = NumberRange.new(4081, 6821)
	},
	["Probability"] = {
		["Chance"] = 2e-6
	},
	["EventTag"] = "HALLOW25",
	["_moduleScript"] = script
}
return v1