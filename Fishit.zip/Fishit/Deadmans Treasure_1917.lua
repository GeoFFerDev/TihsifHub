-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Find all of Dead Skeleton\'s letters to recieve his secret treasure!",
	["AssociatedTier"] = 5
}
local v4 = {}
local v5 = {
	["Id"] = 2,
	["Name"] = "Return and speak with the Dead Skeleton",
	["Goal"] = 1,
	["Type"] = "SpeakWithNPC",
	["Requirements"] = {
		["NPC"] = "Dead Skeleton",
		["Path"] = 1,
		["Index"] = 2
	}
}
__set_list(v4, 1, {{
	["Id"] = 1,
	["Name"] = "Find 4 letters hidden in the Pirate Cove chests",
	["Goal"] = 4,
	["Type"] = "DeadSkeletonLetter"
}, v5})
v3.Objectives = v4
v3.NPC = "Dead Skeleton"
v3.Ordered = true
v3.Reward = v2.fishingRodReward("Leviathan\'s Wrath")
return v3