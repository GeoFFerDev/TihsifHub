-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 244,
		["Type"] = "Fishing Rods",
		["Name"] = "Deep Conjurer",
		["Description"] = "",
		["Icon"] = "rbxassetid://105058378188880",
		["Tier"] = 95
	},
	["IsSkin"] = true,
	["_moduleScript"] = script
}
return v1