-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 152,
		["Type"] = "Fish",
		["Name"] = "Deep Sea Crab",
		["Description"] = "",
		["Icon"] = "rbxassetid://107492220673765",
		["Tier"] = 5
	},
	["SellPrice"] = 4680,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(1610.3, 1802.8),
		["Default"] = NumberRange.new(943.2, 1414.9)
	},
	["Probability"] = {
		["Chance"] = 0.0002
	},
	["_moduleScript"] = script
}
return v1