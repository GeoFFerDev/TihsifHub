-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "The depths of the ocean call your name...",
	["AssociatedTier"] = 6
}
local v4 = {}
local v5 = {
	["Id"] = 2,
	["Name"] = "Catch 3 Mythic fish at Sisyphus Statue",
	["Goal"] = 3,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 6,
		["Location"] = "Sisyphus Statue"
	}
}
local v6 = {
	["Id"] = 3,
	["Name"] = "Catch 1 SECRET fish at Sisyphus Statue",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 7,
		["Location"] = "Sisyphus Statue"
	}
}
__set_list(v4, 1, {{
	["Id"] = 1,
	["Name"] = "Catch 300 Rare/Epic fish at Treasure Room",
	["Goal"] = 300,
	["Type"] = "TreasureRoomMarker"
}, v5, v6, {
	["Id"] = 4,
	["Name"] = "Earn 1M Coins",
	["Goal"] = 1000000,
	["Type"] = "EarnedCoins"
}})
v3.Objectives = v4
v3.Reward = v2.fishingRodReward("Ghostfinn Rod")
return v3