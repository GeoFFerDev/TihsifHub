-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TextChatService")
game:GetService("StarterGui")
local v_u_2 = require(script.Parent.CmdrInterface.Window)
return function(p3)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	p3:HandleEvent("Message", function(p4)
		-- upvalues: (ref) v_u_1
		local v5 = ("[Announcement] %s"):format(p4)
		local v6 = Color3.fromRGB(249, 217, 56)
		local v7 = v_u_1:FindFirstChild("RBXGeneral", true)
		if v7 then
			v7:DisplaySystemMessage(string.format("<font color=\'rgb(%d,%d,%d)\'>%s</font>", v6.R * 255, v6.G * 255, v6.B * 255, v5))
		end
	end)
	p3:HandleEvent("AddLine", function(...)
		-- upvalues: (ref) v_u_2
		v_u_2:AddLine(...)
	end)
end