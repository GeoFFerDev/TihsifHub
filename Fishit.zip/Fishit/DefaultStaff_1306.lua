-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ServerScriptService")
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = require(v1.Shared.UserPriority)
return function(p4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	p4:RegisterHook("BeforeRun", function(p5)
		-- upvalues: (ref) v_u_2, (ref) v_u_3
		if p5.Group == "DefaultStaff" then
			local v6 = v_u_2:GetPlayerByUserId(p5.Executor.UserId)
			if not v6 then
				return "Error locating player"
			end
			if v_u_3:GetPriorityLevel(v6) < 3 then
				return "You don\'t have permission to run this command"
			end
		end
	end)
end