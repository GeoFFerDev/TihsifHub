-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 23,
		["Type"] = "Baits",
		["Name"] = "Delayed Orb Bait",
		["Description"] = "",
		["Icon"] = "rbxassetid://118499175009240",
		["Tier"] = 4
	},
	["Modifiers"] = {
		["BaseLuck"] = 0,
		["SizeMultiplier"] = 0.3
	},
	["_moduleScript"] = script
}
return v1