-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 77,
		["Type"] = "Fishing Rods",
		["Name"] = "Demascus Rod",
		["Description"] = "",
		["Icon"] = "rbxassetid://92202353564703",
		["Tier"] = 2
	},
	["VisualClickPowerPercent"] = 0.04,
	["ClickPower"] = 0.067,
	["Resilience"] = 3.4,
	["Windup"] = NumberRange.new(3.29, 4.55),
	["Price"] = 3000,
	["MaxWeight"] = 400
}
local v2 = {
	["BaseLuck"] = 0.8,
	["Frequency"] = {
		["Golden"] = 0,
		["Rainbow"] = 0
	}
}
v1.RollData = v2
v1._moduleScript = script
return v1