-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Clear the fallen rocks blocking the cave at Pirate Cove Island",
	["AssociatedTier"] = 3
}
local v4 = {}
local v5 = {
	["Id"] = 1,
	["Name"] = "Find a stack TNT explosives",
	["Goal"] = 3,
	["Type"] = "Search",
	["Requirements"] = {
		["Object"] = "TNT"
	}
}
local v6 = {
	["Id"] = 2,
	["Name"] = "Give the TNT to the Carpenter",
	["Goal"] = 1,
	["Type"] = "SpeakWithNPC",
	["Requirements"] = {
		["NPC"] = "Carpenter",
		["Path"] = 1,
		["Index"] = 2
	},
	["GoalNPC"] = "Carpenter"
}
__set_list(v4, 1, {v5, v6})
v3.Objectives = v4
v3.Reward = v2.potionReward("Luck II Potion", 2)
v3.Ordered = false
return v3