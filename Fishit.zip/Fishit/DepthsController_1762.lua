-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
game:GetService("StarterGui")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("ReplicatedStorage")
require(v_u_4.Packages.Net)
local v_u_5 = require(v_u_4.Packages.Replion)
require(v_u_4.Modules.GuiControl)
local v_u_6 = require(v_u_4.Shared.ItemUtility)
local v_u_7 = require(v_u_4.Shared.PlayerStatsUtility)
local v_u_8 = require(v_u_4.Modules.Util.TweenUtil)
local v_u_9 = require(v_u_4.Controllers.TextNotificationController)
local v_u_10 = false
local v_u_11 = v1.LocalPlayer
local v_u_12 = workspace.CurrentCamera
local v13 = v_u_11:WaitForChild("PlayerGui")
local v_u_14 = v13:WaitForChild("Oxygen")
local v_u_15 = v13:WaitForChild("DepthScreen")
local function v_u_20()
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_7
	local v16 = v_u_5.Client:GetReplion("Data")
	if v16 and not v16.Destroyed then
		local v_u_17 = v_u_6:GetItemData("Advanced Diving Gear")
		local v19 = v_u_7:GetItemFromInventory(v16, function(p18)
			-- upvalues: (copy) v_u_17
			return p18.Id == v_u_17.Data.Id
		end, "Items")
		if v19 then
			v19 = v16:GetExpect("EquippedOxygenTankId") == v_u_17.Data.Id
		end
		return v19
	end
end
local function v_u_23(p21, p22)
	-- upvalues: (copy) v_u_11, (copy) v_u_12
	v_u_11.Character.HumanoidRootPart.Anchored = true
	v_u_11.Character:PivotTo(CFrame.lookAt(p21.WorldPosition + Vector3.new(-1.5, 0, 0), p21.WorldPosition))
	v_u_12.CameraType = Enum.CameraType.Scriptable
	v_u_12.CFrame = CFrame.lookAt(p22.WorldPosition, v_u_11.Character:GetPivot().Position)
end
local function v_u_44()
	-- upvalues: (copy) v_u_20, (copy) v_u_11, (copy) v_u_14, (copy) v_u_12, (copy) v_u_4, (copy) v_u_15, (copy) v_u_2, (copy) v_u_23, (copy) v_u_3, (copy) v_u_8, (copy) v_u_9
	if v_u_20() and v_u_11.Character then
		local v_u_24 = false
		local v25 = TweenInfo.new(2.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
		local v26 = TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.In)
		local v27 = (workspace.DivingScene2.Points.Start.WorldPosition - workspace.DivingScene2.Points.End.WorldPosition).Magnitude
		local v28 = (workspace.DivingScene2.Points2.Start.WorldPosition - workspace.DivingScene2.Points2.End.WorldPosition).Magnitude
		local function v35()
			-- upvalues: (ref) v_u_14, (ref) v_u_24, (ref) v_u_11, (ref) v_u_12
			v_u_14.Enabled = false
			if not v_u_24 then
				local v29 = v_u_11.Character.HumanoidRootPart
				local v30 = v_u_12
				local v31 = CFrame.lookAt
				local v32 = v_u_12.CFrame.X
				local v33 = v29.Position.Y
				local v34 = v_u_12.CFrame.Z
				v30.CFrame = v31(Vector3.new(v32, v33, v34), v29.Position)
			end
		end
		local v36 = v_u_11.Character.Humanoid:FindFirstChild("Animator")
		if v36 then
			local v37 = v36:LoadAnimation(v_u_4.Assets.RopeGrab)
			v37.Looped = true
			v37.Priority = Enum.AnimationPriority.Action4
			v37:Play()
			v_u_15.Enabled = true
			v_u_11.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Physics)
			v_u_2:BindToRenderStep("CamFollow", Enum.RenderPriority.Camera.Value, v35)
			v_u_23(workspace.DivingScene2.Points2.End, workspace.DivingScene2.Camera2)
			v_u_3:Create(v_u_15.Blackscreen, TweenInfo.new(1, Enum.EasingStyle.Linear), {
				["Transparency"] = 0
			}):Play()
			task.defer(v_u_8.TweenNumber, v_u_15.Depth, "%dm", 250, 200, TweenInfo.new(1, Enum.EasingStyle.Linear), true)
			v_u_8.TweenModelCFrame(v_u_11.Character, v_u_11.Character:GetPivot() + Vector3.new(0, v28, 0), false, TweenInfo.new(1, Enum.EasingStyle.Linear))
			v_u_24 = true
			v_u_23(workspace.DivingScene2.Points.End, workspace.DivingScene2.Camera)
			v_u_24 = false
			task.defer(v_u_8.TweenModelCFrame, v_u_11.Character, v_u_11.Character:GetPivot() + Vector3.new(0, v27, 0), false, v26)
			local v38 = v_u_3:Create(v_u_15.Blackscreen, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, 0, false, 0.1), {
				["Transparency"] = 1
			})
			v38:Play()
			v38.Completed:Wait()
			local v_u_39 = v_u_3:Create(v_u_15.Blackscreen, v26, {
				["Transparency"] = 0
			})
			task.defer(function()
				-- upvalues: (copy) v_u_39, (ref) v_u_15, (ref) v_u_3, (ref) v_u_8
				v_u_39:Play()
				v_u_39.Completed:Wait()
				v_u_15.LocationText.Text = "Pirate Cove"
				v_u_15.LocationText["Pirate Cove"].Enabled = true
				v_u_15.Header.Visible = true
				v_u_15.LocationText.Visible = true
				local v40 = v_u_3:Create(v_u_15.LocationText, TweenInfo.new(0.5), {
					["TextTransparency"] = 0
				})
				local v41 = v_u_3:Create(v_u_15.LocationText.UIStroke, TweenInfo.new(0.5), {
					["Transparency"] = 0.75
				})
				v_u_3:Create(v_u_15.Header, TweenInfo.new(0.5), {
					["TextTransparency"] = 0
				}):Play()
				v_u_3:Create(v_u_15.Header.UIStroke, TweenInfo.new(0.5), {
					["Transparency"] = 0.7
				}):Play()
				v40:Play()
				v41:Play()
				v40.Completed:Wait()
				task.wait(0.5)
				v_u_8.TweenAll(v_u_15, 1, TweenInfo.new(0.25), true)
			end)
			task.defer(v_u_8.TweenNumber, v_u_15.Depth, "%dm", 200, 100, v25, true)
			task.wait(v26.Time)
			v_u_24 = true
			v_u_23(workspace.DivingScene.Points.End, workspace.DivingScene.Camera)
			workspace:WaitForChild("DivingScene")
			local v42 = (workspace.DivingScene.Points.Start.WorldPosition - workspace.DivingScene.Points.End.WorldPosition).Magnitude
			task.wait(1.25)
			v_u_24 = false
			task.defer(v_u_8.TweenNumber, v_u_15.Depth, "%dm", 100, 0, v25, true)
			v_u_8.TweenModelCFrame(v_u_11.Character, v_u_11.Character:GetPivot() + Vector3.new(0, v42, 0), false, v25)
			v37:Stop()
			v_u_2:UnbindFromRenderStep("CamFollow")
			v_u_11.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Swimming)
			v_u_11.Character.HumanoidRootPart.Anchored = false
			v_u_12.CameraType = Enum.CameraType.Custom
			v_u_12.CameraSubject = v_u_11.Character.Humanoid
			ResetUI()
		end
	else
		local v43 = {
			["Type"] = "Text",
			["Text"] = "You don\'t have the Advanced Diving Gear equipped!",
			["TextColor"] = {
				["R"] = 255,
				["G"] = 0,
				["B"] = 0
			},
			["CustomDuration"] = 5
		}
		v_u_9:DeliverNotification(v43)
		return
	end
end
local function v_u_66()
	-- upvalues: (copy) v_u_20, (copy) v_u_11, (copy) v_u_14, (copy) v_u_12, (copy) v_u_4, (copy) v_u_15, (copy) v_u_23, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_9
	if v_u_20() and v_u_11.Character then
		local v_u_45 = false
		local v46 = TweenInfo.new(2.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In)
		local v47 = TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
		local v48 = (workspace.DivingScene.Points.Start.WorldPosition - workspace.DivingScene.Points.End.WorldPosition).Magnitude
		local function v55()
			-- upvalues: (ref) v_u_14, (ref) v_u_45, (ref) v_u_11, (ref) v_u_12
			v_u_14.Enabled = false
			if not v_u_45 then
				local v49 = v_u_11.Character.HumanoidRootPart
				local v50 = v_u_12
				local v51 = CFrame.lookAt
				local v52 = v_u_12.CFrame.X
				local v53 = v49.Position.Y
				local v54 = v_u_12.CFrame.Z
				v50.CFrame = v51(Vector3.new(v52, v53, v54), v49.Position)
			end
		end
		local v56 = v_u_11.Character.Humanoid:FindFirstChild("Animator")
		if v56 then
			local v57 = v56:LoadAnimation(v_u_4.Assets.RopeGrab)
			v57.Looped = true
			v57.Priority = Enum.AnimationPriority.Action4
			v57:Play()
			v_u_11.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Physics)
			v_u_15.Enabled = true
			v_u_23(workspace.DivingScene.Points.Start, workspace.DivingScene.Camera)
			v_u_2:BindToRenderStep("CamFollow", Enum.RenderPriority.Camera.Value, v55)
			v_u_3:Create(v_u_15.Blackscreen, v46, {
				["Transparency"] = 0
			}):Play()
			task.defer(v_u_8.TweenNumber, v_u_15.Depth, "%dm", 0, 100, v46, true)
			v_u_8.TweenModelCFrame(v_u_11.Character, v_u_11.Character:GetPivot() - Vector3.new(0, v48, 0), false, v46)
			v_u_45 = true
			v_u_23(workspace.DivingScene2.Points.Start, workspace.DivingScene2.Camera)
			workspace:WaitForChild("DivingScene2")
			task.wait(1)
			local v58 = (workspace.DivingScene2.Points.Start.WorldPosition - workspace.DivingScene2.Points.End.WorldPosition).Magnitude
			local v59 = (workspace.DivingScene2.Points2.Start.WorldPosition - workspace.DivingScene2.Points2.End.WorldPosition).Magnitude
			v_u_45 = false
			task.defer(v_u_8.TweenModelCFrame, v_u_11.Character, v_u_11.Character:GetPivot() - Vector3.new(0, v58, 0), false, v47)
			local v60 = v_u_3:Create(v_u_15.Blackscreen, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, 0, false, 0.1), {
				["Transparency"] = 1
			})
			v60:Play()
			v60.Completed:Wait()
			local v_u_61 = v_u_3:Create(v_u_15.Blackscreen, v47, {
				["Transparency"] = 0
			})
			task.defer(function()
				-- upvalues: (copy) v_u_61, (ref) v_u_15, (ref) v_u_3, (ref) v_u_8
				v_u_61:Play()
				v_u_61.Completed:Wait()
				v_u_15.LocationText.Text = "Crystal Depths"
				v_u_15.LocationText["Pirate Cove"].Enabled = false
				v_u_15.LocationText.Visible = true
				v_u_15.Header.Visible = true
				local v62 = v_u_3:Create(v_u_15.LocationText, TweenInfo.new(0.5), {
					["TextTransparency"] = 0
				})
				local v63 = v_u_3:Create(v_u_15.LocationText.UIStroke, TweenInfo.new(0.5), {
					["Transparency"] = 0.75
				})
				v_u_3:Create(v_u_15.Header, TweenInfo.new(0.5), {
					["TextTransparency"] = 0
				}):Play()
				v_u_3:Create(v_u_15.Header.UIStroke, TweenInfo.new(0.5), {
					["Transparency"] = 0.7
				}):Play()
				v62:Play()
				v63:Play()
				v62.Completed:Wait()
				task.wait(0.5)
				v_u_8.TweenAll(v_u_15, 1, TweenInfo.new(0.25), true)
			end)
			task.defer(v_u_8.TweenNumber, v_u_15.Depth, "%dm", 100, 200, v46, true)
			task.wait(v47.Time)
			v_u_45 = true
			v_u_23(workspace.DivingScene2.Points2.Start, workspace.DivingScene2.Camera2)
			local v64 = v_u_3:Create(v_u_15.Blackscreen, TweenInfo.new(0.25), {
				["Transparency"] = 1
			})
			v64:Play()
			v64.Completed:Wait()
			v_u_45 = false
			task.defer(v_u_8.TweenNumber, v_u_15.Depth, "%dm", 200, 250, TweenInfo.new(1, Enum.EasingStyle.Linear), true)
			v_u_8.TweenModelCFrame(v_u_11.Character, v_u_11.Character:GetPivot() - Vector3.new(0, v59, 0), false, TweenInfo.new(1, Enum.EasingStyle.Linear))
			v57:Stop()
			v_u_2:UnbindFromRenderStep("CamFollow")
			v_u_11.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Swimming)
			v_u_11.Character.HumanoidRootPart.Anchored = false
			v_u_12.CameraType = Enum.CameraType.Custom
			v_u_12.CameraSubject = v_u_11.Character.Humanoid
			ResetUI()
		end
	else
		local v65 = {
			["Type"] = "Text",
			["Text"] = "You don\'t have the Advanced Diving Gear equipped!",
			["TextColor"] = {
				["R"] = 255,
				["G"] = 0,
				["B"] = 0
			},
			["CustomDuration"] = 5
		}
		v_u_9:DeliverNotification(v65)
		return
	end
end
function ResetUI()
	-- upvalues: (copy) v_u_15
	v_u_15.Enabled = false
	v_u_15.Depth.Text = "Depth: 0m"
	v_u_15.Depth.TextTransparency = 0
	v_u_15.Blackscreen.Transparency = 1
	v_u_15.Header.Visible = false
	v_u_15.LocationText.Visible = false
	v_u_15.Header.TextTransparency = 0
	v_u_15.LocationText.TextTransparency = 0
	v_u_15.Header.UIStroke.Transparency = 0.75
	v_u_15.LocationText.UIStroke.Transparency = 0.75
	v_u_15.LocationText["Pirate Cove"].Enabled = false
end
return {
	["Start"] = function(_)
		-- upvalues: (ref) v_u_10, (copy) v_u_11, (copy) v_u_44, (copy) v_u_66
		workspace.DepthRopePrompts:WaitForChild("Crystal Depths").Ascend.Triggered:Connect(function(p67)
			-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_44
			if v_u_10 then
				return
			elseif p67 == v_u_11 then
				v_u_10 = true
				ResetUI()
				v_u_44()
				task.delay(1, function()
					-- upvalues: (ref) v_u_10
					v_u_10 = false
				end)
			end
		end)
		workspace.DepthRopePrompts:WaitForChild("Pirate Cove").Descend.Triggered:Connect(function(p68)
			-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_66
			if v_u_10 then
				return
			elseif p68 == v_u_11 then
				v_u_10 = true
				ResetUI()
				v_u_66()
				task.delay(1, function()
					-- upvalues: (ref) v_u_10
					v_u_10 = false
				end)
			end
		end)
	end
}