-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 450,
		["Type"] = "Fish",
		["Name"] = "Depthseeker Ray",
		["Description"] = "",
		["Icon"] = "rbxassetid://92527448781061",
		["Tier"] = 7
	},
	["SellPrice"] = 220000,
	["Variants"] = {},
	["Weight"] = {
		["Big"] = NumberRange.new(165000, 205000),
		["Default"] = NumberRange.new(145000, 155000)
	},
	["Probability"] = {
		["Chance"] = 8.333333333333333e-7
	},
	["TimeOfDay"] = {
		["Min"] = 17.78,
		["Max"] = 7
	},
	["Events"] = { "Night" },
	["_moduleScript"] = script
}
return v1