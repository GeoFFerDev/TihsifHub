-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	{ "WholeBody", 1 },
	{ "Centre", 2 }
}