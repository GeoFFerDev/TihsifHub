-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Packages.Observers)
local v_u_3 = require(v1.Packages.MarketplaceService)
v2.observeTag("DevProductPrice", function(p_u_4)
	-- upvalues: (copy) v_u_3
	local function v11()
		-- upvalues: (copy) p_u_4, (ref) v_u_3
		local v_u_5 = p_u_4:FindFirstChild("Cost", true) or p_u_4:FindFirstChild("Label")
		if v_u_5 then
			local v_u_6 = p_u_4:GetAttribute("ProductId") or p_u_4:GetAttribute("DevProductId")
			if v_u_6 then
				if v_u_6 <= 0 then
					v_u_5.Visible = false
				else
					v_u_3:GetProductInfoAsync(v_u_6, Enum.InfoType.Product):andThen(function(p7)
						-- upvalues: (copy) v_u_5
						local v8
						if p7 then
							local v9 = p7.PriceInRobux
							v8 = tostring(v9)
						else
							v8 = "???"
						end
						v_u_5.Text = ("\238\128\130%*"):format(v8)
						v_u_5.Visible = true
					end):catch(function(p10)
						-- upvalues: (copy) v_u_6, (copy) v_u_5
						warn((("[DevProductPrice] Failed to get product price for id: %* ||| Error: %*"):format(v_u_6, p10)))
						v_u_5.Text = "\238\128\130 Unknown"
					end)
				end
			else
				v_u_5.Visible = false
				return
			end
		else
			warn((("[DevProductPrice] Failed to update product for - %*"):format((p_u_4:GetFullName()))))
			return
		end
	end
	local v_u_12 = p_u_4:GetAttributeChangedSignal("ProductId"):Connect(v11)
	v11()
	return function()
		-- upvalues: (copy) v_u_12
		v_u_12:Disconnect()
	end
end)
return {}