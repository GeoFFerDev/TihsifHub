-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = require(v1.Packages.Replion)
local v4 = require(v1.Packages.Observers)
local v_u_5 = require(v1.Packages.MarketplaceService)
require(v1.Modules.GuiControl)
local function v_u_9(p_u_6, p7)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_2
	local v8 = v_u_3.Client:GetReplion("Data")
	if v8 then
		if not (p7 and v8:Find("Limiteds", p_u_6)) then
			pcall(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_2, (copy) p_u_6
				v_u_5:PromptProductPurchase(v_u_2, p_u_6)
			end)
		end
	else
		return
	end
end
v4.observeTag("DevProductPrompt", function(p10)
	-- upvalues: (copy) v_u_2, (copy) v_u_9
	local v_u_11 = p10:GetAttribute("LimitedProduct")
	local v_u_12 = p10:GetAttribute("DevProductId")
	if v_u_12 then
		local v13 = p10:GetAttribute("ActionText") or "Buy Item"
		local v14 = p10:GetAttribute("ObjectText") or ""
		local v_u_15 = Instance.new("ProximityPrompt")
		v_u_15.ObjectText = v14
		v_u_15.ActionText = v13
		v_u_15.ClickablePrompt = true
		v_u_15.RequiresLineOfSight = false
		v_u_15.MaxActivationDistance = 14
		v_u_15.KeyboardKeyCode = Enum.KeyCode.E
		v_u_15.GamepadKeyCode = Enum.KeyCode.DPadUp
		v_u_15.Style = Enum.ProximityPromptStyle.Custom
		v_u_15.Parent = p10
		local v_u_17 = v_u_15.Triggered:Connect(function(p16)
			-- upvalues: (ref) v_u_2, (ref) v_u_9, (copy) v_u_12, (copy) v_u_11
			if p16 == v_u_2 then
				v_u_9(v_u_12, v_u_11)
			end
		end)
		return function()
			-- upvalues: (copy) v_u_17, (copy) v_u_15
			v_u_17:Disconnect()
			v_u_15:Destroy()
		end
	end
	warn((("[DevProductPrompt] No DevProductId found for: %*"):format((p10:GetFullName()))))
end)
return {}