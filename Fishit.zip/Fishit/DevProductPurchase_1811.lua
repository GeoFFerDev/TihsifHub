-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = v_u_2:WaitForChild("PlayerGui")
local v_u_4 = require(v_u_1.Packages.Replion)
local v5 = require(v_u_1.Packages.Net)
local v_u_6 = require(v_u_1.Packages.Observers)
local v_u_7 = require(v_u_1.Packages.MarketplaceService)
require(v_u_1.Shared.GiftProducts)
local v_u_8 = require(v_u_1.Shared.GamePassUtility)
local v_u_9 = require(v_u_1.Shared.Soundbook)
local v_u_10 = require(v_u_1.Modules.GuiControl)
local v_u_11 = nil
local v_u_12 = v5:RemoteEvent("ProductPurchaseCompleted")
local v_u_13 = {
	2672015131,
	2672015276,
	2672015581,
	2672015764,
	2672016438,
	3354034695
}
local function v_u_17(p_u_14, p15)
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_2
	local v16 = v_u_4.Client:GetReplion("Data")
	if v16 then
		if not (p15 and v16:Find("Limiteds", p_u_14)) then
			pcall(function()
				-- upvalues: (ref) v_u_7, (ref) v_u_2, (copy) p_u_14
				return v_u_7:PromptProductPurchase(v_u_2, p_u_14)
			end)
		end
	else
		return
	end
end
v_u_4.Client:AwaitReplion("Data", function()
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (copy) v_u_6, (copy) v_u_10, (copy) v_u_8, (copy) v_u_17, (copy) v_u_3, (copy) v_u_12, (copy) v_u_13, (copy) v_u_9
	v_u_11 = require(v_u_1.Controllers.GiftingController)
	v_u_6.observeTag("DevProductPurchase", function(p18)
		-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_11, (ref) v_u_17
		local v_u_19 = p18:GetAttribute("LimitedProduct")
		local v_u_20 = p18:GetAttribute("DevProductId")
		if v_u_20 then
			local v_u_21 = {}
			local v22 = p18:FindFirstChild("Gift")
			if v22 then
				local v23 = v_u_10:Hook("Hold Button", v22)
				v23.Clicked:Connect(function()
					-- upvalues: (copy) v_u_20, (ref) v_u_8, (ref) v_u_11
					local v24 = v_u_8:GetGiftData(v_u_20)
					if v24 then
						if v_u_11 then
							v_u_11:Open(v24.product)
						end
					end
				end)
				table.insert(v_u_21, v23)
			end
			local v25 = p18:FindFirstChild("Buy") or p18:IsA("ImageButton") and p18
			if v25 then
				local v26 = v_u_10:Hook("Hold Button", v25)
				v26.Clicked:Connect(function()
					-- upvalues: (ref) v_u_17, (copy) v_u_20, (copy) v_u_19
					v_u_17(v_u_20, v_u_19)
				end)
				table.insert(v_u_21, v26)
			end
			return function()
				-- upvalues: (copy) v_u_21
				for _, v27 in v_u_21 do
					v27:Destroy()
				end
				table.clear(v_u_21)
			end
		end
		warn((("[DevProductPurchase] No DevProductId found for: %*"):format((p18:GetFullName()))))
	end, { v_u_3, workspace })
	v_u_12.OnClientEvent:Connect(function(p28)
		-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_1
		local v29
		if p28 and (p28.ProductId and table.find(v_u_13, p28.ProductId)) then
			v_u_9.Sounds.CoinsChanged:Play()
			v29 = {
				["R"] = 255,
				["G"] = 231,
				["B"] = 18
			}
		else
			v29 = {
				["R"] = 255,
				["G"] = 255,
				["B"] = 255
			}
		end
		require(v_u_1.Controllers.TextNotificationController):DeliverNotification({
			["Type"] = "Text",
			["Text"] = "\240\159\164\141 Thank you for supporting us!",
			["TextColor"] = v29,
			["CustomDuration"] = 5
		})
	end)
end)
return {}