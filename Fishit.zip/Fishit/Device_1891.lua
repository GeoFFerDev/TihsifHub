-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("UserInputService")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("Players")
local v_u_5 = workspace.CurrentCamera
local v_u_6 = v4.LocalPlayer.PlayerGui
local v_u_7 = require(v3.Packages.Trove)
local v_u_8 = {}
v_u_8.__index = v_u_8
function v_u_8.new()
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	local v9 = {
		["Device"] = v_u_8:_getDevice(),
		["Cleaner"] = v_u_7.new(),
		["DeviceCallbacks"] = {}
	}
	local v10 = v_u_8
	local v11 = setmetatable(v9, v10)
	v11:_init()
	return v11
end
function v_u_8.IsMobile(p12)
	-- upvalues: (copy) v_u_8
	local v13 = v_u_8:_getDevice()
	p12.Device = v13
	return v13 == "Tablet" and true or v13 == "Phone"
end
function v_u_8.RegisterDeviceChanged(p14, p15)
	local v16 = p14.DeviceCallbacks
	table.insert(v16, p15)
	return p15
end
function v_u_8.Remove(p17, p18)
	local v19 = table.find(p17.DeviceCallbacks, p18)
	if v19 then
		table.remove(p17.DeviceCallbacks, v19)
	end
end
function v_u_8._getDevice(_)
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_5
	local v20 = v_u_2:GetLastInputType()
	if v_u_1:IsTenFootInterface() or v20.Name:find("Gamepad") then
		return "Console"
	end
	if v_u_2.MouseEnabled and v_u_2.KeyboardEnabled then
		return "PC"
	end
	if v_u_1.TouchControlsEnabled or v_u_2.TouchEnabled then
		if v_u_5.ViewportSize.Y <= 500 then
			return "Phone"
		end
		if v_u_2.TouchEnabled or v20 == Enum.UserInputType.Touch then
			return "Tablet"
		end
	end
	return "PC"
end
function v_u_8._onDeviceChanged(p21)
	local v22 = p21.Device
	local v23 = p21:_getDevice()
	if v23 ~= v22 then
		p21.Device = v23
		for _, v24 in ipairs(p21.DeviceCallbacks) do
			task.spawn(v24, v23)
		end
	end
end
function v_u_8._init(p_u_25)
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_6
	p_u_25.Cleaner:Add(v_u_2.InputChanged:Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_2.InputBegan:Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_2.LastInputTypeChanged:Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_5:GetPropertyChangedSignal("ViewportSize"):Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_6:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_2:GetPropertyChangedSignal("MouseEnabled"):Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_2:GetPropertyChangedSignal("TouchEnabled"):Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
	p_u_25.Cleaner:Add(v_u_2:GetPropertyChangedSignal("GamepadEnabled"):Connect(function()
		-- upvalues: (copy) p_u_25
		p_u_25:_onDeviceChanged()
	end))
end
return v_u_8.new()