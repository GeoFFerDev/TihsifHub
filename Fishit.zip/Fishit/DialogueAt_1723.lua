-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	[480] = {
		["Speaker"] = "Scientist",
		["SpeakerColor"] = Color3.fromRGB(255, 50, 50),
		["Message"] = "You really did it! Now we can keep track of the comet... again...",
		["LastsFor"] = 3.1
	},
	[675] = {
		["Speaker"] = "Scientist",
		["SpeakerColor"] = Color3.fromRGB(255, 50, 50),
		["Message"] = "This comet, its holding some... ancient energy.",
		["LastsFor"] = 4.5
	},
	[950] = {
		["Speaker"] = "Scientist",
		["SpeakerColor"] = Color3.fromRGB(255, 50, 50),
		["Message"] = "Like nothing we\'ve seen before.",
		["LastsFor"] = 4
	},
	[1210] = {
		["Speaker"] = "Scientist",
		["SpeakerColor"] = Color3.fromRGB(255, 50, 50),
		["Message"] = "Its going to attract something very... very big!",
		["LastsFor"] = 4.75
	},
	[1505] = {
		["Speaker"] = "Scientist",
		["SpeakerColor"] = Color3.fromRGB(255, 50, 50),
		["Message"] = "Take a look through our telescope to see for yourself.",
		["LastsFor"] = 3.25
	}
}
return v1