-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ProximityPromptService")
game:GetService("RunService")
game:GetService("UserInputService")
game:GetService("ContextActionService")
local v2 = game:GetService("ReplicatedStorage")
local _ = game:GetService("Players").LocalPlayer
require(v2.Packages.Net)
local v3 = require(v2.Packages.Signal)
require(v2.Packages.Trove)
require(v2.Packages.Thread)
require(v2.Packages.Observers)
require(script.Internal.Types)
local v_u_4 = require(script.Internal.DialogueTree)
local v_u_5 = v3.new()
local v_u_6 = false
local v_u_7 = nil
local v_u_8 = false
local v_u_21 = {
	["New"] = function(_, p9, p10)
		-- upvalues: (copy) v_u_21, (copy) v_u_4, (ref) v_u_7
		if v_u_21:IsLocked() or not v_u_4[p9] then
			return false
		end
		local v11
		if p10:IsA("Model") then
			v11 = p10:WaitForChild("Head")
		else
			v11 = p10
		end
		if not v11 then
			return false
		end
		v_u_21:Lock()
		local v12 = v_u_7.create(p9, v11, p10)
		v12:onDestroyed(function()
			-- upvalues: (ref) v_u_21
			v_u_21:Unlock()
		end)
		v12:populate()
		local v13 = v12:wait()
		v12:destroy()
		return v13
	end,
	["Wait"] = function(_)
		-- upvalues: (ref) v_u_6, (copy) v_u_5
		if not v_u_6 then
			v_u_5:Wait()
		end
	end,
	["ObservePath"] = function(_, p_u_14, p_u_15, p_u_16)
		-- upvalues: (copy) v_u_21, (ref) v_u_7
		local v_u_17 = nil
		task.spawn(function()
			-- upvalues: (ref) v_u_21, (ref) v_u_17, (ref) v_u_7, (copy) p_u_14, (copy) p_u_15, (copy) p_u_16
			v_u_21:Wait()
			v_u_17 = v_u_7.PathSignal:Connect(function(p18, p19, p20)
				-- upvalues: (ref) p_u_14, (ref) p_u_15, (ref) p_u_16
				if p18 == p_u_14 and p_u_15 == p19 then
					p_u_16(p20)
				end
			end)
		end)
		return function()
			-- upvalues: (ref) v_u_17
			if v_u_17 then
				v_u_17:Disconnect()
			end
		end
	end,
	["Lock"] = function(_)
		-- upvalues: (ref) v_u_8, (copy) v_u_1
		v_u_8 = true
		v_u_1.Enabled = false
	end,
	["Unlock"] = function(_)
		-- upvalues: (ref) v_u_8, (copy) v_u_1
		v_u_8 = false
		v_u_1.Enabled = true
	end,
	["IsLocked"] = function(_)
		-- upvalues: (ref) v_u_8
		return v_u_8 == true
	end,
	["Start"] = function(_)
		-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_5
		v_u_7 = require(script.Internal.Dialogue)
		v_u_6 = true
		v_u_5:Fire()
	end
}
return v_u_21