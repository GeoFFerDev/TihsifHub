-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
game:GetService("Players")
require(script.Parent.Types)
local v_u_2 = require(v1.Packages.Replion)
require(v1.Packages.Net)
local v_u_3 = require(v1.Modules.Quests)
local v_u_4 = require(v1.Shared.Constants)
local v_u_5 = require(v1.Shared.AreaUtility)
local v_u_6 = require(v1.Shared.ItemUtility)
local v_u_7 = require(v1.Shared.PlayerStatsUtility)
local v_u_8 = require(v1.Observers.VolcanicCavernDoor)
local v_u_9 = v_u_2.Client:WaitReplion("Data")
local function v_u_19(p10, p11)
	-- upvalues: (copy) v_u_3, (copy) v_u_9
	local v12 = v_u_3[p10][p11]
	if not v12 then
		return false, false
	end
	local v13 = v_u_9:GetExpect("CompletedQuests")
	local v14 = false
	if table.find(v13, p11) then
		return true, true
	end
	local v15 = v_u_9:Get({ "Quests", "Event", p11 })
	if not v15 then
		return false
	end
	for v16, v17 in pairs(v15.Objectives) do
		local v18 = v12.Objectives[v16]
		if v18 then
			v14 = v17.Progress >= v18.Goal
			if not v14 then
				break
			end
		end
	end
	return true, v14
end
local v20 = {}
local v21 = {}
local v22 = {
	["Dialogue"] = {
		{
			["Reply"] = "When does this event end?",
			["Response"] = DateTime.fromUnixTimestamp(v_u_4.Flags.ValentineEndTime):FormatLocalTime("lll", "en-us"),
			["Result"] = true
		},
		{
			["Reply"] = "View Shop",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "View Battlepass",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v21, 1, {v22})
v20.Florist = v21
local v23 = {}
local v24 = {
	["Dialogue"] = {
		{
			["Reply"] = "What are you?",
			["Response"] = "\226\132\184 \204\163 \226\149\142\225\146\178\225\146\183  \226\149\142\225\147\173  ||\240\157\153\185\226\154\141\226\136\183  \226\136\180\240\157\153\185\226\136\183\225\147\173\226\132\184 \204\163   \225\146\183\227\131\170\225\146\183\225\146\178||",
			["Result"] = true
		},
		{
			["Reply"] = "When does this area open?",
			["Response"] = "\226\149\142  \225\148\145\225\146\178  \202\150\226\154\141\226\136\183\227\131\170\226\149\142\227\131\170\226\138\163  \226\154\141!\194\161",
			["Result"] = true
		},
		{
			["Reply"] = "I don\'t understand",
			["Response"] = "\225\147\173\226\154\141\225\147\181\226\141\145  \226\149\142\225\147\173  \226\132\184 \204\163 \226\141\145\225\146\183  \227\131\170\225\148\145\226\132\184 \204\163 \226\154\141\226\136\183\225\146\183  \240\157\153\185\226\142\147  \234\150\142\226\149\142\226\142\147\225\146\183",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v23, 1, {v24})
v20["Lava Dweller"] = v23
local v25 = {}
local v26 = {
	["Dialogue"] = {
		{
			["Reply"] = "Seismic activity",
			["Response"] = "You should get out of here! Seismic readings are off the charts lately",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v25, 1, {v26})
v20["Reactor Man"] = v25
local v27 = {}
local v28 = {
	["Dialogue"] = {
		{
			["Reply"] = "Hazmat Suit Quest",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "Why the suit?",
			["Response"] = "It\'s a requirement to travel below the Volcano",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v27, 1, {v28})
v20["Hazmat Leader"] = v27
local v29 = {}
local v30 = {
	["Dialogue"] = {
		{
			["Reply"] = "Any luck?",
			["Response"] = "No not yet! I\'m overflowing with Magma Gobys!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v29, 1, {v30})
v20["Lava Fisherman"] = v29
local v31 = {}
local v32 = {
	["Dialogue"] = {
		{
			["Reply"] = "Scientist Lucille said you forgot this?",
			["Response"] = "OML I totally did! Thank you so much!",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v36 = {
	["Dialogue"] = {
		{
			["Reply"] = "What\'re you even doing here?",
			["Response"] = "Something odd seems to be going on with the island... do you think you could help me measure a few things?",
			["Path"] = 3
		},
		{
			["Reply"] = "Ok I have those measurements!",
			["Response"] = function()
				-- upvalues: (copy) v_u_9, (copy) v_u_3
				local v33 = v_u_9:Get({ "Quests", "Mainline" })
				local v34
				if v33 and v33["Taking Measurements"] then
					local v35 = v_u_3.Mainline["Taking Measurements"]
					v34 = v33["Taking Measurements"].Objectives[1].Progress >= v35.Objectives[1].Goal
				else
					v34 = false
				end
				return v34 and "Those are very interesting readings... something odd is happening..." or "What\'re you talking about?"
			end
		}
	},
	["IncludeExitDialogue"] = true
}
local v37 = {
	["Dialogue"] = {
		{
			["Reply"] = "Absolutely!",
			["Response"] = "Sick! Basically just walk around the island and use that tool and report the findings to me",
			["Result"] = true
		},
		{
			["Reply"] = "No I can\'t right now.",
			["Response"] = "Oh, well that sucks. Let me know if you change your mind."
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v31, 1, {v32, v36, v37})
v20["Scientist Samantha"] = v31
v20["Scientist Lucille"] = { function()
		-- upvalues: (copy) v_u_9
		return v_u_9:Find("CompletedQuests", "Sample Collection") ~= nil and {
			["Dialogue"] = {
				{
					["Reply"] = "What is this place??",
					["Response"] = "Dunno... I just work here",
					["Result"] = true
				},
				{
					["Reply"] = "I have the samples you requested from Scientist Jameson",
					["Response"] = "Awesome! Sam forgot this tool, could you take it to her in Crater Island?",
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		} or {
			["Dialogue"] = {
				{
					["Reply"] = "What is this place??",
					["Response"] = "Dunno... I just work here"
				}
			},
			["IncludeExitDialogue"] = true
		}
	end }
local v38 = {}
local v39 = {
	["Dialogue"] = {
		{
			["Reply"] = "Woah... what is this..?",
			["Response"] = "Not important!! I need samples, please go collect them.",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v40 = {
	["Dialogue"] = {
		{
			["Reply"] = "Ok where can I find them?",
			["Response"] = "They can be found around the island!"
		},
		{
			["Reply"] = "I have your samples!",
			["Response"] = "Could you please take those over to Lucy in the lab? Thanks!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v38, 1, {v39, v40})
v20["Scientist Jameson"] = v38
local v41 = {}
local v42 = {
	["Dialogue"] = {
		{
			["Reply"] = "Who are you guys?",
			["Response"] = "I\'m Phil and this is Bill, we are adventurers!",
			["Result"] = true
		},
		{
			["Reply"] = "Have y\'all heard anything interesting lately?",
			["Response"] = "We have.",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v43 = {
	["Dialogue"] = {
		{
			["Reply"] = "Well... are you going to tell me???",
			["Response"] = "Oh! I guess I could give you some information... but you have to help us first!",
			["Path"] = 3
		}
	},
	["IncludeExitDialogue"] = true
}
local v44 = {
	["Dialogue"] = {
		{
			["Reply"] = "Fine, what do you need?",
			["Response"] = "Ask Bill, I\'m pretty clueless to be honest",
			["Result"] = true
		},
		{
			["Reply"] = "I\'d rather not, I\'ll figure it out myself.",
			["Response"] = "Wow, that was rather rude dontcha think Bill?",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v41, 1, {v42, v43, v44})
v20.Phil = v41
local v45 = {}
local v46 = {
	["Dialogue"] = {
		{
			["Reply"] = "Who are you guys?",
			["Response"] = "I\'m Bill and this is Phil, we are explorers!",
			["Result"] = true
		},
		{
			["Reply"] = "Phil said y\'all needed some help and in exchange you would tell me some rumors you heard?",
			["Response"] = "A weird laboratory has popped up on the island, catch us a few fish from that area and we\'ll let you know what we know.",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v50 = {
	["Dialogue"] = {
		{
			["Reply"] = "Ok, I have the fish, now spill the beans!",
			["Response"] = function()
				-- upvalues: (copy) v_u_9, (copy) v_u_3
				local v47 = v_u_9:Get({ "Quests", "Mainline" })
				local v48
				if v47 and v47["A Rumor"] then
					local v49 = v_u_3.Mainline["A Rumor"]
					v48 = v47["A Rumor"].Objectives[1].Progress >= v49.Objectives[1].Goal
				else
					v48 = false
				end
				return v48 and "All I\'ve heard is they\'re bringing hazmat suits..." or "Yeah right, come back once you\'ve finished!"
			end,
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v45, 1, {v46, v50})
v20.Bill = v45
local v51 = {}
local v52 = {
	["Dialogue"] = {
		{
			["Reply"] = "Deadman\'s Treasure",
			["Response"] = "I lost some letters in Pirate Cove, find them and return them and I\'ll grant you my treasure.",
			["Result"] = true
		},
		{
			["Reply"] = "I have found all the letters!",
			["Response"] = "YARRRRRR!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v51, 1, {v52})
v20["Dead Skeleton"] = v51
local v53 = {}
local v54 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "Mysterious Maze",
			["Response"] = "There is a maze on the other side of that pile of rubble!",
			["Result"] = true
		},
		{
			["Reply"] = "Hooke Bobber",
			["Response"] = "The most precious Bobber pirates have ever known! Do my tasks and you too can own one",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v55 = {
	["Dialogue"] = {
		{
			["Reply"] = "Start Quest",
			["Response"] = "Catch 5 fish with the Leviathan Rage mutation!",
			["Result"] = true
		},
		{
			["Reply"] = "I\'ll pass",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = false
}
__set_list(v53, 1, {v54, v55})
v20.Hookie = v53
local v56 = {}
local v57 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "Who are you?",
			["Response"] = "A lost Sea Captain fella. Unfortunately my quest has expired and I am looking for new waters to explore.",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
local v58 = {
	["Dialogue"] = {
		{
			["Reply"] = "1 Enraged Fish",
			["Response"] = "I need a fish with Leviathan Rage on it",
			["Result"] = true
		},
		{
			["Reply"] = "The Dead Man\'s Compass",
			["Response"] = "Legends say beneath the Trident lies the Compass...",
			["Result"] = true
		},
		{
			["Reply"] = "1 Cursed Kraken",
			["Response"] = "I need you to bring me a SECRET Cursed Kraken",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
local v59 = {
	["Dialogue"] = {
		{
			["Reply"] = "Start Quest",
			["Response"] = "Return when you have completed all my tasks!",
			["Result"] = true
		},
		{
			["Reply"] = "Complete Quest!",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
local v60 = {
	["Dialogue"] = {
		{
			["Reply"] = "[CURSED KRAKEN]",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "[ENRAGED FISH]",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v56, 1, {v57, v58, v59, v60})
v20["Captain Jones"] = v56
local v61 = {}
local v62 = {
	["Dialogue"] = {
		{
			["Reply"] = "What instrument is that?",
			["Response"] = "A Banjo!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v61, 1, {v62})
v20.Musician = v61
local v63 = {}
local v64 = {
	["Dialogue"] = {
		{
			["Reply"] = "What is a Fishmonger?",
			["Response"] = "I prepare the freshest fish for my pirate crew",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v63, 1, {v64})
v20.Fishmonger = v63
v20.Archaeologist = { function()
		-- upvalues: (copy) v_u_5, (copy) v_u_9
		if not v_u_5:AreaUnlocked(v_u_9, "Pirate Cove") then
			return {
				["Dialogue"] = {
					{
						["Reply"] = "The Leviathan",
						["Response"] = "It\'s a monsterous fish that can only be summoned with rare artifacts and a Leviathan\'s Scale",
						["Result"] = true
					},
					{
						["Reply"] = "View Progress",
						["Response"] = "",
						["Result"] = true
					}
				},
				["IncludeExitDialogue"] = true
			}
		end
		local v65 = v_u_9:Get({ "Quests", "Mainline", "Forgotten Scale" })
		local v66 = v65 ~= nil
		local v67
		if v65 == nil then
			v67 = false
		else
			v67 = v65.Claimed
		end
		local v68
		if v67 and (v65 and v65.ClaimedAt) then
			local v69 = 86400 - (workspace:GetServerTimeNow() - v65.ClaimedAt)
			v68 = math.max(v69, 0)
		else
			v68 = nil
		end
		local v70
		if v68 then
			local v71 = v68 % 86400
			local v72 = v68 / 86400
			math.floor(v72)
			local v73 = v71 / 3600
			local v74 = math.floor(v73)
			local v75 = v71 % 3600 / 60
			local v76 = math.floor(v75)
			local v77 = v68 % 60
			v70 = ("Quest resets in: %*"):format((("%dh %dm %ds"):format(v74, v76, (math.floor(v77)))))
		else
			v70 = v67 and "You completed the quest for today!" or (v66 and "Catch the Artifacts on any island, as long as this quest is active!" or "Activated this quest now!")
		end
		return {
			["Dialogue"] = {
				{
					["Reply"] = "The Leviathan",
					["Response"] = "It\'s a monsterous fish that can only be summoned with rare artifacts and a Leviathan\'s Scale",
					["Result"] = true
				},
				{
					["Reply"] = "View Progress",
					["Response"] = "You completed the Pirate Cove index! Come back daily to earn a Leviathan Scale",
					["Result"] = true
				},
				{
					["Reply"] = "Forgotten Scale Quest",
					["Response"] = v70,
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		}
	end }
local v78 = {}
local v79 = {
	["Dialogue"] = {
		{
			["Reply"] = "What are you doing here?",
			["Response"] = "The captain ordered me to clear the rubble blocking the cave",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v80 = {
	["Dialogue"] = {
		{
			["Reply"] = "I can help!",
			["Response"] = "That\'s a relief! Find sticks of TNT around the Island to clear the way",
			["Result"] = true
		},
		{
			["Reply"] = "That sucks",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = false
}
__set_list(v78, 1, {v79, v80})
v20.Carpenter = v78
local v81 = {}
local v82 = {
	["Dialogue"] = {
		{
			["Reply"] = "Crystalline Secrets Quest",
			["Response"] = ""
		},
		{
			["Reply"] = "[Exchange Items]",
			["Response"] = "",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v83 = {
	["Dialogue"] = {
		{
			["Reply"] = "[CURSED KRAKEN]",
			["Response"] = ""
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v81, 1, {v82, v83})
v20["Ghastly Pirate"] = v81
local v84 = {}
local v85 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "Shiny Rocks?",
			["Response"] = "Help me finish my research and I\'ll reward you greatly",
			["Result"] = true
		},
		{
			["Reply"] = "Diamond Researcher Quest",
			["Response"] = ""
		},
		{
			["Reply"] = "[Exchange Items]",
			["Response"] = "",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v86 = {
	["Dialogue"] = {
		{
			["Reply"] = "[GEMSTONE RUBY]",
			["Response"] = ""
		},
		{
			["Reply"] = "[LOCHNESS MONSTER]",
			["Response"] = ""
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v84, 1, {v85, v86})
v20["Diamond Researcher"] = v84
local v87 = {}
local v88 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "I would like to use the elevator.",
			["Response"] = "Ok, that\'ll be 400 Coins.",
			["Path"] = 2
		},
		{
			["Reply"] = "Do you have any quests for me?",
			["Response"] = "If you enchant a rod 5 times I\'ll give you something in exchange."
		}
	},
	["IncludeExitDialogue"] = true
}
local v89 = {
	["Dialogue"] = {
		{
			["Reply"] = "Ok, here you are.",
			["Response"] = "Preciate it"
		},
		{
			["Reply"] = "That\'s too expensive!",
			["Response"] = "Your loss"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v87, 1, {v88, v89})
v20["Esoteric Gatekeeper"] = v87
local v90 = {}
local v91 = {
	["Dialogue"] = {
		{
			["Reply"] = "Do you need any help?",
			["Response"] = "Sam thinks he\'s the best fisherman... we\'ll show him up by catching some BIG fish!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v90, 1, {v91})
v20.Ram = v90
local v92 = {}
local v93 = {
	["Dialogue"] = {
		{
			["Reply"] = "Are you the best fisherman around here?",
			["Response"] = "Some might say that."
		},
		{
			["Reply"] = "How can I get to the level you are at?",
			["Response"] = "If you wanna get on my level, you\'re going to have to prove yourself."
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v92, 1, {v93})
v20.Sam = v92
local v94 = {}
local v95 = {
	["Dialogue"] = {
		{
			["Reply"] = "What\'s wrong??",
			["Response"] = "I dropped some coins I scavenged earlier! Can you help me find them??",
			["DialogueType"] = "QuestGiver"
		},
		{
			["Reply"] = "I think I have found all the coins you were missing...",
			["Response"] = "Really?! You\'re the best!",
			["DialogueType"] = "QuestTurnIn"
		},
		{
			["Reply"] = "Is there anything else I can help you with?",
			["Response"] = "Well actually... I think I misplaced my boat keys in the Tropical Grove",
			["DialogueType"] = "QuestGiver"
		},
		{
			["Reply"] = "I have found your boat keys!",
			["Response"] = "You are a livesaver! Took me forever to get my boating license!!",
			["DialogueType"] = "QuestTurnIn"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v94, 1, {v95})
v20["Scuba Steve"] = v94
local v96 = {}
local v97 = {
	["Dialogue"] = {
		{
			["Reply"] = "Jungle Fish",
			["Response"] = "If you can find me some fish, I\'ll give you something in return!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v96, 1, {v97})
v20.Astrid = v96
local v98 = {}
local v99 = {
	["Dialogue"] = {
		{
			["Reply"] = "What\'re you doing out here?",
			["Response"] = "I am out here foraging for mushrooms! And now you\'re gonna help me, look for cutie mushrooms on the ground!"
		},
		{
			["Reply"] = "Are you looking for any fish?",
			["Response"] = "Nothing specifically, just something... different..."
		},
		{
			["Reply"] = "I have found all your mushrooms!",
			["Response"] = "OMG thank you!! Here is your reward!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v98, 1, {v99})
v20["Forager Jen"] = v98
local v100 = {}
local v101 = {
	["Dialogue"] = {
		{
			["Reply"] = "Spicy Fish",
			["Response"] = "I love spicy food, just like the fish in this area! Collect a few and I\'ll give you something special."
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v100, 1, {v101})
v20["Volcanic Fisherman"] = v100
local v102 = {}
local v103 = {
	["Dialogue"] = {
		{
			["Reply"] = "RIBBIT",
			["Response"] = "RIBBIT RIBBIT"
		},
		{
			["Reply"] = "Frog Army Quest",
			["Response"] = "Gather an army of frogs from the coasts of Fisherman Island!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v102, 1, {v103})
v20["Frog Commander"] = v102
local v104 = {}
local v105 = {
	["Dialogue"] = {
		{
			["Reply"] = "Heavenly Fish Quest",
			["Response"] = "Complete this quest for a reward!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v104, 1, {v105})
v20["Crabby Guy"] = v104
local v106 = {}
local v107 = {
	["Dialogue"] = {
		{
			["Reply"] = "Lost ye treasure?",
			["Response"] = "Aye I did, now you must bring them to me! Now get goin\' -- fortune favors the bold!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v106, 1, {v107})
v20["Capt Jack"] = v106
local v108 = {}
local v109 = {
	["Dialogue"] = {
		{
			["Reply"] = "Swimming Narwhals",
			["Response"] = "Find me a Narwhal and something to eat to receive something awesome!"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v108, 1, {v109})
v20.Narwhal = v108
local v110 = {}
local v111 = {
	["Dialogue"] = {
		{
			["Reply"] = "View Store",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "View Inventory",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v110, 1, {v111})
v20["Lantern Keeper"] = v110
local v112 = {}
local v113 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "Christmas Quest",
			["Response"] = "Complete the Christmas Celebration quest for a reward!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v112, 1, {v113})
v20["Gingerbread Man"] = v112
local v114 = {}
local v115 = {
	["Dialogue"] = {
		{
			["Reply"] = "What is the Gift Factory",
			["Response"] = "Exchange your gifts for limited rewards!",
			["Result"] = true
		},
		{
			["Reply"] = "Where to get Presents",
			["Response"] = "Fishing at the Christmas Cave or knocking on house doors",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v114, 1, {v115})
v20["Tangled Elf"] = v114
v20.Chad = { function()
		-- upvalues: (copy) v_u_2, (copy) v_u_19
		local v116 = false
		local v117
		if v_u_2.Client:GetReplion("Data").Destroyed then
			v117 = true
		else
			local v118, v119 = v_u_19("Event", "Cave Explorer")
			v117 = (v118 or v119) and true or v116
		end
		return v117 and {
			["Dialogue"] = {
				{
					["Reply"] = "What is this place?",
					["Response"] = "Special area that is only open for 1h 30m!",
					["Result"] = true
				},
				{
					["Reply"] = "When does it open next?",
					["Response"] = "Every 3 hours globally!",
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		} or {
			["Dialogue"] = {
				{
					["Reply"] = "What is this place?",
					["Response"] = "Special area that is only open for 1h 30m!",
					["Result"] = true
				},
				{
					["Reply"] = "When does it open next?",
					["Response"] = "Every 3 hours globally!",
					["Result"] = true
				},
				{
					["Reply"] = "[START QUEST]",
					["Response"] = "",
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		}
	end }
local v120 = {}
local v121 = {
	["Dialogue"] = {
		{
			["Reply"] = "Presents",
			["Response"] = "Try knocking on some of the house doors",
			["Result"] = true
		},
		{
			["Reply"] = "Candy Canes",
			["Response"] = "Level up the battlepass or check out the event store",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v120, 1, {v121})
v20["Distinguished Snowman"] = v120
v20.Leo = { function()
		-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_19
		local v122 = workspace:GetServerTimeNow()
		if v_u_9.Destroyed or v_u_4.Flags.ChristmasEndTime < v122 then
			return {
				["Dialogue"] = {
					{
						["Reply"] = "Is this event active?",
						["Response"] = "No",
						["Result"] = true
					}
				},
				["IncludeExitDialogue"] = true
			}
		end
		local v123, v124 = v_u_19("Event", "Save the Christmas Express")
		return v124 and {
			["Dialogue"] = {
				{
					["Reply"] = "I found them all!",
					["Response"] = "Thank you for saivng the day!",
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		} or (v123 and {
			["Dialogue"] = {
				{
					["Reply"] = "Still looking...",
					["Response"] = "I hope you can fish up those wheels!",
					["Result"] = true
				},
				{
					["Reply"] = "Where could they be?",
					["Response"] = "Try using your Fishing Radar",
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		} or {
			["Dialogue"] = {
				{
					["Reply"] = "What happened?",
					["Response"] = "A handful of our train wheels went missing!",
					["Result"] = true
				},
				{
					["Reply"] = "Where are they?",
					["Response"] = "I think they rolled into the water during maintenance",
					["Result"] = true
				},
				{
					["Reply"] = "[START QUEST]",
					["Response"] = "Use your Fishing Radar to locate the spots!",
					["Result"] = true
				}
			},
			["IncludeExitDialogue"] = true
		})
	end }
local v125 = {}
local v126 = {
	["Dialogue"] = {
		{
			["Reply"] = "Ho Ho Ho",
			["Response"] = "HO HO HO!",
			["Result"] = true
		},
		{
			["Reply"] = "[HAND PRESENT]",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v125, 1, {v126})
v20.Santa = v125
local v127 = {}
local v128 = {
	["Dialogue"] = {
		{
			["Reply"] = "Open Shop",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "Ho Ho Ho?",
			["Response"] = "WOOF",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v127, 1, {v128})
v20["Santa Doge"] = v127
local v129 = {}
local v130 = {
	["Dialogue"] = {
		{
			["Reply"] = "Who are you?",
			["Response"] = "I guess that nasty Tornado swept me all the way here",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v129, 1, {v130})
v20.Stickmasterluke = v129
local v131 = {}
local v132 = {
	["Dialogue"] = {
		{
			["Reply"] = "How do you like your chicken",
			["Response"] = "Isn\'t that obvious?",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v131, 1, {v132})
v20.Shedletsky = v131
local v133 = {}
local v134 = {
	["Dialogue"] = {
		{
			["Reply"] = "Fishing Spots",
			["Response"] = "Anywhere along the shore or further up this path!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v133, 1, {v134})
v20.Merely = v133
local v135 = {}
local v136 = {
	["Dialogue"] = {
		{
			["Reply"] = "Classic Event?",
			["Response"] = "Explore the new Classic Event island!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v135, 1, {v136})
v20["Epic Guide"] = v135
local v137 = {}
local v138 = {
	["Dialogue"] = {
		{
			["Reply"] = "SECRETS?",
			["Response"] = "I prefer my Clownfish, no thanks!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v137, 1, {v138})
v20.Noob = v137
local v139 = {}
local v140 = {
	["Dialogue"] = {
		{
			["Reply"] = "Disco Event?",
			["Response"] = "Spawns every 2 hours!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v139, 1, {v140})
v20["John Doe"] = v139
local v141 = {}
local v142 = {
	["Dialogue"] = {
		{
			["Reply"] = "<Observe>",
			["Response"] = "Leave",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v141, 1, {v142})
v20.Guest = v141
v20.Hank = { function()
		-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_9
		local v_u_143 = v_u_6.GetItemDataFromItemType("Gears", "Hank\'s Diary")
		local v144
		if v_u_143 then
			v144 = v_u_7:GetItemFromInventory(v_u_9, function(p145)
				-- upvalues: (copy) v_u_143
				return p145.Id == v_u_143.Data.Id
			end)
		else
			v144 = nil
		end
		if v144 then
			local v146 = {
				["Dialogue"] = {
					{
						["Reply"] = "What are those crystals?",
						["Response"] = "Some of them glow every few hours, I\'ve heard they give a special mutation...",
						["Result"] = true
					},
					{
						["Reply"] = "Crystal Gathering Quest",
						["Response"] = "If you can fish up my Sunken Diary, I\'ll give you my Pickaxe! It can extract glowing crystals!",
						["DialogueType"] = "QuestGiver"
					},
					{
						["Reply"] = "I found your Diary!",
						["Response"] = "My notes! Take this Pickaxe as thanks. Equip it when crystals glow and extract Cave Crystals!",
						["DialogueType"] = "QuestTurnIn"
					},
					{
						["Reply"] = "...",
						["Response"] = "",
						["Void"] = true
					}
				},
				["IncludeExitDialogue"] = false
			}
			return v146
		else
			local v147 = {
				["Dialogue"] = {
					{
						["Reply"] = "What are those crystals?",
						["Response"] = "Some of them glow every few hours, I\'ve heard they give a special mutation...",
						["Result"] = true
					},
					{
						["Reply"] = "Crystal Gathering Quest",
						["Response"] = "If you can fish up my Sunken Diary, I\'ll give you my Pickaxe! It can extract glowing crystals!",
						["DialogueType"] = "QuestGiver"
					},
					{
						["Reply"] = "I found your Diary!",
						["Response"] = "You have not found it yet!",
						["DialogueType"] = "QuestTurnIn"
					},
					{
						["Reply"] = "Leave",
						["Response"] = "",
						["Void"] = true
					}
				},
				["IncludeExitDialogue"] = false
			}
			return v147
		end
	end }
local v148 = {}
local v149 = {
	["Dialogue"] = {
		{
			["Reply"] = "Coral Quest",
			["Response"] = "If you can collect 30 corals, I\'ll give you my Coral Lantern!",
			["DialogueType"] = "QuestGiver"
		},
		{
			["Reply"] = "I got the corals.",
			["Response"] = "Thank you so much, Here is my Coral Lantern!",
			["DialogueType"] = "QuestTurnIn"
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v148, 1, {v149})
v20.Dorian = v148
v20["Magma Fisherman"] = { function()
		-- upvalues: (copy) v_u_19, (copy) v_u_8
		local v150, v151 = v_u_19("Mainline", "Kohana Gatekeeper")
		if v151 then
			local v152 = {
				["Dialogue"] = {
					{
						["Reply"] = "I did everything!",
						["Response"] = "Thank you so much, here let me open the door!",
						["Result"] = true,
						["FinishedCallback"] = function()
							-- upvalues: (ref) v_u_8
							v_u_8.OpenGate:Fire()
						end
					}
				},
				["IncludeExitDialogue"] = true
			}
			return v152
		elseif v150 then
			local v153 = {
				["Dialogue"] = {
					{
						["Reply"] = "Still working on it...",
						["Response"] = "You got this!",
						["Result"] = true
					}
				},
				["IncludeExitDialogue"] = true
			}
			return v153
		else
			local v154 = {
				["Dialogue"] = {
					{
						["Reply"] = "Whats this?",
						["Response"] = "A giant door...",
						["Result"] = true
					},
					{
						["Reply"] = "How can I open the door?",
						["Response"] = "You just need to catch some fishes and use some charms!",
						["Result"] = true
					}
				},
				["IncludeExitDialogue"] = true
			}
			return v154
		end
	end }
local v155 = {}
local v156 = {
	["Dialogue"] = {
		{
			["Reply"] = "Hello",
			["Response"] = "Enjoy your visit!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v155, 1, {v156})
v20.Builderman = v155
local v157 = {}
local v158 = {
	["Dialogue"] = {
		{
			["Reply"] = "Greetings!",
			["Response"] = "Welcome to the Classic Island",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v157, 1, {v158})
v20.BrightEyes = v157
local v159 = {}
local v160 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Boats",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v159, 1, {v160})
v20["Boat Expert"] = v159
local v161 = {}
local v162 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Boats",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v161, 1, {v162})
v20.Navigator = v161
local v163 = {}
local v164 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Boats",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v163, 1, {v164})
v20.McBoatson = v163
local v165 = {}
local v166 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Boats",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v165, 1, {v166})
v20.Jeffery = v165
local v167 = {}
local v168 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Boats",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v167, 1, {v168})
v20.Scott = v167
local v169 = {}
local v170 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Fishing Rods",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "Where is the best Rod?",
			["Response"] = "Hidden deep within the Ancient Jungle",
			["Void"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v169, 1, {v170})
v20.Joe = v169
local v171 = {}
local v172 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Fishing Rods",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v171, 1, {v172})
v20.Burt = v171
local v173 = {}
local v174 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Shop",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v173, 1, {v174})
v20["Alien Merchant"] = v173
local v175 = {}
local v176 = {
	["Dialogue"] = {
		{
			["Reply"] = "The Jungle?",
			["Response"] = "Drive your boat in this direction to reach it!",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v175, 1, {v176})
v20.Jim = v175
local v177 = {}
local v178 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Fishing Rods",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v177, 1, {v178})
v20.Tim = v177
local v179 = {}
local v180 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Potions",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "Do you have any quests?",
			["Response"] = "Well, I might have a few things you can do...",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = true
}
local v181 = {
	["Dialogue"] = {
		{
			["Reply"] = "Do you need any test subjects?",
			["Response"] = "I could use a few fish for an upcoming experiment I want to perform."
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v179, 1, {v180, v181})
v20.Scientist = v179
local v182 = {}
local v183 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Rod Skins",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v182, 1, {v183})
v20["Billy Bob"] = v182
local v184 = {}
local v185 = {
	["Dialogue"] = {
		{
			["Reply"] = "What is that to your left?",
			["Response"] = "This is my trusty Megalofriend Skin",
			["Result"] = true
		},
		{
			["Reply"] = "[More Info]",
			["Response"] = "",
			["Path"] = 2
		},
		{
			["Reply"] = "[Claim Reward]",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
local v186 = {
	["Dialogue"] = {
		{
			["Reply"] = "What level do I have to be?",
			["Response"] = "Level 300",
			["Result"] = true
		},
		{
			["Reply"] = "What else is needed?",
			["Response"] = "Be the ORIGINAL OWNER of 2 Megalodons",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v184, 1, {v185, v186})
v20.Ron = v184
local v187 = {}
local v188 = {
	["Dialogue"] = {
		{
			["Reply"] = "Who are you?",
			["Response"] = "An Indonesian legend",
			["Result"] = true
		},
		{
			["Reply"] = "[START QUEST]",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v187, 1, {v188})
v20["Aura Kid"] = v187
local v189 = {}
local v190 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Baits",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v189, 1, {v190})
v20.Seth = v189
local v191 = {}
local v192 = {
	["Dialogue"] = {
		{
			["Reply"] = "Any luck today?",
			["Response"] = "Nothing but Clownfish...",
			["Void"] = true
		},
		{
			["Reply"] = "Do you know where the Lava Fisherman is?",
			["Response"] = "I heard he was at Kohana Volcano",
			["Void"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v191, 1, {v192})
v20["Silly Fisherman"] = v191
local v193 = {}
local v194 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Battlepass",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v193, 1, {v194})
v20["Tour Guide"] = v193
local v195 = {}
local v196 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "How do I use this Altar?",
			["Response"] = "Sacrifice a SECRET fish for 1 Transcended Stone",
			["Void"] = true
		},
		{
			["Reply"] = "Transcended Stone?",
			["Response"] = "Allows you to apply a second rod enchant",
			["Void"] = true
		},
		{
			["Reply"] = "[Proceed]",
			["Response"] = "",
			["Path"] = 2
		},
		{
			["Reply"] = "[Exit]",
			["Response"] = "",
			["Void"] = true
		}
	},
	["IncludeExitDialogue"] = false
}
local v197 = {
	["Dialogue"] = {
		{
			["Reply"] = "[Exit]",
			["Response"] = "",
			["Void"] = true
		},
		{
			["Reply"] = "[Proceed]",
			["Response"] = "",
			["Path"] = 3
		}
	},
	["IncludeExitDialogue"] = false
}
local v198 = {
	["Dialogue"] = {
		{
			["Reply"] = "[Exit]",
			["Response"] = "",
			["Void"] = true
		},
		{
			["Reply"] = "DESTROY HELD SECRET FISH",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = false
}
__set_list(v195, 1, {v196, v197, v198})
v20["Temple Guardian"] = v195
local v199 = {}
local v200 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Boats",
			["Response"] = "",
			["Result"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v199, 1, {v200})
v20["Hallow Guardian"] = v199
local v201 = {}
local v202 = {
	["Dialogue"] = {
		{
			["Blocked"] = true,
			["Reply"] = "View Battlepass",
			["Response"] = "",
			["Result"] = true
		},
		{
			["Reply"] = "What is this place?",
			["Response"] = "This island has limited Halloween fish!",
			["Void"] = true
		},
		{
			["Reply"] = "[More Options]",
			["Response"] = "",
			["Path"] = 2
		}
	},
	["IncludeExitDialogue"] = false
}
local v203 = {
	["Dialogue"] = {
		{
			["Reply"] = "When does this event end?",
			["Response"] = function()
				return DateTime.fromUnixTimestamp(1762714800):FormatLocalTime("lll", "en-us")
			end,
			["Void"] = true
		}
	},
	["IncludeExitDialogue"] = true
}
__set_list(v201, 1, {v202, v203})
v20["Headless Horseman"] = v201
v20["Pumpkin Bandit"] = {
	{
		["Dialogue"] = {},
		["IncludeExitDialogue"] = true
	}
}
v20.Witch = {
	{
		["Dialogue"] = {},
		["IncludeExitDialogue"] = true
	}
}
v20["Zombified Doge"] = {
	{
		["Dialogue"] = {},
		["IncludeExitDialogue"] = true
	}
}
v20.Ghost = {
	{
		["Dialogue"] = {},
		["IncludeExitDialogue"] = true
	}
}
v20["Lead Scavenger Hunt Scientist"] = { function()
		-- upvalues: (copy) v_u_2, (copy) v_u_19
		local v204 = false
		local v205
		if v_u_2.Client:GetReplion("Data").Destroyed then
			v205 = true
		else
			local v206, v207 = v_u_19("Event", "Scavenger Hunt")
			v205 = (v206 or v207) and true or v204
		end
		return v205 and {
			["Dialogue"] = {
				{
					["Reply"] = "Who are you?",
					["Response"] = "I am the Lead Scavenger Hunt Scientist",
					["Result"] = true
				},
				{
					["Reply"] = "Leave",
					["Response"] = "",
					["Void"] = true
				}
			},
			["IncludeExitDialogue"] = true
		} or {
			["Dialogue"] = {
				{
					["Reply"] = "Who are you?",
					["Response"] = "I am the Lead Scavenger Hunt Scientist",
					["Result"] = true
				},
				{
					["Reply"] = "[START QUEST]",
					["Response"] = "You need to find 4 of the mechanical cores and you will be rewarded with star luck",
					["Result"] = true
				},
				{
					["Reply"] = "Leave",
					["Response"] = "",
					["Void"] = true
				}
			},
			["IncludeExitDialogue"] = true
		}
	end }
for _, v208 in pairs(v20) do
	for _, v209 in ipairs(v208) do
		if typeof(v209) == "table" and v209.IncludeExitDialogue then
			local v210 = v209.Dialogue
			table.insert(v210, {
				["Reply"] = "Leave",
				["Response"] = "",
				["Void"] = true
			})
		end
	end
end
return v20