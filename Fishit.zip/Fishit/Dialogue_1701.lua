-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("UserInputService")
game:GetService("ContextActionService")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("Players")
local v_u_5 = game:GetService("TweenService")
game:GetService("Lighting")
game:GetService("StarterGui")
local v_u_6 = v4.LocalPlayer
local v_u_7 = v_u_6:WaitForChild("PlayerGui"):WaitForChild("Quest")
local v_u_8 = workspace.CurrentCamera
local v_u_9 = require(v3.Packages.Signal)
local v_u_10 = require(v3.Packages.Trove)
local v_u_11 = require(v3.Packages.Thread)
local v12 = require(v3.Packages.Net)
local v_u_13 = require(v3.Packages.spr)
local v_u_14 = require(v3.Modules.GuiControl)
local v_u_15 = require(script.Parent.DialogueTree)
v12:RemoteFunction("SpecialDialogueEvent")
local v_u_16 = v12:RemoteEvent("DialogueEnded")
local v_u_17 = script.SelectionVisual
local v_u_18 = script.DialoguePrompt
local v_u_19 = v_u_18.Content.Inside.List.Option
v_u_19.Parent = nil
require(script.Parent.Types)
local v20 = v_u_9.new()
local v_u_21 = {}
local v_u_22 = {
	["CharsPerSecond"] = 45,
	["BubbleHideDelayAfterTyping"] = 2,
	["CameraTweenTime"] = 1.24,
	["CameraDistance"] = 12.4,
	["CameraHeight"] = 0.073
}
local v_u_23 = {
	["_activeInstance"] = nil
}
v_u_23.__index = v_u_23
v_u_23.PathSignal = v20
local function v_u_29(p24, p25, p26)
	-- upvalues: (copy) v_u_21
	for _, v27 in workspace.CurrentCamera:GetPartsObscuringTarget(p24, p25) do
		if not v_u_21[v27] then
			v_u_21[v27] = true
			v27.LocalTransparencyModifier = p26
			for _, v28 in v27:GetChildren() do
				if v28:IsA("Decal") or v28:IsA("Texture") then
					v28.LocalTransparencyModifier = p26
				end
			end
		end
	end
end
local function v_u_32()
	-- upvalues: (copy) v_u_21
	for v30 in v_u_21 do
		if v30 and v30.Parent then
			v30.LocalTransparencyModifier = 0
			for _, v31 in v30:GetChildren() do
				if v31:IsA("Decal") or v31:IsA("Texture") then
					v31.LocalTransparencyModifier = 0
				end
			end
		end
	end
	table.clear(v_u_21)
end
local function v_u_38(p33, p34)
	local v35 = p33:FindFirstChild("!!!FISHING_VIEW_MODEL!!!") or p33:FindFirstChild("!!!EQUIPPED_TOOL!!!")
	local v36 = {
		"ParticleEmitter",
		"Beam",
		"Trail",
		"PointLight",
		"SpotLight",
		"SurfaceLight"
	}
	if v35 then
		for _, v37 in v35:GetDescendants() do
			if v37:IsA("BasePart") then
				v37.LocalTransparencyModifier = p34 and 0 or 1
			elseif table.find(v36, v37.ClassName) then
				v37.Enabled = p34
			end
		end
	end
end
local function v_u_63(p_u_39)
	-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_22, (copy) v_u_5, (copy) v_u_7, (copy) v_u_1, (copy) v_u_29, (copy) v_u_38, (copy) v_u_32
	local v_u_40 = v_u_8.CameraType
	local v_u_41 = v_u_8.CFrame
	local v_u_42 = v_u_8.FieldOfView
	if v_u_40 == Enum.CameraType.Scriptable then
		v_u_40 = Enum.CameraType.Custom
	end
	v_u_8.CameraType = Enum.CameraType.Scriptable
	local v_u_43 = v_u_6.Character
	local v44
	if v_u_43 then
		v44 = v_u_43:FindFirstChild("HumanoidRootPart")
	else
		v44 = v_u_43
	end
	local v45 = p_u_39.Position
	local v46 = v_u_22.CameraHeight
	local v_u_47 = v45 + Vector3.new(0, v46, 0)
	if v44 then
		local v48 = v_u_47 - v44.Position
		if v48.Magnitude > 0.001 then
			local v49 = CFrame.new
			local v50 = v44.Position
			local v51 = v44.Position
			local v52 = v48.X
			local v53 = v48.Z
			v44.CFrame = v49(v50, v51 + Vector3.new(v52, 0, v53))
		end
	end
	local v54 = v_u_41.Position
	if v44 then
		local v55 = v44.CFrame.RightVector * 4.1 - v44.CFrame.LookVector * (v_u_22.CameraDistance * 0.35)
		v54 = v44.Position + v55 + Vector3.new(0, 2.05, 0)
	end
	v_u_5:Create(v_u_8, TweenInfo.new(v_u_22.CameraTweenTime, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
		["CFrame"] = CFrame.new(v54, v_u_47),
		["FieldOfView"] = 55
	}):Play()
	local v56 = p_u_39 and p_u_39.Parent
	if v56 then
		v56 = p_u_39:FindFirstChild((("Tag - %*"):format(p_u_39.Parent.Name)))
	end
	if v56 then
		v_u_5:Create(v56, TweenInfo.new(0.32, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = UDim2.new()
		}):Play()
	end
	local v57 = p_u_39 and p_u_39.Parent
	if v57 then
		v57 = p_u_39:FindFirstChild((("Tracker - %*"):format(p_u_39.Parent.Name)))
	end
	if v57 then
		for _, v58 in v57:GetChildren() do
			if v58:IsA("GuiObject") then
				v58.Visible = false
			end
		end
	end
	v_u_7.Enabled = false
	local v_u_59 = v_u_1.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_29, (copy) v_u_47, (ref) v_u_6, (copy) p_u_39
		v_u_29({ v_u_47 }, { v_u_6.Character, p_u_39.Parent }, 0.75)
	end)
	local v_u_60 = v_u_43.ChildAdded:Connect(function()
		-- upvalues: (ref) v_u_38, (copy) v_u_43
		v_u_38(v_u_43, false)
	end)
	v_u_38(v_u_43, false)
	return function()
		-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_22, (copy) v_u_41, (copy) v_u_42, (ref) v_u_40, (copy) v_u_59, (copy) v_u_60, (ref) v_u_32, (ref) v_u_38, (copy) v_u_43
		if v_u_8 then
			local v61 = {
				["CFrame"] = v_u_41,
				["FieldOfView"] = v_u_42
			}
			local v62 = v_u_5:Create(v_u_8, TweenInfo.new(v_u_22.CameraTweenTime / 4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), v61)
			v62:Play()
			v62.Completed:Wait()
			v_u_8.CameraType = v_u_40
		end
		if v_u_59 then
			v_u_59:Disconnect()
		end
		if v_u_60 then
			v_u_60:Disconnect()
		end
		v_u_32()
		v_u_38(v_u_43, true)
	end
end
local function v_u_69(p64, p65, p66)
	-- upvalues: (copy) v_u_22
	p65.MaxVisibleGraphemes = -1
	p65.Text = p66
	task.wait()
	p65.MaxVisibleGraphemes = 0
	p64._typing = true
	p64._skipTyping = false
	local v67 = v_u_22.CharsPerSecond
	local v68 = math.max(v67, 1)
	for _ in utf8.graphemes(p66) do
		if p64._skipTyping then
			p65.MaxVisibleGraphemes = -1
			break
		end
		p65.MaxVisibleGraphemes = p65.MaxVisibleGraphemes + 1
		task.wait(1 / v68)
	end
	p64._typing = false
end
function v_u_23.create(p70, p71, p72)
	-- upvalues: (copy) v_u_23, (copy) v_u_9, (copy) v_u_10, (copy) v_u_18, (copy) v_u_6, (copy) v_u_63, (copy) v_u_2, (copy) v_u_11, (copy) v_u_69
	if v_u_23._activeInstance then
		v_u_23._activeInstance:restoreCutscene()
		v_u_23._activeInstance._interrupted = true
		v_u_23._activeInstance:stop()
	end
	local v_u_73 = nil
	local v74 = v_u_23
	local v_u_75 = setmetatable({}, v74)
	v_u_23._activeInstance = v_u_75
	v_u_75.name = p70
	v_u_75.path = 1
	v_u_75.selecting = -1
	v_u_75.pivot = p72:GetPivot()
	v_u_75.animating = false
	v_u_75.dead = false
	v_u_75.selectionMade = false
	v_u_75.waitSignal = v_u_9.new()
	v_u_75._typing = false
	v_u_75._skipTyping = false
	v_u_75._speechGui = nil
	v_u_75._speechText = nil
	v_u_75._speechSeq = 0
	v_u_75._cutsceneRestored = false
	v_u_75._usedTypewriter = false
	v_u_75._interrupted = false
	v_u_75._pathSeq = 0
	v_u_75.cleaner = v_u_10.new()
	v_u_75.optionCleaner = v_u_75.cleaner:Extend()
	v_u_75.selectionCleaner = v_u_75.cleaner:Extend()
	v_u_75.basePart = p71
	v_u_75.instance = v_u_75.cleaner:Clone(v_u_18)
	v_u_75.instance.StudsOffset = Vector3.new(6, 0.5, 0)
	local v76 = p71:FindFirstChild((("Tag - %*"):format(v_u_75.name)))
	if v76 then
		v_u_75.overheadTag = v76
		v_u_75.overheadTagSize = v76.Size
	end
	local v77 = p72:FindFirstChild("Head")
	if v77 then
		v_u_75._speechGui = script.NPCSpeechBubble:Clone()
		if not v_u_75._speechGui then
			return
		end
		v_u_75._speechGui.Adornee = v77
		v_u_75._speechGui.Parent = v_u_6.PlayerGui
		local v78 = v_u_75._speechGui:FindFirstChild("Main")
		if v78 and v78:IsA("Frame") then
			local v_u_79 = v78:FindFirstChild("Title")
			if v_u_79 and v_u_79:IsA("TextLabel") then
				v_u_75._speechText = v_u_79
			end
			local v_u_80 = v78:FindFirstChild("Background")
			if v_u_80 and v_u_79 then
				v_u_75._speechTextBackground = v_u_80
				v_u_80.Size = UDim2.fromOffset(v_u_79.AbsoluteSize.X + 10, v_u_79.AbsoluteSize.Y)
				v_u_79:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
					-- upvalues: (copy) v_u_80, (copy) v_u_79
					v_u_80.Size = UDim2.fromOffset(v_u_79.AbsoluteSize.X + 10, v_u_79.AbsoluteSize.Y)
				end)
			end
		end
	end
	local v81 = v_u_6.Character
	local v82
	if v81 then
		local v_u_83 = v81:FindFirstChildOfClass("Humanoid")
		if v_u_83 then
			local v_u_84 = v_u_83.WalkSpeed
			local v_u_85 = v_u_83.JumpPower
			v_u_83.WalkSpeed = 0
			v_u_83.JumpPower = 0
			v82 = function()
				-- upvalues: (copy) v_u_83, (copy) v_u_84, (copy) v_u_85
				if v_u_83.Parent then
					v_u_83.WalkSpeed = v_u_84
					v_u_83.JumpPower = v_u_85
				end
			end
		else
			v82 = nil
		end
	else
		v82 = nil
	end
	v_u_75._unlockMovement = v82
	if v77 then
		local v_u_86 = v_u_63(v77) or function() end
		function v_u_75._restoreCamera()
			-- upvalues: (copy) v_u_86
			v_u_86()
		end
	end
	v_u_75.cleaner:Add(v_u_2.InputBegan:Connect(function(p87, p88)
		-- upvalues: (copy) v_u_75
		if not p88 then
			if (p87.UserInputType == Enum.UserInputType.MouseButton1 or p87.KeyCode == Enum.KeyCode.Space) and v_u_75._typing then
				v_u_75._skipTyping = true
			end
		end
	end))
	v_u_73 = v_u_75.cleaner:Add(v_u_11:Execute(60, function()
		-- upvalues: (ref) v_u_6, (copy) v_u_75, (ref) v_u_69, (ref) v_u_73
		local v89 = v_u_6.Character
		local v90
		if v89 then
			v90 = (v89:GetPivot().Position - v_u_75.pivot.Position).Magnitude >= 20
		else
			v90 = false
		end
		if v90 then
			if v_u_75._speechText then
				local v91 = v_u_75
				v91._speechSeq = v91._speechSeq + 1
				local v92 = v_u_75._speechSeq
				v_u_75._speechText.TextTransparency = 0
				v_u_75._speechText.Text = ""
				v_u_75._usedTypewriter = true
				v_u_69(v_u_75, v_u_75._speechText, "You walked away!")
				v_u_75:endCutsceneAfterSpeech(v92)
			end
			if v_u_73 then
				v_u_75.cleaner:Remove(v_u_73)
			end
			v_u_75:stop()
		end
	end))
	v_u_75:populate()
	if v_u_75.instance then
		v_u_75.instance.Adornee = v_u_75.basePart
		v_u_75.instance.Parent = v_u_6.PlayerGui
	end
	return v_u_75
end
function v_u_23.undoSelect(p93)
	p93.selecting = -1
	p93.selectionCleaner:Clean()
end
function v_u_23.select(p94, p95, _)
	-- upvalues: (copy) v_u_17, (copy) v_u_13
	if p94.selecting == p95 then
		return
	else
		local _ = p94.selectionMade
		if not p94.dead then
			p94.selectionMade = true
			p94.selecting = p95
			p94.selectionCleaner:Clean()
			local v96 = p94.instance.Content.Inside.List:FindFirstChild((tostring(p95)))
			if v96 then
				local v97 = p94.selectionCleaner:Clone(v_u_17)
				local v_u_98 = v96.Shadow
				local v_u_99 = v96.BG
				v_u_13.stop(v_u_98)
				v_u_13.stop(v_u_99)
				v_u_13.target(v_u_99, 1, 3, {
					["BackgroundTransparency"] = 0.2
				})
				v_u_13.target(v_u_98, 1, 3, {
					["ImageTransparency"] = 0.5
				})
				p94.selectionCleaner:Add(function()
					-- upvalues: (ref) v_u_13, (copy) v_u_98, (copy) v_u_99
					v_u_13.stop(v_u_98)
					v_u_13.stop(v_u_99)
					v_u_13.target(v_u_99, 1, 3, {
						["BackgroundTransparency"] = 0.3
					})
					v_u_13.target(v_u_98, 1, 3, {
						["ImageTransparency"] = 1
					})
				end)
				v97.Parent = v96.Items
			end
			p94.selectionMade = false
		end
	end
end
function v_u_23.confirmSelection(p_u_100, p_u_101, p_u_102, p103)
	-- upvalues: (copy) v_u_16, (copy) v_u_23, (copy) v_u_69
	local _ = p_u_100.selectionMade
	p_u_100.selectionMade = true
	if p103 and p103.FinishedCallback then
		task.spawn(p103.FinishedCallback)
	end
	task.defer(function()
		-- upvalues: (ref) v_u_16, (copy) p_u_100, (copy) p_u_101, (copy) p_u_102, (ref) v_u_23
		v_u_16:FireServer(p_u_100.name, p_u_101, p_u_102)
		v_u_23.PathSignal:Fire(p_u_100.name, p_u_101, p_u_102)
	end)
	local v104 = nil
	local v105 = p103.Response
	if typeof(v105) == "function" then
		v105 = v105()
	elseif typeof(v105) ~= "string" then
		v105 = v104
	end
	if typeof(v105) == "string" and (string.len(v105) > 0 and p_u_100._speechText) then
		p_u_100._speechText.TextTransparency = 0
		p_u_100._speechText.Text = ""
		local v106 = p_u_100._speechTextBackground
		local v107 = p_u_100._speechText
		if v106 and v107 then
			v106.BackgroundTransparency = script.NPCSpeechBubble.Main.Background.BackgroundTransparency
			local v108 = v107:FindFirstChildOfClass("UIStroke")
			if v108 then
				v108.Transparency = script.NPCSpeechBubble.Main.Title.UIStroke.Transparency
			end
		end
		p_u_100._speechSeq = p_u_100._speechSeq + 1
		local v109 = p_u_100._speechSeq
		p_u_100._usedTypewriter = true
		v_u_69(p_u_100, p_u_100._speechText, v105)
		p_u_100:endCutsceneAfterSpeech(v109)
	end
	if p103.Result then
		p_u_100:stop(p103.Result)
		return
	elseif p103.Void then
		p_u_100:stop()
		return
	elseif p103.Path then
		p_u_100:next(p103.Path)
	else
		p_u_100:stop()
	end
end
function v_u_23.populate(p_u_110)
	-- upvalues: (copy) v_u_15, (copy) v_u_19, (copy) v_u_14
	p_u_110.optionCleaner:Clean()
	p_u_110:undoSelect()
	local v111 = v_u_15[p_u_110.name]
	if v111 then
		local v_u_112 = p_u_110.path
		local v113 = v111[v_u_112]
		if v113 then
			local v114 = nil
			if typeof(v113) == "function" then
				v113 = v113()
			elseif typeof(v113) ~= "table" then
				v113 = v114
			end
			if v113 then
				local v115 = p_u_110.instance
				local v_u_116 = v115.Content.Inside.List
				v115.StudsOffset = Vector3.new(6, -1.5, 0)
				local v117 = #v113.Dialogue / 2
				local v118 = math.max(v117, 1)
				v115.Size = UDim2.new(v118 * 5 + 2.4, 0, v118 * 2.2 + 1.2, 0)
				local v119 = 1 / #v113.Dialogue
				local v120 = math.min(v119, 0.5)
				v_u_116.UIGridLayout.CellSize = UDim2.fromScale(1, v120)
				local function v125(p_u_121, p_u_122)
					-- upvalues: (copy) p_u_110, (ref) v_u_19, (ref) v_u_14, (copy) v_u_112, (copy) v_u_116
					local v123 = tostring(p_u_121)
					local v_u_124 = p_u_110.optionCleaner:Clone(v_u_19)
					v_u_124.Name = v123
					v_u_124.Items.QuestLabel.Text = p_u_122.Reply
					v_u_14:Hook("Hold Button", v_u_124, v_u_124.Items, 1, p_u_110.optionCleaner).Clicked:Connect(function()
						-- upvalues: (copy) v_u_124, (ref) p_u_110, (copy) p_u_121, (copy) p_u_122, (ref) v_u_112
						v_u_124.Active = false
						if p_u_110.selecting ~= p_u_121 then
							p_u_110:select(p_u_121, p_u_122)
						end
						p_u_110:confirmSelection(v_u_112, p_u_121, p_u_122)
						v_u_124.Active = true
					end)
					p_u_110.optionCleaner:Add(v_u_124.MouseEnter:Connect(function()
						-- upvalues: (ref) p_u_110, (copy) p_u_121, (copy) p_u_122
						p_u_110:select(p_u_121, p_u_122)
					end))
					v_u_124.Parent = v_u_116
				end
				local v126 = {}
				for v127, v128 in v113.Dialogue do
					v125(v127, v128)
				end
				table.clear(v126)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_23.next(p129, p130)
	-- upvalues: (copy) v_u_15
	p129._pathSeq = p129._pathSeq + 1
	local v131 = v_u_15[p129.name]
	if v131 then
		local v132 = v131[p129.path]
		if v132 then
			local v133 = nil
			if typeof(v132) == "function" then
				v132 = v132()
			elseif typeof(v132) ~= "table" then
				v132 = v133
			end
			if v132 then
				if not p129.animating then
					p129.animating = true
					local v134 = p129.instance.Content.Inside.List
					for v135, _ in v132.Dialogue do
						local v136 = v134:FindFirstChild((tostring(v135)))
						if v136 then
							v136:Destroy()
						end
					end
					p129.path = p130
					p129:populate()
					p129.animating = false
					p129.selectionMade = false
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
function v_u_23.stop(p137, p138)
	if not p137.animating then
		p137.animating = true
		if p137.restoreCutscene then
			p137:restoreCutscene()
		end
		if p138 == nil then
			p137.waitSignal:Fire(false)
		else
			p137.waitSignal:Fire(p138)
		end
		p137:destroy()
	end
end
function v_u_23.restoreCutscene(p139)
	-- upvalues: (copy) v_u_7, (copy) v_u_5
	if not p139._cutsceneRestored then
		p139._cutsceneRestored = true
		if p139._restoreCamera then
			p139._restoreCamera()
			p139._restoreCamera = nil
		end
		if p139._unlockMovement then
			p139._unlockMovement()
			p139._unlockMovement = nil
		end
		v_u_7.Enabled = true
		if p139.overheadTag then
			v_u_5:Create(p139.overheadTag, TweenInfo.new(0.32, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Size"] = p139.overheadTagSize
			}):Play()
		end
		local v140 = p139.basePart
		if v140 then
			v140 = p139.basePart:FindFirstChild((("Tracker - %*"):format(p139.name)))
		end
		if v140 then
			for _, v141 in v140:GetChildren() do
				if v141:IsA("GuiObject") then
					v141.Visible = true
				end
			end
		end
	end
end
function v_u_23.endCutsceneAfterSpeech(p_u_142, p_u_143)
	-- upvalues: (copy) v_u_22, (copy) v_u_5
	task.spawn(function()
		-- upvalues: (copy) p_u_142, (copy) p_u_143, (ref) v_u_22, (ref) v_u_5
		while p_u_142._typing and p_u_142._speechSeq == p_u_143 do
			task.wait()
		end
		if p_u_142._speechSeq == p_u_143 then
			local v144 = v_u_22.BubbleHideDelayAfterTyping
			if v144 and v144 > 0 then
				task.wait(v144)
			end
			if p_u_142._speechSeq == p_u_143 then
				local v145 = p_u_142._speechGui
				local v146 = p_u_142._speechText
				if v145 and v146 then
					local v147 = v145:FindFirstChild("Main")
					if v147 then
						v147 = v147:FindFirstChild("Background")
					end
					if v147 then
						v_u_5:Create(v147, TweenInfo.new(0.15), {
							["BackgroundTransparency"] = 1
						}):Play()
					end
					v_u_5:Create(v146, TweenInfo.new(0.15), {
						["TextTransparency"] = 1
					}):Play()
					local v148 = v146:FindFirstChildOfClass("UIStroke")
					if v148 then
						v_u_5:Create(v148, TweenInfo.new(0.15), {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.2)
				end
			end
		else
			return
		end
	end)
end
function v_u_23.wait(p149)
	return p149.waitSignal:Wait()
end
function v_u_23.onDestroyed(p150, p151)
	p150.cleaner:Add(p151)
end
function v_u_23.destroy(p152)
	if not p152.dead then
		p152.dead = true
		p152.cleaner:Destroy()
		p152.waitSignal:DisconnectAll()
		p152.waitSignal:Destroy()
		p152.basePart = nil
		p152.instance = nil
		if p152._speechSeq == 0 and p152._speechGui then
			p152._speechGui:Destroy()
			p152._speechGui = nil
			p152._speechText = nil
			p152._speechTextSize = nil
		end
	end
end
return v_u_23