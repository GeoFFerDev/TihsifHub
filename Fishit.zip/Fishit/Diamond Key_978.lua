-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Data"] = {
		["Id"] = 574,
		["Type"] = "Gears",
		["Name"] = "Diamond Key",
		["Description"] = "Might be useful for a cellar door",
		["Icon"] = "rbxassetid://109411513980912",
		["Tier"] = 5
	},
	["TradeLocked"] = true,
	["_moduleScript"] = script
}
return v1