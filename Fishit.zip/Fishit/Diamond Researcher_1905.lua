-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v2 = require(v1.Shared.RewardInfo)
local v3 = {
	["Description"] = "Help Lary the Scientist complete his research to receive the Diamond Rod",
	["AssociatedTier"] = 7
}
local v4 = {}
local v5 = {
	["Id"] = 2,
	["Name"] = "Catch a SECRET fish at Coral Reefs",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 7,
		["Location"] = "Coral Reefs"
	}
}
local v6 = {
	["Id"] = 3,
	["Name"] = "Catch a SECRET fish at Tropical Grove",
	["Goal"] = 1,
	["Type"] = "Catch",
	["Requirements"] = {
		["Tier"] = 7,
		["Location"] = "Tropical Grove"
	}
}
local v7 = {
	["Id"] = 4,
	["Name"] = "Bring Lary a mutated Gemstone Ruby",
	["Goal"] = 1,
	["Type"] = "Exchange"
}
local v8 = {
	["Id"] = 243,
	["Metadata"] = {
		["VariantId"] = 3
	}
}
v7.Requirements = v8
v7.AssociatedItem = "Ruby"
v7.AssociatedType = "Fish"
local v9 = {
	["Id"] = 5,
	["Name"] = "Bring Lary a Lochness Monster",
	["Goal"] = 1,
	["Type"] = "Exchange",
	["Requirements"] = {
		["Id"] = 228
	},
	["AssociatedItem"] = "Lochness Monster",
	["AssociatedType"] = "Fish"
}
local v10 = {
	["Id"] = 6,
	["Name"] = "Catch 1,000 fish while using PERFECT! throw",
	["Goal"] = 1000,
	["Type"] = "Catch",
	["Requirements"] = {
		["EffectIndex"] = 5
	}
}
__set_list(v4, 1, {{
	["Id"] = 1,
	["Name"] = "Own an Element Rod",
	["Goal"] = 1,
	["Type"] = "ElementRodOwner",
	["Reconcile"] = true,
	["AssociatedItem"] = "Element Rod",
	["AssociatedType"] = "Fishing Rods"
}, v5, v6, v7, v9, v10})
v3.Objectives = v4
v3.Reward = v2.itemReward("Diamond Key")
return v3